import React, { useMemo } from 'react';
import {
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  FolderKanban,
  Building,
  Eye,
  Sparkles,
  Mail,
  ShieldCheck,
  BookOpen,
  Package,
  Plus,
  MessageSquareWarning,
  FileEdit
} from 'lucide-react';
import {
  Department,
  Project,
  Publication,
  Product,
  SiteHealthItem,
  FormSubmission,
  ActivityRecord,
  SiteSettings,
  User,
  RoleDefinition
} from '../../../types';
import { can } from '../../../shared/permissions';
import { splitOrgUnits } from '../../../utils/orgHelpers';
import { CreateActionType, getVisibleCreateActions } from '../portalRegistry';
import {
  PortalEmptyState,
  PortalPageHeader,
  PortalSection,
  PortalStatusBadge
} from '../ui';

interface OverviewTabProps {
  currentUser: User;
  roles?: RoleDefinition[];
  departments: Department[];
  projects: Project[];
  publications?: Publication[];
  products?: Product[];
  healthWarnings: SiteHealthItem[];
  submissions: FormSubmission[];
  activityLog: ActivityRecord[];
  settings?: SiteSettings;
  onNavigateTab: (
    tab: string,
    subTab?: string,
    id?: string,
    kind?: 'projects' | 'publications' | 'products' | 'departments',
    drawerTab?: string
  ) => void;
  onCreateAction?: (actionType: CreateActionType) => void;
  onNavigateSite: () => void;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({
  currentUser,
  roles,
  departments,
  projects,
  publications = [],
  products = [],
  healthWarnings,
  submissions,
  activityLog,
  onNavigateTab,
  onCreateAction,
  onNavigateSite
}) => {
  const canEditSite = can(currentUser, 'website.edit', roles);
  const canManageDepts = can(currentUser, 'departments.manage', roles);
  const canEditAllProjects = can(currentUser, 'projects.editAll', roles);
  const canPublish = can(currentUser, 'projects.publish', roles);
  const canViewInbox = can(currentUser, 'inbox.view', roles);
  const canViewAudit = can(currentUser, 'audit.view', roles);
  const canManageSettings = can(currentUser, 'settings.manage', roles);
  const canViewHealth =
    canViewAudit ||
    canManageSettings ||
    can(currentUser, 'website.edit', roles) ||
    can(currentUser, 'pages.manage', roles) ||
    can(currentUser, 'seo.manage', roles);

  const isPrivilegedOverview =
    canEditSite ||
    canManageDepts ||
    canEditAllProjects ||
    canPublish ||
    canManageSettings ||
    canViewAudit ||
    canViewInbox ||
    canViewHealth;

  const activeDepts = useMemo(() => departments.filter(d => !d.deletedAt), [departments]);
  const { departments: deptUnits, sectors: sectorUnits } = useMemo(
    () => splitOrgUnits(activeDepts),
    [activeDepts]
  );
  const publishedDeptUnits = useMemo(() => deptUnits.filter(d => d.published), [deptUnits]);
  const activeProjects = useMemo(() => projects.filter(p => !p.deletedAt), [projects]);
  const activePubs = useMemo(() => publications.filter(p => !p.deletedAt), [publications]);
  const activeProds = useMemo(() => products.filter(p => !p.deletedAt), [products]);

  const publishedProjects = activeProjects.filter(p => p.publicationStatus === 'Published');
  const pendingReviews = [
    ...activeProjects.filter(p => p.publicationStatus === 'Pending Review'),
    ...activePubs.filter(p => p.publicationStatus === 'Pending Review'),
    ...activeProds.filter(p => p.publicationStatus === 'Pending Review')
  ];
  const draftProjects = activeProjects.filter(p => p.publicationStatus === 'Draft');
  const newSubmissionsCount = submissions.filter(s => s.status === 'new').length;

  const myDrafts = useMemo(() => {
    const mine: Array<{
      kind: 'projects' | 'publications' | 'products';
      id: string;
      title: string;
      updatedAt: string;
    }> = [];
    activeProjects
      .filter(p => p.authorId === currentUser.id && p.publicationStatus === 'Draft')
      .forEach(p =>
        mine.push({ kind: 'projects', id: p.id, title: p.title, updatedAt: p.updatedAt || p.createdAt })
      );
    activePubs
      .filter(p => p.authorId === currentUser.id && p.publicationStatus === 'Draft')
      .forEach(p =>
        mine.push({ kind: 'publications', id: p.id, title: p.title, updatedAt: p.updatedAt || p.createdAt })
      );
    activeProds
      .filter(p => p.authorId === currentUser.id && p.publicationStatus === 'Draft')
      .forEach(p =>
        mine.push({ kind: 'products', id: p.id, title: p.name, updatedAt: p.updatedAt || p.createdAt })
      );
    return mine.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }, [activeProjects, activePubs, activeProds, currentUser.id]);

  const myPending = useMemo(() => {
    return [
      ...activeProjects
        .filter(p => p.authorId === currentUser.id && p.publicationStatus === 'Pending Review')
        .map(p => ({ kind: 'projects' as const, id: p.id, title: p.title, updatedAt: p.updatedAt || p.createdAt })),
      ...activePubs
        .filter(p => p.authorId === currentUser.id && p.publicationStatus === 'Pending Review')
        .map(p => ({ kind: 'publications' as const, id: p.id, title: p.title, updatedAt: p.updatedAt || p.createdAt })),
      ...activeProds
        .filter(p => p.authorId === currentUser.id && p.publicationStatus === 'Pending Review')
        .map(p => ({ kind: 'products' as const, id: p.id, title: p.name, updatedAt: p.updatedAt || p.createdAt }))
    ];
  }, [activeProjects, activePubs, activeProds, currentUser.id]);

  const myFeedbackItems = useMemo(() => {
    const items: Array<{
      kind: 'projects' | 'publications' | 'products';
      id: string;
      title: string;
      comment: string;
    }> = [];
    activeProjects
      .filter(p => p.authorId === currentUser.id && p.reviewComment)
      .forEach(p => items.push({ kind: 'projects', id: p.id, title: p.title, comment: p.reviewComment || '' }));
    activePubs
      .filter(p => p.authorId === currentUser.id && p.reviewComment)
      .forEach(p => items.push({ kind: 'publications', id: p.id, title: p.title, comment: p.reviewComment || '' }));
    activeProds
      .filter(p => p.authorId === currentUser.id && p.reviewComment)
      .forEach(p => items.push({ kind: 'products', id: p.id, title: p.name, comment: p.reviewComment || '' }));
    return items;
  }, [activeProjects, activePubs, activeProds, currentUser.id]);

  const myPublishedCount =
    activeProjects.filter(p => p.authorId === currentUser.id && p.publicationStatus === 'Published').length +
    activePubs.filter(p => p.authorId === currentUser.id && p.publicationStatus === 'Published').length +
    activeProds.filter(p => p.authorId === currentUser.id && p.publicationStatus === 'Published').length;

  const myRecentActivity = useMemo(
    () =>
      activityLog
        .filter(a => a.userId === currentUser.id || a.userEmail === currentUser.email)
        .slice(0, 6),
    [activityLog, currentUser.id, currentUser.email]
  );

  const visibleCreateActions = useMemo(
    () => getVisibleCreateActions(currentUser, roles),
    [currentUser, roles]
  );

  const firstName = currentUser?.name?.split(' ')[0] || 'Contributor';

  if (!isPrivilegedOverview) {
    return (
      <div className="space-y-6">
        <PortalPageHeader
          title={`Welcome back, ${firstName}`}
          titleClassName="text-2xl sm:text-3xl font-extrabold font-display tracking-tight text-[#EDE9E0]"
          subtitle="Manage your drafts, track review feedback, and submit projects, publications, or products."
          actions={
            <>
              <button
                type="button"
                onClick={onNavigateSite}
                className="h-9 px-3.5 rounded-xl bg-[#031D1C] hover:bg-white/10 border border-white/12 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer"
              >
                <Eye className="w-3.5 h-3.5 text-[#25CDB6] shrink-0" />
                <span>View Live Site</span>
              </button>

              {visibleCreateActions.slice(0, 2).map(action => (
                <button
                  key={action.id}
                  type="button"
                  onClick={() =>
                    onCreateAction
                      ? onCreateAction(action.id)
                      : onNavigateTab(action.targetTab, action.targetSubTab)
                  }
                  className="h-9 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] text-xs font-bold inline-flex items-center gap-1.5 shadow-sm whitespace-nowrap transition-colors cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5 stroke-[2.5] shrink-0" />
                  <span>{action.label}</span>
                </button>
              ))}
            </>
          }
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            type="button"
            onClick={() => onNavigateTab('content', 'projects')}
            className="text-left p-5 rounded-2xl bg-[#031D1C] border border-white/10 hover:border-[#25CDB6]/40 transition-colors cursor-pointer space-y-2"
          >
            <div className="flex items-center justify-between text-xs text-[#EDE9E0]/65">
              <span className="font-semibold">My Drafts</span>
              <FileEdit className="w-4 h-4 text-[#25CDB6]" />
            </div>
            <div className="text-3xl font-extrabold text-[#EDE9E0] font-mono tabular-nums">
              {myDrafts.length}
            </div>
            <div className="text-[11px] text-[#EDE9E0]/50">In progress</div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('content', 'projects')}
            className="text-left p-5 rounded-2xl bg-[#031D1C] border border-white/10 hover:border-[#25CDB6]/40 transition-colors cursor-pointer space-y-2"
          >
            <div className="flex items-center justify-between text-xs text-[#EDE9E0]/65">
              <span className="font-semibold">Pending Review</span>
              <Clock className="w-4 h-4 text-[#D0A873]" />
            </div>
            <div className="text-3xl font-extrabold text-[#D0A873] font-mono tabular-nums">
              {myPending.length}
            </div>
            <div className="text-[11px] text-[#EDE9E0]/50">Awaiting approval</div>
          </button>

          <div className="p-5 rounded-2xl bg-[#031D1C] border border-white/10 space-y-2">
            <div className="flex items-center justify-between text-xs text-[#EDE9E0]/65">
              <span className="font-semibold">Reviewer Feedback</span>
              <MessageSquareWarning className="w-4 h-4 text-[#CA7952]" />
            </div>
            <div className="text-3xl font-extrabold text-[#CA7952] font-mono tabular-nums">
              {myFeedbackItems.length}
            </div>
            <div className="text-[11px] text-[#EDE9E0]/50">Items with notes</div>
          </div>

          <div className="p-5 rounded-2xl bg-[#031D1C] border border-white/10 space-y-2">
            <div className="flex items-center justify-between text-xs text-[#EDE9E0]/65">
              <span className="font-semibold">Published by Me</span>
              <CheckCircle2 className="w-4 h-4 text-[#25CDB6]" />
            </div>
            <div className="text-3xl font-extrabold text-[#25CDB6] font-mono tabular-nums">
              {myPublishedCount}
            </div>
            <div className="text-[11px] text-[#EDE9E0]/50">Live across MoA</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <PortalSection
            title="My Drafts & Submissions"
            description="Jump back into active drafts or pending review entries."
          >
            {myDrafts.length === 0 && myPending.length === 0 ? (
              <PortalEmptyState
                compact
                icon={FileEdit}
                title="No active drafts"
                description="You have no drafts or pending reviews yet."
              />
            ) : (
              <div className="space-y-2.5">
                {[
                  ...myPending.map(x => ({ ...x, status: 'Pending Review' as const })),
                  ...myDrafts.map(x => ({ ...x, status: 'Draft' as const }))
                ]
                  .slice(0, 6)
                  .map(item => (
                    <button
                      key={`${item.kind}-${item.id}`}
                      type="button"
                      onClick={() => onNavigateTab('content', item.kind, item.id, item.kind)}
                      className="w-full text-left p-3.5 rounded-xl bg-[#06302F]/80 hover:bg-[#06302F] border border-white/10 hover:border-[#25CDB6]/40 flex items-center justify-between gap-4 transition-colors cursor-pointer"
                    >
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-[#EDE9E0] truncate">{item.title}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-[11px] text-[#EDE9E0]/55 capitalize">{item.kind}</span>
                          <PortalStatusBadge status={item.status} />
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-[#EDE9E0]/40 shrink-0" />
                    </button>
                  ))}
              </div>
            )}
          </PortalSection>

          <PortalSection
            title="Reviewer Feedback"
            description="Editorial notes and your latest workspace activity."
          >
            {myFeedbackItems.length === 0 ? (
              <PortalEmptyState
                compact
                icon={MessageSquareWarning}
                title="No reviewer notes"
                description="Editorial feedback on your submissions will appear here."
              />
            ) : (
              <div className="space-y-2.5">
                {myFeedbackItems.map(item => (
                  <button
                    key={`${item.kind}-${item.id}`}
                    type="button"
                    onClick={() => onNavigateTab('content', item.kind, item.id, item.kind)}
                    className="w-full text-left p-3.5 rounded-xl bg-[#CA7952]/10 border border-[#CA7952]/30 space-y-1 cursor-pointer hover:border-[#CA7952]/60 transition-colors"
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-[#EDE9E0]">
                      <span>{item.title}</span>
                      <span className="text-[10px] font-mono uppercase text-[#CA7952]">{item.kind}</span>
                    </div>
                    <p className="text-[11px] text-[#EDE9E0]/75 leading-relaxed">{item.comment}</p>
                  </button>
                ))}
              </div>
            )}

            {myRecentActivity.length > 0 && (
              <div className="pt-4 mt-4 border-t border-white/10 space-y-2">
                <h4 className="text-[11px] font-bold uppercase tracking-wider text-[#EDE9E0]/50 font-mono">
                  Recent Activity
                </h4>
                {myRecentActivity.map(act => (
                  <div
                    key={act.id}
                    className="text-[11px] text-[#EDE9E0]/70 flex items-center justify-between gap-2"
                  >
                    <span className="truncate">{act.action}</span>
                    <span className="text-[10px] font-mono text-[#EDE9E0]/45 shrink-0 tabular-nums">
                      {new Date(act.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </PortalSection>
        </div>
      </div>
    );
  }

  const getDeptCompleteness = (dept: Department) => {
    let score = 0;
    if (dept.name) score += 20;
    if (dept.introduction && dept.introduction.length > 20) score += 20;
    if (dept.purpose && dept.purpose.length > 20) score += 20;
    if (dept.mission && dept.mission.length > 20) score += 20;
    if (dept.areasOfFocus && dept.areasOfFocus.length > 0) score += 20;
    return score;
  };

  const continueEditingItems = [
    ...activeProjects.map(p => ({
      kind: 'projects' as const,
      id: p.id,
      title: p.title,
      meta: p.category || 'Innovation',
      publicationStatus: p.publicationStatus,
      updatedAt: p.updatedAt || p.createdAt
    })),
    ...activePubs.map(p => ({
      kind: 'publications' as const,
      id: p.id,
      title: p.title,
      meta: p.publicationType || 'Publication',
      publicationStatus: p.publicationStatus,
      updatedAt: p.updatedAt || p.createdAt
    })),
    ...activeProds.map(p => ({
      kind: 'products' as const,
      id: p.id,
      title: p.name,
      meta: p.category || 'Product',
      publicationStatus: p.publicationStatus,
      updatedAt: p.updatedAt || p.createdAt
    }))
  ]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 4);

  return (
    <div className="space-y-6">
      <PortalPageHeader
        title={`Welcome back, ${firstName}`}
        titleClassName="text-2xl sm:text-3xl font-extrabold font-display tracking-tight text-[#EDE9E0]"
        subtitle={`${pendingReviews.length} item${pendingReviews.length === 1 ? '' : 's'} pending editorial review${
          canViewInbox
            ? ` · ${newSubmissionsCount} new ${newSubmissionsCount === 1 ? 'inquiry' : 'inquiries'}`
            : ''
        }.`}
        actions={
          <>
            <button
              type="button"
              onClick={onNavigateSite}
              className="h-9 px-3.5 rounded-xl bg-[#031D1C] hover:bg-white/10 border border-white/12 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 whitespace-nowrap transition-colors cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5 text-[#25CDB6] shrink-0" />
              <span>View Live Site</span>
            </button>

            {canEditSite && (
              <button
                type="button"
                onClick={() => onNavigateTab('website', 'pages')}
                className="h-9 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] text-xs font-bold inline-flex items-center gap-1.5 shadow-sm whitespace-nowrap transition-colors cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 shrink-0" />
                <span>Manage Website</span>
              </button>
            )}
          </>
        }
      />

      {/* Metric Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          type="button"
          onClick={() => onNavigateTab('content', 'projects')}
          className="text-left p-5 rounded-2xl bg-[#031D1C] border border-white/10 hover:border-[#25CDB6]/40 transition-colors cursor-pointer space-y-3"
        >
          <div className="flex items-center justify-between text-xs text-[#EDE9E0]/65">
            <span className="font-semibold">Projects Pipeline</span>
            <FolderKanban className="w-4 h-4 text-[#25CDB6]" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-[#EDE9E0] tracking-tight tabular-nums font-mono">
              {activeProjects.length}
            </span>
            <span className="text-xs text-[#25CDB6] font-semibold tabular-nums">
              {publishedProjects.length} live
            </span>
          </div>
          <div className="flex gap-1 h-1.5 rounded-full overflow-hidden bg-white/5">
            <div
              style={{ width: `${(publishedProjects.length / (activeProjects.length || 1)) * 100}%` }}
              className="bg-[#25CDB6]"
              title="Published"
            />
            <div
              style={{
                width: `${(activeProjects.filter(p => p.publicationStatus === 'Pending Review').length / (activeProjects.length || 1)) * 100}%`
              }}
              className="bg-[#D0A873]"
              title="In Review"
            />
            <div
              style={{ width: `${(draftProjects.length / (activeProjects.length || 1)) * 100}%` }}
              className="bg-white/20"
              title="Draft"
            />
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigateTab('content', 'publications')}
          className="text-left p-5 rounded-2xl bg-[#031D1C] border border-white/10 hover:border-[#25CDB6]/40 transition-colors cursor-pointer space-y-3"
        >
          <div className="flex items-center justify-between text-xs text-[#EDE9E0]/65">
            <span className="font-semibold">Publications &amp; Products</span>
            <div className="flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-[#D0A873]" />
              <Package className="w-4 h-4 text-[#64B5D9]" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-[#EDE9E0] tracking-tight tabular-nums font-mono">
              {activePubs.length + activeProds.length}
            </span>
            <span className="text-xs text-[#25CDB6] font-semibold tabular-nums">
              {activePubs.filter(p => p.publicationStatus === 'Published').length} pubs ·{' '}
              {activeProds.filter(p => p.publicationStatus === 'Published').length} products
            </span>
          </div>
          <div className="text-[11px] text-[#EDE9E0]/55 truncate tabular-nums">
            {activePubs.length} papers · {activeProds.length} products total
          </div>
        </button>

        <button
          type="button"
          onClick={() => onNavigateTab('content', 'departments')}
          className="text-left p-5 rounded-2xl bg-[#031D1C] border border-white/10 hover:border-[#25CDB6]/40 transition-colors cursor-pointer space-y-3"
        >
          <div className="flex items-center justify-between text-xs text-[#EDE9E0]/65">
            <span className="font-semibold">Active Departments</span>
            <Building className="w-4 h-4 text-[#D0A873]" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-[#EDE9E0] tracking-tight tabular-nums font-mono">
              {publishedDeptUnits.length}
            </span>
            <span className="text-xs text-[#EDE9E0]/55 font-semibold tabular-nums">
              of {deptUnits.length} published
            </span>
          </div>
          <div className="text-[11px] text-[#EDE9E0]/55 truncate tabular-nums">
            Departments {deptUnits.length} · Sectors {sectorUnits.length}
          </div>
        </button>

        {canViewInbox ? (
          <button
            type="button"
            onClick={() => onNavigateTab('settings', 'inbox')}
            className="text-left p-5 rounded-2xl bg-[#031D1C] border border-white/10 hover:border-[#25CDB6]/40 transition-colors cursor-pointer space-y-3"
          >
            <div className="flex items-center justify-between text-xs text-[#EDE9E0]/65">
              <span className="font-semibold">Contact Inquiries</span>
              <Mail className="w-4 h-4 text-[#64B5D9]" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-[#EDE9E0] tracking-tight tabular-nums font-mono">
                {submissions.length}
              </span>
              {newSubmissionsCount > 0 && (
                <PortalStatusBadge
                  status="In review"
                  labelOverride={`${newSubmissionsCount} new`}
                />
              )}
            </div>
            <div className="text-[11px] text-[#EDE9E0]/55">Direct private inbox</div>
          </button>
        ) : (
          <button
            type="button"
            onClick={() => canViewHealth && onNavigateTab('settings', 'health')}
            className="text-left p-5 rounded-2xl bg-[#031D1C] border border-white/10 hover:border-[#25CDB6]/40 transition-colors cursor-pointer space-y-3"
          >
            <div className="flex items-center justify-between text-xs text-[#EDE9E0]/65">
              <span className="font-semibold">Site Health</span>
              <ShieldCheck className="w-4 h-4 text-[#25CDB6]" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-[#25CDB6] tracking-tight tabular-nums font-mono">
                {healthWarnings.length === 0 ? '100%' : `${Math.max(0, 100 - healthWarnings.length * 10)}%`}
              </span>
              <span className="text-xs text-[#EDE9E0]/55 font-semibold tabular-nums">
                {healthWarnings.length === 0
                  ? 'Optimal'
                  : `${healthWarnings.length} alert${healthWarnings.length === 1 ? '' : 's'}`}
              </span>
            </div>
            <div className="text-[11px] text-[#EDE9E0]/55">
              {healthWarnings.length === 0 ? 'All links & assets verified' : 'Review diagnostics'}
            </div>
          </button>
        )}
      </div>

      {/* Continue Editing + Actionable Site Health */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <PortalSection
          title="Continue Editing"
          description="Recently updated projects, publications, and products."
          actions={
            <button
              type="button"
              onClick={() => onNavigateTab('content', 'projects')}
              className="h-8 px-3 rounded-xl bg-[#06302F] hover:bg-white/10 border border-white/12 text-xs font-semibold text-[#25CDB6] cursor-pointer"
            >
              View all
            </button>
          }
        >
          {continueEditingItems.length === 0 ? (
            <PortalEmptyState
              compact
              icon={Clock}
              title="No active content items"
              description="Create a project, publication, or product from the Content workspace."
            />
          ) : (
            <div className="space-y-2.5">
              {continueEditingItems.map(item => (
                <button
                  key={`${item.kind}-${item.id}`}
                  type="button"
                  onClick={() => onNavigateTab('content', item.kind, item.id, item.kind)}
                  className="w-full text-left p-3.5 rounded-xl bg-[#06302F]/80 hover:bg-[#06302F] border border-white/10 hover:border-[#25CDB6]/40 flex items-center justify-between gap-4 transition-colors cursor-pointer"
                >
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-[#EDE9E0] truncate">{item.title}</h4>
                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-[#EDE9E0]/55 mt-1">
                      <span className="capitalize">{item.meta}</span>
                      <PortalStatusBadge status={item.publicationStatus} />
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#EDE9E0]/40 shrink-0" />
                </button>
              ))}
            </div>
          )}
        </PortalSection>

        <PortalSection
          title="Actionable Site Health"
          description="SEO metadata checks, asset alt-text alerts, and configuration warnings."
          badge={
            healthWarnings.length > 0 ? (
              <PortalStatusBadge status="In review" labelOverride={`${healthWarnings.length} open`} />
            ) : (
              <PortalStatusBadge status="Published" labelOverride="All passing" />
            )
          }
          actions={
            canViewHealth ? (
              <button
                type="button"
                onClick={() => onNavigateTab('settings', 'health')}
                className="h-8 px-3 rounded-xl bg-[#06302F] hover:bg-white/10 border border-white/12 text-xs font-semibold text-[#25CDB6] cursor-pointer"
              >
                View diagnostics
              </button>
            ) : undefined
          }
        >
          {healthWarnings.length === 0 ? (
            <PortalEmptyState
              compact
              icon={CheckCircle2}
              title="No health warnings"
              description="All SEO titles, department introductions, and uploaded assets look great."
            />
          ) : (
            <div className="space-y-2.5">
              {healthWarnings.slice(0, 4).map((item, idx) => (
                <div
                  key={item.id || idx}
                  className="p-3.5 rounded-xl bg-[#06302F]/80 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <AlertTriangle
                        className={`w-3.5 h-3.5 shrink-0 ${
                          item.type === 'error' ? 'text-red-400' : 'text-amber-400'
                        }`}
                      />
                      <h4 className="text-xs font-bold text-[#EDE9E0] break-words">{item.title}</h4>
                    </div>
                    <p className="text-[11px] text-[#EDE9E0]/60 mt-1 break-words">{item.message}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      onNavigateTab(
                        item.actionTab || 'settings',
                        item.actionSubTab || (item.actionTab === 'settings' ? 'health' : undefined),
                        item.targetPageId,
                        undefined,
                        item.targetDrawerTab
                      )
                    }
                    className="h-8 px-3 rounded-xl bg-[#17A491]/15 hover:bg-[#17A491] text-[#25CDB6] hover:text-[#031D1C] border border-[#25CDB6]/25 text-xs font-bold inline-flex items-center gap-1 shrink-0 self-start sm:self-auto transition-colors cursor-pointer"
                  >
                    Fix
                  </button>
                </div>
              ))}
            </div>
          )}
        </PortalSection>
      </div>

      {/* Department Completeness Section */}
      {canManageDepts && (
        <PortalSection
          title="Department Completeness Scores"
          description="Ensure each department has structured purpose, mission, and areas of focus for public display."
          actions={
            <button
              type="button"
              onClick={() => onNavigateTab('content', 'departments')}
              className="h-8 px-3 rounded-xl bg-[#06302F] hover:bg-white/10 border border-white/12 text-xs font-semibold text-[#25CDB6] cursor-pointer"
            >
              Manage Departments &rarr;
            </button>
          }
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {activeDepts.map(dept => {
              const pct = getDeptCompleteness(dept);
              return (
                <button
                  key={dept.id}
                  type="button"
                  onClick={() => onNavigateTab('content', 'departments', dept.id, 'departments')}
                  className="text-left p-4 rounded-xl bg-[#06302F]/80 border border-white/10 hover:border-[#25CDB6]/40 transition-colors cursor-pointer space-y-2.5"
                >
                  <div className="flex items-center justify-between text-xs gap-2">
                    <span className="font-bold text-[#EDE9E0] truncate">{dept.name}</span>
                    <span className="font-mono font-bold text-[#25CDB6] text-[11px] tabular-nums shrink-0">
                      {pct}%
                    </span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                    <div
                      style={{ width: `${pct}%` }}
                      className={`h-full transition-all duration-300 ${
                        pct === 100 ? 'bg-[#25CDB6]' : pct >= 60 ? 'bg-[#17A491]' : 'bg-amber-400'
                      }`}
                    />
                  </div>
                </button>
              );
            })}
          </div>
        </PortalSection>
      )}
    </div>
  );
};
