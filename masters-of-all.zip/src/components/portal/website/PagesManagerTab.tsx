import React, { useMemo, useState } from 'react';
import {
  Search,
  Filter,
  Plus,
  Edit3,
  Settings,
  ExternalLink,
  MoreHorizontal,
  Copy,
  Trash2,
  AlertTriangle,
  ArrowRight,
  X,
  Save,
  Loader2,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import {
  PageBlock,
  PageRecord,
  WebsiteOverviewResponse,
  WebsitePageListEntry
} from '../../../types';
import { api } from '../../../services/api';
import { ModularBlockEditor, createDefaultModularBlock } from '../ModularBlockEditor';
import { ConfirmDialog } from '../ConfirmDialog';
import { DrawerTabKey } from './PageSettingsDrawer';

interface PagesManagerTabProps {
  overview: WebsiteOverviewResponse;
  pages: PageRecord[];
  canEditWebsite: boolean;
  canManagePages: boolean;
  onOpenDrawer: (pageId: string, tab?: DrawerTabKey) => void;
  onEditOnSite: (path: string, sectionAnchorId?: string) => void | Promise<void>;
  onViewPage: (path: string) => void;
  onOpenAttentionSubTab: (subTab: 'pages' | 'menus' | 'brand' | 'seo', pageId?: string, drawerTab?: DrawerTabKey) => void;
  onRefresh: () => Promise<void>;
}

function formatShortDate(iso?: string): string {
  if (!iso) return 'Initial';
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return 'Initial';
  return dt.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

export const PagesManagerTab: React.FC<PagesManagerTabProps> = ({
  overview,
  pages,
  canEditWebsite,
  canManagePages,
  onOpenDrawer,
  onEditOnSite,
  onViewPage,
  onOpenAttentionSubTab,
  onRefresh
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [attentionCollapsed, setAttentionCollapsed] = useState(false);
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);

  // Create Custom Page Modal state
  const [createOpen, setCreateOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newSlug, setNewSlug] = useState('');
  const [newTemplate, setNewTemplate] = useState<PageRecord['template']>('Standard');
  const [newStatus, setNewStatus] = useState<PageRecord['status']>('Published');
  const [newBlocks, setNewBlocks] = useState<PageBlock[]>(() => [
    createDefaultModularBlock('heading'),
    createDefaultModularBlock('paragraph')
  ]);
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  // Custom page duplicate/delete state
  const [actionError, setActionError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<WebsitePageListEntry | null>(null);
  const [deleting, setDeleting] = useState(false);

  const attentionItems = overview.attentionItems || [];

  const filteredPages = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (overview.pages || []).filter(p => {
      if (statusFilter !== 'all' && p.status !== statusFilter) return false;
      if (q) {
        const hay = `${p.name} ${p.path} ${p.description}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [overview.pages, search, statusFilter]);

  const standardPages = useMemo(
    () => filteredPages.filter(p => p.kind === 'core' || p.kind === 'system'),
    [filteredPages]
  );
  const customPages = useMemo(() => filteredPages.filter(p => p.kind === 'custom'), [filteredPages]);

  const handleOpenCreate = () => {
    setNewTitle('');
    setNewSlug('');
    setNewTemplate('Standard');
    setNewStatus('Published');
    setNewBlocks([createDefaultModularBlock('heading'), createDefaultModularBlock('paragraph')]);
    setCreateError(null);
    setCreateOpen(true);
  };

  const handleTitleChange = (val: string) => {
    setNewTitle(val);
    if (!newSlug || newSlug === newTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')) {
      setNewSlug(val.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, ''));
    }
  };

  const handleCreatePage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      setCreateError('Page title is required.');
      return;
    }
    const cleanSlug = (newSlug || newTitle)
      .toLowerCase()
      .replace(/[^a-z0-9-]+/g, '-')
      .replace(/^-+|-+$/g, '');
    if (!cleanSlug) {
      setCreateError('A valid URL slug is required.');
      return;
    }

    setCreating(true);
    setCreateError(null);
    try {
      const now = new Date().toISOString();
      const record: PageRecord = {
        id: `page-${Date.now()}`,
        title: newTitle.trim(),
        slug: cleanSlug,
        template: newTemplate,
        status: newStatus,
        blocks: newBlocks,
        seo: {
          title: newTitle.trim(),
          description: ''
        },
        createdAt: now,
        updatedAt: now
      };
      await api.savePage(record);
      setCreateOpen(false);
      await onRefresh();
    } catch (err) {
      setCreateError(err instanceof Error ? err.message : 'Failed to create page.');
    } finally {
      setCreating(false);
    }
  };

  const handleDuplicate = async (entry: WebsitePageListEntry) => {
    setOpenMenuId(null);
    setActionError(null);
    try {
      await api.duplicateWebsitePage(entry.id);
      await onRefresh();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to duplicate page.');
    }
  };

  const handleConfirmDelete = async () => {
    if (!confirmDelete) return;
    setDeleting(true);
    setActionError(null);
    try {
      await api.deletePage(confirmDelete.id);
      setConfirmDelete(null);
      await onRefresh();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to delete page.');
    } finally {
      setDeleting(false);
    }
  };

  const renderStatusBadge = (entry: WebsitePageListEntry) => {
    const status = entry.status;
    if (status === 'Published') {
      return (
        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
          Published
        </span>
      );
    }
    if (status === 'Draft changes' || status === 'Draft') {
      return (
        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#D0A873]/15 text-[#D0A873] border border-[#D0A873]/30">
          {status}
        </span>
      );
    }
    if (status === 'Auto-visible') {
      return (
        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#25CDB6]/15 text-[#25CDB6] border border-[#25CDB6]/30">
          Auto-visible
        </span>
      );
    }
    return (
      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-white/10 text-[#EDE9E0]/65 border border-white/15">
        Hidden
      </span>
    );
  };

  const renderGroup = (title: string, items: WebsitePageListEntry[]) => {
    if (items.length === 0) return null;
    return (
      <div className="space-y-2">
        <h3 className="text-[11px] uppercase tracking-wider font-bold text-[#EDE9E0]/55 px-1">
          {title} ({items.length})
        </h3>
        <div className="rounded-2xl bg-[#031D1C] border border-white/10 overflow-visible">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead className="bg-[#06302F]/60 border-b border-white/10 text-[#EDE9E0]/55 font-semibold uppercase tracking-wider font-mono text-[10px]">
                <tr>
                  <th className="py-3 px-4">Page &amp; URL</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 hidden md:table-cell">Last Edited</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {items.map(item => {
                  const isCustom = item.kind === 'custom';
                  const matchedRecord = isCustom ? pages.find(p => p.id === item.id) : null;
                  const viewHref = matchedRecord
                    ? `/pages/${matchedRecord.slug}${matchedRecord.status !== 'Published' ? '?preview=1' : ''}`
                    : item.path;

                  return (
                    <tr key={item.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="py-3.5 px-4 max-w-md">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-[#EDE9E0]">{item.name}</span>
                          <span className="text-[11px] font-mono text-[#25CDB6]">{item.path}</span>
                        </div>
                        <p className="text-[11px] text-[#EDE9E0]/55 mt-0.5 line-clamp-1">
                          {item.description}
                        </p>
                      </td>

                      <td className="py-3.5 px-4 whitespace-nowrap">{renderStatusBadge(item)}</td>

                      <td className="py-3.5 px-4 hidden md:table-cell whitespace-nowrap text-[#EDE9E0]/70">
                        <span className="block">{formatShortDate(item.lastEditedAt)}</span>
                        <span className="text-[10px] text-[#EDE9E0]/45">
                          {item.lastEditedByName || 'System'}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center justify-end gap-1.5 relative">
                          {canEditWebsite && !isCustom && (
                            <button
                              type="button"
                              onClick={() => void onEditOnSite(item.path)}
                              className="px-2.5 py-1.5 rounded-lg bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold inline-flex items-center gap-1 cursor-pointer"
                            >
                              <Edit3 className="w-3 h-3" />
                              <span className="hidden sm:inline">Edit on site</span>
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => onOpenDrawer(item.id, isCustom ? 'text' : 'general')}
                            className="px-2.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0] font-semibold inline-flex items-center gap-1 cursor-pointer"
                          >
                            <Settings className="w-3 h-3 text-[#25CDB6]" />
                            <span>Settings</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => onViewPage(viewHref)}
                            title="View page"
                            aria-label={`View ${item.name}`}
                            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0]/80 hover:text-[#25CDB6] cursor-pointer"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>

                          {isCustom && canManagePages && (
                            <div className="relative">
                              <button
                                type="button"
                                onClick={() => setOpenMenuId(openMenuId === item.id ? null : item.id)}
                                aria-label={`More actions for ${item.name}`}
                                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0]/80 cursor-pointer"
                              >
                                <MoreHorizontal className="w-3.5 h-3.5" />
                              </button>
                              {openMenuId === item.id && (
                                <div
                                  className="absolute right-0 mt-1 w-36 rounded-xl bg-[#06302F] border border-white/15 shadow-xl py-1 z-30 text-left"
                                  onMouseLeave={() => setOpenMenuId(null)}
                                >
                                  <button
                                    type="button"
                                    onClick={() => void handleDuplicate(item)}
                                    className="w-full px-3 py-2 text-xs text-[#EDE9E0] hover:bg-white/10 flex items-center gap-2 cursor-pointer"
                                  >
                                    <Copy className="w-3.5 h-3.5 text-[#25CDB6]" />
                                    <span>Duplicate</span>
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setOpenMenuId(null);
                                      setConfirmDelete(item);
                                    }}
                                    className="w-full px-3 py-2 text-xs text-red-300 hover:bg-red-500/15 flex items-center gap-2 cursor-pointer"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                    <span>Delete</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {actionError && (
        <div className="p-3.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center justify-between gap-2">
          <span>{actionError}</span>
          <button type="button" onClick={() => setActionError(null)} className="underline cursor-pointer">
            Dismiss
          </button>
        </div>
      )}

      {/* Needs Attention Panel — shown ONLY when there is at least 1 issue */}
      {attentionItems.length > 0 && (
        <div className="rounded-2xl bg-[#031D1C] border border-[#D0A873]/40 overflow-hidden">
          <div className="px-4 py-3 bg-[#D0A873]/10 border-b border-[#D0A873]/25 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs font-bold text-[#D0A873]">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>Needs attention ({attentionItems.length})</span>
            </div>
            <button
              type="button"
              onClick={() => setAttentionCollapsed(!attentionCollapsed)}
              className="text-xs text-[#EDE9E0]/70 hover:text-white inline-flex items-center gap-1 cursor-pointer"
            >
              <span>{attentionCollapsed ? 'Show' : 'Hide'}</span>
              {attentionCollapsed ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
            </button>
          </div>

          {!attentionCollapsed && (
            <div className="divide-y divide-white/5">
              {attentionItems.map(item => (
                <div
                  key={item.id}
                  className="px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs"
                >
                  <div className="min-w-0">
                    <span className="font-bold text-[#EDE9E0] block">{item.title}</span>
                    <span className="text-[#EDE9E0]/65 text-[11px]">{item.message}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      onOpenAttentionSubTab(
                        item.fixAction.subTab,
                        item.fixAction.pageId,
                        item.fixAction.drawerTab
                      )
                    }
                    className="h-8 px-3 rounded-lg bg-[#17A491]/15 hover:bg-[#17A491] text-[#25CDB6] hover:text-[#06302F] font-bold inline-flex items-center gap-1 cursor-pointer shrink-0 transition-colors"
                  >
                    <span>Fix</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Search, Filter & New Page Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="flex-1 p-3 rounded-2xl bg-[#031D1C] border border-white/10 relative w-full">
          <Search className="w-4 h-4 text-[#EDE9E0]/40 absolute left-6 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search pages by name or URL..."
            aria-label="Search pages"
            className="w-full h-9 bg-[#06302F] border border-white/10 rounded-xl pl-10 pr-4 text-xs text-[#EDE9E0] placeholder-[#EDE9E0]/35 focus:outline-none focus:border-[#25CDB6]"
          />
        </div>

        <div className="flex items-center gap-2.5 flex-wrap sm:flex-nowrap">
          <div className="flex items-center gap-2 p-3 rounded-2xl bg-[#031D1C] border border-white/10 flex-1 sm:flex-initial">
            <Filter className="w-3.5 h-3.5 text-[#EDE9E0]/45 shrink-0" />
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              aria-label="Filter pages by status"
              className="w-full sm:w-auto h-9 bg-[#06302F] border border-white/10 rounded-xl px-3 text-xs font-bold text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6] cursor-pointer"
            >
              <option value="all">All statuses</option>
              <option value="Published">Published</option>
              <option value="Draft changes">Draft changes</option>
              <option value="Draft">Draft</option>
              <option value="Auto-visible">Auto-visible</option>
              <option value="Hidden">Hidden</option>
            </select>
          </div>

          {canManagePages && (
            <button
              type="button"
              onClick={handleOpenCreate}
              className="h-9 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] text-xs font-bold inline-flex items-center gap-1.5 shadow-md cursor-pointer shrink-0 transition-all"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>New page</span>
            </button>
          )}
        </div>
      </div>

      {/* Grouped Pages Tables */}
      <div className="space-y-6">
        {renderGroup('Pages', standardPages)}
        {renderGroup('Custom pages', customPages)}

        {standardPages.length === 0 && customPages.length === 0 && (
          <div className="p-10 rounded-2xl bg-[#031D1C] border border-white/10 text-center text-xs text-[#EDE9E0]/60">
            No pages match your current search or filter.
          </div>
        )}
      </div>

      {/* Create Custom Page Modal */}
      {createOpen && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Create custom page"
          onClick={() => setCreateOpen(false)}
        >
          <form
            onSubmit={handleCreatePage}
            onClick={e => e.stopPropagation()}
            className="w-full max-w-3xl max-h-[90dvh] flex flex-col rounded-2xl bg-[#031D1C] border border-white/15 shadow-2xl overflow-hidden text-[#EDE9E0]"
          >
            <div className="px-5 py-4 border-b border-white/10 bg-[#06302F] flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold">New Custom Page</h3>
                <p className="text-xs text-[#EDE9E0]/60">Compose using shared modular blocks.</p>
              </div>
              <button
                type="button"
                onClick={() => setCreateOpen(false)}
                aria-label="Close new page modal"
                className="p-1.5 rounded-lg text-[#EDE9E0]/60 hover:text-white hover:bg-white/10 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs flex-1">
              {createError && (
                <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200">
                  {createError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Page Title</label>
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={e => handleTitleChange(e.target.value)}
                    placeholder="e.g. Open Fellowship 2026"
                    className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                  />
                </div>
                <div>
                  <label className="block text-[#EDE9E0]/75 font-semibold mb-1">URL Slug</label>
                  <input
                    type="text"
                    value={newSlug}
                    onChange={e => setNewSlug(e.target.value)}
                    placeholder="open-fellowship-2026"
                    className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 font-mono text-[#EDE9E0]"
                  />
                </div>
                <div>
                  <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Template</label>
                  <select
                    value={newTemplate}
                    onChange={e => setNewTemplate(e.target.value as PageRecord['template'])}
                    className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                  >
                    <option value="Standard">Standard</option>
                    <option value="Landing">Landing</option>
                    <option value="Article">Article</option>
                    <option value="Gallery">Gallery</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Initial Status</label>
                  <select
                    value={newStatus}
                    onChange={e => setNewStatus(e.target.value as PageRecord['status'])}
                    className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                  >
                    <option value="Published">Published</option>
                    <option value="Draft">Draft</option>
                    <option value="Hidden">Hidden</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 border-t border-white/10">
                <ModularBlockEditor blocks={newBlocks} onChange={setNewBlocks} />
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-white/10 bg-[#06302F] flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setCreateOpen(false)}
                className="h-9 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-[#EDE9E0]/80 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={creating}
                className="h-9 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {creating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                <span>{creating ? 'Creating...' : 'Create Page'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog
        isOpen={Boolean(confirmDelete)}
        title="Delete Custom Page"
        message={`Move "${confirmDelete?.name}" (${confirmDelete?.path}) to Trash? Any menus pointing to it can still be updated in Menus.`}
        confirmLabel={deleting ? 'Deleting...' : 'Move to Trash'}
        isDestructive
        onCancel={() => setConfirmDelete(null)}
        onConfirm={() => void handleConfirmDelete()}
      />
    </div>
  );
};
