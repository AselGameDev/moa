import React, { useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';

export interface PortalSectionProps {
  title: string;
  description?: string;
  badge?: React.ReactNode;
  actions?: React.ReactNode;
  collapsible?: boolean;
  defaultOpen?: boolean;
  children: React.ReactNode;
  className?: string;
  id?: string;
}

export const PortalSection: React.FC<PortalSectionProps> = ({
  title,
  description,
  badge,
  actions,
  collapsible = false,
  defaultOpen = true,
  children,
  className = '',
  id
}) => {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <section
      id={id}
      className={`rounded-2xl bg-[#031D1C] border border-white/10 overflow-hidden ${className}`}
    >
      <div className="px-4 sm:px-5 py-3.5 border-b border-white/10 flex flex-wrap items-center justify-between gap-3">
        {collapsible ? (
          <button
            type="button"
            onClick={() => setOpen(v => !v)}
            aria-expanded={open}
            className="flex items-center gap-2.5 text-left min-w-0 flex-1 cursor-pointer group"
          >
            {open ? (
              <ChevronDown className="w-4 h-4 text-[#25CDB6] shrink-0" />
            ) : (
              <ChevronRight className="w-4 h-4 text-[#EDE9E0]/55 group-hover:text-[#25CDB6] shrink-0" />
            )}
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-sm font-bold text-[#EDE9E0]">{title}</h2>
                {badge}
              </div>
              {description && (
                <p className="text-[11px] text-[#EDE9E0]/60 mt-0.5 break-words">{description}</p>
              )}
            </div>
          </button>
        ) : (
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-sm font-bold text-[#EDE9E0]">{title}</h2>
              {badge}
            </div>
            {description && (
              <p className="text-[11px] text-[#EDE9E0]/60 mt-0.5 break-words">{description}</p>
            )}
          </div>
        )}
        {actions && <div className="flex flex-wrap items-center gap-2 shrink-0">{actions}</div>}
      </div>

      {(!collapsible || open) && <div className="p-4 sm:p-5">{children}</div>}
    </section>
  );
};
