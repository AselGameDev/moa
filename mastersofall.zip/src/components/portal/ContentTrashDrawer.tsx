import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Loader2, RefreshCw, RotateCcw, Trash2 } from 'lucide-react';
import { TrashItemsResponse } from '../../types';
import { api } from '../../services/api';
import { PortalConfirmDialog, PortalDrawer, PortalEmptyState } from './ui';

type TrashEntityType =
  | 'department'
  | 'project'
  | 'publication'
  | 'product'
  | 'page'
  | 'media'
  | 'submission';

interface FlattenedTrashEntry {
  type: TrashEntityType;
  id: string;
  label: string;
  deletedAt: string;
  kindHint: string;
}

export interface ContentTrashDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  canManageTrash: boolean;
  onChanged: () => Promise<void>;
}

export const ContentTrashDrawer: React.FC<ContentTrashDrawerProps> = ({
  isOpen,
  onClose,
  canManageTrash,
  onChanged
}) => {
  const [data, setData] = useState<TrashItemsResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [permDeleteTarget, setPermDeleteTarget] = useState<FlattenedTrashEntry | null>(null);
  const [emptyConfirmOpen, setEmptyConfirmOpen] = useState(false);

  const loadTrash = useCallback(async () => {
    if (!canManageTrash) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api.getTrashItems();
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load trash.');
    } finally {
      setLoading(false);
    }
  }, [canManageTrash]);

  useEffect(() => {
    if (isOpen) {
      void loadTrash();
    }
  }, [isOpen, loadTrash]);

  const items = useMemo<FlattenedTrashEntry[]>(() => {
    if (!data) return [];
    const list: FlattenedTrashEntry[] = [];
    for (const d of data.departments || []) {
      list.push({
        type: 'department',
        id: d.id,
        label: d.name,
        deletedAt: d.deletedAt || '',
        kindHint: d.kind === 'sector' ? 'Sector' : 'Department'
      });
    }
    for (const p of data.projects || []) {
      list.push({
        type: 'project',
        id: p.id,
        label: p.title,
        deletedAt: p.deletedAt || '',
        kindHint: 'Project'
      });
    }
    for (const pub of data.publications || []) {
      list.push({
        type: 'publication',
        id: pub.id,
        label: pub.title,
        deletedAt: pub.deletedAt || '',
        kindHint: 'Publication'
      });
    }
    for (const prod of data.products || []) {
      list.push({
        type: 'product',
        id: prod.id,
        label: prod.name,
        deletedAt: prod.deletedAt || '',
        kindHint: 'Product'
      });
    }
    for (const pg of data.pages || []) {
      list.push({
        type: 'page',
        id: pg.id,
        label: pg.title,
        deletedAt: pg.deletedAt || '',
        kindHint: 'Page'
      });
    }
    for (const m of data.media || []) {
      list.push({
        type: 'media',
        id: m.id,
        label: m.name,
        deletedAt: m.deletedAt || '',
        kindHint: 'Media'
      });
    }
    for (const s of data.submissions || []) {
      list.push({
        type: 'submission',
        id: s.id,
        label: `${s.name} — ${s.subject || s.email}`,
        deletedAt: s.deletedAt || '',
        kindHint: 'Inquiry'
      });
    }
    return list.sort((a, b) => (Date.parse(b.deletedAt) || 0) - (Date.parse(a.deletedAt) || 0));
  }, [data]);

  const handleRestore = async (entry: FlattenedTrashEntry) => {
    const key = `${entry.type}:${entry.id}`;
    setBusyKey(key);
    setError(null);
    try {
      await api.restoreTrashItem(entry.type, entry.id);
      await loadTrash();
      await onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Restore failed.');
    } finally {
      setBusyKey(null);
    }
  };

  const handleDeleteForever = async () => {
    if (!permDeleteTarget) return;
    const key = `${permDeleteTarget.type}:${permDeleteTarget.id}`;
    setBusyKey(key);
    setError(null);
    try {
      await api.deleteTrashItem(permDeleteTarget.type, permDeleteTarget.id);
      setPermDeleteTarget(null);
      await loadTrash();
      await onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Permanent delete failed.');
    } finally {
      setBusyKey(null);
    }
  };

  const handleEmptyTrash = async () => {
    setBusyKey('empty');
    setError(null);
    try {
      await api.emptyTrash();
      setEmptyConfirmOpen(false);
      await loadTrash();
      await onChanged();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to empty trash.');
    } finally {
      setBusyKey(null);
    }
  };

  return (
    <>
      <PortalDrawer
        isOpen={isOpen}
        onClose={onClose}
        title="Trash"
        subtitle="Soft-deleted content that can be restored or permanently removed."
        blockEscape={Boolean(permDeleteTarget || emptyConfirmOpen)}
        headerBadge={
          <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-white/10 text-[#EDE9E0]/75 tabular-nums">
            {items.length}
          </span>
        }
        headerActions={
          items.length > 0 && canManageTrash ? (
            <button
              type="button"
              onClick={() => setEmptyConfirmOpen(true)}
              className="h-8 px-2.5 rounded-lg bg-red-500/15 hover:bg-red-500/25 border border-red-400/30 text-[11px] font-semibold text-red-300 cursor-pointer"
            >
              Empty trash
            </button>
          ) : undefined
        }
      >
        {!canManageTrash ? (
          <PortalEmptyState
            compact
            icon={Trash2}
            title="Permission required"
            description="Your role does not allow managing items in Trash."
          />
        ) : loading ? (
          <div className="py-12 flex flex-col items-center gap-2 text-xs text-[#EDE9E0]/60">
            <Loader2 className="w-5 h-5 animate-spin text-[#25CDB6]" />
            <span>Loading trash items...</span>
          </div>
        ) : error ? (
          <div className="p-4 rounded-2xl bg-red-950/30 border border-red-500/30 space-y-2 text-xs">
            <p className="text-red-200">{error}</p>
            <button
              type="button"
              onClick={() => void loadTrash()}
              className="h-8 px-3 rounded-lg bg-white/10 hover:bg-white/15 text-[#EDE9E0] font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry</span>
            </button>
          </div>
        ) : items.length === 0 ? (
          <PortalEmptyState
            compact
            icon={Trash2}
            title="Trash is empty"
            description="Deleted departments, sectors, projects, publications, products, pages, media assets, and inquiries appear here."
          />
        ) : (
          <div className="space-y-3">
            {items.map(entry => {
              const key = `${entry.type}:${entry.id}`;
              const isBusy = busyKey === key;
              return (
                <div
                  key={key}
                  className="p-4 rounded-2xl bg-[#031D1C] border border-white/10 space-y-2.5"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 text-[11px] text-[#EDE9E0]/55">
                        <span className="font-semibold text-[#D0A873]">{entry.kindHint}</span>
                        {entry.deletedAt && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="tabular-nums">
                              Deleted {new Date(entry.deletedAt).toLocaleDateString()}
                            </span>
                          </>
                        )}
                      </div>
                      <h3 className="text-sm font-bold text-[#EDE9E0] mt-0.5 break-words">
                        {entry.label}
                      </h3>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => void handleRestore(entry)}
                      className="h-8 px-3 rounded-xl bg-[#17A491]/15 hover:bg-[#17A491]/25 border border-[#25CDB6]/30 text-xs font-semibold text-[#25CDB6] inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      {isBusy ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <RotateCcw className="w-3.5 h-3.5" />
                      )}
                      <span>Restore</span>
                    </button>

                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() => setPermDeleteTarget(entry)}
                      className="h-8 px-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-400/25 text-xs font-semibold text-red-300 inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50 ml-auto"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete forever</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </PortalDrawer>

      <PortalConfirmDialog
        isOpen={Boolean(permDeleteTarget)}
        title="Delete permanently?"
        message={
          permDeleteTarget
            ? `"${permDeleteTarget.label}" will be permanently removed and cannot be recovered.`
            : ''
        }
        confirmLabel="Delete forever"
        cancelLabel="Cancel"
        isDestructive
        loading={Boolean(permDeleteTarget && busyKey === `${permDeleteTarget.type}:${permDeleteTarget.id}`)}
        onConfirm={() => void handleDeleteForever()}
        onCancel={() => setPermDeleteTarget(null)}
      />

      <PortalConfirmDialog
        isOpen={emptyConfirmOpen}
        title="Empty trash?"
        message={`All ${items.length} trashed item${items.length === 1 ? '' : 's'} will be permanently deleted and cannot be recovered.`}
        confirmLabel="Empty trash"
        cancelLabel="Cancel"
        isDestructive
        loading={busyKey === 'empty'}
        onConfirm={() => void handleEmptyTrash()}
        onCancel={() => setEmptyConfirmOpen(false)}
      />
    </>
  );
};
