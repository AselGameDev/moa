import React, { useMemo } from 'react';
import { Mail, ArrowUpRight, MapPin } from 'lucide-react';
import {
  Department,
  FooterColumn,
  NavigationItem,
  SiteContent,
  WebsiteMenusConfig
} from '../types';
import { resolveSocialLinks } from './SocialIcons';
import { SpaLink } from './SpaLink';
import { getUnitHref, splitOrgUnits } from '../utils/orgHelpers';

interface FooterProps {
  departments: Department[];
  onNavigate: (path: string) => void;
  socialLinks?: Array<{ id: string; platform: string; url: string; icon?: string; visible?: boolean }>;
  footerText?: string;
  footerColumns?: FooterColumn[];
  websiteFooter?: WebsiteMenusConfig['footer'];
  headerMenu?: NavigationItem[];
  showProducts?: boolean;
  contactEmail?: string;
  organizationAddress?: string;
  logoUrl?: string;
  siteName?: string;
  tagline?: string;
  content?: SiteContent['footer'];
}

const DEFAULT_EXPLORE_LINKS = [
  { label: 'Home', url: '/', isExternal: false, newTab: false },
  { label: 'About', url: '/about', isExternal: false, newTab: false },
  { label: 'Departments', url: '/departments', isExternal: false, newTab: false },
  { label: 'Projects', url: '/projects', isExternal: false, newTab: false },
  { label: 'Products', url: '/products', isExternal: false, newTab: false },
  { label: 'Contact', url: '/contact', isExternal: false, newTab: false }
];

const DEFAULT_COLUMN_ORDER: WebsiteMenusConfig['footer']['columns'] = [
  { id: 'explore', title: 'Explore', visible: true, kind: 'auto-header', sameAsHeader: true, links: [] },
  { id: 'departments', title: 'Departments', visible: true, kind: 'auto-departments' },
  { id: 'sectors', title: 'Sectors', visible: true, kind: 'auto-sectors' },
  { id: 'community', title: 'Community', visible: true, kind: 'auto-social' },
  { id: 'legal', title: 'Legal', visible: false, kind: 'custom', links: [] }
];

export const Footer: React.FC<FooterProps> = ({
  departments,
  onNavigate,
  socialLinks,
  footerText,
  footerColumns,
  websiteFooter,
  headerMenu,
  showProducts = false,
  contactEmail = 'business@mastersofall.org',
  organizationAddress,
  logoUrl = '/drawing1.png',
  siteName = 'Masters Of All',
  tagline = 'Believe. Build. Become.',
  content
}) => {
  const links = resolveSocialLinks(socialLinks);
  const customExploreCol = footerColumns && footerColumns.length > 0 ? footerColumns[0] : null;
  const exploreConfigCol = websiteFooter?.columns?.find(c => c.id === 'explore');
  const useHeaderSync = exploreConfigCol ? exploreConfigCol.sameAsHeader !== false : false;

  const exploreLinks = useMemo(() => {
    let raw: Array<{ label: string; url: string; isExternal?: boolean; newTab?: boolean }>;
    if (useHeaderSync && headerMenu && headerMenu.length > 0) {
      raw = headerMenu
        .filter(item => item.visible !== false && item.path.toLowerCase() !== '/login')
        .map(item => ({
          label: item.label,
          url: item.path === '/home' ? '/' : item.path,
          isExternal: item.isExternal,
          newTab: item.newTab
        }));
    } else if (exploreConfigCol && !useHeaderSync && exploreConfigCol.links && exploreConfigCol.links.length > 0) {
      raw = [...exploreConfigCol.links];
    } else if (customExploreCol && customExploreCol.links.length > 0) {
      raw = [...customExploreCol.links];
    } else {
      raw = [...DEFAULT_EXPLORE_LINKS];
    }

    const normalized = raw
      .filter(item => (item.url || '').toLowerCase() !== '/login')
      .map(item => {
        if (item.url === '/home') return { ...item, url: '/' };
        if (item.url === '/projects' && item.label === 'Our Work') {
          return { ...item, label: 'Projects' };
        }
        return item;
      });

    const filtered = normalized.filter(item => item.url !== '/products' || showProducts);

    if (showProducts && !useHeaderSync && !filtered.some(item => item.url === '/products')) {
      const contactIdx = filtered.findIndex(item => item.url === '/contact');
      const prodLink = { label: 'Products', url: '/products', isExternal: false, newTab: false };
      if (contactIdx >= 0) filtered.splice(contactIdx, 0, prodLink);
      else filtered.push(prodLink);
    }

    return filtered;
  }, [useHeaderSync, headerMenu, exploreConfigCol, customExploreCol, showProducts]);

  const blurb =
    websiteFooter?.blurb?.trim() ||
    footerText ||
    content?.blurb ||
    'An ecosystem for explorers, creators, innovators and problem-solvers.';

  const showContactEmail = websiteFooter ? websiteFooter.showContactEmail !== false : true;

  const publishedUnits = useMemo(
    () => departments.filter(d => d.published && !d.deletedAt),
    [departments]
  );
  const { departments: publishedDepartments, sectors: publishedSectors } = useMemo(
    () => splitOrgUnits(publishedUnits),
    [publishedUnits]
  );

  const orderedColumns = useMemo(() => {
    const cols = websiteFooter?.columns && websiteFooter.columns.length > 0
      ? websiteFooter.columns
      : DEFAULT_COLUMN_ORDER;
    return cols.filter(c => c.visible);
  }, [websiteFooter?.columns]);

  const currentYear = String(new Date().getFullYear());
  const copyrightText = websiteFooter?.copyrightText?.trim()
    ? websiteFooter.copyrightText.replace(/\{year\}/g, currentYear)
    : `© ${currentYear} ${siteName}. ${content?.copyrightSuffix || 'All rights reserved.'}`;

  const renderColumn = (col: WebsiteMenusConfig['footer']['columns'][number]) => {
    if (col.id === 'explore') {
      return (
        <div key={col.id} className="min-w-0 lg:flex-initial">
          <h4 className="text-[13px] uppercase tracking-wider text-[#EDE9E0]/70 mb-4 font-semibold">
            {col.title || customExploreCol?.title || content?.exploreHeading || 'Explore'}
          </h4>
          <ul className="space-y-1 sm:space-y-2.5 text-[13px]">
            {exploreLinks.map((item, idx) => {
              const openNewTab = Boolean(item.newTab || item.isExternal);
              return (
                <li key={`${item.url}-${idx}`}>
                  <SpaLink
                    href={item.url}
                    external={item.isExternal}
                    target={openNewTab ? '_blank' : undefined}
                    rel={openNewTab ? 'noopener noreferrer' : undefined}
                    onNavigate={onNavigate}
                    className="min-h-[44px] sm:min-h-0 inline-flex items-center text-[#EDE9E0]/80 hover:text-[#EDE9E0] transition-colors cursor-pointer"
                  >
                    {item.label}
                  </SpaLink>
                </li>
              );
            })}
          </ul>
        </div>
      );
    }

    if (col.id === 'departments') {
      return (
        <div key={col.id} className="min-w-0 lg:flex-initial lg:max-w-[230px]">
          <h4 className="text-[13px] uppercase tracking-wider text-[#EDE9E0]/70 mb-4 font-semibold">
            {col.title || content?.departmentsHeading || 'Departments'}
          </h4>
          <ul className="space-y-1 sm:space-y-2 text-[13px]">
            {publishedDepartments.map(dept => (
              <li key={dept.id}>
                <SpaLink
                  href={getUnitHref(dept)}
                  onNavigate={onNavigate}
                  className="min-h-[44px] sm:min-h-0 flex items-center text-[13px] text-[#EDE9E0]/80 hover:text-[#25CDB6] transition-colors text-left cursor-pointer leading-snug whitespace-normal break-words"
                >
                  {dept.name}
                </SpaLink>
              </li>
            ))}
          </ul>
        </div>
      );
    }

    if (col.id === 'sectors') {
      return (
        <div key={col.id} className="min-w-0 lg:flex-initial lg:max-w-[230px]">
          <h4 className="text-[13px] uppercase tracking-wider text-[#EDE9E0]/70 mb-4 font-semibold">
            {col.title || content?.sectorsHeading || 'Sectors'}
          </h4>
          <ul className="space-y-1 sm:space-y-2 text-[13px]">
            {publishedSectors.map(sector => (
              <li key={sector.id}>
                <SpaLink
                  href={getUnitHref(sector)}
                  onNavigate={onNavigate}
                  className="min-h-[44px] sm:min-h-0 flex items-center text-[13px] text-[#EDE9E0]/80 hover:text-[#25CDB6] transition-colors text-left cursor-pointer leading-snug whitespace-normal break-words"
                >
                  {sector.name}
                </SpaLink>
              </li>
            ))}
          </ul>
        </div>
      );
    }

    if (col.id === 'community') {
      return (
        <div key={col.id} className="min-w-0 lg:flex-initial">
          <h4 className="text-[13px] uppercase tracking-wider text-[#EDE9E0]/70 mb-4 font-semibold">
            {col.title || content?.communityHeading || 'Community'}
          </h4>
          <ul className="space-y-1 sm:space-y-2.5 text-[13px]">
            {links.map(item => {
              const Icon = item.icon;
              return (
                <li key={item.id}>
                  <a
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={item.ariaLabel}
                    className="min-h-[44px] sm:min-h-0 text-[#EDE9E0]/80 hover:text-[#25CDB6] transition-colors inline-flex items-center gap-2.5 group"
                  >
                    <Icon
                      size={16}
                      className="text-[#EDE9E0]/70 group-hover:text-[#25CDB6] transition-colors shrink-0"
                    />
                    <span>{item.name}</span>
                    <ArrowUpRight className="w-3 h-3 opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                  </a>
                </li>
              );
            })}
          </ul>
        </div>
      );
    }

    // Legal / custom column
    const customLinks = (col.links || []).filter(l => (l.url || '').toLowerCase() !== '/login');
    return (
      <div key={col.id} className="min-w-0 lg:flex-initial">
        <h4 className="text-[13px] uppercase tracking-wider text-[#EDE9E0]/70 mb-4 font-semibold">
          {col.title || 'Legal'}
        </h4>
        <ul className="space-y-1 sm:space-y-2.5 text-[13px]">
          {customLinks.map((item, idx) => {
            const openNewTab = Boolean(item.newTab || item.isExternal);
            return (
              <li key={`${item.url}-${idx}`}>
                <SpaLink
                  href={item.url}
                  external={item.isExternal}
                  target={openNewTab ? '_blank' : undefined}
                  rel={openNewTab ? 'noopener noreferrer' : undefined}
                  onNavigate={onNavigate}
                  className="min-h-[44px] sm:min-h-0 inline-flex items-center text-[#EDE9E0]/80 hover:text-[#EDE9E0] transition-colors cursor-pointer"
                >
                  {item.label}
                </SpaLink>
              </li>
            );
          })}
        </ul>
      </div>
    );
  };

  return (
    <footer className="bg-[#031D1C] border-t border-[#EDE9E0]/10 text-[#EDE9E0] pt-16 pb-12 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:flex lg:flex-row lg:items-start lg:justify-between gap-10 lg:gap-8 mb-12 sm:mb-16">
          {/* Brand Column */}
          <div className="sm:col-span-2 lg:w-[270px] lg:shrink-0 space-y-5">
            <SpaLink
              href="/"
              onNavigate={onNavigate}
              className="flex items-center gap-3.5 text-left focus:outline-none group cursor-pointer w-fit"
            >
              <div className="w-12 h-12 rounded-full overflow-hidden shadow-lg transition-transform duration-300 group-hover:scale-105">
                <img
                  src={logoUrl || '/drawing1.png'}
                  alt={`${siteName} Logo`}
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <span className="text-xl font-bold tracking-tight text-[#EDE9E0] group-hover:text-[#25CDB6] transition-colors">
                {siteName}
              </span>
            </SpaLink>

            <p className="text-sm text-[#EDE9E0]/80 max-w-sm leading-relaxed">
              {blurb}
            </p>

            <p className="text-sm font-serif italic text-[#CA7952]">
              {tagline}
            </p>

            {showContactEmail && (
              <div className="pt-2 space-y-2">
                <a
                  href={`mailto:${contactEmail}`}
                  className="inline-flex items-center gap-2 text-sm text-[#25CDB6] hover:underline min-h-[44px] sm:min-h-0"
                >
                  <Mail className="w-4 h-4 shrink-0" />
                  <span className="break-all">{contactEmail}</span>
                </a>
                {organizationAddress && organizationAddress.trim() && (
                  <div className="flex items-start gap-2 text-[13px] text-[#EDE9E0]/75">
                    <MapPin className="w-3.5 h-3.5 shrink-0 mt-0.5 text-[#D0A873]" />
                    <span>{organizationAddress}</span>
                  </div>
                )}
              </div>
            )}
          </div>

          {orderedColumns.map(renderColumn)}
        </div>

        <div className="pt-8 border-t border-[#EDE9E0]/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[13px] text-[#EDE9E0]/70">
          <p>{copyrightText}</p>
          <div className="flex items-center gap-4">
            <span className="text-[#CA7952]">{tagline}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
