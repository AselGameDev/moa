import React from 'react';
import { LayoutGrid, List as ListIcon, RotateCcw } from 'lucide-react';
import { PortalSearchInput } from './PortalSearchInput';

export interface PortalFilterOption {
  value: string;
  label: string;
}

export interface PortalFilterSelectConfig {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: PortalFilterOption[];
  disabled?: boolean;
}

export interface PortalFilterBarProps {
  search: string;
  onSearchChange: (val: string) => void;
  searchPlaceholder?: string;
  filters?: PortalFilterSelectConfig[];
  sortValue?: string;
  onSortChange?: (val: string) => void;
  sortOptions?: PortalFilterOption[];
  viewMode?: 'table' | 'cards';
  onViewModeChange?: (mode: 'table' | 'cards') => void;
  hasActiveFilters?: boolean;
  onResetFilters?: () => void;
  rightSlot?: React.ReactNode;
  className?: string;
}

export const PortalFilterBar: React.FC<PortalFilterBarProps> = ({
  search,
  onSearchChange,
  searchPlaceholder = 'Search...',
  filters = [],
  sortValue,
  onSortChange,
  sortOptions = [],
  viewMode,
  onViewModeChange,
  hasActiveFilters = false,
  onResetFilters,
  rightSlot,
  className = ''
}) => {
  return (
    <div
      className={`p-3 rounded-2xl bg-[#031D1C]/80 border border-white/10 flex flex-wrap items-center gap-2.5 ${className}`}
    >
      <PortalSearchInput
        value={search}
        onChange={onSearchChange}
        placeholder={searchPlaceholder}
        className="w-full sm:w-64 lg:flex-1 lg:min-w-[200px] lg:max-w-sm"
      />

      {filters.map(filter => (
        <select
          key={filter.id}
          value={filter.value}
          disabled={filter.disabled}
          onChange={e => filter.onChange(e.target.value)}
          aria-label={filter.label}
          className="h-9 px-3 rounded-xl bg-[#06302F] border border-white/12 hover:border-white/20 focus:border-[#25CDB6]/60 text-xs text-[#EDE9E0] font-medium focus:outline-none cursor-pointer disabled:opacity-50"
        >
          {filter.options.map(opt => (
            <option key={opt.value} value={opt.value} className="bg-[#031D1C] text-[#EDE9E0]">
              {opt.label}
            </option>
          ))}
        </select>
      ))}

      {sortOptions.length > 0 && onSortChange && (
        <select
          value={sortValue}
          onChange={e => onSortChange(e.target.value)}
          aria-label="Sort by"
          className="h-9 px-3 rounded-xl bg-[#06302F] border border-white/12 hover:border-white/20 focus:border-[#25CDB6]/60 text-xs text-[#EDE9E0] font-medium focus:outline-none cursor-pointer"
        >
          {sortOptions.map(opt => (
            <option key={opt.value} value={opt.value} className="bg-[#031D1C] text-[#EDE9E0]">
              {opt.label}
            </option>
          ))}
        </select>
      )}

      {hasActiveFilters && onResetFilters && (
        <button
          type="button"
          onClick={onResetFilters}
          className="h-9 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-[#EDE9E0]/80 inline-flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset</span>
        </button>
      )}

      <div className="flex items-center gap-2 ml-auto">
        {rightSlot}

        {viewMode && onViewModeChange && (
          <div
            className="inline-flex items-center p-0.5 rounded-xl bg-[#06302F] border border-white/10"
            role="group"
            aria-label="View mode"
          >
            <button
              type="button"
              onClick={() => onViewModeChange('table')}
              aria-label="Table view"
              aria-pressed={viewMode === 'table'}
              className={`h-8 px-2.5 rounded-lg inline-flex items-center gap-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-[#17A491] text-[#06302F]'
                  : 'text-[#EDE9E0]/65 hover:text-white'
              }`}
            >
              <ListIcon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Table</span>
            </button>
            <button
              type="button"
              onClick={() => onViewModeChange('cards')}
              aria-label="Cards view"
              aria-pressed={viewMode === 'cards'}
              className={`h-8 px-2.5 rounded-lg inline-flex items-center gap-1.5 text-xs font-semibold transition-colors cursor-pointer ${
                viewMode === 'cards'
                  ? 'bg-[#17A491] text-[#06302F]'
                  : 'text-[#EDE9E0]/65 hover:text-white'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Cards</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
