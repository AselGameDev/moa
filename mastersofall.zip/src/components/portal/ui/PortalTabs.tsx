import React from 'react';

export interface PortalTabItem<T extends string = string> {
  id: T;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  badge?: string | number | null;
}

export interface PortalTabsProps<T extends string = string> {
  items: PortalTabItem<T>[];
  activeId: T;
  onChange: (id: T) => void;
  ariaLabel?: string;
  className?: string;
}

export function PortalTabs<T extends string = string>({
  items,
  activeId,
  onChange,
  ariaLabel = 'Section navigation',
  className = ''
}: PortalTabsProps<T>) {
  return (
    <div
      className={`flex items-center gap-1.5 p-1 bg-[#031D1C] rounded-2xl border border-white/10 w-full overflow-x-auto no-scrollbar text-xs ${className}`}
      role="tablist"
      aria-label={ariaLabel}
    >
      {items.map(tab => {
        const Icon = tab.icon;
        const isActive = tab.id === activeId;
        const hasBadge = tab.badge !== undefined && tab.badge !== null && tab.badge !== '';
        return (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={isActive}
            onClick={() => onChange(tab.id)}
            className={`flex-1 min-w-fit h-9 px-3.5 rounded-xl font-bold inline-flex items-center justify-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
              isActive
                ? 'bg-[#17A491] text-[#06302F] shadow-sm'
                : 'text-[#EDE9E0]/65 hover:text-white hover:bg-white/5'
            }`}
          >
            {Icon && <Icon className="w-3.5 h-3.5 shrink-0" />}
            <span>{tab.label}</span>
            {hasBadge && (
              <span
                className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold tabular-nums ${
                  isActive ? 'bg-[#06302F]/20 text-[#06302F]' : 'bg-white/10 text-[#EDE9E0]/75'
                }`}
              >
                {tab.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
