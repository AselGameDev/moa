import { CORE_AND_SYSTEM_PAGES } from '../../src/shared/pageRegistry';
import type {
  FooterColumn,
  NavigationItem,
  SiteContent,
  SiteSettings,
  WebsiteFooterColumnConfig,
  WebsitePageMeta,
  WebsiteState
} from '../../src/types/index';

export function buildDefaultHeaderMenu(): NavigationItem[] {
  return [
    { id: 'nav-home', label: 'Home', path: '/', pageId: 'home', visible: true, isCore: true, newTab: false },
    { id: 'nav-about', label: 'About', path: '/about', pageId: 'about', visible: true, isCore: true, newTab: false },
    { id: 'nav-departments', label: 'Departments', path: '/departments', pageId: 'departments', visible: true, isCore: true, newTab: false },
    { id: 'nav-projects', label: 'Projects', path: '/projects', pageId: 'projects', visible: true, isCore: true, newTab: false },
    { id: 'nav-products', label: 'Products', path: '/products', pageId: 'products', visible: true, isCore: true, newTab: false },
    { id: 'nav-contact', label: 'Contact', path: '/contact', pageId: 'contact', visible: true, isCore: true, newTab: false }
  ];
}

export function buildDefaultFooterColumns(): WebsiteFooterColumnConfig[] {
  return [
    {
      id: 'explore',
      title: 'Explore',
      visible: true,
      kind: 'auto-header',
      sameAsHeader: true,
      links: []
    },
    {
      id: 'departments',
      title: 'Departments',
      visible: true,
      kind: 'auto-departments'
    },
    {
      id: 'sectors',
      title: 'Sectors',
      visible: true,
      kind: 'auto-sectors'
    },
    {
      id: 'community',
      title: 'Community',
      visible: true,
      kind: 'auto-social'
    },
    {
      id: 'legal',
      title: 'Legal',
      visible: false,
      kind: 'custom',
      links: []
    }
  ];
}

export function buildDefaultPagesMeta(nowIso = new Date().toISOString()): Record<string, WebsitePageMeta> {
  const meta: Record<string, WebsitePageMeta> = {};
  for (const pg of CORE_AND_SYSTEM_PAGES) {
    meta[pg.id] = {
      pageId: pg.id,
      seoTitle: '',
      seoDescription: '',
      seoShareImage: '',
      noindex: pg.id === 'notFound',
      lastEditedAt: nowIso,
      lastEditedByName: 'System',
      lastPublishedAt: nowIso,
      lastPublishedByName: 'System',
      version: 1
    };
  }
  return meta;
}

const CORE_PATH_TO_PAGE_ID = new Map<string, string>([
  ['/', 'home'],
  ['/home', 'home'],
  ['/about', 'about'],
  ['/departments', 'departments'],
  ['/projects', 'projects'],
  ['/products', 'products'],
  ['/contact', 'contact']
]);

export function normalizeHeaderMenuItems(items: NavigationItem[] | undefined): NavigationItem[] {
  const source = Array.isArray(items) && items.length > 0 ? items : buildDefaultHeaderMenu();
  const mapped: NavigationItem[] = [];
  const seenPaths = new Set<string>();

  for (const raw of source) {
    if (!raw || typeof raw !== 'object') continue;
    let pathVal = typeof raw.path === 'string' ? raw.path.trim() : '';
    if (!pathVal) continue;
    const lower = pathVal.toLowerCase();
    if (lower === '/login' || lower === '/signin' || lower === '/admin' || lower === '/portal') {
      continue;
    }
    if (lower === '/home' || pathVal === '/') {
      pathVal = '/';
    }
    const normLower = pathVal.toLowerCase();
    if (seenPaths.has(normLower)) continue;
    seenPaths.add(normLower);

    const corePageId = CORE_PATH_TO_PAGE_ID.get(normLower);
    const label =
      normLower === '/projects' && raw.label === 'Our Work'
        ? 'Projects'
        : typeof raw.label === 'string' && raw.label.trim()
        ? raw.label.trim()
        : corePageId === 'home'
        ? 'Home'
        : 'Link';

    mapped.push({
      id: typeof raw.id === 'string' && raw.id ? raw.id : `nav-${mapped.length + 1}`,
      label,
      path: pathVal,
      pageId: raw.pageId || corePageId,
      isExternal: Boolean(raw.isExternal || /^https?:\/\//i.test(pathVal)),
      newTab: Boolean(raw.newTab),
      visible: typeof raw.visible === 'boolean' ? raw.visible : true,
      isCore: Boolean(raw.isCore || corePageId)
    });
  }

  // Ensure Home ('/') always exists and is required
  if (!mapped.some(m => m.path === '/')) {
    mapped.unshift({
      id: 'nav-home',
      label: 'Home',
      path: '/',
      pageId: 'home',
      visible: true,
      isCore: true,
      newTab: false
    });
  }

  return mapped;
}

export function createDefaultWebsiteState(
  settings: SiteSettings,
  pageContent: SiteContent,
  nowIso = new Date().toISOString()
): WebsiteState {
  const header = normalizeHeaderMenuItems(settings.navigation);
  const legacyFooterCols: FooterColumn[] = Array.isArray(settings.footerColumns) ? settings.footerColumns : [];
  const legacyExplore = legacyFooterCols[0];
  const defaultExploreUrls = new Set(['/', '/home', '/about', '/departments', '/projects', '/products', '/contact']);
  const hasCustomExplore =
    Boolean(legacyExplore && Array.isArray(legacyExplore.links) && legacyExplore.links.length > 0) &&
    legacyExplore!.links.some(l => !defaultExploreUrls.has((l.url || '').trim().toLowerCase()));

  const columns = buildDefaultFooterColumns();
  if (legacyExplore) {
    columns[0] = {
      id: 'explore',
      title: legacyExplore.title || pageContent.footer?.exploreHeading || 'Explore',
      visible: true,
      kind: 'auto-header',
      sameAsHeader: !hasCustomExplore,
      links: (legacyExplore.links || []).map(l => ({
        ...l,
        url: l.url === '/home' ? '/' : l.url
      }))
    };
  }
  if (pageContent.footer?.departmentsHeading) {
    columns[1].title = pageContent.footer.departmentsHeading;
  }
  if (pageContent.footer?.sectorsHeading) {
    columns[2].title = pageContent.footer.sectorsHeading;
  }
  if (pageContent.footer?.communityHeading) {
    columns[3].title = pageContent.footer.communityHeading;
  }

  return {
    version: 1,
    lastPublishedAt: nowIso,
    lastPublishedById: 'system',
    lastPublishedByName: 'System',
    brandVersion: 1,
    seoVersion: 1,
    announcementVersion: 1,
    socialVersion: 1,
    sameLoaderAsPrimary:
      typeof settings.sameLoaderAsPrimary === 'boolean'
        ? settings.sameLoaderAsPrimary
        : !settings.loaderLogoUrl || settings.loaderLogoUrl === settings.moaLogoUrl,
    pagesMeta: buildDefaultPagesMeta(nowIso),
    pageDrafts: {},
    menus: {
      version: 1,
      updatedAt: nowIso,
      updatedByName: 'System',
      header,
      footer: {
        blurb: pageContent.footer?.blurb || settings.footerText || '',
        copyrightText: pageContent.footer?.copyrightSuffix || 'All rights reserved.',
        showContactEmail: true,
        columns
      }
    }
  };
}
