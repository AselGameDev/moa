import React, { useMemo, useState } from 'react';
import { CheckCircle2, Edit, Loader2, RotateCcw } from 'lucide-react';
import { Product, Project, Publication } from '../../types';
import { api } from '../../services/api';
import { PortalDrawer, PortalEmptyState, PortalStatusBadge } from './ui';

export interface ReviewQueueEntry {
  kind: 'project' | 'publication' | 'product';
  id: string;
  title: string;
  authorName: string;
  updatedAt: string;
  isRevision: boolean;
  summary?: string;
}

export interface ContentReviewDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  projects: Project[];
  publications: Publication[];
  products: Product[];
  canPublish: boolean;
  onOpenEditor: (kind: 'project' | 'publication' | 'product', id: string) => void;
  onReviewed: () => Promise<void>;
}

export const ContentReviewDrawer: React.FC<ContentReviewDrawerProps> = ({
  isOpen,
  onClose,
  projects,
  publications,
  products,
  canPublish,
  onOpenEditor,
  onReviewed
}) => {
  const [comments, setComments] = useState<Record<string, string>>({});
  const [busyKey, setBusyKey] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const queueItems = useMemo<ReviewQueueEntry[]>(() => {
    const entries: ReviewQueueEntry[] = [];

    for (const p of projects) {
      if (p.deletedAt) continue;
      if (p.publicationStatus === 'Pending Review' || p.pendingRevision) {
        entries.push({
          kind: 'project',
          id: p.id,
          title: p.title,
          authorName: p.pendingRevision?.submittedByName || p.authorName,
          updatedAt: p.pendingRevision?.submittedAt || p.updatedAt,
          isRevision: Boolean(p.pendingRevision),
          summary: p.pendingRevision?.summary || p.shortDescription
        });
      }
    }

    for (const pub of publications) {
      if (pub.deletedAt) continue;
      if (pub.publicationStatus === 'Pending Review' || pub.pendingRevision) {
        entries.push({
          kind: 'publication',
          id: pub.id,
          title: pub.title,
          authorName: pub.pendingRevision?.submittedByName || pub.authorName,
          updatedAt: pub.pendingRevision?.submittedAt || pub.updatedAt,
          isRevision: Boolean(pub.pendingRevision),
          summary: pub.pendingRevision?.summary || pub.authors
        });
      }
    }

    for (const prod of products) {
      if (prod.deletedAt) continue;
      if (prod.publicationStatus === 'Pending Review' || prod.pendingRevision) {
        entries.push({
          kind: 'product',
          id: prod.id,
          title: prod.name,
          authorName: prod.pendingRevision?.submittedByName || prod.authorName,
          updatedAt: prod.pendingRevision?.submittedAt || prod.updatedAt,
          isRevision: Boolean(prod.pendingRevision),
          summary: prod.pendingRevision?.summary || prod.tagline
        });
      }
    }

    return entries.sort((a, b) => (Date.parse(b.updatedAt) || 0) - (Date.parse(a.updatedAt) || 0));
  }, [projects, publications, products]);

  const handleAction = async (
    item: ReviewQueueEntry,
    action: 'approved' | 'requested_changes'
  ) => {
    const key = `${item.kind}:${item.id}`;
    const comment = comments[key]?.trim() || undefined;
    setBusyKey(key);
    setError(null);
    try {
      if (item.kind === 'project') {
        await api.reviewProject(item.id, { action, comment });
      } else if (item.kind === 'publication') {
        await api.reviewPublication(item.id, { action, comment });
      } else {
        await api.reviewProduct(item.id, { action, comment });
      }
      await onReviewed();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Review action failed.');
    } finally {
      setBusyKey(null);
    }
  };

  return (
    <PortalDrawer
      isOpen={isOpen}
      onClose={onClose}
      title="Review Queue"
      subtitle="Pending submissions and live revisions awaiting editorial approval."
      headerBadge={
        <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#D0A873]/15 border border-[#D0A873]/35 text-[#D0A873] tabular-nums">
          {queueItems.length}
        </span>
      }
    >
      {error && (
        <div className="p-3 rounded-xl bg-red-950/50 border border-red-500/40 text-xs text-red-200">
          {error}
        </div>
      )}

      {queueItems.length === 0 ? (
        <PortalEmptyState
          compact
          icon={CheckCircle2}
          title="Queue is clear"
          description="All submitted projects, publications, and products have been reviewed."
        />
      ) : (
        <div className="space-y-3">
          {queueItems.map(item => {
            const key = `${item.kind}:${item.id}`;
            const isBusy = busyKey === key;
            return (
              <div
                key={key}
                className="p-4 rounded-2xl bg-[#031D1C] border border-white/10 space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-[#EDE9E0]/60">
                      <span className="uppercase tracking-wider font-semibold text-[#25CDB6]">
                        {item.kind}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{item.authorName}</span>
                    </div>
                    <h3 className="text-sm font-bold text-[#EDE9E0] mt-0.5 break-words">
                      {item.title}
                    </h3>
                    {item.summary && (
                      <p className="text-xs text-[#EDE9E0]/65 mt-1 line-clamp-2 break-words">
                        {item.summary}
                      </p>
                    )}
                  </div>
                  <PortalStatusBadge
                    status="In review"
                    labelOverride={item.isRevision ? 'Revision' : 'In review'}
                  />
                </div>

                {canPublish && (
                  <input
                    type="text"
                    placeholder="Optional reviewer note..."
                    value={comments[key] || ''}
                    onChange={e =>
                      setComments(prev => ({ ...prev, [key]: e.target.value }))
                    }
                    className="w-full h-9 px-3 rounded-xl bg-[#06302F] border border-white/10 text-xs text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]/60"
                  />
                )}

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenEditor(item.kind, item.id);
                    }}
                    className="h-8 px-3 rounded-xl bg-white/8 hover:bg-white/12 border border-white/10 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Edit className="w-3.5 h-3.5" />
                    <span>Open in editor</span>
                  </button>

                  {canPublish && (
                    <>
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => void handleAction(item, 'requested_changes')}
                        className="h-8 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 text-xs font-semibold text-[#D0A873] inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Request changes</span>
                      </button>
                      <button
                        type="button"
                        disabled={isBusy}
                        onClick={() => void handleAction(item, 'approved')}
                        className="h-8 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50 ml-auto"
                      >
                        {isBusy ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        )}
                        <span>Approve &amp; Publish</span>
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </PortalDrawer>
  );
};
