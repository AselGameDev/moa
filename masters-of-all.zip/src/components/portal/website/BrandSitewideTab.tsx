import React, { useEffect, useMemo, useState } from 'react';
import {
  RotateCcw,
  Image as ImageIcon,
  Check,
  AlertCircle,
  Plus,
  Trash2,
  MoveUp,
  MoveDown,
  GripVertical,
  Eye,
  EyeOff,
  ExternalLink,
  AlertTriangle
} from 'lucide-react';
import {
  AnnouncementBarConfig,
  MediaAsset,
  SocialLink,
  WebsiteOverviewResponse
} from '../../../types';
import { api, HttpError } from '../../../services/api';
import { isHttpUrl, isSafeUrl } from '../../../shared/url';
import { MediaPicker } from '../../MediaPicker';
import { FloatingSaveBar } from '../FloatingSaveBar';

interface BrandSitewideTabProps {
  overview: WebsiteOverviewResponse;
  onDirtyChange?: (dirty: boolean) => void;
  onSaved: () => Promise<void>;
}

type BrandAssetKey = 'moaLogoUrl' | 'rddLogoUrl' | 'loaderLogoUrl' | 'faviconUrl' | 'shareImageUrl';

const DEFAULT_BRAND_URLS: Record<BrandAssetKey, string> = {
  moaLogoUrl: '/drawing1.png',
  rddLogoUrl: '/5320.jpg',
  loaderLogoUrl: '/drawing1.png',
  faviconUrl: '/drawing1.png',
  shareImageUrl: ''
};

function extractFilename(url: string, mediaAssets: MediaAsset[]): string {
  if (!url) return 'None selected';
  const asset = mediaAssets.find(m => m.url === url);
  if (asset?.name) return asset.name;
  const clean = url.split('?')[0].split('/').pop();
  return clean || url;
}

function formatBytes(bytes?: number): string {
  if (!bytes || !Number.isFinite(bytes)) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export const BrandSitewideTab: React.FC<BrandSitewideTabProps> = ({
  overview,
  onDirtyChange,
  onSaved
}) => {
  const brand = overview?.brand || {
    version: 1,
    moaLogoUrl: DEFAULT_BRAND_URLS.moaLogoUrl,
    rddLogoUrl: DEFAULT_BRAND_URLS.rddLogoUrl,
    loaderLogoUrl: DEFAULT_BRAND_URLS.loaderLogoUrl,
    sameLoaderAsPrimary: true,
    faviconUrl: DEFAULT_BRAND_URLS.faviconUrl,
    shareImageUrl: ''
  };
  const overviewAnnouncement = overview?.announcement || {
    version: 1,
    enabled: false,
    text: '',
    linkUrl: '',
    linkLabel: '',
    startDate: '',
    endDate: ''
  };
  const overviewSocial = overview?.social || {
    version: 1,
    links: []
  };

  const [mediaAssets, setMediaAssets] = useState<MediaAsset[]>([]);
  const [dimensions, setDimensions] = useState<Record<string, { w: number; h: number }>>({});

  // 1. Brand state
  const [moaLogoUrl, setMoaLogoUrl] = useState(brand.moaLogoUrl || DEFAULT_BRAND_URLS.moaLogoUrl);
  const [rddLogoUrl, setRddLogoUrl] = useState(brand.rddLogoUrl || DEFAULT_BRAND_URLS.rddLogoUrl);
  const [loaderLogoUrl, setLoaderLogoUrl] = useState(brand.loaderLogoUrl || DEFAULT_BRAND_URLS.loaderLogoUrl);
  const [sameLoaderAsPrimary, setSameLoaderAsPrimary] = useState(Boolean(brand.sameLoaderAsPrimary));
  const [faviconUrl, setFaviconUrl] = useState(brand.faviconUrl || DEFAULT_BRAND_URLS.faviconUrl);
  const [shareImageUrl, setShareImageUrl] = useState(brand.shareImageUrl || '');
  const [pickerTarget, setPickerTarget] = useState<BrandAssetKey | null>(null);

  const [brandMsg, setBrandMsg] = useState<{ type: 'ok' | 'err'; text: string; conflict?: boolean } | null>(null);

  // 2. Announcement bar state
  const [announcement, setAnnouncement] = useState<AnnouncementBarConfig>({
    enabled: Boolean(overviewAnnouncement.enabled),
    text: overviewAnnouncement.text || '',
    linkUrl: overviewAnnouncement.linkUrl || '',
    linkLabel: overviewAnnouncement.linkLabel || '',
    startDate: (overviewAnnouncement.startDate || '').slice(0, 10),
    endDate: (overviewAnnouncement.endDate || overviewAnnouncement.expiresAt || '').slice(0, 10)
  });
  const [annMsg, setAnnMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // 3. Social channels state
  const [socialLinks, setSocialLinks] = useState<SocialLink[]>(
    Array.isArray(overviewSocial.links) ? overviewSocial.links : []
  );
  const [dragSocialIdx, setDragSocialIdx] = useState<number | null>(null);
  const [newPlatform, setNewPlatform] = useState('LinkedIn');
  const [newUrl, setNewUrl] = useState('');
  const [socialMsg, setSocialMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [savingAll, setSavingAll] = useState(false);

  useEffect(() => {
    api
      .getMedia()
      .then(m => setMediaAssets(Array.isArray(m) ? m : []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    setMoaLogoUrl(brand.moaLogoUrl || DEFAULT_BRAND_URLS.moaLogoUrl);
    setRddLogoUrl(brand.rddLogoUrl || DEFAULT_BRAND_URLS.rddLogoUrl);
    setLoaderLogoUrl(brand.loaderLogoUrl || DEFAULT_BRAND_URLS.loaderLogoUrl);
    setSameLoaderAsPrimary(Boolean(brand.sameLoaderAsPrimary));
    setFaviconUrl(brand.faviconUrl || DEFAULT_BRAND_URLS.faviconUrl);
    setShareImageUrl(brand.shareImageUrl || '');
  }, [
    brand.version,
    brand.moaLogoUrl,
    brand.rddLogoUrl,
    brand.loaderLogoUrl,
    brand.sameLoaderAsPrimary,
    brand.faviconUrl,
    brand.shareImageUrl
  ]);

  useEffect(() => {
    setAnnouncement({
      enabled: Boolean(overviewAnnouncement.enabled),
      text: overviewAnnouncement.text || '',
      linkUrl: overviewAnnouncement.linkUrl || '',
      linkLabel: overviewAnnouncement.linkLabel || '',
      startDate: (overviewAnnouncement.startDate || '').slice(0, 10),
      endDate: (overviewAnnouncement.endDate || overviewAnnouncement.expiresAt || '').slice(0, 10)
    });
  }, [
    overviewAnnouncement.version,
    overviewAnnouncement.enabled,
    overviewAnnouncement.text,
    overviewAnnouncement.linkUrl,
    overviewAnnouncement.linkLabel,
    overviewAnnouncement.startDate,
    overviewAnnouncement.endDate,
    overviewAnnouncement.expiresAt
  ]);

  useEffect(() => {
    setSocialLinks(Array.isArray(overviewSocial.links) ? overviewSocial.links : []);
  }, [overviewSocial.version, overviewSocial.links]);

  const brandDirty = useMemo(() => {
    const baseLoader = brand.sameLoaderAsPrimary
      ? brand.moaLogoUrl || DEFAULT_BRAND_URLS.moaLogoUrl
      : brand.loaderLogoUrl || DEFAULT_BRAND_URLS.loaderLogoUrl;
    const currLoader = sameLoaderAsPrimary ? moaLogoUrl : loaderLogoUrl;
    return (
      moaLogoUrl !== (brand.moaLogoUrl || DEFAULT_BRAND_URLS.moaLogoUrl) ||
      rddLogoUrl !== (brand.rddLogoUrl || DEFAULT_BRAND_URLS.rddLogoUrl) ||
      currLoader !== baseLoader ||
      sameLoaderAsPrimary !== Boolean(brand.sameLoaderAsPrimary) ||
      faviconUrl !== (brand.faviconUrl || DEFAULT_BRAND_URLS.faviconUrl) ||
      shareImageUrl !== (brand.shareImageUrl || '')
    );
  }, [brand, moaLogoUrl, rddLogoUrl, loaderLogoUrl, sameLoaderAsPrimary, faviconUrl, shareImageUrl]);

  const annDirty = useMemo(() => {
    return (
      Boolean(announcement.enabled) !== Boolean(overviewAnnouncement.enabled) ||
      announcement.text !== (overviewAnnouncement.text || '') ||
      (announcement.linkUrl || '') !== (overviewAnnouncement.linkUrl || '') ||
      (announcement.linkLabel || '') !== (overviewAnnouncement.linkLabel || '') ||
      (announcement.startDate || '') !== (overviewAnnouncement.startDate || '').slice(0, 10) ||
      (announcement.endDate || '') !==
        (overviewAnnouncement.endDate || overviewAnnouncement.expiresAt || '').slice(0, 10)
    );
  }, [announcement, overviewAnnouncement]);

  const socialDirty = useMemo(() => {
    const base = Array.isArray(overviewSocial.links) ? overviewSocial.links : [];
    return JSON.stringify(socialLinks) !== JSON.stringify(base);
  }, [socialLinks, overviewSocial.links]);

  const isDirty = brandDirty || annDirty || socialDirty;

  useEffect(() => {
    onDirtyChange?.(isDirty);
    if (!isDirty) return;
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isDirty, onDirtyChange]);

  const setBrandField = (key: BrandAssetKey, url: string) => {
    setBrandMsg(null);
    if (key === 'moaLogoUrl') setMoaLogoUrl(url);
    if (key === 'rddLogoUrl') setRddLogoUrl(url);
    if (key === 'loaderLogoUrl') setLoaderLogoUrl(url);
    if (key === 'faviconUrl') setFaviconUrl(url);
    if (key === 'shareImageUrl') setShareImageUrl(url);
  };

  const getBrandField = (key: BrandAssetKey): string => {
    if (key === 'moaLogoUrl') return moaLogoUrl;
    if (key === 'rddLogoUrl') return rddLogoUrl;
    if (key === 'loaderLogoUrl') return sameLoaderAsPrimary ? moaLogoUrl : loaderLogoUrl;
    if (key === 'faviconUrl') return faviconUrl;
    return shareImageUrl;
  };

  const handleAddSocialChannel = () => {
    const plat = newPlatform.trim();
    const url = newUrl.trim();
    if (!plat || !isHttpUrl(url)) {
      setSocialMsg({ type: 'err', text: 'Enter a valid platform name and an http:// or https:// URL.' });
      return;
    }
    setSocialMsg(null);
    setSocialLinks(prev => [
      ...prev,
      {
        id: `soc-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        platform: plat,
        icon: plat.toLowerCase().replace(/[^a-z0-9]/g, ''),
        url,
        visible: true
      }
    ]);
    setNewUrl('');
  };

  const moveSocial = (fromIdx: number, toIdx: number) => {
    if (toIdx < 0 || toIdx >= socialLinks.length || fromIdx === toIdx) return;
    setSocialLinks(prev => {
      const next = [...prev];
      const [moved] = next.splice(fromIdx, 1);
      next.splice(toIdx, 0, moved);
      return next;
    });
  };

  const handleDiscardAll = () => {
    setMoaLogoUrl(brand.moaLogoUrl || DEFAULT_BRAND_URLS.moaLogoUrl);
    setRddLogoUrl(brand.rddLogoUrl || DEFAULT_BRAND_URLS.rddLogoUrl);
    setLoaderLogoUrl(brand.loaderLogoUrl || DEFAULT_BRAND_URLS.loaderLogoUrl);
    setSameLoaderAsPrimary(Boolean(brand.sameLoaderAsPrimary));
    setFaviconUrl(brand.faviconUrl || DEFAULT_BRAND_URLS.faviconUrl);
    setShareImageUrl(brand.shareImageUrl || '');
    setAnnouncement({
      enabled: Boolean(overviewAnnouncement.enabled),
      text: overviewAnnouncement.text || '',
      linkUrl: overviewAnnouncement.linkUrl || '',
      linkLabel: overviewAnnouncement.linkLabel || '',
      startDate: (overviewAnnouncement.startDate || '').slice(0, 10),
      endDate: (overviewAnnouncement.endDate || overviewAnnouncement.expiresAt || '').slice(0, 10)
    });
    setSocialLinks(Array.isArray(overviewSocial.links) ? overviewSocial.links : []);
    setBrandMsg(null);
    setAnnMsg(null);
    setSocialMsg(null);
  };

  const handleSaveAll = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setBrandMsg(null);
    setAnnMsg(null);
    setSocialMsg(null);

    if (annDirty) {
      if (announcement.linkUrl && !isSafeUrl(announcement.linkUrl.trim())) {
        setAnnMsg({ type: 'err', text: 'Announcement link URL must use http(s) or start with /.' });
        return;
      }
      if (announcement.startDate && announcement.endDate && announcement.endDate < announcement.startDate) {
        setAnnMsg({ type: 'err', text: 'End date must be on or after start date.' });
        return;
      }
    }

    if (socialDirty) {
      for (const s of socialLinks) {
        if (!s.platform.trim() || !isHttpUrl(s.url)) {
          setSocialMsg({ type: 'err', text: `"${s.platform || 'Channel'}" must have a valid https:// or http:// URL.` });
          return;
        }
      }
    }

    setSavingAll(true);
    let savedAny = false;
    try {
      if (brandDirty) {
        try {
          await api.updateWebsiteBrand({
            version: brand.version,
            moaLogoUrl,
            rddLogoUrl,
            loaderLogoUrl: sameLoaderAsPrimary ? moaLogoUrl : loaderLogoUrl,
            sameLoaderAsPrimary,
            faviconUrl,
            shareImageUrl
          });
          setBrandMsg({ type: 'ok', text: 'Brand identity assets committed to database.' });
          savedAny = true;
        } catch (err) {
          setBrandMsg({
            type: 'err',
            text: err instanceof Error ? err.message : 'Failed to save brand assets.',
            conflict: err instanceof HttpError && err.status === 409
          });
          return;
        }
      }

      if (annDirty) {
        try {
          await api.updateWebsiteAnnouncement({
            version: overviewAnnouncement.version,
            enabled: announcement.enabled,
            text: announcement.text,
            linkUrl: announcement.linkUrl?.trim() || '',
            linkLabel: announcement.linkLabel?.trim() || '',
            startDate: announcement.startDate || '',
            endDate: announcement.endDate || ''
          });
          setAnnMsg({ type: 'ok', text: 'Announcement bar saved to database.' });
          savedAny = true;
        } catch (err) {
          setAnnMsg({ type: 'err', text: err instanceof Error ? err.message : 'Failed to save announcement bar.' });
          return;
        }
      }

      if (socialDirty) {
        try {
          await api.updateWebsiteSocial({
            version: overviewSocial.version,
            links: socialLinks
          });
          setSocialMsg({ type: 'ok', text: 'Social channels saved to database.' });
          savedAny = true;
        } catch (err) {
          setSocialMsg({ type: 'err', text: err instanceof Error ? err.message : 'Failed to save social channels.' });
          return;
        }
      }

      if (savedAny) {
        await onSaved();
      }
    } finally {
      setSavingAll(false);
    }
  };

  const renderAssetCard = (
    key: BrandAssetKey,
    title: string,
    guidance: string,
    options?: {
      isFavicon?: boolean;
      isShare?: boolean;
      disabled?: boolean;
      extraHeader?: React.ReactNode;
    }
  ) => {
    const url = getBrandField(key);
    const asset = mediaAssets.find(m => m.url === url);
    const sizeStr = formatBytes(asset?.size);
    const dim = dimensions[key];
    const shareRatioWarn =
      options?.isShare && dim && dim.h > 0 && Math.abs(dim.w / dim.h - 1200 / 630) > 0.35;

    return (
      <div className="p-4 rounded-xl bg-[#06302F] border border-white/10 flex flex-col justify-between gap-3 text-xs">
        <div className="space-y-2.5">
          <div className="flex items-start justify-between gap-2">
            <div>
              <span className="font-bold text-[#EDE9E0] block">{title}</span>
              <span className="text-[11px] text-[#EDE9E0]/55">{guidance}</span>
            </div>
          </div>

          {options?.extraHeader}

          {/* Visual Preview */}
          {options?.isFavicon ? (
            <div className="p-3 rounded-lg bg-[#031D1C] border border-white/10 flex items-center gap-4">
              {url ? (
                <>
                  <div className="flex items-center gap-2">
                    <img
                      src={url}
                      alt="16x16 favicon preview"
                      onLoad={e => {
                        const w = e.currentTarget.naturalWidth;
                        const h = e.currentTarget.naturalHeight;
                        setDimensions(prev => ({
                          ...prev,
                          [key]: { w, h }
                        }));
                      }}
                      className="w-4 h-4 object-contain"
                    />
                    <span className="text-[10px] font-mono text-[#EDE9E0]/50">16×16</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <img src={url} alt="32x32 favicon preview" className="w-8 h-8 object-contain" />
                    <span className="text-[10px] font-mono text-[#EDE9E0]/50">32×32</span>
                  </div>
                </>
              ) : (
                <span className="text-[#EDE9E0]/45">No favicon set</span>
              )}
            </div>
          ) : (
            <div
              className={`rounded-lg bg-[#031D1C] border border-white/10 flex items-center justify-center overflow-hidden ${
                options?.isShare ? 'aspect-[1200/630] w-full' : 'h-24 p-3'
              }`}
            >
              {url ? (
                <img
                  src={url}
                  alt={title}
                  onLoad={e => {
                    const w = e.currentTarget.naturalWidth;
                    const h = e.currentTarget.naturalHeight;
                    setDimensions(prev => ({
                      ...prev,
                      [key]: { w, h }
                    }));
                  }}
                  className={options?.isShare ? 'w-full h-full object-cover' : 'max-h-full max-w-full object-contain'}
                />
              ) : (
                <div className="flex flex-col items-center gap-1 text-[#EDE9E0]/40">
                  <ImageIcon className="w-5 h-5" />
                  <span className="text-[11px]">No image selected</span>
                </div>
              )}
            </div>
          )}

          {/* Metadata readout */}
          <div className="text-[11px] text-[#EDE9E0]/65 space-y-0.5">
            <p className="truncate font-medium text-[#EDE9E0]">
              {extractFilename(url, mediaAssets)}
              {sizeStr ? ` · ${sizeStr}` : ''}
            </p>
            {dim && (
              <p className="font-mono text-[10px] text-[#EDE9E0]/50">
                Detected: {dim.w}×{dim.h}px
              </p>
            )}
            {shareRatioWarn && (
              <p className="text-[#D0A873] inline-flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 shrink-0" />
                <span>Aspect ratio differs from recommended 1200×630 (1.91:1).</span>
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 pt-2 border-t border-white/10">
          <button
            type="button"
            disabled={options?.disabled}
            onClick={() => setPickerTarget(key)}
            className="flex-1 h-8 px-3 rounded-lg bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold cursor-pointer disabled:opacity-40"
          >
            Change
          </button>
          <button
            type="button"
            disabled={options?.disabled || url === DEFAULT_BRAND_URLS[key]}
            onClick={() => setBrandField(key, DEFAULT_BRAND_URLS[key])}
            className="h-8 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0]/80 font-semibold inline-flex items-center gap-1 cursor-pointer disabled:opacity-40"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset</span>
          </button>
        </div>
      </div>
    );
  };

  const activeError =
    brandMsg?.type === 'err'
      ? brandMsg.text
      : annMsg?.type === 'err'
      ? annMsg.text
      : socialMsg?.type === 'err'
      ? socialMsg.text
      : null;

  return (
    <div className={`space-y-6 ${isDirty ? 'pb-24' : ''}`}>
      {/* 1. Brand Assets */}
      <section className="rounded-2xl bg-[#031D1C] border border-white/10 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-[#EDE9E0]">Brand Visual Identity</h2>
            <p className="text-xs text-[#EDE9E0]/60">
              Select logos, favicon, and social share graphics directly from the Media Library.
            </p>
          </div>
        </div>

        {brandMsg && (
          <div
            className={`p-3 rounded-xl border text-xs flex items-center justify-between gap-2 ${
              brandMsg.type === 'err'
                ? 'bg-red-950/60 border-red-500/40 text-red-200'
                : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
            }`}
          >
            <div className="flex items-center gap-2">
              {brandMsg.type === 'err' ? <AlertCircle className="w-4 h-4" /> : <Check className="w-4 h-4" />}
              <span>{brandMsg.text}</span>
            </div>
            {brandMsg.conflict && (
              <button
                type="button"
                onClick={() => void onSaved()}
                className="px-2.5 py-1 rounded bg-white/10 font-bold text-white cursor-pointer"
              >
                Reload latest
              </button>
            )}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {renderAssetCard('moaLogoUrl', 'Primary Logo', 'Navbar & institutional emblem')}
          {renderAssetCard('rddLogoUrl', 'RDD Logo', 'Research & Development Division crest')}
          {renderAssetCard('loaderLogoUrl', 'Loading-screen Logo', 'Animated preloader emblem', {
            disabled: sameLoaderAsPrimary,
            extraHeader: (
              <label className="inline-flex items-center gap-2 text-[11px] font-semibold text-[#25CDB6] cursor-pointer">
                <input
                  type="checkbox"
                  checked={sameLoaderAsPrimary}
                  onChange={e => setSameLoaderAsPrimary(e.target.checked)}
                  className="w-3.5 h-3.5 accent-[#25CDB6]"
                />
                <span>Same as primary logo</span>
              </label>
            )
          })}
          {renderAssetCard('faviconUrl', 'Favicon', 'Square PNG/ICO (512×512 recommended)', {
            isFavicon: true
          })}
          {renderAssetCard('shareImageUrl', 'Default Share Image', 'OpenGraph card (1200×630)', {
            isShare: true
          })}
        </div>
      </section>

      {/* 2. Announcement Bar */}
      <form
        onSubmit={e => void handleSaveAll(e)}
        className="rounded-2xl bg-[#031D1C] border border-white/10 p-5 space-y-4 text-xs"
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-[#EDE9E0]">Floating Announcement Bar</h2>
            <p className="text-xs text-[#EDE9E0]/60">
              Site-wide public callout banner with optional schedule window.
            </p>
          </div>
          <label className="inline-flex items-center gap-2 font-bold text-[#EDE9E0] cursor-pointer">
            <input
              type="checkbox"
              checked={announcement.enabled}
              onChange={e => setAnnouncement(prev => ({ ...prev, enabled: e.target.checked }))}
              className="w-4 h-4 accent-[#25CDB6]"
            />
            <span>{announcement.enabled ? 'Enabled' : 'Disabled'}</span>
          </label>
        </div>

        {annMsg && (
          <div
            className={`p-3 rounded-xl border flex items-center gap-2 ${
              annMsg.type === 'err'
                ? 'bg-red-950/60 border-red-500/40 text-red-200'
                : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
            }`}
          >
            {annMsg.type === 'err' ? <AlertCircle className="w-4 h-4" /> : <Check className="w-4 h-4" />}
            <span>{annMsg.text}</span>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-2">
            <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Announcement Message</label>
            <input
              type="text"
              value={announcement.text}
              onChange={e => setAnnouncement(prev => ({ ...prev, text: e.target.value }))}
              placeholder="Applications open for the Autumn 2026 Fellowship."
              className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
            />
          </div>
          <div>
            <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Link Label (optional)</label>
            <input
              type="text"
              value={announcement.linkLabel || ''}
              onChange={e => setAnnouncement(prev => ({ ...prev, linkLabel: e.target.value }))}
              placeholder="Read announcement"
              className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
            />
          </div>
          <div>
            <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Link URL (optional)</label>
            <input
              type="text"
              value={announcement.linkUrl || ''}
              onChange={e => setAnnouncement(prev => ({ ...prev, linkUrl: e.target.value }))}
              placeholder="/projects or https://..."
              className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 font-mono text-[#EDE9E0]"
            />
          </div>
          <div>
            <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Start Date (optional)</label>
            <input
              type="date"
              value={announcement.startDate || ''}
              onChange={e => setAnnouncement(prev => ({ ...prev, startDate: e.target.value }))}
              className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
            />
          </div>
          <div>
            <label className="block text-[#EDE9E0]/75 font-semibold mb-1">End Date (optional)</label>
            <input
              type="date"
              value={announcement.endDate || ''}
              onChange={e => setAnnouncement(prev => ({ ...prev, endDate: e.target.value }))}
              className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
            />
          </div>
        </div>

        {/* Live Floating Announcement Preview */}
        {announcement.text.trim() && (
          <div className="p-3 rounded-xl bg-[#06302F] border border-white/10 space-y-1.5">
            <span className="text-[10px] uppercase tracking-wider font-bold text-[#EDE9E0]/45 block">
              Live Banner Preview {announcement.enabled ? '' : '(currently disabled)'}
            </span>
            <div className="px-4 py-2 rounded-full bg-[#17A491] text-[#031D1C] font-semibold inline-flex flex-wrap items-center gap-2 shadow">
              <span>{announcement.text}</span>
              {announcement.linkLabel && (
                <span className="underline font-bold">{announcement.linkLabel} →</span>
              )}
            </div>
          </div>
        )}
      </form>

      {/* 3. Social Channels */}
      <section className="rounded-2xl bg-[#031D1C] border border-white/10 p-5 space-y-4 text-xs">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-[#EDE9E0]">Official Social Channels</h2>
            <p className="text-xs text-[#EDE9E0]/60">
              Reorder channels or toggle visibility for the public Footer and Contact page.
            </p>
          </div>
        </div>

        {socialMsg && (
          <div
            className={`p-3 rounded-xl border flex items-center gap-2 ${
              socialMsg.type === 'err'
                ? 'bg-red-950/60 border-red-500/40 text-red-200'
                : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
            }`}
          >
            {socialMsg.type === 'err' ? <AlertCircle className="w-4 h-4" /> : <Check className="w-4 h-4" />}
            <span>{socialMsg.text}</span>
          </div>
        )}

        <div className="space-y-2.5">
          {socialLinks.map((link, idx) => (
            <div
              key={link.id}
              draggable
              onDragStart={() => setDragSocialIdx(idx)}
              onDragOver={e => e.preventDefault()}
              onDrop={() => {
                if (dragSocialIdx !== null) moveSocial(dragSocialIdx, idx);
                setDragSocialIdx(null);
              }}
              onDragEnd={() => setDragSocialIdx(null)}
              className="p-3 rounded-xl bg-[#06302F] border border-white/10 flex flex-wrap items-center gap-2.5"
            >
              <span className="text-[#EDE9E0]/40 cursor-grab">
                <GripVertical className="w-4 h-4" />
              </span>
              <button
                type="button"
                disabled={idx === 0}
                onClick={() => moveSocial(idx, idx - 1)}
                className="p-1 rounded bg-white/5 hover:bg-white/10 disabled:opacity-30 cursor-pointer"
              >
                <MoveUp className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                disabled={idx === socialLinks.length - 1}
                onClick={() => moveSocial(idx, idx + 1)}
                className="p-1 rounded bg-white/5 hover:bg-white/10 disabled:opacity-30 cursor-pointer"
              >
                <MoveDown className="w-3.5 h-3.5" />
              </button>

              <input
                type="text"
                value={link.platform}
                onChange={e =>
                  setSocialLinks(prev =>
                    prev.map((s, i) => (i === idx ? { ...s, platform: e.target.value, icon: e.target.value.toLowerCase() } : s))
                  )
                }
                placeholder="Platform"
                className="w-32 bg-[#031D1C] border border-white/10 rounded-lg px-2.5 py-1.5 font-semibold text-[#EDE9E0]"
              />
              <input
                type="url"
                value={link.url}
                onChange={e =>
                  setSocialLinks(prev => prev.map((s, i) => (i === idx ? { ...s, url: e.target.value } : s)))
                }
                placeholder="https://..."
                className={`flex-1 min-w-[180px] bg-[#031D1C] border rounded-lg px-3 py-1.5 font-mono text-[#EDE9E0] ${
                  isHttpUrl(link.url) ? 'border-white/10' : 'border-red-500/60'
                }`}
              />

              <button
                type="button"
                onClick={() =>
                  setSocialLinks(prev =>
                    prev.map((s, i) => (i === idx ? { ...s, visible: s.visible === false } : s))
                  )
                }
                className={`px-2.5 py-1.5 rounded-lg border font-semibold inline-flex items-center gap-1 cursor-pointer ${
                  link.visible !== false
                    ? 'bg-[#25CDB6]/15 border-[#25CDB6]/30 text-[#25CDB6]'
                    : 'bg-white/5 border-white/10 text-[#EDE9E0]/55'
                }`}
              >
                {link.visible !== false ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                <span>{link.visible !== false ? 'Visible' : 'Hidden'}</span>
              </button>

              {isHttpUrl(link.url) && (
                <a
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#25CDB6]"
                  title="Test link"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}

              <button
                type="button"
                onClick={() => setSocialLinks(prev => prev.filter((_, i) => i !== idx))}
                aria-label={`Remove ${link.platform}`}
                className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-300 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>

        <div className="pt-2 border-t border-white/10 flex flex-wrap items-center gap-2">
          <select
            value={newPlatform}
            onChange={e => setNewPlatform(e.target.value)}
            className="h-9 bg-[#06302F] border border-white/10 rounded-xl px-3 text-[#EDE9E0]"
          >
            <option value="LinkedIn">LinkedIn</option>
            <option value="GitHub">GitHub</option>
            <option value="X">X</option>
            <option value="Instagram">Instagram</option>
            <option value="YouTube">YouTube</option>
            <option value="Discord">Discord</option>
            <option value="Custom">Custom</option>
          </select>
          <input
            type="url"
            value={newUrl}
            onChange={e => setNewUrl(e.target.value)}
            placeholder="https://linkedin.com/company/..."
            className="flex-1 min-w-[200px] h-9 bg-[#06302F] border border-white/10 rounded-xl px-3 font-mono text-[#EDE9E0]"
          />
          <button
            type="button"
            onClick={handleAddSocialChannel}
            className="h-9 px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[#25CDB6] font-bold inline-flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Channel</span>
          </button>
        </div>
      </section>

      <FloatingSaveBar
        visible={isDirty}
        saving={savingAll}
        error={activeError}
        title="Unsaved brand & site-wide changes"
        subtitle="Save brand identity, announcement bar, and channel updates."
        onDiscard={handleDiscardAll}
        onSave={() => void handleSaveAll()}
      />

      <MediaPicker
        isOpen={pickerTarget !== null}
        onClose={() => setPickerTarget(null)}
        onSelect={asset => {
          if (pickerTarget) setBrandField(pickerTarget, asset.url);
          setPickerTarget(null);
        }}
        allowedTypes={['image']}
        currentUrl={pickerTarget ? getBrandField(pickerTarget) : undefined}
        title="Select Brand Asset"
      />
    </div>
  );
};
