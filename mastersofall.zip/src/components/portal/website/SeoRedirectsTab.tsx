import React, { useEffect, useMemo, useState } from 'react';
import {
  Check,
  AlertCircle,
  ExternalLink,
  Plus,
  Trash2,
  ArrowRight,
  Search,
  Edit3,
  AlertTriangle
} from 'lucide-react';
import { RedirectRule, RedirectTestResult, WebsiteOverviewResponse, WebsitePageListEntry } from '../../../types';
import { api, HttpError } from '../../../services/api';
import { formatSeoTitle, validateSeoTitleTemplate } from '../../../shared/pageRegistry';
import { isSafeUrl } from '../../../shared/url';
import {
  PortalConfirmDialog,
  PortalEmptyState,
  PortalFloatingSaveBar,
  PortalSearchInput,
  PortalSection,
  PortalStatusBadge,
  PortalTable,
  PortalTableColumn
} from '../ui';

interface SeoRedirectsTabProps {
  overview: WebsiteOverviewResponse;
  canAccessBrand: boolean;
  onDirtyChange?: (dirty: boolean) => void;
  onOpenPageSeoDrawer: (pageId: string) => void;
  onOpenBrandTab: () => void;
  onSaved: () => Promise<void>;
}

export const SeoRedirectsTab: React.FC<SeoRedirectsTabProps> = ({
  overview,
  canAccessBrand,
  onDirtyChange,
  onOpenPageSeoDrawer,
  onOpenBrandTab,
  onSaved
}) => {
  const [titleTemplate, setTitleTemplate] = useState(overview.seo.titleTemplate || '{page} · {site}');
  const [description, setDescription] = useState(overview.seo.description || '');
  const [sitemapEnabled, setSitemapEnabled] = useState(overview.seo.sitemapEnabled);
  const [robotsEnabled, setRobotsEnabled] = useState(overview.seo.robotsEnabled);
  const [savingSeo, setSavingSeo] = useState(false);
  const [seoMsg, setSeoMsg] = useState<{ type: 'ok' | 'err'; text: string; conflict?: boolean } | null>(null);

  const [pageSeoSearch, setPageSeoSearch] = useState('');
  const [redirectSearch, setRedirectSearch] = useState('');

  const [fromPath, setFromPath] = useState('');
  const [toPath, setToPath] = useState('');
  const [ruleType, setRuleType] = useState<'301' | '302'>('301');
  const [addingRedirect, setAddingRedirect] = useState(false);
  const [redirectMsg, setRedirectMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const [testPath, setTestPath] = useState('');
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<RedirectTestResult | null>(null);

  const [confirmClearAuto, setConfirmClearAuto] = useState(false);
  const [clearingAuto, setClearingAuto] = useState(false);

  useEffect(() => {
    setTitleTemplate(overview.seo.titleTemplate || '{page} · {site}');
    setDescription(overview.seo.description || '');
    setSitemapEnabled(overview.seo.sitemapEnabled);
    setRobotsEnabled(overview.seo.robotsEnabled);
  }, [overview.seo]);

  const templateErr = validateSeoTitleTemplate(titleTemplate);
  const sampleTitle = formatSeoTitle(titleTemplate, 'About', overview.seo.siteName);
  const autoCount = overview.redirects.filter(r => r.source === 'auto').length;

  const seoDirty = useMemo(() => {
    return (
      titleTemplate !== (overview.seo.titleTemplate || '{page} · {site}') ||
      description !== (overview.seo.description || '') ||
      sitemapEnabled !== overview.seo.sitemapEnabled ||
      robotsEnabled !== overview.seo.robotsEnabled
    );
  }, [titleTemplate, description, sitemapEnabled, robotsEnabled, overview.seo]);

  useEffect(() => {
    onDirtyChange?.(seoDirty);
    if (!seoDirty) return;
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [seoDirty, onDirtyChange]);

  const filteredSeoPages = useMemo(() => {
    const q = pageSeoSearch.trim().toLowerCase();
    if (!q) return overview.pages;
    return overview.pages.filter(pg =>
      `${pg.name} ${pg.path} ${pg.resolvedSeoTitle}`.toLowerCase().includes(q)
    );
  }, [overview.pages, pageSeoSearch]);

  const filteredRedirects = useMemo(() => {
    const q = redirectSearch.trim().toLowerCase();
    if (!q) return overview.redirects;
    return overview.redirects.filter(r =>
      `${r.from} ${r.to} ${r.type}`.toLowerCase().includes(q)
    );
  }, [overview.redirects, redirectSearch]);

  const handleDiscardSeo = () => {
    setTitleTemplate(overview.seo.titleTemplate || '{page} · {site}');
    setDescription(overview.seo.description || '');
    setSitemapEnabled(overview.seo.sitemapEnabled);
    setRobotsEnabled(overview.seo.robotsEnabled);
    setSeoMsg(null);
  };

  const handleSaveSeo = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (templateErr) {
      setSeoMsg({ type: 'err', text: templateErr });
      return;
    }
    setSavingSeo(true);
    setSeoMsg(null);
    try {
      await api.updateWebsiteSeo({
        version: overview.seo.version,
        titleTemplate: titleTemplate.trim(),
        description,
        sitemapEnabled,
        robotsEnabled
      });
      await onSaved();
      setSeoMsg({ type: 'ok', text: 'Site-wide SEO defaults committed to database.' });
    } catch (err) {
      setSeoMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'Failed to save SEO settings.',
        conflict: err instanceof HttpError && err.status === 409
      });
    } finally {
      setSavingSeo(false);
    }
  };

  const handleAddRedirect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fromPath.trim().startsWith('/')) {
      setRedirectMsg({ type: 'err', text: 'Source path must start with /.' });
      return;
    }
    if (!isSafeUrl(toPath.trim())) {
      setRedirectMsg({ type: 'err', text: 'Destination must be a safe internal path or http/https URL.' });
      return;
    }
    setAddingRedirect(true);
    setRedirectMsg(null);
    try {
      await api.createWebsiteRedirect({
        from: fromPath.trim(),
        to: toPath.trim(),
        type: ruleType
      });
      setFromPath('');
      setToPath('');
      await onSaved();
      setRedirectMsg({ type: 'ok', text: 'Redirect rule created.' });
    } catch (err) {
      setRedirectMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'Could not create redirect rule.'
      });
    } finally {
      setAddingRedirect(false);
    }
  };

  const handleDeleteRedirect = async (id: string) => {
    setRedirectMsg(null);
    try {
      await api.deleteWebsiteRedirect(id);
      await onSaved();
      setRedirectMsg({ type: 'ok', text: 'Redirect rule deleted.' });
    } catch (err) {
      setRedirectMsg({ type: 'err', text: err instanceof Error ? err.message : 'Failed to delete redirect.' });
    }
  };

  const handleClearAutoRedirects = async () => {
    setClearingAuto(true);
    setRedirectMsg(null);
    try {
      const res = await api.deleteAutoWebsiteRedirects();
      setConfirmClearAuto(false);
      await onSaved();
      setRedirectMsg({
        type: 'ok',
        text: `Removed ${res.removed} auto-generated ${res.removed === 1 ? 'redirect' : 'redirects'}.`
      });
    } catch (err) {
      setRedirectMsg({ type: 'err', text: err instanceof Error ? err.message : 'Failed to remove auto redirects.' });
    } finally {
      setClearingAuto(false);
    }
  };

  const handleRunTest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testPath.trim()) return;
    setTesting(true);
    try {
      const res = await api.testRedirect(testPath.trim());
      setTestResult(res);
    } catch (err) {
      setRedirectMsg({ type: 'err', text: err instanceof Error ? err.message : 'Redirect test failed.' });
    } finally {
      setTesting(false);
    }
  };

  const seoPageColumns: PortalTableColumn<WebsitePageListEntry>[] = [
    {
      key: 'page',
      header: 'Page',
      render: pg => (
        <div className="py-1">
          <span className="font-bold text-[#EDE9E0] block">{pg.name}</span>
          <span className="font-mono text-[11px] text-[#25CDB6]">{pg.path}</span>
        </div>
      )
    },
    {
      key: 'title',
      header: 'Effective SEO Title',
      render: pg => <span className="max-w-xs truncate block text-[#EDE9E0]/85">{pg.resolvedSeoTitle}</span>
    },
    {
      key: 'desc',
      header: 'Meta Description',
      render: pg => {
        const descLen = (pg.seo.description || '').trim().length;
        return descLen === 0 ? (
          <PortalStatusBadge status="Hidden" labelOverride="Missing" />
        ) : (
          <span className="font-mono text-[#25CDB6]">{descLen} chars</span>
        );
      }
    },
    {
      key: 'indexing',
      header: 'Indexing',
      render: pg =>
        pg.seo.noindex || !robotsEnabled ? (
          <PortalStatusBadge status="Archived" labelOverride="noindex" />
        ) : (
          <PortalStatusBadge status="Published" labelOverride="Indexable" />
        )
    },
    {
      key: 'action',
      header: 'Action',
      align: 'right',
      render: pg => (
        <button
          type="button"
          onClick={() => onOpenPageSeoDrawer(pg.id)}
          className="h-8 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0] font-semibold inline-flex items-center gap-1 cursor-pointer"
        >
          <Edit3 className="w-3 h-3 text-[#25CDB6]" />
          <span>Edit SEO</span>
        </button>
      )
    }
  ];

  const redirectColumns: PortalTableColumn<RedirectRule>[] = [
    {
      key: 'from',
      header: 'From',
      render: rule => <span className="font-mono text-[#D0A873]">{rule.from}</span>
    },
    {
      key: 'to',
      header: 'To',
      render: rule => <span className="font-mono text-[#25CDB6]">{rule.to}</span>
    },
    {
      key: 'type',
      header: 'Type',
      render: rule => <span className="font-mono">{rule.type}</span>
    },
    {
      key: 'source',
      header: 'Source',
      render: rule => (
        <PortalStatusBadge
          status={rule.source === 'auto' ? 'In review' : 'Draft'}
          labelOverride={rule.source === 'auto' ? 'Auto' : 'Manual'}
        />
      )
    },
    {
      key: 'hits',
      header: 'Hits',
      render: rule => <span className="font-mono text-[#EDE9E0]/75 tabular-nums">{rule.hits || 0}</span>
    },
    {
      key: 'action',
      header: 'Action',
      align: 'right',
      render: rule => (
        <button
          type="button"
          onClick={() => void handleDeleteRedirect(rule.id)}
          aria-label={`Delete redirect from ${rule.from}`}
          className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-300 cursor-pointer"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      )
    }
  ];

  return (
    <div className={`space-y-6 ${seoDirty ? 'pb-24' : ''}`}>
      <PortalSection
        title="Site SEO Defaults"
        description="Global title formatting, fallback description, indexing controls, and XML sitemap status."
      >
        <form onSubmit={handleSaveSeo} className="space-y-4 text-xs">
          {seoMsg && (
            <div
              className={`p-3 rounded-xl border flex items-center justify-between gap-2 ${
                seoMsg.type === 'err'
                  ? 'bg-red-950/60 border-red-500/40 text-red-200'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              }`}
            >
              <div className="flex items-center gap-2">
                {seoMsg.type === 'err' ? <AlertCircle className="w-4 h-4" /> : <Check className="w-4 h-4" />}
                <span>{seoMsg.text}</span>
              </div>
              {seoMsg.conflict && (
                <button
                  type="button"
                  onClick={() => void onSaved()}
                  className="px-2.5 py-1 rounded bg-white/10 font-bold text-white cursor-pointer"
                >
                  Reload latest
                </button>
              )}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[#EDE9E0]/75 font-semibold">Page Title Template</label>
                  <span className="text-[11px] font-mono text-[#25CDB6]">Preview: {sampleTitle}</span>
                </div>
                <input
                  type="text"
                  value={titleTemplate}
                  onChange={e => setTitleTemplate(e.target.value)}
                  placeholder="{page} · {site}"
                  className={`w-full bg-[#06302F] border rounded-xl px-3.5 py-2.5 font-mono text-[#EDE9E0] ${
                    templateErr ? 'border-red-500/60' : 'border-white/10'
                  }`}
                />
                {templateErr && <p className="text-[11px] text-red-300 mt-1">{templateErr}</p>}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[#EDE9E0]/75 font-semibold">Default Meta Description</label>
                  <span className={`font-mono font-bold ${description.length > 160 ? 'text-amber-300' : 'text-[#25CDB6]'}`}>
                    {description.length} / 160
                  </span>
                </div>
                <textarea
                  rows={3}
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Concise institutional summary shown when pages have no custom description..."
                  className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                />
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-3.5 rounded-xl bg-[#06302F] border border-white/10 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  {overview.seo.shareImageUrl ? (
                    <img
                      src={overview.seo.shareImageUrl}
                      alt="Default share image"
                      className="w-20 h-11 rounded-lg object-cover border border-white/10 shrink-0"
                    />
                  ) : (
                    <div className="w-20 h-11 rounded-lg border border-dashed border-[#D0A873]/40 flex items-center justify-center text-[#D0A873] shrink-0">
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                  )}
                  <div className="min-w-0">
                    <span className="font-bold text-[#EDE9E0] block">Default Share Image</span>
                    <span className="text-[11px] text-[#EDE9E0]/60 block truncate">
                      {overview.seo.shareImageUrl ? 'Configured in Brand & site-wide' : 'Missing — recommended 1200×630'}
                    </span>
                  </div>
                </div>
                {canAccessBrand && (
                  <button
                    type="button"
                    onClick={onOpenBrandTab}
                    className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#25CDB6] font-bold shrink-0 cursor-pointer"
                  >
                    Change
                  </button>
                )}
              </div>

              <div className="p-3.5 rounded-xl bg-[#06302F] border border-white/10 space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <span className="font-bold text-[#EDE9E0] block">XML Sitemap</span>
                    <span className="text-[11px] text-[#EDE9E0]/60">
                      {sitemapEnabled ? `${overview.seo.sitemapUrlCount} live URLs indexed` : 'Disabled'}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <a
                      href="/sitemap.xml"
                      target="_blank"
                      rel="noreferrer"
                      className="text-[#25CDB6] hover:underline inline-flex items-center gap-1 font-semibold"
                    >
                      <span>/sitemap.xml</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                    <input
                      type="checkbox"
                      checked={sitemapEnabled}
                      onChange={e => setSitemapEnabled(e.target.checked)}
                      aria-label="Enable XML sitemap"
                      className="w-4 h-4 accent-[#25CDB6] cursor-pointer"
                    />
                  </div>
                </div>

                <label className="flex items-center justify-between gap-3 pt-2 border-t border-white/10 cursor-pointer">
                  <div>
                    <span className="font-bold text-[#EDE9E0] block">Allow search engines to index this site</span>
                    <span className="text-[11px] text-[#EDE9E0]/60">
                      Controls site-wide robots directives for public pages.
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={robotsEnabled}
                    onChange={e => setRobotsEnabled(e.target.checked)}
                    className="w-4 h-4 accent-[#25CDB6] cursor-pointer"
                  />
                </label>
              </div>

              <div className="p-3.5 rounded-xl bg-[#11191a] border border-white/10 space-y-1">
                <span className="text-[10px] uppercase tracking-wider font-bold text-[#EDE9E0]/45 block">
                  Google Search Result Preview
                </span>
                <p className="text-[11px] text-[#bdc1c6] font-mono">mastersofall.org › about</p>
                <p className="text-sm font-medium text-[#8ab4f8] line-clamp-1">{sampleTitle}</p>
                <p className="text-[11px] text-[#bdc1c6]/80 line-clamp-2">
                  {description.trim() || 'Add a default meta description to control search result snippets.'}
                </p>
              </div>
            </div>
          </div>
        </form>
      </PortalSection>

      <PortalSection
        title="Page SEO Overview"
        description="Jump straight into any page's SEO drawer to customize title overrides, descriptions, or OpenGraph images."
        actions={
          <PortalSearchInput
            value={pageSeoSearch}
            onChange={setPageSeoSearch}
            placeholder="Filter pages..."
            className="w-full sm:w-56"
          />
        }
      >
        <PortalTable
          columns={seoPageColumns}
          items={filteredSeoPages}
          getRowKey={pg => pg.id}
          emptyState={
            <PortalEmptyState
              compact
              title="No matching pages"
              description="Clear the search filter to see all pages."
            />
          }
        />
      </PortalSection>

      <PortalSection
        title="URL Redirects"
        description="Manage 301/302 rules, detect multi-hop chains or loops, and trace live path resolution."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <PortalSearchInput
              value={redirectSearch}
              onChange={setRedirectSearch}
              placeholder="Filter redirects..."
              className="w-full sm:w-48"
            />
            {autoCount > 0 && (
              <button
                type="button"
                onClick={() => setConfirmClearAuto(true)}
                className="h-9 px-3.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-xs text-red-300 font-bold cursor-pointer"
              >
                Delete all auto redirects ({autoCount})
              </button>
            )}
          </div>
        }
      >
        <div className="space-y-5 text-xs">
          {redirectMsg && (
            <div
              className={`p-3 rounded-xl border flex items-center gap-2 ${
                redirectMsg.type === 'err'
                  ? 'bg-red-950/60 border-red-500/40 text-red-200'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              }`}
            >
              {redirectMsg.type === 'err' ? <AlertCircle className="w-4 h-4" /> : <Check className="w-4 h-4" />}
              <span>{redirectMsg.text}</span>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <form onSubmit={handleAddRedirect} className="p-4 rounded-xl bg-[#06302F] border border-white/10 space-y-3">
              <span className="font-bold text-[#EDE9E0] block">Add Redirect Rule</span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <input
                  type="text"
                  value={fromPath}
                  onChange={e => setFromPath(e.target.value)}
                  placeholder="From (/old-url)"
                  aria-label="Redirect from path"
                  className="bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 font-mono text-[#EDE9E0]"
                />
                <input
                  type="text"
                  value={toPath}
                  onChange={e => setToPath(e.target.value)}
                  placeholder="To (/new-url)"
                  aria-label="Redirect to path"
                  className="bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 font-mono text-[#EDE9E0]"
                />
                <select
                  value={ruleType}
                  onChange={e => setRuleType(e.target.value as '301' | '302')}
                  aria-label="Redirect status code"
                  className="bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                >
                  <option value="301">301 (Permanent)</option>
                  <option value="302">302 (Temporary)</option>
                </select>
              </div>
              <button
                type="submit"
                disabled={addingRedirect}
                className="h-9 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{addingRedirect ? 'Adding...' : 'Add Redirect'}</span>
              </button>
            </form>

            <form onSubmit={handleRunTest} className="p-4 rounded-xl bg-[#06302F] border border-white/10 space-y-3">
              <span className="font-bold text-[#EDE9E0] block">Test a Path</span>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={testPath}
                  onChange={e => setTestPath(e.target.value)}
                  placeholder="/legacy-path"
                  aria-label="Path to test redirect"
                  className="flex-1 bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 font-mono text-[#EDE9E0]"
                />
                <button
                  type="submit"
                  disabled={testing}
                  className="h-9 px-3.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-[#EDE9E0] font-bold inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Search className="w-3.5 h-3.5 text-[#25CDB6]" />
                  <span>{testing ? 'Tracing...' : 'Trace'}</span>
                </button>
              </div>

              {testResult && (
                <div className="p-3 rounded-lg bg-[#031D1C] border border-white/10 space-y-1.5">
                  {!testResult.matched ? (
                    <p className="text-[#EDE9E0]/65">
                      No redirect matched <span className="font-mono text-[#25CDB6]">{testResult.inputPath}</span> (serves 200 direct route).
                    </p>
                  ) : (
                    <>
                      <div className="flex flex-wrap items-center gap-1.5 font-mono text-[11px]">
                        {testResult.chain.map((step, i) => (
                          <React.Fragment key={i}>
                            {i > 0 && <ArrowRight className="w-3 h-3 text-[#25CDB6]" />}
                            <span className={i === testResult.chain.length - 1 ? 'text-[#25CDB6] font-bold' : 'text-[#EDE9E0]'}>
                              {step}
                            </span>
                          </React.Fragment>
                        ))}
                        <span className="ml-auto px-2 py-0.5 rounded bg-white/10 text-[#EDE9E0]">
                          HTTP {testResult.finalStatusCode}
                        </span>
                      </div>
                      {(testResult.loopDetected || testResult.chainDetected) && (
                        <p className="text-red-300 font-semibold">
                          {testResult.loopDetected ? 'Redirect loop detected!' : 'Multi-hop redirect chain detected!'}
                        </p>
                      )}
                    </>
                  )}
                </div>
              )}
            </form>
          </div>

          <PortalTable
            columns={redirectColumns}
            items={filteredRedirects}
            getRowKey={rule => rule.id}
            emptyState={
              <PortalEmptyState
                compact
                title="No redirect rules"
                description="Add a 301 or 302 redirect above when migrating legacy URLs."
              />
            }
          />
        </div>
      </PortalSection>

      <PortalFloatingSaveBar
        visible={seoDirty}
        saving={savingSeo}
        saveDisabled={Boolean(templateErr)}
        error={seoMsg?.type === 'err' ? seoMsg.text : templateErr || null}
        title="Unsaved SEO defaults"
        subtitle="Save global title template, default description, and indexing settings."
        saveLabel="Save SEO defaults"
        onDiscard={handleDiscardSeo}
        onSave={() => void handleSaveSeo()}
      />

      <PortalConfirmDialog
        isOpen={confirmClearAuto}
        title="Delete All Auto Redirects"
        message={`Remove all ${autoCount} auto-generated redirects? Manual redirects will be preserved.`}
        confirmLabel={clearingAuto ? 'Deleting...' : 'Delete Auto Redirects'}
        isDestructive
        loading={clearingAuto}
        onCancel={() => setConfirmClearAuto(false)}
        onConfirm={() => void handleClearAutoRedirects()}
      />
    </div>
  );
};
