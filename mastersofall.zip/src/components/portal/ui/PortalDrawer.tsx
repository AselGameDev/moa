import React, { useEffect, useRef } from 'react';
import { X } from 'lucide-react';

export interface PortalDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  headerBadge?: React.ReactNode;
  headerActions?: React.ReactNode;
  footer?: React.ReactNode;
  children: React.ReactNode;
  widthClass?: string;
  blockEscape?: boolean;
  zIndexClass?: string;
  ariaLabel?: string;
}

const FOCUSABLE_SELECTOR =
  'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

export const PortalDrawer: React.FC<PortalDrawerProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  headerBadge,
  headerActions,
  footer,
  children,
  widthClass = 'max-w-[480px]',
  blockEscape = false,
  zIndexClass = 'z-[100]',
  ariaLabel
}) => {
  const panelRef = useRef<HTMLDivElement | null>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    previousFocusRef.current = document.activeElement as HTMLElement | null;

    const timer = window.setTimeout(() => {
      if (!panelRef.current) return;
      const focusables = panelRef.current.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR);
      if (focusables.length > 0) {
        focusables[0].focus();
      } else {
        panelRef.current.focus();
      }
    }, 10);

    return () => {
      window.clearTimeout(timer);
      previousFocusRef.current?.focus?.();
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !blockEscape) {
        e.preventDefault();
        onClose();
        return;
      }

      if (e.key === 'Tab' && panelRef.current) {
        const focusables = Array.from(
          panelRef.current.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)
        ).filter(el => el.offsetParent !== null || el === document.activeElement);

        if (focusables.length === 0) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];

        if (e.shiftKey) {
          if (document.activeElement === first || !panelRef.current.contains(document.activeElement)) {
            e.preventDefault();
            last.focus();
          }
        } else if (document.activeElement === last || !panelRef.current.contains(document.activeElement)) {
          e.preventDefault();
          first.focus();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, blockEscape, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className={`fixed inset-0 ${zIndexClass} flex justify-end bg-black/75 backdrop-blur-sm`}
      role="dialog"
      aria-modal="true"
      aria-label={ariaLabel || title}
      onClick={() => {
        if (!blockEscape) onClose();
      }}
    >
      <div
        ref={panelRef}
        tabIndex={-1}
        onClick={e => e.stopPropagation()}
        className={`w-full ${widthClass} h-full bg-[#06302F] border-l border-white/15 shadow-2xl flex flex-col text-[#EDE9E0] focus:outline-none`}
      >
        <div className="px-5 py-4 bg-[#031D1C] border-b border-white/10 flex items-start justify-between gap-3 shrink-0">
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-base font-bold text-[#EDE9E0] tracking-tight break-words">{title}</h2>
              {headerBadge}
            </div>
            {subtitle && (
              <p className="text-xs text-[#EDE9E0]/60 mt-0.5 break-words">{subtitle}</p>
            )}
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            {headerActions}
            <button
              type="button"
              onClick={onClose}
              aria-label="Close drawer"
              className="w-8 h-8 rounded-lg inline-flex items-center justify-center text-[#EDE9E0]/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">{children}</div>

        {footer && (
          <div className="px-5 py-3.5 bg-[#031D1C] border-t border-white/10 shrink-0">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};
