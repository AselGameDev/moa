import React, { useMemo, useState } from 'react';
import {
  Plus,
  Edit3,
  Settings,
  ExternalLink,
  Copy,
  Trash2,
  AlertTriangle,
  ArrowRight,
  X,
  Save,
  Loader2,
  FileText
} from 'lucide-react';
import {
  PageBlock,
  PageRecord,
  WebsiteOverviewResponse,
  WebsitePageListEntry
} from '../../../types';
import { api } from '../../../services/api';
import { ModularBlockEditor, createDefaultModularBlock } from '../ModularBlockEditor';
import {
  PortalConfirmDialog,
  PortalEmptyState,
  PortalFilterBar,
  PortalSection,
  PortalStatusBadge,
  PortalStatusLegend,
  PortalTable,
  PortalTableColumn,
  PortalTableRowAction
} from '../ui';
import { DrawerTabKey } from './PageSettingsDrawer';

interface PagesManagerTabProps {
  overview: WebsiteOverviewResponse;
  pages: PageRecord[];
  canEditWebsite: boolean;
  canManagePages: boolean;
  onOpenDrawer: (pageId: string, tab?: DrawerTabKey) => void;
  onEditOnSite: (path: string, sectionAnchorId?: string) => void | Promise<void>;
  onViewPage: (path: string) => void;
  onOpenAttentionSubTab: (subTab: 'pages' | 'menus' | 'brand' | 'seo', pageId?: string, drawerTab?: DrawerTabKey) => void;
  onRefresh: () => Promise<void>;
}

function formatShortDate(iso?: string): string {
  if (!iso) return 'Initial';
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return 'Initial';
  return dt.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

export const PagesManagerTab: React.FC<PagesManagerTabProps> = ({
  overview,
  pages,
  canEditWebsite,
  canManagePages,
  onOpenDrawer,
  onEditOnSite,
  onViewPage,
  onOpenAttentionSubTab,
  onRefresh
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const [createOpen, setCreateOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newSlug, setNewSlug] = useState('');
  const [newTemplate, setNewTemplate] = useState<PageRecord['template']>('Standard');
  const [newStatus, setNewStatus] = useState<PageRecord['status']>('Published');
  const [newBlocks, setNewBlocks] = useState<PageBlock[]>(() => [
    createDefaultModularBlock('heading'),
    createDefaultModularBlock('paragraph')
  ]);
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  const [actionError, setActionError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<WebsitePageListEntry | null>(null);
  const [deleting, setDeleting] = useState(false);

  const attentionItems = overview.attentionItems || [];

  const filteredPages = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (overview.pages || []).filter(p => {
      if (statusFilter !== 'all' && p.status !== statusFilter) return false;
      if (q) {
        const hay = `${p.name} ${p.path} ${p.description}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [overview.pages, search, statusFilter]);

  const standardPages = useMemo(
    () => filteredPages.filter(p => p.kind === 'core' || p.kind === 'system'),
    [filteredPages]
  );
  const customPages = useMemo(() => filteredPages.filter(p => p.kind === 'custom'), [filteredPages]);

  const handleOpenCreate = () => {
    setNewTitle('');
    setNewSlug('');
    setNewTemplate('Standard');
    setNewStatus('Published');
    setNewBlocks([createDefaultModularBlock('heading'), createDefaultModularBlock('paragraph')]);
    setCreateError(null);
    setCreateOpen(true);
  };

  const handleTitleChange = (val: string) => {
    setNewTitle(val);
    if (!newSlug || newSlug === newTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')) {
      setNewSlug(val.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, ''));
    }
  };

  const handleCreatePage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      setCreateError('Page title is required.');
      return;
    }
    const cleanSlug = (newSlug || newTitle)
      .toLowerCase()
      .replace(/[^a-z0-9-]+/g, '-')
      .replace(/^-+|-+$/g, '');
    if (!cleanSlug) {
      setCreateError('A valid URL slug is required.');
      return;
    }

    setCreating(true);
    setCreateError(null);
    try {
      const now = new Date().toISOString();
      const record: PageRecord = {
        id: `page-${Date.now()}`,
        title: newTitle.trim(),
        slug: cleanSlug,
        template: newTemplate,
        status: newStatus,
        blocks: newBlocks,
        seo: {
          title: newTitle.trim(),
          description: ''
        },
        createdAt: now,
        updatedAt: now
      };
      await api.savePage(record);
      setCreateOpen(false);
      await onRefresh();
    } catch (err) {
      setCreateError(err instanceof Error ? err.message : 'Failed to create page.');
    } finally {
      setCreating(false);
    }
  };

  const handleDuplicate = async (entry: WebsitePageListEntry) => {
    setActionError(null);
    try {
      await api.duplicateWebsitePage(entry.id);
      await onRefresh();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to duplicate page.');
    }
  };

  const handleConfirmDelete = async () => {
    if (!confirmDelete) return;
    setDeleting(true);
    setActionError(null);
    try {
      await api.deletePage(confirmDelete.id);
      setConfirmDelete(null);
      await onRefresh();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to delete page.');
    } finally {
      setDeleting(false);
    }
  };

  const getViewHref = (item: WebsitePageListEntry) => {
    if (item.kind !== 'custom') return item.path;
    const matched = pages.find(p => p.id === item.id);
    return matched
      ? `/pages/${matched.slug}${matched.status !== 'Published' ? '?preview=1' : ''}`
      : item.path;
  };

  const columns: PortalTableColumn<WebsitePageListEntry>[] = [
    {
      key: 'page',
      header: 'Page & URL',
      render: item => (
        <div className="min-w-0 max-w-md py-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold text-[#EDE9E0]">{item.name}</span>
            <span className="text-[11px] font-mono text-[#25CDB6]">{item.path}</span>
          </div>
          <p className="text-[11px] text-[#EDE9E0]/55 mt-0.5 line-clamp-1">{item.description}</p>
        </div>
      )
    },
    {
      key: 'status',
      header: 'Status',
      render: item => <PortalStatusBadge status={item.status} />
    },
    {
      key: 'edited',
      header: 'Last Edited',
      hideOnMobile: true,
      render: item => (
        <div className="text-[#EDE9E0]/70 whitespace-nowrap">
          <span className="block">{formatShortDate(item.lastEditedAt)}</span>
          <span className="text-[10px] text-[#EDE9E0]/45">{item.lastEditedByName || 'System'}</span>
        </div>
      )
    },
    {
      key: 'quickActions',
      header: 'Quick Tools',
      align: 'right',
      render: item => {
        const isCustom = item.kind === 'custom';
        const viewHref = getViewHref(item);
        return (
          <div className="inline-flex items-center justify-end gap-1.5">
            {canEditWebsite && !isCustom && (
              <button
                type="button"
                onClick={() => void onEditOnSite(item.path)}
                className="h-8 px-2.5 rounded-lg bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold inline-flex items-center gap-1 cursor-pointer"
              >
                <Edit3 className="w-3 h-3" />
                <span className="hidden sm:inline">Edit on site</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => onOpenDrawer(item.id, isCustom ? 'text' : 'general')}
              className="h-8 px-2.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0] font-semibold inline-flex items-center gap-1 cursor-pointer"
            >
              <Settings className="w-3 h-3 text-[#25CDB6]" />
              <span>Settings</span>
            </button>
            <button
              type="button"
              onClick={() => onViewPage(viewHref)}
              title="View page"
              aria-label={`View ${item.name}`}
              className="w-8 h-8 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0]/80 hover:text-[#25CDB6] inline-flex items-center justify-center cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      }
    }
  ];

  const getRowActions = (item: WebsitePageListEntry): PortalTableRowAction[] => {
    const isCustom = item.kind === 'custom';
    const viewHref = getViewHref(item);
    return [
      {
        id: 'settings',
        label: 'Page settings',
        icon: Settings,
        onClick: () => onOpenDrawer(item.id, isCustom ? 'text' : 'general')
      },
      {
        id: 'view',
        label: 'Open on site',
        icon: ExternalLink,
        onClick: () => onViewPage(viewHref)
      },
      {
        id: 'duplicate',
        label: 'Duplicate',
        icon: Copy,
        hidden: !(isCustom && canManagePages),
        onClick: () => void handleDuplicate(item)
      },
      {
        id: 'delete',
        label: 'Move to trash',
        icon: Trash2,
        destructive: true,
        hidden: !(isCustom && canManagePages),
        onClick: () => setConfirmDelete(item)
      }
    ];
  };

  const hasActiveFilters = Boolean(search.trim() || statusFilter !== 'all');

  return (
    <div className="space-y-6">
      {actionError && (
        <div className="p-3.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center justify-between gap-2">
          <span>{actionError}</span>
          <button type="button" onClick={() => setActionError(null)} className="underline cursor-pointer">
            Dismiss
          </button>
        </div>
      )}

      {attentionItems.length > 0 && (
        <PortalSection
          title={`Needs attention (${attentionItems.length})`}
          description="Configuration checks and missing metadata flagged across public routes."
          collapsible
          defaultOpen
          badge={<AlertTriangle className="w-4 h-4 text-[#D0A873]" />}
          className="border-[#D0A873]/40"
        >
          <div className="divide-y divide-white/5 -mx-4 -my-4 sm:-mx-5 sm:-my-5">
            {attentionItems.map(item => (
              <div
                key={item.id}
                className="px-4 sm:px-5 py-3 flex flex-wrap items-center justify-between gap-3 text-xs"
              >
                <div className="min-w-0">
                  <span className="font-bold text-[#EDE9E0] block">{item.title}</span>
                  <span className="text-[#EDE9E0]/65 text-[11px]">{item.message}</span>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    onOpenAttentionSubTab(
                      item.fixAction.subTab,
                      item.fixAction.pageId,
                      item.fixAction.drawerTab
                    )
                  }
                  className="h-8 px-3 rounded-lg bg-[#17A491]/15 hover:bg-[#17A491] text-[#25CDB6] hover:text-[#06302F] font-bold inline-flex items-center gap-1 cursor-pointer shrink-0 transition-colors"
                >
                  <span>Fix</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </PortalSection>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-[#EDE9E0]">Pages &amp; Routes</h2>
          <p className="text-xs text-[#EDE9E0]/60">
            Manage site pages, visibility, SEO overrides, and open the visual editor.
          </p>
        </div>

        {canManagePages && (
          <button
            type="button"
            onClick={handleOpenCreate}
            className="h-9 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] text-xs font-bold inline-flex items-center justify-center gap-1.5 shadow-md cursor-pointer shrink-0 whitespace-nowrap transition-all self-start sm:self-auto"
          >
            <Plus className="w-4 h-4 stroke-[2.5] shrink-0" />
            <span>New Page</span>
          </button>
        )}
      </div>

      <PortalFilterBar
        search={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search pages by name or URL..."
        filters={[
          {
            id: 'status',
            label: 'Filter pages by status',
            value: statusFilter,
            onChange: setStatusFilter,
            options: [
              { value: 'all', label: 'All Statuses' },
              { value: 'Published', label: 'Published' },
              { value: 'Draft changes', label: 'Draft changes' },
              { value: 'Draft', label: 'Draft' },
              { value: 'Auto-visible', label: 'Auto-visible' },
              { value: 'Hidden', label: 'Hidden' }
            ]
          }
        ]}
        hasActiveFilters={hasActiveFilters}
        onResetFilters={() => {
          setSearch('');
          setStatusFilter('all');
        }}
        rightSlot={<PortalStatusLegend statuses={['Published', 'Draft changes', 'Draft', 'Hidden']} />}
      />

      <div className="space-y-6">
        {standardPages.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-[11px] uppercase tracking-wider font-bold text-[#EDE9E0]/55 px-1">
              Pages ({standardPages.length})
            </h3>
            <PortalTable
              columns={columns}
              items={standardPages}
              getRowKey={item => item.id}
              rowActions={getRowActions}
            />
          </div>
        )}

        {customPages.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-[11px] uppercase tracking-wider font-bold text-[#EDE9E0]/55 px-1">
              Custom pages ({customPages.length})
            </h3>
            <PortalTable
              columns={columns}
              items={customPages}
              getRowKey={item => item.id}
              rowActions={getRowActions}
            />
          </div>
        )}

        {standardPages.length === 0 && customPages.length === 0 && (
          <PortalEmptyState
            icon={FileText}
            title="No pages match your filter"
            description="Adjust your search query or clear the active status filter to view all pages."
            action={
              hasActiveFilters ? (
                <button
                  type="button"
                  onClick={() => {
                    setSearch('');
                    setStatusFilter('all');
                  }}
                  className="h-9 px-4 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-bold text-[#EDE9E0] cursor-pointer"
                >
                  Clear filters
                </button>
              ) : undefined
            }
          />
        )}
      </div>

      {createOpen && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Create custom page"
          onClick={() => setCreateOpen(false)}
        >
          <form
            onSubmit={handleCreatePage}
            onClick={e => e.stopPropagation()}
            className="w-full max-w-3xl max-h-[90dvh] flex flex-col rounded-2xl bg-[#031D1C] border border-white/15 shadow-2xl overflow-hidden text-[#EDE9E0]"
          >
            <div className="px-5 py-4 border-b border-white/10 bg-[#06302F] flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold">New Custom Page</h3>
                <p className="text-xs text-[#EDE9E0]/60">Compose using shared modular blocks.</p>
              </div>
              <button
                type="button"
                onClick={() => setCreateOpen(false)}
                aria-label="Close new page modal"
                className="p-1.5 rounded-lg text-[#EDE9E0]/60 hover:text-white hover:bg-white/10 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs flex-1">
              {createError && (
                <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200">
                  {createError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Page Title</label>
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={e => handleTitleChange(e.target.value)}
                    placeholder="e.g. Open Fellowship 2026"
                    className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                  />
                </div>
                <div>
                  <label className="block text-[#EDE9E0]/75 font-semibold mb-1">URL Slug</label>
                  <input
                    type="text"
                    value={newSlug}
                    onChange={e => setNewSlug(e.target.value)}
                    placeholder="open-fellowship-2026"
                    className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 font-mono text-[#EDE9E0]"
                  />
                </div>
                <div>
                  <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Template</label>
                  <select
                    value={newTemplate}
                    onChange={e => setNewTemplate(e.target.value as PageRecord['template'])}
                    className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                  >
                    <option value="Standard">Standard</option>
                    <option value="Landing">Landing</option>
                    <option value="Article">Article</option>
                    <option value="Gallery">Gallery</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Initial Status</label>
                  <select
                    value={newStatus}
                    onChange={e => setNewStatus(e.target.value as PageRecord['status'])}
                    className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                  >
                    <option value="Published">Published</option>
                    <option value="Draft">Draft</option>
                    <option value="Hidden">Hidden</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 border-t border-white/10">
                <ModularBlockEditor blocks={newBlocks} onChange={setNewBlocks} />
              </div>
            </div>

            <div className="px-5 py-3.5 border-t border-white/10 bg-[#06302F] flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setCreateOpen(false)}
                className="h-9 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-[#EDE9E0]/80 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={creating}
                className="h-9 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                {creating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                <span>{creating ? 'Creating...' : 'Create Page'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      <PortalConfirmDialog
        isOpen={Boolean(confirmDelete)}
        title="Delete Custom Page"
        message={`Move "${confirmDelete?.name}" (${confirmDelete?.path}) to Trash? Any menus pointing to it can still be updated in Menus.`}
        confirmLabel={deleting ? 'Deleting...' : 'Move to Trash'}
        isDestructive
        loading={deleting}
        onCancel={() => setConfirmDelete(null)}
        onConfirm={() => void handleConfirmDelete()}
      />
    </div>
  );
};
