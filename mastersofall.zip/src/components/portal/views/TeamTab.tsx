import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  Users,
  Shield,
  Mail,
  Check,
  Plus,
  Copy,
  Trash2,
  X,
  UserPlus,
  KeyRound,
  AlertCircle,
  Lock,
  Ban,
  CheckCircle2,
  Pencil,
  SlidersHorizontal
} from 'lucide-react';
import { User, Department, RoleDefinition } from '../../../types';
import { api } from '../../../services/api';
import { can, PERMISSION_GROUPS, PermissionKey } from '../../../shared/permissions';
import { DeleteButton } from '../DeleteButton';
import {
  PortalConfirmDialog,
  PortalDrawer,
  PortalEmptyState,
  PortalFilterBar,
  PortalFloatingSaveBar,
  PortalPageHeader,
  PortalSection,
  PortalStatusBadge,
  PortalTabItem,
  PortalTabs,
  PortalTable,
  type PortalTableColumn,
  type PortalTableRowAction
} from '../ui';

interface TeamTabProps {
  currentSubTab: 'members' | 'roles';
  onSubTabChange: (sub: 'members' | 'roles') => void;
  requestedAction?: { action: 'add-member'; nonce: number } | null;
  onConsumeRequestedAction?: () => void;
  currentUser: User;
  roles: RoleDefinition[];
  onRolesChange?: (roles: RoleDefinition[]) => void;
  departments?: Department[];
}

export const TeamTab: React.FC<TeamTabProps> = ({
  currentSubTab,
  onSubTabChange,
  requestedAction,
  onConsumeRequestedAction,
  currentUser,
  roles: initialRoles,
  onRolesChange,
  departments = []
}) => {
  const canManageTeam = can(currentUser, 'team.manage', initialRoles);

  const [members, setMembers] = useState<User[]>([]);
  const [roles, setRoles] = useState<RoleDefinition[]>(initialRoles);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    if (initialRoles.length > 0) setRoles(initialRoles);
  }, [initialRoles]);

  // Filters & Drawer
  const [selectedMember, setSelectedMember] = useState<User | null>(null);
  const [drawerRoleId, setDrawerRoleId] = useState<string>('role-member');
  const [drawerDeptScope, setDrawerDeptScope] = useState<string[]>([]);
  const [drawerDeactivated, setDrawerDeactivated] = useState<boolean>(false);
  const [drawerEmail, setDrawerEmail] = useState('');
  const [drawerPassword, setDrawerPassword] = useState('');
  const [drawerSaving, setDrawerSaving] = useState(false);
  const [confirmDiscardMemberDrawer, setConfirmDiscardMemberDrawer] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    setDrawerRoleId(selectedMember?.roleId || 'role-member');
    setDrawerDeptScope(selectedMember?.departmentScope || []);
    setDrawerDeactivated(Boolean(selectedMember?.deactivated));
    setDrawerEmail(selectedMember?.email || '');
    setDrawerPassword('');
    setConfirmDiscardMemberDrawer(false);
  }, [
    selectedMember?.id,
    selectedMember?.roleId,
    selectedMember?.departmentScope,
    selectedMember?.deactivated,
    selectedMember?.email
  ]);

  const drawerDirty = useMemo(() => {
    if (!selectedMember) return false;
    const baseRoleId = selectedMember.roleId || 'role-member';
    const baseScope = [...(selectedMember.departmentScope || [])].sort().join(',');
    const nextScope = [...drawerDeptScope].sort().join(',');
    const baseDeactivated = Boolean(selectedMember.deactivated);
    const baseEmail = (selectedMember.email || '').trim().toLowerCase();
    const nextEmail = drawerEmail.trim().toLowerCase();
    const emailChanged = Boolean(currentUser?.isFounder) && nextEmail !== baseEmail;
    const passwordChanged = Boolean(currentUser?.isFounder) && Boolean(drawerPassword);
    return (
      drawerRoleId !== baseRoleId ||
      nextScope !== baseScope ||
      drawerDeactivated !== baseDeactivated ||
      emailChanged ||
      passwordChanged
    );
  }, [
    selectedMember,
    drawerRoleId,
    drawerDeptScope,
    drawerDeactivated,
    drawerEmail,
    drawerPassword,
    currentUser?.isFounder
  ]);

  // Add Member Modal
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [memberEmail, setMemberEmail] = useState('');
  const [memberName, setMemberName] = useState('');
  const [memberRoleId, setMemberRoleId] = useState<string>('role-member');
  const [memberDeptScope, setMemberDeptScope] = useState<string[]>([]);
  const [memberTempPassword, setMemberTempPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Role Management Modal / State
  const [showCreateRoleModal, setShowCreateRoleModal] = useState(false);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRolePerms, setNewRolePerms] = useState<PermissionKey[]>([
    'projects.create',
    'projects.editOwn',
    'media.upload'
  ]);
  const [renamingRoleId, setRenamingRoleId] = useState<string | null>(null);
  const [renameRoleValue, setRenameRoleValue] = useState('');
  const [busyRoleId, setBusyRoleId] = useState<string | null>(null);
  const [confirmDeleteRole, setConfirmDeleteRole] = useState<RoleDefinition | null>(null);

  // One-time temporary password banner
  const [oneTimeCredential, setOneTimeCredential] = useState<{
    email: string;
    password: string;
    label: string;
  } | null>(null);

  // Confirmation dialogs
  const [confirmRemoveMember, setConfirmRemoveMember] = useState<User | null>(null);

  const onRolesChangeRef = useRef(onRolesChange);
  useEffect(() => {
    onRolesChangeRef.current = onRolesChange;
  }, [onRolesChange]);

  useEffect(() => {
    if (requestedAction?.action === 'add-member') {
      setShowAddMemberModal(true);
      onConsumeRequestedAction?.();
    }
  }, [requestedAction, onConsumeRequestedAction]);

  const loadTeamData = useCallback(async () => {
    if (!canManageTeam) return;
    setLoading(true);
    setError(null);
    try {
      const [mems, rolesList] = await Promise.all([api.getMembers(), api.getRoles()]);
      setMembers(mems);
      setRoles(rolesList);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load team directory.');
    } finally {
      setLoading(false);
    }
  }, [canManageTeam]);

  useEffect(() => {
    void loadTeamData();
  }, [loadTeamData]);

  const filteredMembers = useMemo(
    () =>
      members.filter(m => {
        const matchesSearch =
          m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          m.email.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesRole = roleFilter === 'all' || m.roleId === roleFilter || m.role === roleFilter;
        return matchesSearch && matchesRole;
      }),
    [members, searchQuery, roleFilter]
  );

  const handleCopyText = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(key);
    setTimeout(() => setCopiedId(prev => (prev === key ? null : prev)), 2500);
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!memberEmail.trim()) return;
    if (!memberName.trim()) {
      setError('Full name is required when adding a team member.');
      return;
    }
    setSubmitting(true);
    setError(null);
    const chosenRole = roles.find(r => r.id === memberRoleId);
    const roleName = chosenRole?.name || 'Member';
    try {
      const created = await api.createMember({
        name: memberName.trim(),
        email: memberEmail.trim(),
        roleId: memberRoleId,
        role: roleName,
        departmentScope: memberRoleId === 'role-admin' ? [] : memberDeptScope,
        temporaryPassword: memberTempPassword.trim() || undefined
      });
      setMembers(prev => [...prev, created]);
      if (created.temporaryPassword) {
        setOneTimeCredential({
          email: created.email,
          password: created.temporaryPassword,
          label: `Account created for ${created.name}`
        });
      } else {
        setNotice(`Member ${created.name} created.`);
      }
      onSubTabChange('members');
      setShowAddMemberModal(false);
      setMemberEmail('');
      setMemberName('');
      setMemberTempPassword('');
      setMemberDeptScope([]);
      setMemberRoleId('role-member');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to create team member.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDiscardMemberDrawer = () => {
    if (!selectedMember) return;
    setDrawerRoleId(selectedMember.roleId || 'role-member');
    setDrawerDeptScope(selectedMember.departmentScope || []);
    setDrawerDeactivated(Boolean(selectedMember.deactivated));
    setDrawerEmail(selectedMember.email || '');
    setDrawerPassword('');
    setError(null);
  };

  const handleAttemptCloseMemberDrawer = () => {
    if (drawerDirty) {
      setConfirmDiscardMemberDrawer(true);
    } else {
      setSelectedMember(null);
    }
  };

  const handleSaveMemberDrawer = async () => {
    if (!selectedMember) return;
    const payload: Partial<User> & { email?: string; password?: string } = {};
    const baseRoleId = selectedMember.roleId || 'role-member';
    const baseScope = [...(selectedMember.departmentScope || [])].sort().join(',');
    const nextScope = [...drawerDeptScope].sort().join(',');

    if (drawerRoleId !== baseRoleId) {
      const chosen = roles.find(r => r.id === drawerRoleId);
      payload.roleId = drawerRoleId;
      payload.role = chosen?.name || 'Member';
    }
    if (nextScope !== baseScope) {
      payload.departmentScope = drawerDeptScope;
    }
    if (drawerDeactivated !== Boolean(selectedMember.deactivated)) {
      payload.deactivated = drawerDeactivated;
    }

    if (currentUser?.isFounder) {
      const cleanEmail = drawerEmail.trim().toLowerCase();
      const baseEmail = (selectedMember.email || '').trim().toLowerCase();
      if (cleanEmail && cleanEmail !== baseEmail) {
        payload.email = cleanEmail;
      }
      if (drawerPassword) {
        payload.password = drawerPassword;
      }
    }

    if (Object.keys(payload).length === 0) return;

    setDrawerSaving(true);
    setError(null);
    try {
      const updated = await api.updateMember(selectedMember.id, payload);
      setMembers(prev => prev.map(m => (m.id === updated.id ? updated : m)));
      setSelectedMember(updated);
      if (updated.id === currentUser.id && api.getToken()) {
        api.setSession(api.getToken()!, updated);
      }
      setDrawerPassword('');
      setNotice(`Updated member profile for ${updated.name}.`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to update member.');
    } finally {
      setDrawerSaving(false);
    }
  };

  const handleResetMemberPassword = async (member: User) => {
    setError(null);
    try {
      const res = await api.resetMemberPassword(member.id);
      setOneTimeCredential({
        email: member.email,
        password: res.temporaryPassword,
        label: `Password reset for ${member.name}`
      });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to reset member password.');
    }
  };

  const handleToggleRolePermission = async (role: RoleDefinition, perm: PermissionKey) => {
    if (role.locked || role.id === 'role-admin') return;
    const hasPerm = role.permissions.includes(perm);
    const nextPerms = hasPerm
      ? role.permissions.filter(p => p !== perm)
      : [...role.permissions, perm];
    setBusyRoleId(role.id);
    setError(null);
    try {
      const updated = await api.updateRole(role.id, { permissions: nextPerms });
      const nextRoles = roles.map(r => (r.id === updated.id ? updated : r));
      setRoles(nextRoles);
      onRolesChange?.(nextRoles);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to update role permissions.');
    } finally {
      setBusyRoleId(null);
    }
  };

  const handleSaveRoleRename = async (role: RoleDefinition) => {
    if (!renameRoleValue.trim() || role.locked) {
      setRenamingRoleId(null);
      return;
    }
    setBusyRoleId(role.id);
    setError(null);
    try {
      const updated = await api.updateRole(role.id, { name: renameRoleValue.trim() });
      const nextRoles = roles.map(r => (r.id === updated.id ? updated : r));
      setRoles(nextRoles);
      onRolesChange?.(nextRoles);
      setRenamingRoleId(null);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to rename role.');
    } finally {
      setBusyRoleId(null);
    }
  };

  const handleCreateRole = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoleName.trim()) return;
    setError(null);
    setSubmitting(true);
    try {
      const created = await api.createRole({
        name: newRoleName.trim(),
        permissions: newRolePerms
      });
      const nextRoles = [...roles, created];
      setRoles(nextRoles);
      onRolesChange?.(nextRoles);
      setShowCreateRoleModal(false);
      setNewRoleName('');
      setNotice(`Created custom role "${created.name}".`);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to create role.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleMemberDept = (deptId: string) => {
    setMemberDeptScope(prev =>
      prev.includes(deptId) ? prev.filter(id => id !== deptId) : [...prev, deptId]
    );
  };

  const tabItems: PortalTabItem<'members' | 'roles'>[] = useMemo(
    () => [
      { id: 'members', label: 'Members', icon: Users, badge: members.length },
      { id: 'roles', label: 'Roles & Permissions', icon: Shield, badge: roles.length }
    ],
    [members.length, roles.length]
  );

  const memberColumns = useMemo<PortalTableColumn<User>[]>(
    () => [
      {
        key: 'member',
        header: 'Member',
        render: member => (
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-8 h-8 rounded-xl bg-[#06302F] border border-white/12 flex items-center justify-center font-bold text-[#25CDB6] text-xs shrink-0">
              {member.name.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-[#EDE9E0] truncate">{member.name}</span>
                {member.isFounder && (
                  <span className="px-1.5 py-0.5 rounded-md text-[9px] font-mono uppercase bg-[#D0A873]/15 text-[#D0A873] border border-[#D0A873]/35">
                    Founder
                  </span>
                )}
              </div>
              <span className="text-[11px] text-[#EDE9E0]/50 font-mono block truncate">
                {member.email}
              </span>
            </div>
          </div>
        )
      },
      {
        key: 'role',
        header: 'Role',
        render: member => {
          const roleObj = roles.find(r => r.id === member.roleId);
          const displayRole = roleObj?.name || member.role;
          const isAdminRole = member.roleId === 'role-admin' || displayRole.toLowerCase() === 'admin';
          return (
            <PortalStatusBadge
              status={isAdminRole ? 'Published' : 'In review'}
              labelOverride={displayRole}
              showDot={false}
            />
          );
        }
      },
      {
        key: 'status',
        header: 'Status',
        render: member => (
          <PortalStatusBadge
            status={member.deactivated ? 'Archived' : 'Published'}
            labelOverride={member.deactivated ? 'Deactivated' : 'Active'}
          />
        )
      },
      {
        key: 'twoFactor',
        header: '2FA',
        hideOnMobile: true,
        render: member =>
          member.twoFactorEnabled ? (
            <span className="font-mono text-[11px] text-[#25CDB6] font-semibold">Enrolled</span>
          ) : (
            <span className="font-mono text-[11px] text-[#EDE9E0]/45">Off</span>
          )
      },
      {
        key: 'lastSignIn',
        header: 'Last Sign-In',
        hideOnMobile: true,
        render: member => (
          <span className="text-[#EDE9E0]/60 font-mono text-[11px] tabular-nums">
            {member.lastSignIn ? new Date(member.lastSignIn).toLocaleDateString() : 'Never'}
          </span>
        )
      }
    ],
    [roles]
  );

  if (!canManageTeam) {
    return (
      <PortalEmptyState
        icon={Lock}
        title="Team Management Restricted"
        description="Roster management and role permissions require the team management permission."
      />
    );
  }

  return (
    <div className="space-y-6">
      <PortalPageHeader
        title="Team & Governance"
        subtitle="Manage organization members, department scopes, and custom RBAC roles."
        actions={
          <button
            type="button"
            onClick={() => setShowAddMemberModal(true)}
            className="h-9 px-3.5 bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] rounded-xl text-xs font-bold inline-flex items-center justify-center gap-1.5 shadow-sm whitespace-nowrap transition-colors cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5 stroke-[2.25]" />
            <span>Add Member</span>
          </button>
        }
      />

      {error && (
        <div className="p-3.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
          <button
            type="button"
            onClick={() => setError(null)}
            className="text-red-300 hover:text-white cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {notice && (
        <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{notice}</span>
          </div>
          <button
            type="button"
            onClick={() => setNotice(null)}
            className="text-emerald-200 hover:text-white cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {oneTimeCredential && (
        <div className="p-5 rounded-2xl bg-[#031D1C] border border-amber-400/50 space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-300 text-xs font-bold">
              <KeyRound className="w-4 h-4" />
              <span>{oneTimeCredential.label} &mdash; Copy Temporary Password Now</span>
            </div>
            <button
              type="button"
              onClick={() => setOneTimeCredential(null)}
              className="text-white/50 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-[11px] text-[#EDE9E0]/70">
            This password is displayed once. The user will be prompted to replace it upon first sign-in.
          </p>
          <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-[#06302F] border border-white/10 font-mono text-xs">
            <div>
              <span className="text-[#EDE9E0]/50 mr-2">{oneTimeCredential.email}:</span>
              <span className="text-[#25CDB6] font-bold select-all">{oneTimeCredential.password}</span>
            </div>
            <button
              type="button"
              onClick={() => handleCopyText(oneTimeCredential.password, 'one-time-pw')}
              className="h-8 px-3 rounded-lg bg-[#25CDB6]/15 hover:bg-[#25CDB6]/25 text-[#25CDB6] text-xs font-sans font-bold flex items-center gap-1.5 cursor-pointer"
            >
              {copiedId === 'one-time-pw' ? (
                <Check className="w-3.5 h-3.5" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
              <span>{copiedId === 'one-time-pw' ? 'Copied' : 'Copy Password'}</span>
            </button>
          </div>
        </div>
      )}

      <PortalTabs
        items={tabItems}
        activeId={currentSubTab}
        onChange={onSubTabChange}
        ariaLabel="Team and governance sections"
      />

      {/* 1. MEMBERS SUB-TAB */}
      {currentSubTab === 'members' && (
        <div className="space-y-4">
          <PortalFilterBar
            search={searchQuery}
            onSearchChange={setSearchQuery}
            searchPlaceholder="Search by name or email..."
            filters={[
              {
                id: 'role-filter',
                label: 'Filter by role',
                value: roleFilter,
                onChange: setRoleFilter,
                options: [
                  { value: 'all', label: 'All Roles' },
                  ...roles.map(r => ({ value: r.id, label: r.name }))
                ]
              }
            ]}
            hasActiveFilters={Boolean(searchQuery.trim() || roleFilter !== 'all')}
            onResetFilters={() => {
              setSearchQuery('');
              setRoleFilter('all');
            }}
          />

          <PortalTable<User>
            columns={memberColumns}
            items={filteredMembers}
            getRowKey={m => m.id}
            loading={loading}
            error={error}
            onRetry={() => void loadTeamData()}
            onRowClick={member => setSelectedMember(member)}
            rowActions={(member): PortalTableRowAction[] => [
              {
                id: 'manage',
                label: 'Manage Member',
                icon: SlidersHorizontal,
                onClick: () => setSelectedMember(member)
              },
              {
                id: 'reset-pw',
                label: 'Reset Temp Password',
                icon: KeyRound,
                hidden: !currentUser?.isFounder,
                onClick: () => void handleResetMemberPassword(member)
              },
              {
                id: 'remove',
                label: 'Remove Member',
                icon: Trash2,
                destructive: true,
                hidden: Boolean(member.isFounder) || member.id === currentUser?.id,
                onClick: () => setConfirmRemoveMember(member)
              }
            ]}
            emptyState={
              <PortalEmptyState
                icon={Users}
                title="No matching team members"
                description="Try clearing your search or role filter, or add a new team member."
                action={
                  searchQuery || roleFilter !== 'all' ? (
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery('');
                        setRoleFilter('all');
                      }}
                      className="h-9 px-3.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-[#EDE9E0] cursor-pointer"
                    >
                      Clear filters
                    </button>
                  ) : undefined
                }
              />
            }
          />
        </div>
      )}

      {/* 2. INTERACTIVE ROLES & PERMISSIONS MATRIX */}
      {currentSubTab === 'roles' && (
        <PortalSection
          title="Live Roles & Permissions Matrix"
          description="Click any permission cell on a custom or Member role to grant or revoke Access immediately. Admin stays full-access."
          actions={
            <button
              type="button"
              onClick={() => setShowCreateRoleModal(true)}
              className="h-9 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] text-xs font-bold inline-flex items-center justify-center gap-1.5 shadow-sm whitespace-nowrap shrink-0 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>Create Custom Role</span>
            </button>
          }
        >
          <div className="rounded-xl border border-white/10 overflow-x-auto bg-[#06302F]/40">
            <table className="w-full text-left text-xs min-w-[740px]">
              <thead className="bg-[#06302F] border-b border-white/10 text-[#EDE9E0]/65 font-semibold uppercase tracking-wider font-mono text-[10px]">
                <tr>
                  <th className="py-3.5 px-4 min-w-[260px]">Permission</th>
                  {roles.map(role => {
                    const assignedCount = members.filter(m => m.roleId === role.id).length;
                    const isLocked = Boolean(role.locked || role.id === 'role-admin');
                    return (
                      <th key={role.id} className="py-3.5 px-4 text-center min-w-[140px]">
                        {renamingRoleId === role.id ? (
                          <div className="flex items-center justify-center gap-1">
                            <input
                              type="text"
                              value={renameRoleValue}
                              onChange={e => setRenameRoleValue(e.target.value)}
                              className="w-24 bg-[#031D1C] border border-[#25CDB6] rounded-lg px-2 py-1 text-xs text-[#EDE9E0] normal-case focus:outline-none"
                            />
                            <button
                              type="button"
                              onClick={() => handleSaveRoleRename(role)}
                              className="text-[#25CDB6] cursor-pointer"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center gap-1">
                            <div className="flex items-center gap-1.5">
                              <span>{role.name}</span>
                              {isLocked && <Lock className="w-3 h-3 text-[#25CDB6]" />}
                              {!role.isSystem && (
                                <>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setRenamingRoleId(role.id);
                                      setRenameRoleValue(role.name);
                                    }}
                                    className="text-white/40 hover:text-[#25CDB6] cursor-pointer"
                                    title="Rename role"
                                  >
                                    <Pencil className="w-3 h-3" />
                                  </button>
                                  <DeleteButton
                                    disabled={assignedCount > 0}
                                    onClick={() => setConfirmDeleteRole(role)}
                                    title={
                                      assignedCount > 0
                                        ? 'Reassign members before deleting role'
                                        : 'Delete role'
                                    }
                                    ariaLabel={`Delete role ${role.name}`}
                                  />
                                </>
                              )}
                            </div>
                            <span className="text-[10px] font-normal normal-case text-[#EDE9E0]/45 tabular-nums">
                              {assignedCount} member{assignedCount === 1 ? '' : 's'}
                            </span>
                          </div>
                        )}
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-[#EDE9E0]">
                {PERMISSION_GROUPS.map(group => (
                  <React.Fragment key={group.category}>
                    <tr className="bg-[#031D1C]/80">
                      <td
                        colSpan={roles.length + 1}
                        className="py-2 px-4 text-[10px] font-mono uppercase tracking-widest text-[#25CDB6] font-bold"
                      >
                        {group.category}
                      </td>
                    </tr>
                    {group.items.map(perm => (
                      <tr key={perm.key} className="hover:bg-white/[0.02] transition">
                        <td className="py-3 px-4">
                          <span className="font-semibold text-[#EDE9E0] block">{perm.label}</span>
                          <span className="text-[11px] text-[#EDE9E0]/55 block mt-0.5">
                            {perm.description}
                          </span>
                        </td>
                        {roles.map(role => {
                          const isLocked = Boolean(role.locked || role.id === 'role-admin');
                          const hasAccess = isLocked || role.permissions.includes(perm.key);
                          return (
                            <td key={role.id} className="py-3 px-4 text-center">
                              <button
                                type="button"
                                disabled={isLocked || busyRoleId === role.id}
                                onClick={() => handleToggleRolePermission(role, perm.key)}
                                className={`h-8 inline-flex items-center gap-1.5 px-3 rounded-xl text-[11px] font-bold transition ${
                                  hasAccess
                                    ? 'bg-[#17A491]/15 text-[#25CDB6] border border-[#25CDB6]/35'
                                    : 'bg-[#031D1C] text-[#EDE9E0]/55 border border-white/10 hover:text-white'
                                } ${isLocked ? 'cursor-default opacity-85' : 'cursor-pointer hover:border-[#25CDB6]/50'}`}
                              >
                                {hasAccess ? (
                                  <>
                                    <Check className="w-3 h-3" />
                                    <span>Access</span>
                                  </>
                                ) : (
                                  <>
                                    <Ban className="w-3 h-3" />
                                    <span>Restricted</span>
                                  </>
                                )}
                              </button>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </PortalSection>
      )}

      {/* MEMBER PROFILE DRAWER */}
      <PortalDrawer
        isOpen={Boolean(selectedMember)}
        onClose={handleAttemptCloseMemberDrawer}
        title={selectedMember?.name || 'Member Profile'}
        subtitle={selectedMember?.email}
        headerBadge={
          selectedMember?.isFounder ? (
            <PortalStatusBadge status="In review" labelOverride="Founder" showDot={false} />
          ) : undefined
        }
      >
        {selectedMember && (
          <div className={`space-y-5 text-xs ${drawerDirty ? 'pb-20' : ''}`}>
            <div>
              <label className="text-[#EDE9E0]/70 block mb-1.5 font-semibold">Assigned Role</label>
              <select
                value={drawerRoleId}
                disabled={Boolean(selectedMember.isFounder)}
                onChange={e => setDrawerRoleId(e.target.value)}
                className="w-full h-9 bg-[#031D1C] border border-white/12 rounded-xl px-3 text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6] cursor-pointer disabled:opacity-50"
              >
                {roles.map(r => (
                  <option key={r.id} value={r.id} className="bg-[#031D1C] text-[#EDE9E0]">
                    {r.name}
                  </option>
                ))}
              </select>
              {selectedMember.isFounder && (
                <p className="text-[11px] text-[#D0A873] mt-1.5">
                  Organization founder role is permanently protected.
                </p>
              )}
            </div>

            {drawerRoleId !== 'role-admin' && departments.length > 0 && (
              <div>
                <label className="text-[#EDE9E0]/70 block mb-1.5 font-semibold">
                  Department Editing Scope (leave unchecked for unrestricted content scope)
                </label>
                <div className="grid grid-cols-1 gap-1.5 max-h-48 overflow-y-auto no-scrollbar p-2.5 rounded-xl bg-[#031D1C] border border-white/10">
                  {departments
                    .filter(d => !d.deletedAt)
                    .map(dept => {
                      const scoped = drawerDeptScope.includes(dept.id);
                      return (
                        <label
                          key={dept.id}
                          className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-white/5 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={scoped}
                            onChange={() => {
                              setDrawerDeptScope(prev =>
                                scoped ? prev.filter(id => id !== dept.id) : [...prev, dept.id]
                              );
                            }}
                            className="accent-[#25CDB6]"
                          />
                          <span className="truncate">{dept.name}</span>
                        </label>
                      );
                    })}
                </div>
              </div>
            )}

            <div className="p-3.5 rounded-xl bg-[#031D1C] border border-white/10 flex items-center justify-between gap-3">
              <div>
                <span className="font-bold block text-[#EDE9E0]">Account Active</span>
                <span className="text-[11px] text-[#EDE9E0]/55 block mt-0.5">
                  Deactivating terminates all active sessions immediately.
                </span>
              </div>
              <button
                type="button"
                disabled={Boolean(selectedMember.isFounder) || selectedMember.id === currentUser?.id}
                onClick={() => setDrawerDeactivated(prev => !prev)}
                className={`h-8 px-3 rounded-xl text-xs font-bold transition cursor-pointer disabled:opacity-40 shrink-0 ${
                  drawerDeactivated
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                }`}
              >
                {drawerDeactivated ? 'Reactivate' : 'Deactivate'}
              </button>
            </div>

            {Boolean(currentUser?.isFounder) && (
              <form
                onSubmit={e => {
                  e.preventDefault();
                  void handleSaveMemberDrawer();
                }}
                className="p-4 rounded-2xl bg-[#031D1C] border border-[#25CDB6]/25 space-y-3"
              >
                <div className="flex items-center gap-2">
                  <KeyRound className="w-3.5 h-3.5 text-[#25CDB6]" />
                  <span className="font-bold text-[#EDE9E0]">Account Credentials (Founder Only)</span>
                </div>
                <div>
                  <label className="text-[#EDE9E0]/65 block mb-1 font-semibold">Sign-In Email</label>
                  <input
                    type="email"
                    value={drawerEmail}
                    onChange={e => setDrawerEmail(e.target.value)}
                    required
                    className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3 text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                  />
                </div>
                <div>
                  <label className="text-[#EDE9E0]/65 block mb-1 font-semibold">
                    Set New Password (optional)
                  </label>
                  <input
                    type="password"
                    value={drawerPassword}
                    onChange={e => setDrawerPassword(e.target.value)}
                    placeholder="Leave blank to keep existing password"
                    className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3 text-[#EDE9E0] placeholder-[#EDE9E0]/30 focus:outline-none focus:border-[#25CDB6]"
                  />
                </div>
              </form>
            )}

            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-2">
              {Boolean(currentUser?.isFounder) && (
                <button
                  type="button"
                  onClick={() => handleResetMemberPassword(selectedMember)}
                  className="h-9 px-3.5 rounded-xl bg-[#031D1C] hover:bg-white/10 border border-white/12 text-xs font-bold text-[#25CDB6] inline-flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>Generate Temp Password</span>
                </button>
              )}

              {!selectedMember.isFounder && selectedMember.id !== currentUser?.id && (
                <DeleteButton
                  onClick={() => setConfirmRemoveMember(selectedMember)}
                  label="Remove Member"
                  title="Remove team member"
                />
              )}
            </div>
          </div>
        )}
      </PortalDrawer>

      <PortalFloatingSaveBar
        zIndexClass="z-[110]"
        visible={Boolean(selectedMember) && drawerDirty}
        saving={drawerSaving}
        error={error}
        title="Unsaved team member changes"
        saveLabel="Save Member"
        onDiscard={handleDiscardMemberDrawer}
        onSave={() => void handleSaveMemberDrawer()}
      />

      <PortalConfirmDialog
        isOpen={confirmDiscardMemberDrawer}
        title="Discard Unsaved Changes"
        message="You have unsaved changes to this team member profile. Discard them and close the drawer?"
        confirmLabel="Discard"
        onCancel={() => setConfirmDiscardMemberDrawer(false)}
        onConfirm={() => {
          setConfirmDiscardMemberDrawer(false);
          setSelectedMember(null);
          setError(null);
        }}
      />

      {/* ADD MEMBER MODAL */}
      {showAddMemberModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-3 sm:p-4">
          <div className="w-full max-w-md max-h-[90dvh] overflow-y-auto no-scrollbar bg-[#031D1C] border border-white/15 rounded-2xl p-5 sm:p-6 shadow-2xl space-y-4 text-[#EDE9E0]">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="font-bold text-base text-[#EDE9E0]">Add Team Member</h3>
              <button
                type="button"
                onClick={() => setShowAddMemberModal(false)}
                className="p-1.5 rounded-lg text-[#EDE9E0]/50 hover:text-[#EDE9E0] hover:bg-white/5 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-[#EDE9E0]/70 block mb-1 font-semibold">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Alex Morgan"
                  value={memberName}
                  onChange={e => setMemberName(e.target.value)}
                  className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] placeholder-[#EDE9E0]/30 focus:outline-none focus:border-[#25CDB6]"
                />
              </div>

              <div>
                <label className="text-[#EDE9E0]/70 block mb-1 font-semibold">Email Address *</label>
                <input
                  type="email"
                  required
                  placeholder="collaborator@mastersofall.org"
                  value={memberEmail}
                  onChange={e => setMemberEmail(e.target.value)}
                  className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] placeholder-[#EDE9E0]/30 focus:outline-none focus:border-[#25CDB6]"
                />
              </div>

              <div>
                <label className="text-[#EDE9E0]/70 block mb-1 font-semibold">Assign Role</label>
                <select
                  value={memberRoleId}
                  onChange={e => setMemberRoleId(e.target.value)}
                  className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3 text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6] cursor-pointer"
                >
                  {roles.map(r => (
                    <option key={r.id} value={r.id} className="bg-[#031D1C]">
                      {r.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[#EDE9E0]/70 block mb-1 font-semibold">
                  Temporary Password (optional &mdash; leave blank to auto-generate)
                </label>
                <input
                  type="text"
                  value={memberTempPassword}
                  onChange={e => setMemberTempPassword(e.target.value)}
                  placeholder="Auto-generate secure 16-char password"
                  className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] placeholder-[#EDE9E0]/30 focus:outline-none focus:border-[#25CDB6]"
                />
              </div>

              {memberRoleId !== 'role-admin' && departments.length > 0 && (
                <div>
                  <label className="text-[#EDE9E0]/70 block mb-1 font-semibold">
                    Department Scope (optional)
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 max-h-32 overflow-y-auto no-scrollbar p-2.5 rounded-xl bg-[#06302F] border border-white/12">
                    {departments
                      .filter(d => !d.deletedAt)
                      .map(dept => (
                        <label
                          key={dept.id}
                          className="flex items-center gap-1.5 text-[11px] cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            checked={memberDeptScope.includes(dept.id)}
                            onChange={() => handleToggleMemberDept(dept.id)}
                            className="accent-[#25CDB6]"
                          />
                          <span className="truncate">{dept.name}</span>
                        </label>
                      ))}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setShowAddMemberModal(false)}
                  className="h-9 px-3.5 bg-white/5 hover:bg-white/10 border border-white/12 text-xs font-bold text-[#EDE9E0]/75 hover:text-white rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="h-9 px-4 bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] rounded-xl text-xs font-bold transition shadow-sm cursor-pointer disabled:opacity-50"
                >
                  {submitting ? 'Creating...' : 'Create Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CREATE CUSTOM ROLE MODAL */}
      {showCreateRoleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <form
            onSubmit={handleCreateRole}
            className="w-full max-w-lg max-h-[85vh] overflow-y-auto no-scrollbar bg-[#031D1C] border border-white/15 rounded-2xl p-6 shadow-2xl space-y-4 text-[#EDE9E0]"
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="font-bold text-base">Create Custom Role</h3>
              <button
                type="button"
                onClick={() => setShowCreateRoleModal(false)}
                className="p-1.5 rounded-lg text-white/50 hover:text-white hover:bg-white/5 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5 text-xs">
              <label className="text-[#EDE9E0]/70 font-semibold block">Role Name *</label>
              <input
                type="text"
                required
                value={newRoleName}
                onChange={e => setNewRoleName(e.target.value)}
                placeholder="e.g. Managing Editor, Department Lead..."
                className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
              />
            </div>

            <div className="space-y-3 text-xs">
              <label className="text-[#EDE9E0]/70 font-semibold block">Initial Permissions</label>
              {PERMISSION_GROUPS.map(group => (
                <div
                  key={group.category}
                  className="p-3 rounded-xl bg-[#06302F] border border-white/10 space-y-2"
                >
                  <span className="text-[10px] font-mono uppercase text-[#25CDB6] font-bold block">
                    {group.category}
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    {group.items.map(perm => (
                      <label
                        key={perm.key}
                        className="flex items-center gap-2 cursor-pointer text-[11px]"
                      >
                        <input
                          type="checkbox"
                          checked={newRolePerms.includes(perm.key)}
                          onChange={() =>
                            setNewRolePerms(prev =>
                              prev.includes(perm.key)
                                ? prev.filter(p => p !== perm.key)
                                : [...prev, perm.key]
                            )
                          }
                          className="accent-[#25CDB6]"
                        />
                        <span>{perm.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => setShowCreateRoleModal(false)}
                className="h-9 px-3.5 bg-white/5 hover:bg-white/10 border border-white/12 rounded-xl text-xs font-bold text-[#EDE9E0]/75 hover:text-white cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={submitting}
                className="h-9 px-4 bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] rounded-xl text-xs font-bold shadow-sm cursor-pointer disabled:opacity-50"
              >
                {submitting ? 'Creating...' : 'Create Role'}
              </button>
            </div>
          </form>
        </div>
      )}

      <PortalConfirmDialog
        isOpen={Boolean(confirmRemoveMember)}
        title="Remove Team Member"
        message={
          confirmRemoveMember
            ? `Permanently remove ${confirmRemoveMember.name} (${confirmRemoveMember.email}) and revoke all active sessions?`
            : ''
        }
        confirmLabel="Remove Member"
        onCancel={() => setConfirmRemoveMember(null)}
        onConfirm={async () => {
          if (!confirmRemoveMember) return;
          const target = confirmRemoveMember;
          setConfirmRemoveMember(null);
          try {
            await api.deleteMember(target.id);
            setMembers(prev => prev.filter(m => m.id !== target.id));
            if (selectedMember?.id === target.id) setSelectedMember(null);
            setNotice(`Removed ${target.name} from the Control Room.`);
          } catch (err: unknown) {
            setError(err instanceof Error ? err.message : 'Failed to remove member.');
          }
        }}
      />

      <PortalConfirmDialog
        isOpen={Boolean(confirmDeleteRole)}
        title="Delete Custom Role"
        message={
          confirmDeleteRole
            ? `Delete custom role "${confirmDeleteRole.name}"? Roles currently assigned to team members cannot be deleted.`
            : ''
        }
        confirmLabel="Delete Role"
        onCancel={() => setConfirmDeleteRole(null)}
        onConfirm={async () => {
          if (!confirmDeleteRole) return;
          const target = confirmDeleteRole;
          setConfirmDeleteRole(null);
          try {
            await api.deleteRole(target.id);
            const nextRoles = roles.filter(r => r.id !== target.id);
            setRoles(nextRoles);
            onRolesChange?.(nextRoles);
            setNotice(`Deleted role "${target.name}".`);
          } catch (err: unknown) {
            setError(err instanceof Error ? err.message : 'Failed to delete custom role.');
          }
        }}
      />
    </div>
  );
};
