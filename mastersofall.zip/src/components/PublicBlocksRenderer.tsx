import React, { useState } from 'react';
import { ArrowRight, Check, ChevronDown, Loader2, Send } from 'lucide-react';
import {
  Department,
  PageBlock,
  StoryBlock,
  StoryBlockImageContent
} from '../types';
import { api } from '../services/api';
import { parseVideoEmbed, sanitizeSafeUrl } from '../shared/url';
import { getUnitHref } from '../utils/orgHelpers';
import { DepartmentLogo } from './DepartmentLogo';
import { ScrollHierarchyTree } from './ScrollHierarchyTree';
import { SpaLink } from './SpaLink';

export interface PublicBlocksRendererProps {
  blocks?: (PageBlock | StoryBlock)[];
  departments?: Department[];
  onNavigate: (path: string) => void;
  moaLogoUrl?: string;
  rddLogoUrl?: string;
  siteName?: string;
  fallbackTitle?: string;
  className?: string;
}

const BlockContactForm: React.FC<{ heading?: string }> = ({ heading }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setErr(null);
    try {
      await api.submitContactForm({ name, email, message, formType: 'contact' });
      setDone(true);
      setName('');
      setEmail('');
      setMessage('');
    } catch (error) {
      setErr(error instanceof Error ? error.message : 'Submission failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="p-6 sm:p-8 rounded-2xl bg-[#031D1C] border border-white/10 max-w-2xl mx-auto space-y-4">
      {heading && <h3 className="text-xl font-bold text-[#EDE9E0]">{heading}</h3>}
      {done ? (
        <div className="p-4 rounded-xl bg-[#17A491]/15 border border-[#25CDB6]/40 text-sm text-[#EDE9E0] flex items-center gap-2">
          <Check className="w-4 h-4 text-[#25CDB6]" />
          <span>Thank you. Your message has been received.</span>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              type="text"
              required
              placeholder="Your name"
              value={name}
              onChange={e => setName(e.target.value)}
              className="bg-[#06302F] border border-white/15 rounded-xl px-3.5 py-2.5 text-sm text-[#EDE9E0]"
            />
            <input
              type="email"
              required
              placeholder="Email address"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="bg-[#06302F] border border-white/15 rounded-xl px-3.5 py-2.5 text-sm text-[#EDE9E0]"
            />
          </div>
          <textarea
            rows={4}
            required
            placeholder="Your message"
            value={message}
            onChange={e => setMessage(e.target.value)}
            className="w-full bg-[#06302F] border border-white/15 rounded-xl px-3.5 py-2.5 text-sm text-[#EDE9E0]"
          />
          {err && <p className="text-xs text-[#CA7952]">{err}</p>}
          <button
            type="submit"
            disabled={submitting}
            className="px-5 py-2.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold text-sm flex items-center gap-2 cursor-pointer"
          >
            {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            <span>{submitting ? 'Sending...' : 'Send Message'}</span>
          </button>
        </form>
      )}
    </div>
  );
};

export function isPageBlock(block: PageBlock | StoryBlock): block is PageBlock {
  return 'config' in block && typeof block.config === 'object' && block.config !== null;
}

export function normalizeLegacyStoryBlockToPageBlock(
  block: PageBlock | StoryBlock,
  idx = 0
): PageBlock {
  if (isPageBlock(block)) return block;

  const id = block.id || `blk-legacy-${idx}`;
  const c = block.content;
  const cObj =
    c && typeof c === 'object' && !Array.isArray(c) ? (c as Record<string, unknown>) : {};

  switch (block.type) {
    case 'heading':
      return {
        id,
        type: 'heading',
        config: {
          text: typeof c === 'string' ? c : String(cObj.text || cObj.heading || ''),
          level: Number(cObj.level || 2),
          eyebrow: String(cObj.eyebrow || ''),
          subtitle: String(cObj.subtitle || '')
        }
      };
    case 'quote':
      return {
        id,
        type: 'quote',
        config: {
          quote: typeof c === 'string' ? c : String(cObj.quote || cObj.text || ''),
          attribution: String(cObj.attribution || '')
        }
      };
    case 'image': {
      const img = cObj as StoryBlockImageContent;
      return {
        id,
        type: 'image',
        config: {
          imageUrl: typeof c === 'string' ? c : String(img.url || ''),
          alt: String(img.alt || ''),
          caption: String(img.caption || '')
        }
      };
    }
    case 'gallery':
      return {
        id,
        type: 'gallery',
        config: {
          images: Array.isArray(c) ? c.filter((u): u is string => typeof u === 'string') : []
        }
      };
    case 'video':
      return {
        id,
        type: 'video',
        config: {
          title: String(cObj.title || 'Video Showcase'),
          url: typeof c === 'string' ? c : String(cObj.url || '')
        }
      };
    case 'stats':
      return {
        id,
        type: 'numbers',
        config: {
          heading: String(cObj.heading || ''),
          items: Array.isArray(cObj.items) ? cObj.items : []
        }
      };
    case 'callout':
      return {
        id,
        type: 'paragraph',
        config: {
          heading: String(cObj.heading || ''),
          text: typeof c === 'string' ? c : String(cObj.text || ''),
          variant: 'callout'
        }
      };
    case 'divider':
      return {
        id,
        type: 'paragraph',
        config: {
          text: '',
          variant: 'divider'
        }
      };
    default:
      return {
        id,
        type: 'paragraph',
        config: {
          heading: typeof cObj.title === 'string' ? cObj.title : '',
          text: typeof c === 'string' ? c : String(cObj.text || cObj.body || '')
        }
      };
  }
}

export function normalizeBlocksForEditor(blocks?: (PageBlock | StoryBlock)[]): PageBlock[] {
  if (!Array.isArray(blocks)) return [];
  return blocks
    .filter(b => Boolean(b))
    .map((b, idx) => normalizeLegacyStoryBlockToPageBlock(b, idx))
    .filter(b => b.config?.variant !== 'divider');
}

export function isRenderableBlock(block: PageBlock | StoryBlock): boolean {
  if (!block) return false;
  if (!isPageBlock(block)) {
    if (block.type === 'divider') return true;
    if (typeof block.content === 'string') return block.content.trim().length > 0;
    if (Array.isArray(block.content)) return block.content.length > 0;
    if (block.content && typeof block.content === 'object') {
      return Object.values(block.content).some(v =>
        typeof v === 'string' ? v.trim().length > 0 : Boolean(v)
      );
    }
    return false;
  }

  const cfg = block.config || {};
  if (cfg.variant === 'divider') return true;

  switch (block.type) {
    case 'heading':
    case 'hero':
      return Boolean(
        String(cfg.text || cfg.heading || cfg.title || cfg.subtitle || '').trim()
      );
    case 'paragraph':
    case 'text':
      return Boolean(String(cfg.heading || cfg.text || cfg.body || '').trim());
    case 'image':
      return Boolean(sanitizeSafeUrl(cfg.imageUrl || cfg.url));
    case 'image-text':
      return Boolean(
        sanitizeSafeUrl(cfg.imageUrl) || String(cfg.heading || cfg.text || cfg.body || '').trim()
      );
    case 'list':
    case 'feature-cards':
    case 'cards-grid':
    case 'numbers':
    case 'stats':
    case 'links':
    case 'accordion':
      return Array.isArray(cfg.items) && cfg.items.length > 0;
    case 'quote':
      return Boolean(String(cfg.quote || cfg.text || '').trim());
    case 'gallery':
      return (
        Array.isArray(cfg.images) &&
        cfg.images.some(img => Boolean(sanitizeSafeUrl(img)))
      );
    case 'video':
      return Boolean(parseVideoEmbed(String(cfg.url || '')));
    case 'button':
      return Boolean(sanitizeSafeUrl(cfg.url || cfg.ctaUrl));
    case 'cta-band':
    case 'department-grid':
    case 'hierarchy-diagram':
    case 'contact-form':
      return true;
    default:
      return true;
  }
}

export const PublicBlocksRenderer: React.FC<PublicBlocksRendererProps> = ({
  blocks = [],
  departments = [],
  onNavigate,
  moaLogoUrl = '/drawing1.png',
  rddLogoUrl = '',
  siteName = 'Masters Of All',
  fallbackTitle = '',
  className = ''
}) => {
  const [openAcc, setOpenAcc] = useState<string | null>(null);

  const visibleBlocks = blocks.filter(isRenderableBlock);
  if (visibleBlocks.length === 0) return null;

  const renderNormalized = (block: PageBlock) => {
    const cfg = block.config || {};
    const str = (key: string, fallback = '') =>
      typeof cfg[key] === 'string' ? (cfg[key] as string) : fallback;

    if (cfg.variant === 'divider') {
      return <hr className="border-[#EDE9E0]/15 my-6" />;
    }

    if (cfg.variant === 'callout') {
      return (
        <div className="p-5 rounded-2xl bg-[#031D1C] border border-[#25CDB6]/35 text-sm sm:text-base text-[#EDE9E0]/90 leading-relaxed space-y-1.5">
          {str('heading') && (
            <h3 className="text-sm font-bold text-[#25CDB6]">{str('heading')}</h3>
          )}
          <div className="whitespace-pre-line">{str('text', str('body', ''))}</div>
        </div>
      );
    }

    switch (block.type) {
      case 'heading': {
        const level = Number(cfg.level || 2);
        const text = str('text', str('heading', fallbackTitle));
        const eyebrow = str('eyebrow');
        return (
          <div className="max-w-4xl space-y-2">
            {eyebrow && (
              <span className="text-xs uppercase tracking-widest text-[#25CDB6] font-bold block">
                {eyebrow}
              </span>
            )}
            {level === 1 ? (
              <h1 className="text-4xl sm:text-5xl font-extrabold text-[#EDE9E0] tracking-tight">
                {text}
              </h1>
            ) : level === 3 ? (
              <h3 className="text-xl sm:text-2xl font-bold text-[#EDE9E0]">{text}</h3>
            ) : (
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#EDE9E0] tracking-tight">
                {text}
              </h2>
            )}
            {str('subtitle') && (
              <p className="text-base text-[#EDE9E0]/80 leading-relaxed">{str('subtitle')}</p>
            )}
          </div>
        );
      }

      case 'paragraph':
        return (
          <div className="max-w-4xl space-y-2">
            {str('heading') && (
              <h3 className="text-xl font-bold text-[#EDE9E0]">{str('heading')}</h3>
            )}
            <div className="text-base text-[#EDE9E0]/85 leading-relaxed whitespace-pre-line">
              {str('text', str('body', ''))}
            </div>
          </div>
        );

      case 'image': {
        const imgSrc = sanitizeSafeUrl(str('imageUrl', str('url')));
        if (!imgSrc) return null;
        return (
          <figure className="max-w-5xl space-y-2">
            <div className="rounded-2xl overflow-hidden border border-white/10 bg-[#031D1C]">
              <img
                src={imgSrc}
                alt={str('alt', fallbackTitle || 'Visual asset')}
                referrerPolicy="no-referrer"
                className="w-full max-h-[540px] object-cover"
              />
            </div>
            {str('caption') && (
              <figcaption className="text-xs text-[#EDE9E0]/60 text-center">
                {str('caption')}
              </figcaption>
            )}
          </figure>
        );
      }

      case 'list': {
        const items = Array.isArray(cfg.items)
          ? (cfg.items as unknown[]).map(x => String(x || '')).filter(Boolean)
          : [];
        const ordered = Boolean(cfg.ordered);
        const Tag = ordered ? 'ol' : 'ul';
        return (
          <div className="max-w-4xl space-y-3">
            {str('heading') && (
              <h3 className="text-xl font-bold text-[#EDE9E0]">{str('heading')}</h3>
            )}
            <Tag
              className={`space-y-2 text-base text-[#EDE9E0]/85 pl-5 ${
                ordered ? 'list-decimal' : 'list-disc'
              }`}
            >
              {items.map((item, idx) => (
                <li key={idx} className="leading-relaxed">
                  {item}
                </li>
              ))}
            </Tag>
          </div>
        );
      }

      case 'feature-cards':
      case 'cards-grid': {
        const cards = Array.isArray(cfg.items)
          ? (cfg.items as Array<Record<string, unknown>>)
          : [];
        return (
          <div className="space-y-4">
            {str('heading') && (
              <h2 className="text-2xl font-bold text-[#EDE9E0]">{str('heading')}</h2>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {cards.map((c, idx) => (
                <div
                  key={idx}
                  className="p-6 rounded-2xl bg-[#031D1C] border border-white/10 space-y-2"
                >
                  <h3 className="font-bold text-lg text-[#EDE9E0]">{String(c.title || '')}</h3>
                  <p className="text-sm text-[#EDE9E0]/75 leading-relaxed">
                    {String(c.description || c.body || '')}
                  </p>
                </div>
              ))}
            </div>
          </div>
        );
      }

      case 'numbers':
      case 'stats': {
        const stats = Array.isArray(cfg.items)
          ? (cfg.items as Array<Record<string, unknown>>)
          : [];
        return (
          <div className="space-y-4">
            {str('heading') && (
              <h2 className="text-2xl font-bold text-[#EDE9E0]">{str('heading')}</h2>
            )}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {stats.map((s, idx) => (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-[#031D1C] border border-white/10 text-center"
                >
                  <span className="text-2xl sm:text-3xl font-black text-[#25CDB6] block tabular-nums">
                    {String(s.value || '')}
                  </span>
                  <span className="text-xs text-[#EDE9E0]/65 mt-1 block">
                    {String(s.label || '')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        );
      }

      case 'links': {
        const items = Array.isArray(cfg.items)
          ? (cfg.items as Array<Record<string, unknown>>)
          : [];
        return (
          <div className="max-w-3xl space-y-3">
            {str('heading') && (
              <h3 className="text-xl font-bold text-[#EDE9E0]">{str('heading')}</h3>
            )}
            <div className="flex flex-wrap gap-3">
              {items.map((item, idx) => {
                const href = sanitizeSafeUrl(item.url);
                if (!href) return null;
                return (
                  <SpaLink
                    key={idx}
                    href={href}
                    target={item.newTab ? '_blank' : undefined}
                    rel={item.newTab ? 'noopener noreferrer' : undefined}
                    onNavigate={onNavigate}
                    className="px-4 py-2.5 rounded-xl bg-[#031D1C] border border-white/15 hover:border-[#25CDB6] text-sm font-semibold text-[#25CDB6] inline-flex items-center gap-2 transition-colors"
                  >
                    <span>{String(item.label || href)}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </SpaLink>
                );
              })}
            </div>
          </div>
        );
      }

      case 'button': {
        const href = sanitizeSafeUrl(str('url', str('ctaUrl')));
        const label = str('label', str('ctaLabel', 'Learn more'));
        if (!href) return null;
        return (
          <div>
            <SpaLink
              href={href}
              target={cfg.newTab ? '_blank' : undefined}
              rel={cfg.newTab ? 'noopener noreferrer' : undefined}
              onNavigate={onNavigate}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold text-sm transition-colors"
            >
              <span>{label}</span>
              <ArrowRight className="w-4 h-4" />
            </SpaLink>
          </div>
        );
      }

      case 'hero':
        return (
          <div className="max-w-4xl space-y-4">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-[#EDE9E0] tracking-tight">
              {str('heading', str('title', fallbackTitle))}
            </h1>
            {str('subtitle') && (
              <p className="text-lg text-[#EDE9E0]/80 leading-relaxed">{str('subtitle')}</p>
            )}
            {str('ctaLabel') && str('ctaUrl') && (
              <SpaLink
                href={str('ctaUrl')}
                onNavigate={onNavigate}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold text-sm"
              >
                <span>{str('ctaLabel')}</span>
                <ArrowRight className="w-4 h-4" />
              </SpaLink>
            )}
          </div>
        );

      case 'text':
        return (
          <div className="max-w-4xl space-y-3">
            {str('heading') && (
              <h2 className="text-2xl sm:text-3xl font-bold text-[#EDE9E0]">{str('heading')}</h2>
            )}
            <div className="text-base text-[#EDE9E0]/85 leading-relaxed whitespace-pre-line">
              {str('body', str('text', ''))}
            </div>
          </div>
        );

      case 'image-text': {
        const imgSrc = sanitizeSafeUrl(str('imageUrl'));
        const imageRight = cfg.imagePosition === 'right';
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {imgSrc && (
              <div
                className={`rounded-2xl overflow-hidden border border-white/10 bg-[#031D1C] ${
                  imageRight ? 'md:order-2' : ''
                }`}
              >
                <img
                  src={imgSrc}
                  alt={str('alt', str('heading', fallbackTitle || 'Feature visual'))}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            <div className={`space-y-3 ${imageRight ? 'md:order-1' : ''}`}>
              {str('heading') && (
                <h2 className="text-2xl font-bold text-[#EDE9E0]">{str('heading')}</h2>
              )}
              <p className="text-sm sm:text-base text-[#EDE9E0]/80 leading-relaxed whitespace-pre-line">
                {str('body', str('text', ''))}
              </p>
            </div>
          </div>
        );
      }

      case 'quote':
        return (
          <blockquote className="max-w-3xl mx-auto text-center space-y-3 py-4">
            <p className="text-2xl sm:text-3xl font-serif italic text-[#EDE9E0]">
              &ldquo;{str('quote', str('text', ''))}&rdquo;
            </p>
            {str('attribution') && (
              <footer className="text-xs uppercase tracking-widest font-bold text-[#CA7952]">
                {str('attribution')}
              </footer>
            )}
          </blockquote>
        );

      case 'cta-band':
        return (
          <div className="p-8 sm:p-10 rounded-3xl bg-[#031D1C] border border-[#25CDB6]/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div className="space-y-1.5">
              <h3 className="text-2xl font-bold text-[#EDE9E0]">{str('heading', 'Get involved')}</h3>
              {str('text') && <p className="text-sm text-[#EDE9E0]/75">{str('text')}</p>}
            </div>
            {str('ctaLabel') && str('ctaUrl') && (
              <SpaLink
                href={str('ctaUrl')}
                onNavigate={onNavigate}
                className="px-6 py-3 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold text-sm inline-flex items-center gap-2 shrink-0"
              >
                <span>{str('ctaLabel')}</span>
                <ArrowRight className="w-4 h-4" />
              </SpaLink>
            )}
          </div>
        );

      case 'video': {
        const embed = parseVideoEmbed(str('url'));
        if (!embed) return null;
        return embed.kind === 'iframe' ? (
          <div className="aspect-video w-full rounded-2xl overflow-hidden border border-white/10">
            <iframe
              src={embed.src}
              title={str('title', 'Embedded video')}
              className="w-full h-full"
              sandbox="allow-scripts allow-same-origin allow-presentation"
              referrerPolicy="strict-origin-when-cross-origin"
              allowFullScreen
            />
          </div>
        ) : (
          <video src={embed.src} controls className="w-full max-h-[520px] rounded-2xl bg-black" />
        );
      }

      case 'gallery': {
        const urls = Array.isArray(cfg.images)
          ? (cfg.images as unknown[]).map(u => sanitizeSafeUrl(u)).filter(Boolean)
          : [];
        if (urls.length === 0) return null;
        return (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {urls.map((url, idx) => (
              <div
                key={idx}
                className="aspect-[4/3] rounded-2xl overflow-hidden border border-white/10 bg-[#031D1C]"
              >
                <img
                  src={url}
                  alt={`Gallery ${idx + 1}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        );
      }

      case 'accordion': {
        const items = Array.isArray(cfg.items)
          ? (cfg.items as Array<Record<string, unknown>>)
          : [];
        return (
          <div className="space-y-2 max-w-3xl mx-auto">
            {items.map((item, idx) => {
              const key = `${block.id}-${idx}`;
              const isOpen = openAcc === key;
              return (
                <div
                  key={key}
                  className="rounded-xl bg-[#031D1C] border border-white/10 overflow-hidden"
                >
                  <button
                    type="button"
                    onClick={() => setOpenAcc(isOpen ? null : key)}
                    className="w-full px-5 py-4 flex items-center justify-between text-left font-semibold text-sm text-[#EDE9E0] cursor-pointer"
                  >
                    <span>{String(item.question || item.title || '')}</span>
                    <ChevronDown
                      className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`}
                    />
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-4 text-sm text-[#EDE9E0]/75 leading-relaxed">
                      {String(item.answer || item.body || '')}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        );
      }

      case 'department-grid':
        return (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {departments
              .filter(d => d.published && !d.deletedAt)
              .map(dept => (
                <SpaLink
                  key={dept.id}
                  href={getUnitHref(dept, departments)}
                  onNavigate={onNavigate}
                  className="p-5 rounded-2xl bg-[#031D1C] border border-white/10 hover:border-[#25CDB6] transition-colors flex items-center gap-3"
                >
                  <DepartmentLogo
                    department={dept}
                    size={40}
                    fallbackMode="icon"
                    iconSize={22}
                    showBorder
                  />
                  <span className="font-bold text-sm text-[#EDE9E0]">{dept.name}</span>
                </SpaLink>
              ))}
          </div>
        );

      case 'hierarchy-diagram':
        return (
          <ScrollHierarchyTree
            departments={departments}
            onSelectUnit={unit => onNavigate(getUnitHref(unit, departments))}
            moaLogoUrl={moaLogoUrl}
            rddLogoUrl={rddLogoUrl}
            siteName={siteName}
          />
        );

      case 'contact-form':
        return <BlockContactForm heading={str('heading')} />;

      default:
        return null;
    }
  };

  return (
    <div className={`space-y-8 ${className}`}>
      {visibleBlocks.map((rawBlock, idx) => {
        const normalized = normalizeLegacyStoryBlockToPageBlock(rawBlock, idx);
        const anchorId = isPageBlock(rawBlock) ? rawBlock.sectionSettings?.anchorId : undefined;
        return (
          <div key={normalized.id || idx} id={anchorId || undefined}>
            {renderNormalized(normalized)}
          </div>
        );
      })}
    </div>
  );
};
