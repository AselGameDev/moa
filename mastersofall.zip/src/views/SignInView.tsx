import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import QRCode from 'qrcode';
import {
  Eye,
  EyeOff,
  Lock,
  Mail,
  ArrowRight,
  ShieldCheck,
  KeyRound,
  AlertCircle,
  Shield,
  User as UserIcon,
  CheckCircle2
} from 'lucide-react';
import { api } from '../services/api';
import { User } from '../types';

interface SignInViewProps {
  onSignInSuccess: (user: User) => void;
  onNavigate: (path: string) => void;
  logoUrl?: string;
  minPasswordLength?: number;
}

export const SignInView: React.FC<SignInViewProps> = ({
  onSignInSuccess,
  onNavigate,
  logoUrl = '/drawing1.png',
  minPasswordLength = 12
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [twoFactorCode, setTwoFactorCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [infoBanner, setInfoBanner] = useState<string | null>(null);
  const [needs2FA, setNeeds2FA] = useState(false);

  // Forced password change & founder profile completion state
  const [pendingUser, setPendingUser] = useState<User | null>(null);
  const [founderName, setFounderName] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [changeError, setChangeError] = useState<string | null>(null);
  const [changeLoading, setChangeLoading] = useState(false);

  // Mandatory 2FA enrollment state
  const [setup2FAUser, setSetup2FAUser] = useState<User | null>(null);
  const [setup2FAData, setSetup2FAData] = useState<{
    secret: string;
    qrDataUrl: string;
    recoveryCodes: string[];
  } | null>(null);
  const [setup2FACode, setSetup2FACode] = useState('');
  const [setup2FAError, setSetup2FAError] = useState<string | null>(null);
  const [setup2FALoading, setSetup2FALoading] = useState(false);

  // Password length minimum
  const requiredMinLen = Math.max(12, minPasswordLength || 12);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('expired') === '1') {
      setInfoBanner('Your session has expired or was invalidated. Please sign in again.');
    } else if (params.get('reset') === '1') {
      setInfoBanner(
        'Your session was ended because your account credentials, status, or permissions changed. Please sign in again.'
      );
    }
  }, []);

  const getPasswordStrength = (pass: string) => {
    let score = 0;
    if (pass.length >= requiredMinLen) score++;
    if (/[A-Z]/.test(pass)) score++;
    if (/[a-z]/.test(pass)) score++;
    if (/[0-9]/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass)) score++;
    return score;
  };

  const beginMandatory2FASetup = async (user: User) => {
    setSetup2FAUser(user);
    setSetup2FAError(null);
    setSetup2FALoading(true);
    try {
      const data = await api.setup2FA();
      const qrDataUrl = await QRCode.toDataURL(data.otpauthUri, { width: 200, margin: 1 });
      setSetup2FAData({
        secret: data.secret,
        qrDataUrl,
        recoveryCodes: data.recoveryCodes
      });
    } catch (err: unknown) {
      setSetup2FAError(err instanceof Error ? err.message : 'Failed to initialize two-factor authentication.');
    } finally {
      setSetup2FALoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please enter both your email address and password.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await api.signIn(email, password, twoFactorCode);

      if (res.requires2FA) {
        setNeeds2FA(true);
        setLoading(false);
        return;
      }

      if (!res.user) {
        setError('Sign-in failed. Please try again.');
        setLoading(false);
        return;
      }

      if (res.user.mustChangePassword) {
        setPendingUser(res.user);
        setFounderName(res.user.name || '');
        setLoading(false);
        return;
      }

      if (res.requires2FASetup || res.user.requires2FASetup) {
        await beginMandatory2FASetup(res.user);
        setLoading(false);
        return;
      }

      onSignInSuccess(res.user);
      onNavigate('/portal');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Incorrect credentials. Please verify your email and password.');
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = founderName.trim();
    if (!trimmedName) {
      setChangeError('Please enter your display name.');
      return;
    }
    if (newPassword.length < requiredMinLen) {
      setChangeError(`Password must be at least ${requiredMinLen} characters long.`);
      return;
    }
    if (newPassword !== confirmPassword) {
      setChangeError('Passwords do not match.');
      return;
    }

    setChangeLoading(true);
    setChangeError(null);

    try {
      const res = await api.changePassword(newPassword);
      let updatedUser: User | undefined =
        res.user || (pendingUser ? { ...pendingUser, mustChangePassword: false } : undefined);
      if (pendingUser && trimmedName !== (pendingUser.name || '').trim()) {
        const profRes = await api.updateProfile({ name: trimmedName });
        updatedUser = profRes.user;
      }
      if (pendingUser && updatedUser) {
        setPendingUser(null);
        if (updatedUser.requires2FASetup && !updatedUser.twoFactorEnabled) {
          await beginMandatory2FASetup(updatedUser);
          return;
        }
        onSignInSuccess(updatedUser);
        onNavigate('/portal');
      }
    } catch (err: unknown) {
      setChangeError(err instanceof Error ? err.message : 'Failed to update credentials.');
    } finally {
      setChangeLoading(false);
    }
  };

  const handleVerifyMandatory2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!setup2FACode.trim()) {
      setSetup2FAError('Enter the 6-digit code from your authenticator app.');
      return;
    }
    setSetup2FALoading(true);
    setSetup2FAError(null);
    try {
      const res = await api.verify2FA(setup2FACode.trim());
      setSetup2FAUser(null);
      setSetup2FAData(null);
      onSignInSuccess(res.user);
      onNavigate('/portal');
    } catch (err: unknown) {
      setSetup2FAError(err instanceof Error ? err.message : 'Verification failed.');
    } finally {
      setSetup2FALoading(false);
    }
  };

  const strength = getPasswordStrength(newPassword);

  return (
    <div className="min-h-screen bg-[#06302F] text-[#EDE9E0] flex items-center justify-center px-4 py-16 sm:px-6 lg:px-8">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-block w-20 h-20 rounded-full overflow-hidden shadow-2xl mb-4 ring-2 ring-[#25CDB6]/30 bg-[#06302F]">
            <img
              src={logoUrl || '/drawing1.png'}
              alt="Masters Of All Emblem"
              className="w-full h-full object-cover rounded-full"
            />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#EDE9E0]">
            MoA Control Room
          </h1>
          <p className="mt-1 text-xs text-[#EDE9E0]/60">
            Sign in to access your administrative workspace
          </p>
        </div>

        <AnimatePresence mode="wait">
          {pendingUser ? (
            <motion.div
              key="password-change"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.2 }}
              className="bg-[#0A3D3C]/80 backdrop-blur-md border border-[#25CDB6]/30 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-5"
            >
              <div className="flex items-center gap-3 p-3.5 rounded-xl bg-[#17A491]/15 border border-[#17A491]/30">
                <KeyRound className="w-5 h-5 text-[#25CDB6] shrink-0" />
                <div className="text-xs text-[#EDE9E0]/90">
                  <p className="font-bold text-[#EDE9E0]">Strong Password Required</p>
                  <p className="text-[#EDE9E0]/70 mt-0.5">
                    Set a new password (at least {requiredMinLen} characters) before entering the Control Room.
                  </p>
                </div>
              </div>

              {changeError && (
                <div className="p-3.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <span>{changeError}</span>
                </div>
              )}

              <form onSubmit={handleChangePassword} className="space-y-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#EDE9E0]/70 font-semibold mb-2">
                    Your Display Name
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#EDE9E0]/40">
                      <UserIcon className="w-4 h-4" />
                    </div>
                    <input
                      type="text"
                      value={founderName}
                      onChange={e => setFounderName(e.target.value)}
                      required
                      placeholder="Full name or handle"
                      className="w-full bg-[#06302F]/90 border border-[#EDE9E0]/20 rounded-xl pl-10 pr-4 py-3 text-sm text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#EDE9E0]/70 font-semibold mb-2">
                    New Password
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      value={newPassword}
                      onChange={e => setNewPassword(e.target.value)}
                      required
                      placeholder={`Minimum ${requiredMinLen} characters`}
                      className="w-full bg-[#06302F]/90 border border-[#EDE9E0]/20 rounded-xl px-4 py-3 text-sm text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-[#EDE9E0]/40 hover:text-[#EDE9E0]"
                    >
                      {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  <div className="mt-2 space-y-1.5">
                    <div className="flex gap-1 h-1 w-full bg-white/10 rounded-full overflow-hidden">
                      <div className={`h-full transition-all duration-300 ${strength >= 1 ? 'w-1/4 bg-red-500' : ''}`} />
                      <div className={`h-full transition-all duration-300 ${strength >= 2 ? 'w-1/4 bg-amber-500' : ''}`} />
                      <div className={`h-full transition-all duration-300 ${strength >= 3 ? 'w-1/4 bg-[#17A491]' : ''}`} />
                      <div className={`h-full transition-all duration-300 ${strength >= 4 ? 'w-1/4 bg-[#25CDB6]' : ''}`} />
                    </div>
                    <p className="text-[10px] text-[#EDE9E0]/50">
                      Use at least {requiredMinLen} characters including uppercase letters, numbers, and symbols.
                    </p>
                  </div>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#EDE9E0]/70 font-semibold mb-2">
                    Confirm New Password
                  </label>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={e => setConfirmPassword(e.target.value)}
                    required
                    placeholder="Repeat new password"
                    className="w-full bg-[#06302F]/90 border border-[#EDE9E0]/20 rounded-xl px-4 py-3 text-sm text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={changeLoading}
                  className="w-full mt-2 py-3.5 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] font-semibold text-sm transition-all duration-200 flex items-center justify-center gap-2 shadow-lg disabled:opacity-50 cursor-pointer"
                >
                  {changeLoading ? (
                    <div className="w-5 h-5 border-2 border-[#06302F] border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>Set Password &amp; Continue</span>
                    </>
                  )}
                </button>
              </form>
            </motion.div>
          ) : setup2FAUser ? (
            <motion.div
              key="mandatory-2fa-setup"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.2 }}
              className="bg-[#0A3D3C]/80 backdrop-blur-md border border-[#25CDB6]/30 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-5"
            >
              <div className="flex items-center gap-3 p-3.5 rounded-xl bg-[#17A491]/15 border border-[#17A491]/30">
                <Shield className="w-5 h-5 text-[#25CDB6] shrink-0" />
                <div className="text-xs text-[#EDE9E0]/90">
                  <p className="font-bold text-[#EDE9E0]">Two-Factor Authentication Required</p>
                  <p className="text-[#EDE9E0]/70 mt-0.5">
                    Administrators must enroll an authenticator app before accessing the Control Room.
                  </p>
                </div>
              </div>

              {setup2FAError && (
                <div className="p-3.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <span>{setup2FAError}</span>
                </div>
              )}

              {setup2FAData && (
                <form onSubmit={handleVerifyMandatory2FA} className="space-y-4">
                  <div className="flex flex-col items-center gap-3 p-4 rounded-xl bg-[#06302F] border border-white/10">
                    <img
                      src={setup2FAData.qrDataUrl}
                      alt="TOTP Authenticator QR Code"
                      className="w-40 h-40 rounded-lg bg-white p-2"
                    />
                    <div className="text-center">
                      <span className="text-[10px] uppercase tracking-wider text-[#EDE9E0]/50 block">Manual Setup Key</span>
                      <code className="text-xs font-mono text-[#25CDB6] break-all select-all">{setup2FAData.secret}</code>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-[#06302F]/80 border border-amber-500/30 space-y-1.5">
                    <span className="text-[10px] uppercase tracking-wider text-amber-300 font-bold block">
                      Save Recovery Codes (single-use)
                    </span>
                    <div className="grid grid-cols-2 gap-1 text-[11px] font-mono text-[#EDE9E0]/85 select-all">
                      {setup2FAData.recoveryCodes.map(rc => (
                        <span key={rc}>{rc}</span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#EDE9E0]/70 font-semibold mb-2">
                      Verify 6-Digit Code
                    </label>
                    <input
                      type="text"
                      inputMode="numeric"
                      maxLength={6}
                      value={setup2FACode}
                      onChange={e => setSetup2FACode(e.target.value)}
                      required
                      placeholder="123456"
                      className="w-full bg-[#06302F]/90 border border-[#EDE9E0]/20 rounded-xl px-4 py-3 text-sm text-[#EDE9E0] font-mono tracking-widest focus:outline-none focus:border-[#25CDB6]"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={setup2FALoading}
                    className="w-full py-3.5 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-lg disabled:opacity-50 cursor-pointer"
                  >
                    {setup2FALoading ? 'Verifying...' : 'Enable 2FA & Enter Control Room'}
                  </button>
                </form>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="signin-form"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.2 }}
              className="bg-[#0A3D3C]/70 backdrop-blur-md border border-[#EDE9E0]/15 rounded-2xl p-6 sm:p-8 shadow-2xl"
            >
              {infoBanner && (
                <div className="mb-5 p-3.5 rounded-xl bg-[#17A491]/15 border border-[#25CDB6]/40 text-[#EDE9E0] text-xs flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#25CDB6] shrink-0 mt-0.5" />
                  <span>{infoBanner}</span>
                </div>
              )}

              {error && (
                <div className="mb-6 p-4 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-start gap-3">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{error}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#EDE9E0]/70 font-semibold mb-2">
                    Email Address
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#EDE9E0]/40">
                      <Mail className="w-4 h-4" />
                    </div>
                    <input
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      required
                      placeholder="name@mastersofall.org"
                      className="w-full bg-[#06302F]/90 border border-[#EDE9E0]/20 rounded-xl pl-10 pr-4 py-3 text-sm text-[#EDE9E0] placeholder-[#EDE9E0]/30 focus:outline-none focus:border-[#25CDB6] focus:ring-1 focus:ring-[#25CDB6] transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs uppercase tracking-wider text-[#EDE9E0]/70 font-semibold mb-2">
                    Password
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#EDE9E0]/40">
                      <Lock className="w-4 h-4" />
                    </div>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      required
                      placeholder="••••••••"
                      className="w-full bg-[#06302F]/90 border border-[#EDE9E0]/20 rounded-xl pl-10 pr-11 py-3 text-sm text-[#EDE9E0] placeholder-[#EDE9E0]/30 focus:outline-none focus:border-[#25CDB6] focus:ring-1 focus:ring-[#25CDB6] transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-[#EDE9E0]/40 hover:text-[#EDE9E0] transition-colors focus:outline-none cursor-pointer"
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {needs2FA && (
                  <div>
                    <label className="block text-xs uppercase tracking-wider text-[#25CDB6] font-semibold mb-2 flex items-center gap-1.5">
                      <Shield className="w-3.5 h-3.5" />
                      <span>Two-Factor Authentication Code</span>
                    </label>
                    <input
                      type="text"
                      value={twoFactorCode}
                      onChange={e => setTwoFactorCode(e.target.value)}
                      placeholder="6-digit TOTP or recovery code"
                      className="w-full bg-[#06302F]/90 border border-[#25CDB6]/40 rounded-xl px-4 py-3 text-sm text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                    />
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-2 py-3.5 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] font-semibold text-sm transition-all duration-200 flex items-center justify-center gap-2 shadow-lg disabled:opacity-50 cursor-pointer"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-[#06302F] border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Sign In</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>

                <p className="pt-1 text-center text-xs text-[#EDE9E0]/55">
                  Forgot your password? Contact an administrator.
                </p>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
