import React, { useState, useEffect, useCallback, useRef, lazy, Suspense } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Department,
  Project,
  Publication,
  Product,
  PageRecord,
  SiteContent,
  SiteSettings,
  User
} from './types';
import { api } from './services/api';
import { INITIAL_SITE_CONTENT } from './data/initialData';
import { resetPortalActiveTabOnExit } from './components/portal/portalSessionCookie';
import { useContent } from './hooks/useContent';
import { can, hasPortalAccess } from './shared/permissions';
import { sanitizeSafeUrl } from './shared/url';
import { LoadingScreen } from './components/LoadingScreen';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { ErrorBoundary } from './components/ErrorBoundary';
import { SpaLink } from './components/SpaLink';
import { HomeView } from './views/HomeView';
import { AboutView } from './views/AboutView';
import { DepartmentsView } from './views/DepartmentsView';
import { DepartmentDetailView } from './views/DepartmentDetailView';
import { ProjectsView } from './views/ProjectsView';
import { ProjectDetailView } from './views/ProjectDetailView';
import { ProductsView } from './views/ProductsView';
import { ProductDetailView } from './views/ProductDetailView';
import { ContactView } from './views/ContactView';
import { SignInView } from './views/SignInView';
import { NotFoundView } from './views/NotFoundView';
import { CustomPageView } from './views/CustomPageView';
import { isSector } from './utils/orgHelpers';
import {
  Save,
  Send,
  X,
  RotateCcw,
  RefreshCw,
  AlertTriangle,
  ShieldAlert,
  LayoutDashboard,
  ArrowRight,
  Pencil,
  Megaphone
} from 'lucide-react';

const AdminPortal = lazy(() =>
  import('./views/AdminPortal').then(mod => ({ default: mod.AdminPortal }))
);

function normalizeRoutePath(rawPath: string): string {
  const pathOnly = rawPath.split('?')[0].split('#')[0] || '/';
  if (pathOnly === '/') return '/home';
  const cleaned = pathOnly.replace(/\/+$/, '');
  return cleaned.startsWith('/') ? cleaned : `/${cleaned}`;
}

function setByFieldPath(obj: Record<string, unknown>, fieldPath: string, value: unknown): Record<string, unknown> {
  const clone = JSON.parse(JSON.stringify(obj || {})) as Record<string, unknown>;
  const parts = fieldPath.split('.').filter(Boolean);
  if (parts.length === 0) return clone;
  let curr: Record<string, unknown> = clone;
  for (let i = 0; i < parts.length - 1; i++) {
    const key = parts[i];
    const next = curr[key];
    if (!next || typeof next !== 'object' || Array.isArray(next)) {
      curr[key] = {};
    }
    curr = curr[key] as Record<string, unknown>;
  }
  curr[parts[parts.length - 1]] = value;
  return clone;
}

function upsertMetaTag(attr: 'name' | 'property', key: string, content: string) {
  let el = document.head.querySelector(`meta[${attr}="${key}"]`) as HTMLMetaElement | null;
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.content = content;
}

function removeMetaTag(attr: 'name' | 'property', key: string) {
  const el = document.head.querySelector(`meta[${attr}="${key}"]`);
  if (el) el.remove();
}

function resolveRedirects(
  rawPath: string,
  redirects: SiteSettings['redirects'] | undefined
): { target: string; isExternal: boolean } | null {
  if (!redirects || redirects.length === 0) return null;
  let current = normalizeRoutePath(rawPath);
  const visited = new Set<string>([current.toLowerCase()]);
  let redirected = false;

  for (let hop = 0; hop < 5; hop++) {
    const rule = redirects.find(r => normalizeRoutePath(r.from).toLowerCase() === current.toLowerCase());
    if (!rule) break;
    redirected = true;
    const dest = (rule.to || '').trim();
    if (!dest) break;
    if (/^https?:\/\//i.test(dest)) {
      return { target: dest, isExternal: true };
    }
    const normalizedDest = normalizeRoutePath(dest);
    const key = normalizedDest.toLowerCase();
    if (visited.has(key)) {
      break;
    }
    visited.add(key);
    current = normalizedDest;
  }

  return redirected ? { target: current, isExternal: false } : null;
}

export default function App() {
  const [introDone, setIntroDone] = useState(false);
  const [currentRoute, setCurrentRoute] = useState<string>(() => {
    if (typeof window === 'undefined') return '/home';
    return normalizeRoutePath(window.location.pathname);
  });

  useEffect(() => {
    if (typeof window !== 'undefined' && window.location.pathname === '/') {
      window.history.replaceState({}, '', `/home${window.location.search}${window.location.hash}`);
    }
  }, []);

  // Public & authenticated core state (no hardcoded fallback content lists)
  const [departments, setDepartments] = useState<Department[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [publications, setPublications] = useState<Publication[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [pages, setPages] = useState<PageRecord[]>([]);
  const [siteContent, setSiteContent] = useState<SiteContent | null>(null);
  const [settings, setSettings] = useState<SiteSettings | null>(null);

  const [initialLoading, setInitialLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Auth & Edit Mode state
  const [currentUser, setCurrentUser] = useState<User | null>(() => api.getCurrentUser());
  const [authChecked, setAuthChecked] = useState<boolean>(() => !api.getToken());
  const [isEditMode, setIsEditMode] = useState(false);
  const [draftContent, setDraftContent] = useState<Partial<SiteContent> | null>(null);
  const [hasDraftChanges, setHasDraftChanges] = useState(false);
  const [editSaving, setEditSaving] = useState(false);
  const [editBannerMsg, setEditBannerMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Announcement bar dismissal (per session)
  const [announcementDismissed, setAnnouncementDismissed] = useState(false);

  // Optional `?preview=1` single-item lookup for unpublished items when signed in
  const [previewProject, setPreviewProject] = useState<Project | null>(null);
  const [previewProduct, setPreviewProduct] = useState<Product | null>(null);

  const knownVersionRef = useRef<number | null>(null);
  const draftContentRef = useRef<Partial<SiteContent> | null>(null);
  const stickyStackRef = useRef<HTMLDivElement>(null);
  const { content: mergedContent } = useContent(siteContent, isEditMode ? draftContent : null);

  // Measure sticky top stack height (live editor bar + navbar) + 16px breathing room
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const updateOffset = () => {
      const h = stickyStackRef.current ? stickyStackRef.current.getBoundingClientRect().height : 80;
      document.documentElement.style.setProperty('--sticky-stack-offset', `${Math.ceil(h) + 16}px`);
    };
    updateOffset();
    if (typeof ResizeObserver === 'undefined' || !stickyStackRef.current) return;
    const ro = new ResizeObserver(updateOffset);
    ro.observe(stickyStackRef.current);
    return () => ro.disconnect();
  }, [currentUser, isEditMode]);

  const scrollToHashTarget = useCallback((hash: string) => {
    const targetId = hash.replace(/^#/, '').trim();
    if (!targetId) return;
    const tryScroll = (attempt = 0) => {
      const el = document.getElementById(targetId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      } else if (attempt < 6) {
        window.setTimeout(() => tryScroll(attempt + 1), 60);
      }
    };
    window.requestAnimationFrame(() => tryScroll(0));
  }, []);

  const navigate = useCallback((to: string) => {
    const raw = to.trim() || '/home';
    if (/^https?:\/\//i.test(raw) || raw.startsWith('mailto:')) {
      const safe = sanitizeSafeUrl(raw, true);
      if (safe) window.location.assign(safe);
      return;
    }

    const hIdx = raw.indexOf('#');
    const withoutHash = hIdx >= 0 ? raw.slice(0, hIdx) : raw;
    const hashPart = hIdx >= 0 ? raw.slice(hIdx) : '';
    const qIdx = withoutHash.indexOf('?');
    const pathPart = qIdx >= 0 ? withoutHash.slice(0, qIdx) : withoutHash;
    const queryPart = qIdx >= 0 ? withoutHash.slice(qIdx) : '';
    const normalized = normalizeRoutePath(pathPart);
    const fullUrl = `${normalized}${queryPart}${hashPart}`;

    if (typeof window !== 'undefined') {
      const currentFull = `${normalizeRoutePath(window.location.pathname)}${window.location.search}${window.location.hash}`;
      if (fullUrl !== currentFull) {
        window.history.pushState({}, '', fullUrl);
        if (hashPart) {
          window.dispatchEvent(new HashChangeEvent('hashchange'));
        }
      }
      if (hashPart) {
        scrollToHashTarget(hashPart);
      } else {
        window.scrollTo({ top: 0, behavior: 'auto' });
      }
    }
    setCurrentRoute(normalized);
  }, [scrollToHashTarget]);

  // Sync browser back/forward navigation & scroll cleanly
  useEffect(() => {
    const onPopState = () => {
      setCurrentRoute(normalizeRoutePath(window.location.pathname));
      setPreviewProject(null);
      setPreviewProduct(null);
      if (window.location.hash) {
        scrollToHashTarget(window.location.hash);
      } else {
        window.scrollTo({ top: 0, behavior: 'auto' });
      }
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, [scrollToHashTarget]);

  // Ensure initial route load with hash scrolls cleanly after data renders
  useEffect(() => {
    if (!initialLoading && typeof window !== 'undefined' && window.location.hash) {
      scrollToHashTarget(window.location.hash);
    }
  }, [initialLoading, currentRoute, scrollToHashTarget]);

  // Register 401 unauthorized handler
  useEffect(() => {
    api.registerUnauthorizedHandler(() => {
      setCurrentUser(null);
      setIsEditMode(false);
      setDraftContent(null);
      setHasDraftChanges(false);
      navigate('/login?expired=1');
    });
    return () => api.registerUnauthorizedHandler(null);
  }, [navigate]);

  // Verify stored token on mount
  useEffect(() => {
    const token = api.getToken();
    if (!token) {
      setCurrentUser(null);
      setAuthChecked(true);
      return;
    }
    let active = true;
    api
      .getMe()
      .then(res => {
        if (active) setCurrentUser(res.user);
      })
      .catch(() => {
        if (active) {
          api.clearSession();
          setCurrentUser(null);
        }
      })
      .finally(() => {
        if (active) setAuthChecked(true);
      });
    return () => {
      active = false;
    };
  }, []);

  // Fetch public site data with transient retry
  const fetchPublicData = useCallback(async (isInitial = false) => {
    if (isInitial) {
      setInitialLoading(true);
    }
    setLoadError(null);

    const maxAttempts = isInitial ? 3 : 2;
    let lastErr: unknown = null;

    try {
      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        try {
          const [deptsRes, projRes, pubRes, prodRes, contentRes, settingsRes, pagesRes, verRes] =
            await Promise.all([
              api.getDepartments(),
              api.getProjects(),
              api.getPublications(),
              api.getProducts(),
              api.getPageContent(),
              api.getSettings(),
              api.getPages().catch(() => [] as PageRecord[]),
              api.getContentVersion()
            ]);

          setDepartments(deptsRes);
          setProjects(projRes);
          setPublications(pubRes);
          setProducts(prodRes);
          setSiteContent(contentRes);
          setSettings(settingsRes);
          setPages(pagesRes);
          knownVersionRef.current = verRes.version;
          return;
        } catch (err) {
          lastErr = err;
          if (attempt < maxAttempts) {
            await new Promise(r => setTimeout(r, attempt * 200));
          }
        }
      }

      setLoadError(
        lastErr instanceof Error ? lastErr.message : 'Unable to load website content from the server.'
      );
    } finally {
      if (isInitial) setInitialLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchPublicData(true);
  }, [fetchPublicData]);

  // Content version freshness check on route change, window focus, and 60s interval
  const checkContentVersion = useCallback(async () => {
    try {
      const res = await api.getContentVersion();
      if (knownVersionRef.current !== null && res.version !== knownVersionRef.current) {
        await fetchPublicData(false);
      } else if (knownVersionRef.current === null) {
        knownVersionRef.current = res.version;
      }
    } catch {
      // Ignore background version check errors
    }
  }, [fetchPublicData]);

  useEffect(() => {
    void checkContentVersion();
  }, [currentRoute, checkContentVersion]);

  useEffect(() => {
    const onFocus = () => {
      void checkContentVersion();
    };
    window.addEventListener('focus', onFocus);
    const timer = window.setInterval(() => {
      void checkContentVersion();
    }, 60_000);
    return () => {
      window.removeEventListener('focus', onFocus);
      window.clearInterval(timer);
    };
  }, [checkContentVersion]);

  // Redirect rules check on route changes
  useEffect(() => {
    if (!settings?.redirects || settings.redirects.length === 0) return;
    if (
      currentRoute === '/portal' ||
      currentRoute.startsWith('/portal/') ||
      currentRoute === '/admin' ||
      currentRoute.startsWith('/admin/') ||
      currentRoute === '/login' ||
      currentRoute === '/invite'
    ) {
      return;
    }
    const resolved = resolveRedirects(currentRoute, settings.redirects);
    if (resolved) {
      if (resolved.isExternal) {
        window.location.replace(resolved.target);
      } else if (resolved.target !== currentRoute) {
        window.history.replaceState({}, '', resolved.target);
        setCurrentRoute(resolved.target);
      }
    }
  }, [currentRoute, settings]);

  // Preview lookup when visiting /projects/:slug?preview=1 or /products/:slug?preview=1
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('preview') !== '1' || !currentUser) {
      setPreviewProject(null);
      setPreviewProduct(null);
      return;
    }

    if (currentRoute.startsWith('/projects/')) {
      const slug = decodeURIComponent(currentRoute.slice('/projects/'.length));
      if (slug && !projects.some(p => p.slug === slug)) {
        api
          .getProjectBySlug(slug)
          .then(p => setPreviewProject(p))
          .catch(() => setPreviewProject(null));
      }
    } else if (currentRoute.startsWith('/products/')) {
      const slug = decodeURIComponent(currentRoute.slice('/products/'.length));
      if (slug && !products.some(p => p.slug === slug)) {
        api
          .getProductBySlug(slug)
          .then(p => setPreviewProduct(p))
          .catch(() => setPreviewProduct(null));
      }
    }
  }, [currentRoute, currentUser, projects, products]);

  // Warn before unloading page if inline edit mode has unsaved draft edits
  useEffect(() => {
    if (!isEditMode || !hasDraftChanges) return;
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', onBeforeUnload);
    return () => window.removeEventListener('beforeunload', onBeforeUnload);
  }, [isEditMode, hasDraftChanges]);

  // Edit mode actions (permission-gated)
  const enterEditMode = useCallback(async () => {
    if (!can(currentUser, 'website.edit')) return;
    try {
      const res = await api.getDraftContent();
      setDraftContent(res.draft || null);
      const nextDraft = res.draft && Object.keys(res.draft).length > 0 ? res.draft : null;
      draftContentRef.current = nextDraft;
      setDraftContent(nextDraft);
      setHasDraftChanges(Boolean(nextDraft));
    } catch {
      draftContentRef.current = null;
      setDraftContent(null);
    }
    setEditBannerMsg(null);
    setIsEditMode(true);
    if (
      currentRoute === '/portal' ||
      currentRoute.startsWith('/portal/') ||
      currentRoute === '/admin' ||
      currentRoute.startsWith('/admin/')
    ) {
      navigate('/home');
    }
  }, [currentUser, currentRoute, navigate]);

  const handleUpdateInlineContent = useCallback(
    (fieldPath: string, newValue: unknown) => {
      if (!can(currentUser, 'website.edit')) return;
      const base = (draftContentRef.current || siteContent || INITIAL_SITE_CONTENT) as Record<string, unknown>;
      const nextDraft = setByFieldPath(base, fieldPath, newValue) as Partial<SiteContent>;
      draftContentRef.current = nextDraft;
      setDraftContent(nextDraft);
      setHasDraftChanges(true);
      setEditBannerMsg({ type: 'ok', text: 'Saving draft to database...' });
      void api
        .saveDraftContent(nextDraft)
        .then(() => {
          setEditBannerMsg({ type: 'ok', text: 'Draft saved to database.' });
        })
        .catch(err => {
          setEditBannerMsg({
            type: 'err',
            text: err instanceof Error ? err.message : 'Failed to save draft to database.'
          });
        });
    },
    [currentUser, siteContent]
  );

  const handleUpdateInlineDepartment = useCallback(
    async (departmentId: string, patch: Partial<Department>) => {
      if (!can(currentUser, 'departments.manage') && !can(currentUser, 'website.edit')) return;
      try {
        const updated = await api.updateDepartment(departmentId, patch);
        setDepartments(prev => prev.map(d => (d.id === departmentId ? updated : d)));
        if ((updated.isRdd || updated.id === 'dept-rdd') && patch.customLogoUrl !== undefined) {
          setSettings(prev => (prev ? { ...prev, rddLogoUrl: updated.customLogoUrl || '' } : prev));
        }
        setEditBannerMsg({ type: 'ok', text: `Saved ${updated.name}.` });
      } catch (err) {
        setEditBannerMsg({
          type: 'err',
          text: err instanceof Error ? err.message : 'Failed to update record.'
        });
      }
    },
    [currentUser]
  );

  const handleSaveInlineDraft = async () => {
    if (!draftContent) return;
    setEditSaving(true);
    setEditBannerMsg(null);
    try {
      await api.saveDraftContent(draftContent);
      setEditBannerMsg({ type: 'ok', text: 'Draft saved.' });
    } catch (err) {
      setEditBannerMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'Failed to save draft.'
      });
    } finally {
      setEditSaving(false);
    }
  };

  const handlePublishInlineDraft = async () => {
    setEditSaving(true);
    setEditBannerMsg(null);
    try {
      const pendingDraft = draftContentRef.current || draftContent;
      if (pendingDraft) {
        await api.saveDraftContent(pendingDraft);
      }
      const published = await api.publishDraftContent();
      setSiteContent(published);
      draftContentRef.current = null;
      setDraftContent(null);
      setHasDraftChanges(false);
      await fetchPublicData(false);
      setEditBannerMsg({ type: 'ok', text: 'Published live.' });
    } catch (err) {
      setEditBannerMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'Failed to publish changes.'
      });
    } finally {
      setEditSaving(false);
    }
  };

  const handleDiscardInlineDraft = async () => {
    setEditSaving(true);
    setEditBannerMsg(null);
    try {
      await api.saveDraftContent(null as unknown as Partial<SiteContent>);
    } catch {
      // Ignore clear error
    } finally {
      draftContentRef.current = null;
      setDraftContent(null);
      setHasDraftChanges(false);
      await fetchPublicData(false);
      setEditSaving(false);
      setEditBannerMsg({ type: 'ok', text: 'Draft discarded.' });
    }
  };

  // Compute route resolution
  const isPortalRoute =
    currentRoute === '/portal' ||
    currentRoute.startsWith('/portal/') ||
    currentRoute === '/admin' ||
    currentRoute.startsWith('/admin/');
  const isAuthRoute = currentRoute === '/login' || currentRoute === '/invite';

  const wasPortalRouteRef = useRef(isPortalRoute);
  useEffect(() => {
    if (wasPortalRouteRef.current && !isPortalRoute) {
      resetPortalActiveTabOnExit();
    }
    wasPortalRouteRef.current = isPortalRoute;
  }, [isPortalRoute]);

  const showProducts =
    products.some(p => !p.deletedAt) || Boolean(settings?.alwaysShowProducts);

  // Route matching helper for document metadata & view rendering
  const nestedDeptSegments = currentRoute.startsWith('/departments/')
    ? currentRoute
        .slice('/departments/'.length)
        .split('/')
        .filter(Boolean)
        .map(seg => decodeURIComponent(seg))
    : [];
  const matchedNestedParentSlug = nestedDeptSegments.length >= 2 ? nestedDeptSegments[0] : null;
  const matchedNestedSectorSlug =
    nestedDeptSegments.length >= 2 ? nestedDeptSegments.slice(1).join('/') : null;
  const matchedLegacySectorSlug = currentRoute.startsWith('/sectors/')
    ? decodeURIComponent(currentRoute.slice('/sectors/'.length))
    : null;
  const matchedSectorSlug = matchedNestedSectorSlug || matchedLegacySectorSlug;
  const matchedDeptSlug =
    !matchedSectorSlug && nestedDeptSegments.length === 1 ? nestedDeptSegments[0] : null;
  const matchedDepartment = matchedSectorSlug
    ? (() => {
        if (matchedNestedParentSlug) {
          const parentMatch = departments.find(
            d => !d.deletedAt && !isSector(d) && d.slug.toLowerCase() === matchedNestedParentSlug.toLowerCase()
          );
          if (parentMatch) {
            const exactChild = departments.find(
              d =>
                !d.deletedAt &&
                isSector(d) &&
                (d.parentDepartmentId || 'dept-rdd') === parentMatch.id &&
                d.slug.toLowerCase() === matchedSectorSlug.toLowerCase()
            );
            if (exactChild) return exactChild;
          }
        }
        return (
          departments.find(
            d => d.slug.toLowerCase() === matchedSectorSlug.toLowerCase() && isSector(d) && !d.deletedAt
          ) ||
          departments.find(d => d.slug.toLowerCase() === matchedSectorSlug.toLowerCase() && !d.deletedAt)
        );
      })()
    : matchedDeptSlug
      ? departments.find(
          d => d.slug.toLowerCase() === matchedDeptSlug.toLowerCase() && !isSector(d) && !d.deletedAt
        )
      : undefined;

  // Canonicalize legacy /sectors/:slug URLs to /departments/:parentSlug/:slug cleanly
  useEffect(() => {
    if (
      matchedLegacySectorSlug &&
      matchedDepartment &&
      isSector(matchedDepartment) &&
      typeof window !== 'undefined'
    ) {
      const parentId = matchedDepartment.parentDepartmentId || 'dept-rdd';
      const parentDept = departments.find(d => d.id === parentId && !isSector(d));
      const canonical = `/departments/${parentDept?.slug || 'rdd'}/${matchedDepartment.slug}`;
      window.history.replaceState({}, '', `${canonical}${window.location.search}${window.location.hash}`);
      setCurrentRoute(canonical);
    }
  }, [matchedLegacySectorSlug, matchedDepartment, departments]);

  const matchedProjectSlug = currentRoute.startsWith('/projects/')
    ? decodeURIComponent(currentRoute.slice('/projects/'.length))
    : null;
  const matchedProject = matchedProjectSlug
    ? projects.find(p => p.slug === matchedProjectSlug && !p.deletedAt) ||
      (previewProject?.slug === matchedProjectSlug ? previewProject : undefined)
    : undefined;

  const matchedProductSlug = currentRoute.startsWith('/products/')
    ? decodeURIComponent(currentRoute.slice('/products/'.length))
    : null;
  const matchedProduct = matchedProductSlug
    ? products.find(p => p.slug === matchedProductSlug && !p.deletedAt) ||
      (previewProduct?.slug === matchedProductSlug ? previewProduct : undefined)
    : undefined;

  const customPageSlug = currentRoute.startsWith('/pages/')
    ? decodeURIComponent(currentRoute.slice('/pages/'.length))
    : currentRoute !== '/home'
      ? decodeURIComponent(currentRoute.slice(1))
      : '';
  const matchedCustomPage = customPageSlug
    ? pages.find(p => p.slug === customPageSlug && !p.deletedAt && p.status === 'Published')
    : undefined;

  // Dynamic <head> metadata + JSON-LD + robots
  useEffect(() => {
    const siteName = settings?.siteName || 'Masters Of All';
    const defaultTitle = settings?.seoDefaults?.title || `${siteName} — Believe. Build. Become.`;
    const defaultDesc =
      settings?.seoDefaults?.description ||
      'Masters Of All (MoA) is a platform dedicated to research, discovery and development.';
    const defaultKeywords = settings?.seoDefaults?.keywords || '';
    const defaultImage = sanitizeSafeUrl(settings?.shareImageUrl) || '/drawing1.png';
    const favicon = sanitizeSafeUrl(settings?.faviconUrl) || sanitizeSafeUrl(settings?.moaLogoUrl) || '/drawing1.png';

    let title = defaultTitle;
    let description = defaultDesc;
    let image = defaultImage;
    let noindex = false;

    if (currentRoute === '/login' || currentRoute === '/invite') {
      title = `Control Room Sign In — ${siteName}`;
      noindex = true;
    } else if (isPortalRoute) {
      if (currentUser && hasPortalAccess(currentUser)) {
        title = `Control Room — ${siteName}`;
      } else {
        title = `Not Found — ${siteName}`;
      }
      noindex = true;
    } else if (currentRoute === '/signin') {
      title = `Not Found — ${siteName}`;
      noindex = true;
    } else if (currentRoute === '/about') {
      title = `About — ${siteName}`;
      description = mergedContent.about.heroSub || defaultDesc;
    } else if (currentRoute === '/departments') {
      title = `Departments — ${siteName}`;
      description = mergedContent.departments.directorySubtitle || defaultDesc;
    } else if (currentRoute === '/projects') {
      title = `Projects — ${siteName}`;
      description = mergedContent.work.subtitle || defaultDesc;
    } else if (currentRoute === '/products') {
      if (showProducts) {
        title = `Products — ${siteName}`;
        description = mergedContent.products?.subtext || defaultDesc;
      } else {
        title = `Not Found — ${siteName}`;
        noindex = true;
      }
    } else if (currentRoute === '/contact') {
      title = `Contact — ${siteName}`;
      description = mergedContent.contact.subtext || defaultDesc;
    } else if (matchedDepartment) {
      title = matchedDepartment.seoTitle || `${matchedDepartment.name} — ${siteName}`;
      description =
        matchedDepartment.seoDescription || matchedDepartment.introduction || defaultDesc;
      image = sanitizeSafeUrl(matchedDepartment.seoShareImage) || sanitizeSafeUrl(matchedDepartment.heroImage) || defaultImage;
    } else if (matchedProject) {
      title = matchedProject.seoTitle || `${matchedProject.title} — ${siteName}`;
      description = matchedProject.seoDescription || matchedProject.shortDescription || defaultDesc;
      image = sanitizeSafeUrl(matchedProject.seoShareImage) || sanitizeSafeUrl(matchedProject.coverImage) || defaultImage;
    } else if (matchedProduct && (showProducts || Boolean(previewProduct))) {
      title = matchedProduct.seoTitle || `${matchedProduct.name} — ${siteName}`;
      description = matchedProduct.seoDescription || matchedProduct.shortDescription || defaultDesc;
      image = sanitizeSafeUrl(matchedProduct.seoShareImage) || sanitizeSafeUrl(matchedProduct.coverImage) || defaultImage;
    } else if (matchedCustomPage) {
      title = matchedCustomPage.seo?.title || `${matchedCustomPage.title} — ${siteName}`;
      description = matchedCustomPage.seo?.description || defaultDesc;
      image = sanitizeSafeUrl(matchedCustomPage.seo?.shareImage) || defaultImage;
      noindex = Boolean(matchedCustomPage.seo?.noindex);
    } else if (currentRoute !== '/home') {
      title = `Not Found — ${siteName}`;
      noindex = true;
    }

    document.title = title;
    upsertMetaTag('name', 'description', description);
    upsertMetaTag('property', 'og:title', title);
    upsertMetaTag('property', 'og:description', description);
    upsertMetaTag('property', 'og:image', image);
    if (defaultKeywords) {
      upsertMetaTag('name', 'keywords', defaultKeywords);
    } else {
      removeMetaTag('name', 'keywords');
    }
    if (noindex) {
      upsertMetaTag('name', 'robots', 'noindex, nofollow');
    } else {
      removeMetaTag('name', 'robots');
    }

    const iconEl = document.head.querySelector('link[rel="icon"]') as HTMLLinkElement | null;
    if (iconEl) {
      iconEl.href = favicon;
    }

    // Schema.org Organization JSON-LD
    let ldScript = document.getElementById('moa-org-jsonld') as HTMLScriptElement | null;
    if (!ldScript) {
      ldScript = document.createElement('script');
      ldScript.id = 'moa-org-jsonld';
      ldScript.type = 'application/ld+json';
      document.head.appendChild(ldScript);
    }
    const orgSchema: Record<string, unknown> = {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: siteName,
      url: typeof window !== 'undefined' ? window.location.origin : '',
      logo: sanitizeSafeUrl(settings?.moaLogoUrl) || '/drawing1.png',
      email: settings?.contactEmail || undefined,
      sameAs: (settings?.socialLinks || []).map(l => sanitizeSafeUrl(l.url)).filter(Boolean)
    };
    if (settings?.organizationAddress) {
      orgSchema.address = settings.organizationAddress;
    }
    ldScript.textContent = JSON.stringify(orgSchema);
  }, [
    settings,
    mergedContent,
    currentRoute,
    currentUser,
    isPortalRoute,
    showProducts,
    matchedDepartment,
    matchedProject,
    matchedProduct,
    previewProduct,
    matchedCustomPage
  ]);

  const moaLogoUrl = sanitizeSafeUrl(settings?.moaLogoUrl) || '/drawing1.png';
  const loaderLogoUrl = sanitizeSafeUrl(settings?.loaderLogoUrl) || moaLogoUrl;
  const rddLogoUrl = settings ? sanitizeSafeUrl(settings.rddLogoUrl) : '';
  const siteName = settings?.siteName || 'Masters Of All';

  // Announcement bar logic
  const announcement = settings?.announcementBar;
  const isAnnouncementActive = Boolean(
    !announcementDismissed &&
      announcement?.enabled &&
      announcement.text?.trim() &&
      (!announcement.expiresAt || new Date(announcement.expiresAt).getTime() > Date.now())
  );

  // Dedicated Control Room route
  if (isPortalRoute) {
    if (!authChecked) {
      return (
        <div className="min-h-screen bg-[#06302F] flex items-center justify-center text-[#EDE9E0]/70 text-xs font-mono">
          Verifying session...
        </div>
      );
    }

    if (!currentUser) {
      return (
        <ErrorBoundary onResetHome={() => navigate('/home')}>
          <div className="min-h-screen flex flex-col bg-[#06302F] text-[#EDE9E0]">
            <Navbar
              currentPath={currentRoute}
              onNavigate={navigate}
              socialLinks={settings?.socialLinks}
              navigation={settings?.navigation}
              showProducts={showProducts}
              logoUrl={moaLogoUrl}
              siteName={siteName}
            />
            <main className="flex-1 flex flex-col">
              <NotFoundView content={mergedContent} onNavigate={navigate} />
            </main>
            <Footer
              departments={departments}
              onNavigate={navigate}
              socialLinks={settings?.socialLinks}
              footerText={settings?.footerText}
              footerColumns={settings?.footerColumns}
              showProducts={showProducts}
              contactEmail={settings?.contactEmail}
              organizationAddress={settings?.organizationAddress}
              logoUrl={moaLogoUrl}
              siteName={siteName}
              tagline={settings?.tagline}
              content={mergedContent.footer}
            />
          </div>
        </ErrorBoundary>
      );
    }

    if (!hasPortalAccess(currentUser)) {
      return (
        <div className="min-h-screen bg-[#06302F] flex items-center justify-center p-6 text-[#EDE9E0]">
          <div className="max-w-md w-full bg-[#031D1C] border border-white/10 rounded-3xl p-8 text-center space-y-5 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-[#CA7952]/15 border border-[#CA7952]/40 flex items-center justify-center text-[#CA7952] mx-auto">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold">Portal Access Restricted</h1>
            <p className="text-xs text-[#EDE9E0]/70 leading-relaxed">
              Your account ({currentUser.email}) does not currently have Control Room permissions assigned. Contact an administrator if you need access.
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => navigate('/home')}
                className="px-4 py-2.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold text-xs cursor-pointer"
              >
                Return Home
              </button>
              <button
                type="button"
                onClick={async () => {
                  await api.signOut();
                  setCurrentUser(null);
                  navigate('/login');
                }}
                className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold cursor-pointer"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <ErrorBoundary onResetHome={() => navigate('/home')}>
        <Suspense
          fallback={
            <div className="min-h-screen bg-[#06302F] flex items-center justify-center text-[#25CDB6] text-xs font-mono">
              Loading Control Room...
            </div>
          }
        >
          <AdminPortal
            currentUser={currentUser}
            onUpdateUser={setCurrentUser}
            onLogout={async () => {
              await api.signOut();
              setCurrentUser(null);
              setIsEditMode(false);
              navigate('/login');
            }}
            onNavigateSite={(path = '/home') => {
              setIsEditMode(false);
              navigate(path);
            }}
            onEnterEditMode={enterEditMode}
            onRefreshData={async () => {
              await fetchPublicData(false);
            }}
          />
        </Suspense>
      </ErrorBoundary>
    );
  }

  // Dedicated Sign-In / Invite routes (hidden cleanly; no public navbar/footer)
  if (currentRoute === '/login' || currentRoute === '/invite') {
    if (authChecked && currentUser && currentRoute === '/login') {
      const params =
        typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : null;
      if (!params?.get('reset') && !params?.get('invite') && !params?.get('token')) {
        window.history.replaceState({}, '', '/portal');
        setCurrentRoute('/portal');
        return null;
      }
    }

    return (
      <ErrorBoundary onResetHome={() => navigate('/home')}>
        <SignInView
          onSignInSuccess={user => {
            setCurrentUser(user);
            navigate('/portal');
          }}
          onNavigate={navigate}
          logoUrl={moaLogoUrl}
          minPasswordLength={settings?.securityPolicy?.minPasswordLength || 12}
        />
      </ErrorBoundary>
    );
  }

  const renderPublicView = () => {
    if (loadError && !siteContent && !initialLoading) {
      return (
        <div className="min-h-[60vh] flex items-center justify-center px-6 py-20">
          <div className="max-w-md w-full bg-[#031D1C] border border-white/10 rounded-3xl p-8 text-center space-y-4">
            <AlertTriangle className="w-8 h-8 text-[#CA7952] mx-auto" />
            <h2 className="text-xl font-bold text-[#EDE9E0]">Unable to reach server</h2>
            <p className="text-xs text-[#EDE9E0]/65 leading-relaxed">{loadError}</p>
            <button
              type="button"
              onClick={() => void fetchPublicData(true)}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold text-xs cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry</span>
            </button>
          </div>
        </div>
      );
    }

    if (initialLoading && !siteContent) {
      return (
        <div className="min-h-[65vh] flex items-center justify-center text-xs font-mono text-[#EDE9E0]/50">
          Loading...
        </div>
      );
    }

    // Legacy /signin must return NotFoundView
    if (currentRoute === '/signin') {
      return (
        <NotFoundView
          content={mergedContent}
          onNavigate={navigate}
          isEditMode={isEditMode}
          onUpdateContent={handleUpdateInlineContent}
        />
      );
    }

    if (currentRoute === '/home') {
      return (
        <HomeView
          content={mergedContent}
          departments={departments}
          onNavigate={navigate}
          isEditMode={isEditMode}
          onUpdateContent={handleUpdateInlineContent}
          logoUrl={moaLogoUrl}
        />
      );
    }

    if (currentRoute === '/about') {
      return (
        <AboutView
          content={mergedContent}
          departments={departments}
          isEditMode={isEditMode}
          onUpdateContent={handleUpdateInlineContent}
        />
      );
    }

    if (currentRoute === '/departments') {
      return (
        <DepartmentsView
          departments={departments}
          projects={projects}
          publications={publications}
          products={products}
          content={mergedContent}
          loading={initialLoading && !siteContent}
          animateTreeReady={introDone && !initialLoading}
          onNavigate={navigate}
          isEditMode={isEditMode}
          onUpdateContent={handleUpdateInlineContent}
          onUpdateDepartment={handleUpdateInlineDepartment}
          moaLogoUrl={moaLogoUrl}
          rddLogoUrl={rddLogoUrl}
          siteName={siteName}
        />
      );
    }

    if (matchedSectorSlug || matchedDeptSlug) {
      if (!matchedDepartment) {
        return (
          <NotFoundView
            content={mergedContent}
            onNavigate={navigate}
            isEditMode={isEditMode}
            onUpdateContent={handleUpdateInlineContent}
          />
        );
      }
      const childSectorIds = new Set(
        departments
          .filter(
            d =>
              !d.deletedAt &&
              isSector(d) &&
              (d.parentDepartmentId || 'dept-rdd') === matchedDepartment.id
          )
          .map(d => d.id)
      );
      const matchesDeptOrChildSector = (deptIds?: string[], secIds?: string[]) =>
        (deptIds || []).includes(matchedDepartment.id) ||
        (secIds || []).includes(matchedDepartment.id) ||
        (secIds || []).some(id => childSectorIds.has(id)) ||
        (deptIds || []).some(id => childSectorIds.has(id));
      const relProjects = projects.filter(
        p => !p.deletedAt && matchesDeptOrChildSector(p.departmentIds, p.sectorIds)
      );
      const relPubs = publications.filter(
        p => !p.deletedAt && matchesDeptOrChildSector(p.departmentIds, p.sectorIds)
      );
      const relProducts = products.filter(
        p => !p.deletedAt && matchesDeptOrChildSector(p.departmentIds, p.sectorIds)
      );
      return (
        <DepartmentDetailView
          department={matchedDepartment}
          allDepartments={departments.filter(d => d.published && !d.deletedAt)}
          relatedProjects={relProjects}
          relatedPublications={relPubs}
          relatedProducts={relProducts}
          content={mergedContent}
          isEditMode={isEditMode}
          onUpdateContent={handleUpdateInlineContent}
          onUpdateDepartment={handleUpdateInlineDepartment}
          rddLogoUrl={rddLogoUrl}
          onNavigate={navigate}
        />
      );
    }

    if (currentRoute === '/projects') {
      return (
        <ProjectsView
          projects={projects}
          publications={publications}
          departments={departments}
          content={mergedContent}
          loading={initialLoading && !siteContent}
          onNavigate={navigate}
          isEditMode={isEditMode}
          onUpdateContent={handleUpdateInlineContent}
        />
      );
    }

    if (currentRoute === '/products') {
      const isPreviewAuthorized =
        Boolean(currentUser) &&
        typeof window !== 'undefined' &&
        new URLSearchParams(window.location.search).get('preview') === '1';
      if (!showProducts && !isPreviewAuthorized) {
        return (
          <NotFoundView
            content={mergedContent}
            onNavigate={navigate}
            isEditMode={isEditMode}
            onUpdateContent={handleUpdateInlineContent}
          />
        );
      }
      return (
        <ProductsView
          products={products}
          departments={departments}
          content={mergedContent}
          loading={initialLoading && !siteContent}
          onNavigate={navigate}
          isEditMode={isEditMode}
          onUpdateContent={handleUpdateInlineContent}
        />
      );
    }

    if (matchedProjectSlug) {
      if (!matchedProject) {
        return (
          <NotFoundView
            content={mergedContent}
            onNavigate={navigate}
            isEditMode={isEditMode}
            onUpdateContent={handleUpdateInlineContent}
          />
        );
      }
      const projOrgIds = new Set([...(matchedProject.departmentIds || []), ...(matchedProject.sectorIds || [])]);
      const relProjects = projects
        .filter(
          p =>
            p.id !== matchedProject.id &&
            !p.deletedAt &&
            ([...(p.departmentIds || []), ...(p.sectorIds || [])].some(id => projOrgIds.has(id)))
        )
        .slice(0, 3);
      return (
        <ProjectDetailView
          project={matchedProject}
          departments={departments}
          relatedProjects={relProjects}
          content={mergedContent}
          isEditMode={isEditMode}
          onUpdateContent={handleUpdateInlineContent}
          onNavigate={navigate}
        />
      );
    }

    if (matchedProductSlug) {
      if (!matchedProduct || (!showProducts && !previewProduct)) {
        return (
          <NotFoundView
            content={mergedContent}
            onNavigate={navigate}
            isEditMode={isEditMode}
            onUpdateContent={handleUpdateInlineContent}
          />
        );
      }
      return (
        <ProductDetailView
          product={matchedProduct}
          departments={departments}
          projects={projects}
          content={mergedContent}
          isEditMode={isEditMode}
          onUpdateContent={handleUpdateInlineContent}
          onNavigate={navigate}
        />
      );
    }

    if (currentRoute === '/contact') {
      return (
        <ContactView
          content={mergedContent}
          isEditMode={isEditMode}
          onUpdateContent={handleUpdateInlineContent}
          socialLinks={settings?.socialLinks}
          contactEmail={settings?.contactEmail}
          organizationAddress={settings?.organizationAddress}
        />
      );
    }

    if (matchedCustomPage) {
      return (
        <CustomPageView
          page={matchedCustomPage}
          departments={departments}
          onNavigate={navigate}
          moaLogoUrl={moaLogoUrl}
          rddLogoUrl={rddLogoUrl}
          siteName={siteName}
        />
      );
    }

    return (
      <NotFoundView
        content={mergedContent}
        onNavigate={navigate}
        isEditMode={isEditMode}
        onUpdateContent={handleUpdateInlineContent}
      />
    );
  };

  return (
    <ErrorBoundary onResetHome={() => navigate('/home')}>
      {!introDone && !isAuthRoute && (
        <LoadingScreen onComplete={() => setIntroDone(true)} logoUrl={loaderLogoUrl} />
      )}

      <div className="min-h-screen flex flex-col bg-[#06302F] text-[#EDE9E0]">
        {/* Sticky Top Stack: Live Editor Bar + Navbar */}
        <div ref={stickyStackRef} className="sticky top-0 z-40">
          {can(currentUser, 'website.edit') && (
            <div className="bg-[#031D1C] border-b border-[#25CDB6]/35 px-4 py-2 shadow-lg">
              <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2.5 text-xs">
                <div className="flex items-center gap-2.5">
                  <span className="px-2.5 py-1 rounded-lg bg-[#17A491]/20 border border-[#25CDB6]/40 text-[#25CDB6] font-bold font-mono text-[11px]">
                    {isEditMode ? 'Live Editor Active' : 'Live Editor Ready'}
                  </span>
                  {isEditMode && hasDraftChanges && (
                    <span className="text-amber-300 font-semibold">Unsaved draft changes</span>
                  )}
                  {isEditMode && editBannerMsg && (
                    <span
                      className={
                        editBannerMsg.type === 'ok' ? 'text-[#25CDB6] font-semibold' : 'text-red-300 font-semibold'
                      }
                    >
                      {editBannerMsg.text}
                    </span>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {isEditMode ? (
                    <>
                      <button
                        type="button"
                        disabled={editSaving || !hasDraftChanges}
                        onClick={handleSaveInlineDraft}
                        className="min-h-[36px] px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 disabled:opacity-40 text-[#EDE9E0] font-semibold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>Save Draft</span>
                      </button>
                      <button
                        type="button"
                        disabled={editSaving || !hasDraftChanges}
                        onClick={handlePublishInlineDraft}
                        className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] disabled:opacity-40 text-[#031D1C] font-bold flex items-center gap-1.5 cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Publish Live</span>
                      </button>
                      <button
                        type="button"
                        disabled={editSaving || !hasDraftChanges}
                        onClick={handleDiscardInlineDraft}
                        className="min-h-[36px] px-3 py-1.5 rounded-xl bg-white/5 hover:bg-red-500/20 disabled:opacity-40 text-[#EDE9E0]/85 hover:text-red-200 font-semibold flex items-center gap-1.5 cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Discard</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsEditMode(false)}
                        className="min-h-[36px] px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-[#EDE9E0]/85 font-semibold cursor-pointer"
                      >
                        Exit Edit Mode
                      </button>
                    </>
                  ) : (
                    <button
                      type="button"
                      onClick={() => void enterEditMode()}
                      className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                      <span>Edit Page Live</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setIsEditMode(false);
                      navigate('/portal');
                    }}
                    className="min-h-[36px] px-3 py-1.5 rounded-xl bg-[#0A3D3C] hover:bg-[#0A3D3C]/80 border border-white/15 text-[#EDE9E0] font-semibold flex items-center gap-1.5 cursor-pointer"
                  >
                    <LayoutDashboard className="w-3.5 h-3.5 text-[#25CDB6]" />
                    <span>Control Room</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          <Navbar
            currentPath={currentRoute}
            onNavigate={navigate}
            socialLinks={settings?.socialLinks}
            navigation={settings?.navigation}
            showProducts={showProducts}
            logoUrl={moaLogoUrl}
            siteName={siteName}
          />
        </div>

        <main className="flex-1 flex flex-col">{renderPublicView()}</main>

        <Footer
          departments={departments}
          onNavigate={navigate}
          socialLinks={settings?.socialLinks}
          footerText={settings?.footerText}
          footerColumns={settings?.footerColumns}
          showProducts={showProducts}
          contactEmail={settings?.contactEmail}
          organizationAddress={settings?.organizationAddress}
          logoUrl={moaLogoUrl}
          siteName={siteName}
          tagline={settings?.tagline}
          content={mergedContent.footer}
        />

        {/* Floating Bottom-Right Announcement Widget */}
        <AnimatePresence>
          {isAnnouncementActive && announcement && (
            <motion.aside
              key="floating-announcement-widget"
              aria-label="Site announcement"
              initial={{ opacity: 0, y: 20, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.96 }}
              transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
              className="fixed bottom-5 right-5 z-50 max-w-sm w-[calc(100%-2.5rem)] rounded-2xl bg-[#031D1C]/95 backdrop-blur-md border border-[#17A491]/45 shadow-2xl shadow-black/50 p-4 text-xs text-[#EDE9E0]"
            >
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-[#17A491]/15 border border-[#25CDB6]/30 flex items-center justify-center text-[#25CDB6] shrink-0 mt-0.5">
                  <Megaphone className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0 space-y-2">
                  <p className="text-xs sm:text-[13px] text-[#EDE9E0]/95 leading-relaxed break-words">
                    {announcement.text}
                  </p>
                  {announcement.linkUrl && sanitizeSafeUrl(announcement.linkUrl) && (
                    <SpaLink
                      href={sanitizeSafeUrl(announcement.linkUrl)}
                      onNavigate={navigate}
                      className="inline-flex items-center gap-1 font-bold text-[#25CDB6] hover:underline"
                    >
                      <span>{announcement.linkLabel || 'Learn more'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </SpaLink>
                  )}
                </div>
                <button
                  type="button"
                  aria-label="Dismiss announcement"
                  onClick={() => setAnnouncementDismissed(true)}
                  className="p-1.5 rounded-lg text-[#EDE9E0]/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>
    </ErrorBoundary>
  );
}
