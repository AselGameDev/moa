import React from 'react';
import { AtmosphericBackground } from '../components/AtmosphericBackground';
import { PublicBlocksRenderer } from '../components/PublicBlocksRenderer';
import { PageRecord, Department } from '../types';

interface CustomPageViewProps {
  page: PageRecord;
  departments: Department[];
  onNavigate: (path: string) => void;
  moaLogoUrl?: string;
  rddLogoUrl?: string;
  siteName?: string;
}

export const CustomPageView: React.FC<CustomPageViewProps> = ({
  page,
  departments,
  onNavigate,
  moaLogoUrl = '/drawing1.png',
  rddLogoUrl = '',
  siteName = 'Masters Of All'
}) => {
  return (
    <div className="min-h-screen">
      <AtmosphericBackground intensity="subtle" fadeToColor="transparent" className="py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          {(!page.blocks || page.blocks.length === 0) && (
            <h1 className="text-4xl font-extrabold text-[#EDE9E0]">{page.title}</h1>
          )}
          <PublicBlocksRenderer
            blocks={page.blocks}
            departments={departments}
            onNavigate={onNavigate}
            moaLogoUrl={moaLogoUrl}
            rddLogoUrl={rddLogoUrl}
            siteName={siteName}
            fallbackTitle={page.title}
            className="space-y-12"
          />
        </div>
      </AtmosphericBackground>
    </div>
  );
};
