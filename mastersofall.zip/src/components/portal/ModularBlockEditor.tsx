import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  MoveUp,
  MoveDown,
  GripVertical,
  Image as ImageIcon,
  Heading,
  AlignLeft,
  Columns,
  ListOrdered,
  LayoutGrid,
  Hash,
  Quote,
  Images,
  Video,
  Link2,
  MousePointerClick
} from 'lucide-react';
import { MediaAsset, ModularPageBlockType, PageBlock } from '../../types';
import { isSafeUrl } from '../../shared/url';
import { MediaPicker } from '../MediaPicker';

export interface ModularBlockMeta {
  type: ModularPageBlockType;
  label: string;
  description: string;
}

export const MODULAR_BLOCK_DEFINITIONS: ModularBlockMeta[] = [
  { type: 'heading', label: 'Heading', description: 'Section title with optional eyebrow' },
  { type: 'paragraph', label: 'Paragraph', description: 'Multi-line narrative text' },
  { type: 'image', label: 'Image', description: 'Single framed image with caption' },
  { type: 'image-text', label: 'Image + Text', description: 'Two-column image and copy layout' },
  { type: 'list', label: 'List', description: 'Bulleted or numbered list items' },
  { type: 'feature-cards', label: 'Feature cards', description: 'Responsive grid of highlight cards' },
  { type: 'numbers', label: 'Numbers', description: 'Key statistics and counters row' },
  { type: 'quote', label: 'Quote', description: 'Featured blockquote with attribution' },
  { type: 'gallery', label: 'Gallery', description: 'Multi-image showcase grid' },
  { type: 'video', label: 'Video', description: 'YouTube, Vimeo, or uploaded video' },
  { type: 'links', label: 'Links', description: 'Collection of action links' },
  { type: 'button', label: 'Button', description: 'Primary call-to-action button' }
];

const BLOCK_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  heading: Heading,
  paragraph: AlignLeft,
  image: ImageIcon,
  'image-text': Columns,
  list: ListOrdered,
  'feature-cards': LayoutGrid,
  numbers: Hash,
  quote: Quote,
  gallery: Images,
  video: Video,
  links: Link2,
  button: MousePointerClick
};

export function createDefaultModularBlock(type: ModularPageBlockType): PageBlock {
  const id = `blk-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  switch (type) {
    case 'heading':
      return { id, type, config: { text: 'Section Heading', level: 2, eyebrow: '', subtitle: '' } };
    case 'paragraph':
      return { id, type, config: { heading: '', text: 'Write your paragraph content here.' } };
    case 'image':
      return { id, type, config: { imageUrl: '', alt: '', caption: '' } };
    case 'image-text':
      return { id, type, config: { heading: 'Feature Spotlight', text: '', imageUrl: '', alt: '', imagePosition: 'left' } };
    case 'list':
      return { id, type, config: { heading: '', ordered: false, items: ['First item', 'Second item'] } };
    case 'feature-cards':
      return {
        id,
        type,
        config: {
          heading: 'Key Highlights',
          items: [{ title: 'Highlight Title', description: 'Short summary.' }]
        }
      };
    case 'numbers':
      return {
        id,
        type,
        config: {
          heading: '',
          items: [{ value: '01', label: 'Metric' }]
        }
      };
    case 'quote':
      return { id, type, config: { quote: 'Meaningful statement goes here.', attribution: '' } };
    case 'gallery':
      return { id, type, config: { images: [] } };
    case 'video':
      return { id, type, config: { title: 'Video Showcase', url: '' } };
    case 'links':
      return { id, type, config: { heading: 'Related Links', items: [{ label: 'Learn More', url: '/projects', newTab: false }] } };
    case 'button':
      return { id, type, config: { label: 'Explore', url: '/departments', newTab: false } };
  }
}

interface ModularBlockEditorProps {
  blocks: PageBlock[];
  onChange: (nextBlocks: PageBlock[]) => void;
}

type BlockMediaTarget =
  | { blockIndex: number; mode: 'single' }
  | { blockIndex: number; mode: 'galleryAdd' };

export const ModularBlockEditor: React.FC<ModularBlockEditorProps> = ({ blocks, onChange }) => {
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [mediaTarget, setMediaTarget] = useState<BlockMediaTarget | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);

  const updateBlockConfig = (idx: number, patch: Record<string, unknown>) => {
    const next = blocks.map((b, i) => (i === idx ? { ...b, config: { ...(b.config || {}), ...patch } } : b));
    onChange(next);
  };

  const moveBlock = (from: number, to: number) => {
    if (to < 0 || to >= blocks.length || from === to) return;
    const next = [...blocks];
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    onChange(next);
  };

  const removeBlock = (idx: number) => {
    onChange(blocks.filter((_, i) => i !== idx));
  };

  const handleAddBlock = (type: ModularPageBlockType) => {
    onChange([...blocks, createDefaultModularBlock(type)]);
  };

  const handleMediaSelected = (asset: MediaAsset) => {
    if (!mediaTarget) return;
    const { blockIndex, mode } = mediaTarget;
    const targetBlock = blocks[blockIndex];
    if (!targetBlock) return;
    if (mode === 'single') {
      updateBlockConfig(blockIndex, {
        imageUrl: asset.url,
        alt: String(targetBlock.config?.alt || asset.altText || asset.name)
      });
    } else if (mode === 'galleryAdd') {
      const existing = Array.isArray(targetBlock.config?.images) ? (targetBlock.config.images as string[]) : [];
      updateBlockConfig(blockIndex, { images: [...existing, asset.url] });
    }
    setMediaTarget(null);
    setPickerOpen(false);
  };

  const str = (cfg: Record<string, unknown>, key: string) =>
    typeof cfg?.[key] === 'string' ? (cfg[key] as string) : '';

  return (
    <div className="space-y-4">
      <div className="p-3.5 rounded-xl bg-[#06302F] border border-white/10 space-y-2">
        <span className="text-[11px] font-bold uppercase tracking-wider text-[#25CDB6] block">
          Add Content Block
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {MODULAR_BLOCK_DEFINITIONS.map(def => {
            const Icon = BLOCK_ICONS[def.type] || Plus;
            return (
              <button
                key={def.type}
                type="button"
                onClick={() => handleAddBlock(def.type)}
                title={def.description}
                className="flex items-center gap-2 px-2.5 py-2 rounded-lg bg-[#031D1C] hover:bg-[#17A491]/15 border border-white/10 hover:border-[#25CDB6]/40 text-left text-xs text-[#EDE9E0] transition-colors cursor-pointer"
              >
                <Icon className="w-3.5 h-3.5 text-[#25CDB6] shrink-0" />
                <span className="font-semibold truncate">{def.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {blocks.length === 0 ? (
        <div className="p-8 rounded-2xl border border-dashed border-white/15 bg-[#06302F]/40 text-center text-xs text-[#EDE9E0]/60">
          No blocks yet. Choose any block above to start composing this page.
        </div>
      ) : (
        <div className="space-y-3">
          {blocks.map((block, idx) => {
            const cfg = block.config || {};
            const Icon = BLOCK_ICONS[block.type] || AlignLeft;
            const blockLabel =
              MODULAR_BLOCK_DEFINITIONS.find(d => d.type === block.type)?.label || block.type;

            return (
              <div
                key={block.id}
                draggable
                onDragStart={() => setDragIndex(idx)}
                onDragOver={e => e.preventDefault()}
                onDrop={() => {
                  if (dragIndex !== null && dragIndex !== idx) {
                    moveBlock(dragIndex, idx);
                  }
                  setDragIndex(null);
                }}
                onDragEnd={() => setDragIndex(null)}
                className="rounded-xl bg-[#06302F] border border-white/10 p-4 space-y-3"
              >
                <div className="flex items-center justify-between gap-2 pb-2 border-b border-white/10">
                  <div className="flex items-center gap-2 min-w-0">
                    <GripVertical className="w-4 h-4 text-[#EDE9E0]/40 cursor-grab shrink-0" />
                    <Icon className="w-3.5 h-3.5 text-[#25CDB6] shrink-0" />
                    <span className="text-xs font-bold text-[#EDE9E0] truncate">{blockLabel}</span>
                    <span className="text-[10px] font-mono text-[#EDE9E0]/45">#{idx + 1}</span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => moveBlock(idx, idx - 1)}
                      disabled={idx === 0}
                      aria-label={`Move block ${idx + 1} up`}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 disabled:opacity-30 cursor-pointer"
                    >
                      <MoveUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => moveBlock(idx, idx + 1)}
                      disabled={idx === blocks.length - 1}
                      aria-label={`Move block ${idx + 1} down`}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white/70 disabled:opacity-30 cursor-pointer"
                    >
                      <MoveDown className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => removeBlock(idx)}
                      aria-label={`Delete block ${idx + 1}`}
                      className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-300 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Block-specific fields */}
                {(block.type === 'heading' || block.type === 'hero') && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                    <div>
                      <label className="block text-[#EDE9E0]/65 mb-1">Eyebrow (optional)</label>
                      <input
                        type="text"
                        value={str(cfg, 'eyebrow')}
                        onChange={e => updateBlockConfig(idx, { eyebrow: e.target.value })}
                        className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                      />
                    </div>
                    <div>
                      <label className="block text-[#EDE9E0]/65 mb-1">Heading Level</label>
                      <select
                        value={Number(cfg.level || 2)}
                        onChange={e => updateBlockConfig(idx, { level: Number(e.target.value) })}
                        className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                      >
                        <option value={1}>H1 (Main Title)</option>
                        <option value={2}>H2 (Section)</option>
                        <option value={3}>H3 (Subsection)</option>
                      </select>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-[#EDE9E0]/65 mb-1">Heading Text</label>
                      <input
                        type="text"
                        value={str(cfg, 'text') || str(cfg, 'heading')}
                        onChange={e => updateBlockConfig(idx, { text: e.target.value, heading: e.target.value })}
                        className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-[#EDE9E0]/65 mb-1">Subtitle (optional)</label>
                      <input
                        type="text"
                        value={str(cfg, 'subtitle')}
                        onChange={e => updateBlockConfig(idx, { subtitle: e.target.value })}
                        className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                      />
                    </div>
                  </div>
                )}

                {(block.type === 'paragraph' || block.type === 'text') && (
                  <div className="space-y-2.5 text-xs">
                    <div>
                      <label className="block text-[#EDE9E0]/65 mb-1">Heading (optional)</label>
                      <input
                        type="text"
                        value={str(cfg, 'heading')}
                        onChange={e => updateBlockConfig(idx, { heading: e.target.value })}
                        className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                      />
                    </div>
                    <div>
                      <label className="block text-[#EDE9E0]/65 mb-1">Body Copy</label>
                      <textarea
                        rows={4}
                        value={str(cfg, 'text') || str(cfg, 'body')}
                        onChange={e => updateBlockConfig(idx, { text: e.target.value, body: e.target.value })}
                        className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                      />
                    </div>
                  </div>
                )}

                {block.type === 'image' && (
                  <div className="space-y-2.5 text-xs">
                    <div className="flex flex-wrap items-center gap-3">
                      {str(cfg, 'imageUrl') ? (
                        <img
                          src={str(cfg, 'imageUrl')}
                          alt={str(cfg, 'alt') || 'Block preview'}
                          className="w-24 h-16 rounded-lg object-cover border border-white/10 bg-[#031D1C]"
                        />
                      ) : (
                        <div className="w-24 h-16 rounded-lg border border-dashed border-white/15 flex items-center justify-center text-[#EDE9E0]/40">
                          <ImageIcon className="w-5 h-5" />
                        </div>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          setMediaTarget({ blockIndex: idx, mode: 'single' });
                          setPickerOpen(true);
                        }}
                        className="px-3 py-2 rounded-lg bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold cursor-pointer"
                      >
                        Choose Image
                      </button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder="Alt text"
                        value={str(cfg, 'alt')}
                        onChange={e => updateBlockConfig(idx, { alt: e.target.value })}
                        className="bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                      />
                      <input
                        type="text"
                        placeholder="Caption (optional)"
                        value={str(cfg, 'caption')}
                        onChange={e => updateBlockConfig(idx, { caption: e.target.value })}
                        className="bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                      />
                    </div>
                  </div>
                )}

                {block.type === 'image-text' && (
                  <div className="space-y-2.5 text-xs">
                    <div className="flex flex-wrap items-center gap-3">
                      {str(cfg, 'imageUrl') && (
                        <img
                          src={str(cfg, 'imageUrl')}
                          alt={str(cfg, 'alt') || 'Block image'}
                          className="w-20 h-14 rounded-lg object-cover border border-white/10"
                        />
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          setMediaTarget({ blockIndex: idx, mode: 'single' });
                          setPickerOpen(true);
                        }}
                        className="px-3 py-2 rounded-lg bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold cursor-pointer"
                      >
                        {str(cfg, 'imageUrl') ? 'Change Image' : 'Select Image'}
                      </button>
                      <select
                        value={str(cfg, 'imagePosition') || 'left'}
                        onChange={e => updateBlockConfig(idx, { imagePosition: e.target.value })}
                        className="bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                      >
                        <option value="left">Image Left</option>
                        <option value="right">Image Right</option>
                      </select>
                    </div>
                    <input
                      type="text"
                      placeholder="Heading"
                      value={str(cfg, 'heading')}
                      onChange={e => updateBlockConfig(idx, { heading: e.target.value })}
                      className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                    />
                    <textarea
                      rows={3}
                      placeholder="Body text"
                      value={str(cfg, 'text') || str(cfg, 'body')}
                      onChange={e => updateBlockConfig(idx, { text: e.target.value, body: e.target.value })}
                      className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                    />
                  </div>
                )}

                {block.type === 'list' && (
                  <div className="space-y-2.5 text-xs">
                    <div className="flex items-center gap-3">
                      <input
                        type="text"
                        placeholder="Heading (optional)"
                        value={str(cfg, 'heading')}
                        onChange={e => updateBlockConfig(idx, { heading: e.target.value })}
                        className="flex-1 bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                      />
                      <label className="flex items-center gap-1.5 text-[#EDE9E0]/80 cursor-pointer shrink-0">
                        <input
                          type="checkbox"
                          checked={Boolean(cfg.ordered)}
                          onChange={e => updateBlockConfig(idx, { ordered: e.target.checked })}
                          className="accent-[#25CDB6]"
                        />
                        <span>Numbered</span>
                      </label>
                    </div>
                    <textarea
                      rows={4}
                      placeholder="One list item per line"
                      value={Array.isArray(cfg.items) ? (cfg.items as string[]).join('\n') : ''}
                      onChange={e =>
                        updateBlockConfig(idx, {
                          items: e.target.value.split('\n')
                        })
                      }
                      className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                    />
                  </div>
                )}

                {(block.type === 'feature-cards' || block.type === 'cards-grid') && (
                  <div className="space-y-2.5 text-xs">
                    <input
                      type="text"
                      placeholder="Section heading"
                      value={str(cfg, 'heading')}
                      onChange={e => updateBlockConfig(idx, { heading: e.target.value })}
                      className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                    />
                    {(Array.isArray(cfg.items) ? (cfg.items as Array<{ title?: string; description?: string }>) : []).map(
                      (card, cIdx) => (
                        <div key={cIdx} className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-center">
                          <input
                            type="text"
                            placeholder="Card title"
                            value={card.title || ''}
                            onChange={e => {
                              const arr = [...((cfg.items as Array<{ title?: string; description?: string }>) || [])];
                              arr[cIdx] = { ...arr[cIdx], title: e.target.value };
                              updateBlockConfig(idx, { items: arr });
                            }}
                            className="sm:col-span-4 bg-[#031D1C] border border-white/10 rounded-lg px-2.5 py-1.5 text-[#EDE9E0]"
                          />
                          <input
                            type="text"
                            placeholder="Card description"
                            value={card.description || ''}
                            onChange={e => {
                              const arr = [...((cfg.items as Array<{ title?: string; description?: string }>) || [])];
                              arr[cIdx] = { ...arr[cIdx], description: e.target.value };
                              updateBlockConfig(idx, { items: arr });
                            }}
                            className="sm:col-span-7 bg-[#031D1C] border border-white/10 rounded-lg px-2.5 py-1.5 text-[#EDE9E0]"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              const arr = [...((cfg.items as Array<unknown>) || [])];
                              arr.splice(cIdx, 1);
                              updateBlockConfig(idx, { items: arr });
                            }}
                            className="sm:col-span-1 text-red-300 hover:text-red-200 p-1 cursor-pointer"
                            aria-label="Remove card"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        const arr = [...((cfg.items as Array<unknown>) || []), { title: 'New Card', description: '' }];
                        updateBlockConfig(idx, { items: arr });
                      }}
                      className="text-[#25CDB6] font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add card
                    </button>
                  </div>
                )}

                {(block.type === 'numbers' || block.type === 'stats') && (
                  <div className="space-y-2.5 text-xs">
                    <input
                      type="text"
                      placeholder="Heading (optional)"
                      value={str(cfg, 'heading')}
                      onChange={e => updateBlockConfig(idx, { heading: e.target.value })}
                      className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                    />
                    {(Array.isArray(cfg.items) ? (cfg.items as Array<{ value?: string; label?: string }>) : []).map(
                      (stat, sIdx) => (
                        <div key={sIdx} className="grid grid-cols-12 gap-2 items-center">
                          <input
                            type="text"
                            placeholder="Value (e.g. 42+)"
                            value={stat.value || ''}
                            onChange={e => {
                              const arr = [...((cfg.items as Array<{ value?: string; label?: string }>) || [])];
                              arr[sIdx] = { ...arr[sIdx], value: e.target.value };
                              updateBlockConfig(idx, { items: arr });
                            }}
                            className="col-span-4 bg-[#031D1C] border border-white/10 rounded-lg px-2.5 py-1.5 text-[#EDE9E0]"
                          />
                          <input
                            type="text"
                            placeholder="Label"
                            value={stat.label || ''}
                            onChange={e => {
                              const arr = [...((cfg.items as Array<{ value?: string; label?: string }>) || [])];
                              arr[sIdx] = { ...arr[sIdx], label: e.target.value };
                              updateBlockConfig(idx, { items: arr });
                            }}
                            className="col-span-7 bg-[#031D1C] border border-white/10 rounded-lg px-2.5 py-1.5 text-[#EDE9E0]"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              const arr = [...((cfg.items as Array<unknown>) || [])];
                              arr.splice(sIdx, 1);
                              updateBlockConfig(idx, { items: arr });
                            }}
                            className="col-span-1 text-red-300 hover:text-red-200 p-1 cursor-pointer"
                            aria-label="Remove metric"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        const arr = [...((cfg.items as Array<unknown>) || []), { value: '100%', label: 'Label' }];
                        updateBlockConfig(idx, { items: arr });
                      }}
                      className="text-[#25CDB6] font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add metric
                    </button>
                  </div>
                )}

                {block.type === 'quote' && (
                  <div className="space-y-2 text-xs">
                    <textarea
                      rows={3}
                      placeholder="Quote text"
                      value={str(cfg, 'quote') || str(cfg, 'text')}
                      onChange={e => updateBlockConfig(idx, { quote: e.target.value, text: e.target.value })}
                      className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                    />
                    <input
                      type="text"
                      placeholder="Attribution"
                      value={str(cfg, 'attribution')}
                      onChange={e => updateBlockConfig(idx, { attribution: e.target.value })}
                      className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                    />
                  </div>
                )}

                {block.type === 'gallery' && (
                  <div className="space-y-2.5 text-xs">
                    <div className="flex flex-wrap gap-2">
                      {(Array.isArray(cfg.images) ? (cfg.images as string[]) : []).map((imgUrl, gIdx) => (
                        <div key={gIdx} className="relative group w-20 h-16 rounded-lg overflow-hidden border border-white/15">
                          <img src={imgUrl} alt={`Gallery ${gIdx + 1}`} className="w-full h-full object-cover" />
                          <button
                            type="button"
                            onClick={() => {
                              const arr = [...((cfg.images as string[]) || [])];
                              arr.splice(gIdx, 1);
                              updateBlockConfig(idx, { images: arr });
                            }}
                            className="absolute top-1 right-1 p-1 rounded bg-black/70 text-red-300 cursor-pointer"
                            aria-label="Remove image"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                      <button
                        type="button"
                        onClick={() => {
                          setMediaTarget({ blockIndex: idx, mode: 'galleryAdd' });
                          setPickerOpen(true);
                        }}
                        className="w-20 h-16 rounded-lg border border-dashed border-[#25CDB6]/40 hover:bg-[#17A491]/10 flex flex-col items-center justify-center text-[#25CDB6] cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span className="text-[10px] font-semibold">Add</span>
                      </button>
                    </div>
                  </div>
                )}

                {block.type === 'video' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                    <input
                      type="text"
                      placeholder="Video title"
                      value={str(cfg, 'title')}
                      onChange={e => updateBlockConfig(idx, { title: e.target.value })}
                      className="bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                    />
                    <input
                      type="url"
                      placeholder="YouTube, Vimeo, or MP4 URL"
                      value={str(cfg, 'url')}
                      onChange={e => updateBlockConfig(idx, { url: e.target.value })}
                      className="bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 font-mono text-[#EDE9E0]"
                    />
                  </div>
                )}

                {block.type === 'links' && (
                  <div className="space-y-2.5 text-xs">
                    <input
                      type="text"
                      placeholder="Heading (optional)"
                      value={str(cfg, 'heading')}
                      onChange={e => updateBlockConfig(idx, { heading: e.target.value })}
                      className="w-full bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                    />
                    {(Array.isArray(cfg.items) ? (cfg.items as Array<{ label?: string; url?: string; newTab?: boolean }>) : []).map(
                      (lnk, lIdx) => (
                        <div key={lIdx} className="grid grid-cols-12 gap-2 items-center">
                          <input
                            type="text"
                            placeholder="Label"
                            value={lnk.label || ''}
                            onChange={e => {
                              const arr = [...((cfg.items as Array<{ label?: string; url?: string; newTab?: boolean }>) || [])];
                              arr[lIdx] = { ...arr[lIdx], label: e.target.value };
                              updateBlockConfig(idx, { items: arr });
                            }}
                            className="col-span-4 bg-[#031D1C] border border-white/10 rounded-lg px-2.5 py-1.5 text-[#EDE9E0]"
                          />
                          <input
                            type="text"
                            placeholder="/path or https://..."
                            value={lnk.url || ''}
                            onChange={e => {
                              const arr = [...((cfg.items as Array<{ label?: string; url?: string; newTab?: boolean }>) || [])];
                              arr[lIdx] = { ...arr[lIdx], url: e.target.value };
                              updateBlockConfig(idx, { items: arr });
                            }}
                            className={`col-span-5 bg-[#031D1C] border rounded-lg px-2.5 py-1.5 font-mono text-[#EDE9E0] ${
                              lnk.url && !isSafeUrl(lnk.url) ? 'border-red-500/60' : 'border-white/10'
                            }`}
                          />
                          <label className="col-span-2 flex items-center gap-1 text-[11px] text-[#EDE9E0]/75 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={Boolean(lnk.newTab)}
                              onChange={e => {
                                const arr = [...((cfg.items as Array<{ label?: string; url?: string; newTab?: boolean }>) || [])];
                                arr[lIdx] = { ...arr[lIdx], newTab: e.target.checked };
                                updateBlockConfig(idx, { items: arr });
                              }}
                              className="accent-[#25CDB6]"
                            />
                            <span>Tab</span>
                          </label>
                          <button
                            type="button"
                            onClick={() => {
                              const arr = [...((cfg.items as Array<unknown>) || [])];
                              arr.splice(lIdx, 1);
                              updateBlockConfig(idx, { items: arr });
                            }}
                            className="col-span-1 text-red-300 hover:text-red-200 p-1 cursor-pointer"
                            aria-label="Remove link"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        const arr = [...((cfg.items as Array<unknown>) || []), { label: 'Link', url: '/', newTab: false }];
                        updateBlockConfig(idx, { items: arr });
                      }}
                      className="text-[#25CDB6] font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add link
                    </button>
                  </div>
                )}

                {block.type === 'button' && (
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center text-xs">
                    <input
                      type="text"
                      placeholder="Button label"
                      value={str(cfg, 'label') || str(cfg, 'ctaLabel')}
                      onChange={e => updateBlockConfig(idx, { label: e.target.value, ctaLabel: e.target.value })}
                      className="sm:col-span-4 bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 text-[#EDE9E0]"
                    />
                    <input
                      type="text"
                      placeholder="Destination URL (/path or https://...)"
                      value={str(cfg, 'url') || str(cfg, 'ctaUrl')}
                      onChange={e => updateBlockConfig(idx, { url: e.target.value, ctaUrl: e.target.value })}
                      className="sm:col-span-6 bg-[#031D1C] border border-white/10 rounded-lg px-3 py-2 font-mono text-[#EDE9E0]"
                    />
                    <label className="sm:col-span-2 flex items-center gap-1.5 text-[#EDE9E0]/80 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={Boolean(cfg.newTab)}
                        onChange={e => updateBlockConfig(idx, { newTab: e.target.checked })}
                        className="accent-[#25CDB6]"
                      />
                      <span>New tab</span>
                    </label>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <MediaPicker
        isOpen={pickerOpen}
        onClose={() => {
          setPickerOpen(false);
          setMediaTarget(null);
        }}
        onSelect={handleMediaSelected}
        allowedTypes={['image']}
        title="Select Image Asset"
      />
    </div>
  );
};
