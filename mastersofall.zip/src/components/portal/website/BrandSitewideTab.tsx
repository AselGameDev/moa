import React, { useEffect, useMemo, useState } from 'react';
import {
  RotateCcw,
  Check,
  AlertCircle,
  Plus,
  Trash2,
  MoveUp,
  MoveDown,
  GripVertical,
  Eye,
  EyeOff,
  ExternalLink
} from 'lucide-react';
import {
  AnnouncementBarConfig,
  SocialLink,
  WebsiteOverviewResponse
} from '../../../types';
import { api, HttpError } from '../../../services/api';
import { isHttpUrl, isSafeUrl } from '../../../shared/url';
import { PortalFloatingSaveBar, PortalMediaField, PortalSection } from '../ui';

interface BrandSitewideTabProps {
  overview: WebsiteOverviewResponse;
  onDirtyChange?: (dirty: boolean) => void;
  onSaved: () => Promise<void>;
}

type BrandAssetKey = 'moaLogoUrl' | 'rddLogoUrl' | 'loaderLogoUrl' | 'faviconUrl' | 'shareImageUrl';

const DEFAULT_BRAND_URLS: Record<BrandAssetKey, string> = {
  moaLogoUrl: '/drawing1.png',
  rddLogoUrl: '/5320.jpg',
  loaderLogoUrl: '/drawing1.png',
  faviconUrl: '/drawing1.png',
  shareImageUrl: ''
};

const DEFAULT_BRAND_STATE = {
  version: 1,
  moaLogoUrl: DEFAULT_BRAND_URLS.moaLogoUrl,
  rddLogoUrl: DEFAULT_BRAND_URLS.rddLogoUrl,
  loaderLogoUrl: DEFAULT_BRAND_URLS.loaderLogoUrl,
  sameLoaderAsPrimary: true,
  faviconUrl: DEFAULT_BRAND_URLS.faviconUrl,
  shareImageUrl: ''
};

const DEFAULT_ANNOUNCEMENT_STATE = {
  version: 1,
  enabled: false,
  text: '',
  linkUrl: '',
  linkLabel: '',
  startDate: '',
  endDate: '',
  expiresAt: ''
};

const EMPTY_SOCIAL_LINKS: SocialLink[] = [];
const DEFAULT_SOCIAL_STATE = {
  version: 1,
  links: EMPTY_SOCIAL_LINKS
};

export const BrandSitewideTab: React.FC<BrandSitewideTabProps> = ({
  overview,
  onDirtyChange,
  onSaved
}) => {
  const brand = useMemo(() => overview?.brand || DEFAULT_BRAND_STATE, [overview?.brand]);
  const overviewAnnouncement = useMemo(
    () => overview?.announcement || DEFAULT_ANNOUNCEMENT_STATE,
    [overview?.announcement]
  );
  const overviewSocial = useMemo(
    () => overview?.social || DEFAULT_SOCIAL_STATE,
    [overview?.social]
  );

  const [moaLogoUrl, setMoaLogoUrl] = useState(brand.moaLogoUrl || DEFAULT_BRAND_URLS.moaLogoUrl);
  const [rddLogoUrl, setRddLogoUrl] = useState(brand.rddLogoUrl || DEFAULT_BRAND_URLS.rddLogoUrl);
  const [loaderLogoUrl, setLoaderLogoUrl] = useState(brand.loaderLogoUrl || DEFAULT_BRAND_URLS.loaderLogoUrl);
  const [sameLoaderAsPrimary, setSameLoaderAsPrimary] = useState(Boolean(brand.sameLoaderAsPrimary));
  const [faviconUrl, setFaviconUrl] = useState(brand.faviconUrl || DEFAULT_BRAND_URLS.faviconUrl);
  const [shareImageUrl, setShareImageUrl] = useState(brand.shareImageUrl || '');

  const [brandMsg, setBrandMsg] = useState<{ type: 'ok' | 'err'; text: string; conflict?: boolean } | null>(null);

  const [announcement, setAnnouncement] = useState<AnnouncementBarConfig>({
    enabled: Boolean(overviewAnnouncement.enabled),
    text: overviewAnnouncement.text || '',
    linkUrl: overviewAnnouncement.linkUrl || '',
    linkLabel: overviewAnnouncement.linkLabel || '',
    startDate: (overviewAnnouncement.startDate || '').slice(0, 10),
    endDate: (overviewAnnouncement.endDate || overviewAnnouncement.expiresAt || '').slice(0, 10)
  });
  const [annMsg, setAnnMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const [socialLinks, setSocialLinks] = useState<SocialLink[]>(
    Array.isArray(overviewSocial.links) ? overviewSocial.links : []
  );
  const [dragSocialIdx, setDragSocialIdx] = useState<number | null>(null);
  const [newPlatform, setNewPlatform] = useState('LinkedIn');
  const [newUrl, setNewUrl] = useState('');
  const [socialMsg, setSocialMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [savingAll, setSavingAll] = useState(false);

  useEffect(() => {
    setMoaLogoUrl(brand.moaLogoUrl || DEFAULT_BRAND_URLS.moaLogoUrl);
    setRddLogoUrl(brand.rddLogoUrl || DEFAULT_BRAND_URLS.rddLogoUrl);
    setLoaderLogoUrl(brand.loaderLogoUrl || DEFAULT_BRAND_URLS.loaderLogoUrl);
    setSameLoaderAsPrimary(Boolean(brand.sameLoaderAsPrimary));
    setFaviconUrl(brand.faviconUrl || DEFAULT_BRAND_URLS.faviconUrl);
    setShareImageUrl(brand.shareImageUrl || '');
  }, [
    brand.version,
    brand.moaLogoUrl,
    brand.rddLogoUrl,
    brand.loaderLogoUrl,
    brand.sameLoaderAsPrimary,
    brand.faviconUrl,
    brand.shareImageUrl
  ]);

  useEffect(() => {
    setAnnouncement({
      enabled: Boolean(overviewAnnouncement.enabled),
      text: overviewAnnouncement.text || '',
      linkUrl: overviewAnnouncement.linkUrl || '',
      linkLabel: overviewAnnouncement.linkLabel || '',
      startDate: (overviewAnnouncement.startDate || '').slice(0, 10),
      endDate: (overviewAnnouncement.endDate || overviewAnnouncement.expiresAt || '').slice(0, 10)
    });
  }, [
    overviewAnnouncement.version,
    overviewAnnouncement.enabled,
    overviewAnnouncement.text,
    overviewAnnouncement.linkUrl,
    overviewAnnouncement.linkLabel,
    overviewAnnouncement.startDate,
    overviewAnnouncement.endDate,
    overviewAnnouncement.expiresAt
  ]);

  useEffect(() => {
    setSocialLinks(Array.isArray(overviewSocial.links) ? overviewSocial.links : []);
  }, [overviewSocial.version, overviewSocial.links]);

  const brandDirty = useMemo(() => {
    const baseLoader = brand.sameLoaderAsPrimary
      ? brand.moaLogoUrl || DEFAULT_BRAND_URLS.moaLogoUrl
      : brand.loaderLogoUrl || DEFAULT_BRAND_URLS.loaderLogoUrl;
    const currLoader = sameLoaderAsPrimary ? moaLogoUrl : loaderLogoUrl;
    return (
      moaLogoUrl !== (brand.moaLogoUrl || DEFAULT_BRAND_URLS.moaLogoUrl) ||
      rddLogoUrl !== (brand.rddLogoUrl || DEFAULT_BRAND_URLS.rddLogoUrl) ||
      currLoader !== baseLoader ||
      sameLoaderAsPrimary !== Boolean(brand.sameLoaderAsPrimary) ||
      faviconUrl !== (brand.faviconUrl || DEFAULT_BRAND_URLS.faviconUrl) ||
      shareImageUrl !== (brand.shareImageUrl || '')
    );
  }, [brand, moaLogoUrl, rddLogoUrl, loaderLogoUrl, sameLoaderAsPrimary, faviconUrl, shareImageUrl]);

  const annDirty = useMemo(() => {
    return (
      Boolean(announcement.enabled) !== Boolean(overviewAnnouncement.enabled) ||
      announcement.text !== (overviewAnnouncement.text || '') ||
      (announcement.linkUrl || '') !== (overviewAnnouncement.linkUrl || '') ||
      (announcement.linkLabel || '') !== (overviewAnnouncement.linkLabel || '') ||
      (announcement.startDate || '') !== (overviewAnnouncement.startDate || '').slice(0, 10) ||
      (announcement.endDate || '') !==
        (overviewAnnouncement.endDate || overviewAnnouncement.expiresAt || '').slice(0, 10)
    );
  }, [announcement, overviewAnnouncement]);

  const socialDirty = useMemo(() => {
    const base = Array.isArray(overviewSocial.links) ? overviewSocial.links : [];
    return JSON.stringify(socialLinks) !== JSON.stringify(base);
  }, [socialLinks, overviewSocial.links]);

  const isDirty = brandDirty || annDirty || socialDirty;

  useEffect(() => {
    onDirtyChange?.(isDirty);
    if (!isDirty) return;
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isDirty, onDirtyChange]);

  const setBrandField = (key: BrandAssetKey, url: string) => {
    setBrandMsg(null);
    if (key === 'moaLogoUrl') setMoaLogoUrl(url);
    if (key === 'rddLogoUrl') setRddLogoUrl(url);
    if (key === 'loaderLogoUrl') setLoaderLogoUrl(url);
    if (key === 'faviconUrl') setFaviconUrl(url);
    if (key === 'shareImageUrl') setShareImageUrl(url);
  };

  const handleAddSocialChannel = () => {
    const plat = newPlatform.trim();
    const url = newUrl.trim();
    if (!plat || !isHttpUrl(url)) {
      setSocialMsg({ type: 'err', text: 'Enter a valid platform name and an http:// or https:// URL.' });
      return;
    }
    setSocialMsg(null);
    setSocialLinks(prev => [
      ...prev,
      {
        id: `soc-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        platform: plat,
        icon: plat.toLowerCase().replace(/[^a-z0-9]/g, ''),
        url,
        visible: true
      }
    ]);
    setNewUrl('');
  };

  const moveSocial = (fromIdx: number, toIdx: number) => {
    if (toIdx < 0 || toIdx >= socialLinks.length || fromIdx === toIdx) return;
    setSocialLinks(prev => {
      const next = [...prev];
      const [moved] = next.splice(fromIdx, 1);
      next.splice(toIdx, 0, moved);
      return next;
    });
  };

  const handleDiscardAll = () => {
    setMoaLogoUrl(brand.moaLogoUrl || DEFAULT_BRAND_URLS.moaLogoUrl);
    setRddLogoUrl(brand.rddLogoUrl || DEFAULT_BRAND_URLS.rddLogoUrl);
    setLoaderLogoUrl(brand.loaderLogoUrl || DEFAULT_BRAND_URLS.loaderLogoUrl);
    setSameLoaderAsPrimary(Boolean(brand.sameLoaderAsPrimary));
    setFaviconUrl(brand.faviconUrl || DEFAULT_BRAND_URLS.faviconUrl);
    setShareImageUrl(brand.shareImageUrl || '');
    setAnnouncement({
      enabled: Boolean(overviewAnnouncement.enabled),
      text: overviewAnnouncement.text || '',
      linkUrl: overviewAnnouncement.linkUrl || '',
      linkLabel: overviewAnnouncement.linkLabel || '',
      startDate: (overviewAnnouncement.startDate || '').slice(0, 10),
      endDate: (overviewAnnouncement.endDate || overviewAnnouncement.expiresAt || '').slice(0, 10)
    });
    setSocialLinks(Array.isArray(overviewSocial.links) ? overviewSocial.links : []);
    setBrandMsg(null);
    setAnnMsg(null);
    setSocialMsg(null);
  };

  const handleSaveAll = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setBrandMsg(null);
    setAnnMsg(null);
    setSocialMsg(null);

    if (annDirty) {
      if (announcement.linkUrl && !isSafeUrl(announcement.linkUrl.trim())) {
        setAnnMsg({ type: 'err', text: 'Announcement link URL must use http(s) or start with /.' });
        return;
      }
      if (announcement.startDate && announcement.endDate && announcement.endDate < announcement.startDate) {
        setAnnMsg({ type: 'err', text: 'End date must be on or after start date.' });
        return;
      }
    }

    if (socialDirty) {
      for (const s of socialLinks) {
        if (!s.platform.trim() || !isHttpUrl(s.url)) {
          setSocialMsg({ type: 'err', text: `"${s.platform || 'Channel'}" must have a valid https:// or http:// URL.` });
          return;
        }
      }
    }

    setSavingAll(true);
    let savedAny = false;
    try {
      if (brandDirty) {
        try {
          await api.updateWebsiteBrand({
            version: brand.version,
            moaLogoUrl,
            rddLogoUrl,
            loaderLogoUrl: sameLoaderAsPrimary ? moaLogoUrl : loaderLogoUrl,
            sameLoaderAsPrimary,
            faviconUrl,
            shareImageUrl
          });
          setBrandMsg({ type: 'ok', text: 'Brand identity assets committed to database.' });
          savedAny = true;
        } catch (err) {
          setBrandMsg({
            type: 'err',
            text: err instanceof Error ? err.message : 'Failed to save brand assets.',
            conflict: err instanceof HttpError && err.status === 409
          });
          return;
        }
      }

      if (annDirty) {
        try {
          await api.updateWebsiteAnnouncement({
            version: overviewAnnouncement.version,
            enabled: announcement.enabled,
            text: announcement.text,
            linkUrl: announcement.linkUrl?.trim() || '',
            linkLabel: announcement.linkLabel?.trim() || '',
            startDate: announcement.startDate || '',
            endDate: announcement.endDate || ''
          });
          setAnnMsg({ type: 'ok', text: 'Announcement bar saved to database.' });
          savedAny = true;
        } catch (err) {
          setAnnMsg({ type: 'err', text: err instanceof Error ? err.message : 'Failed to save announcement bar.' });
          return;
        }
      }

      if (socialDirty) {
        try {
          await api.updateWebsiteSocial({
            version: overviewSocial.version,
            links: socialLinks
          });
          setSocialMsg({ type: 'ok', text: 'Social channels saved to database.' });
          savedAny = true;
        } catch (err) {
          setSocialMsg({ type: 'err', text: err instanceof Error ? err.message : 'Failed to save social channels.' });
          return;
        }
      }

      if (savedAny) {
        await onSaved();
      }
    } finally {
      setSavingAll(false);
    }
  };

  const activeError =
    brandMsg?.type === 'err'
      ? brandMsg.text
      : annMsg?.type === 'err'
        ? annMsg.text
        : socialMsg?.type === 'err'
          ? socialMsg.text
          : null;

  return (
    <div className={`space-y-6 ${isDirty ? 'pb-24' : ''}`}>
      <PortalSection
        title="Brand Visual Identity"
        description="Select logos, favicon, and social share graphics directly from the Media Library."
      >
        <div className="space-y-4">
          {brandMsg && (
            <div
              className={`p-3 rounded-xl border text-xs flex items-center justify-between gap-2 ${
                brandMsg.type === 'err'
                  ? 'bg-red-950/60 border-red-500/40 text-red-200'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              }`}
            >
              <div className="flex items-center gap-2">
                {brandMsg.type === 'err' ? <AlertCircle className="w-4 h-4" /> : <Check className="w-4 h-4" />}
                <span>{brandMsg.text}</span>
              </div>
              {brandMsg.conflict && (
                <button
                  type="button"
                  onClick={() => void onSaved()}
                  className="px-2.5 py-1 rounded bg-white/10 font-bold text-white cursor-pointer"
                >
                  Reload latest
                </button>
              )}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-[#06302F]/50 border border-white/10 space-y-3">
              <PortalMediaField
                label="Primary Logo"
                description="Navbar & institutional emblem"
                value={moaLogoUrl}
                onChange={url => setBrandField('moaLogoUrl', url)}
                allowedTypes={['image']}
                uploadFolder="Brand"
                pickerTitle="Select Primary Logo"
              />
              {moaLogoUrl !== DEFAULT_BRAND_URLS.moaLogoUrl && (
                <button
                  type="button"
                  onClick={() => setBrandField('moaLogoUrl', DEFAULT_BRAND_URLS.moaLogoUrl)}
                  className="h-8 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] font-semibold text-[#EDE9E0]/80 inline-flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset default</span>
                </button>
              )}
            </div>

            <div className="p-4 rounded-2xl bg-[#06302F]/50 border border-white/10 space-y-3">
              <PortalMediaField
                label="RDD Logo"
                description="Research & Development Division crest"
                value={rddLogoUrl}
                onChange={url => setBrandField('rddLogoUrl', url)}
                allowedTypes={['image']}
                uploadFolder="Brand"
                pickerTitle="Select RDD Logo"
              />
              {rddLogoUrl !== DEFAULT_BRAND_URLS.rddLogoUrl && (
                <button
                  type="button"
                  onClick={() => setBrandField('rddLogoUrl', DEFAULT_BRAND_URLS.rddLogoUrl)}
                  className="h-8 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] font-semibold text-[#EDE9E0]/80 inline-flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset default</span>
                </button>
              )}
            </div>

            <div className="p-4 rounded-2xl bg-[#06302F]/50 border border-white/10 space-y-3">
              <label className="inline-flex items-center gap-2 text-[11px] font-semibold text-[#25CDB6] cursor-pointer">
                <input
                  type="checkbox"
                  checked={sameLoaderAsPrimary}
                  onChange={e => setSameLoaderAsPrimary(e.target.checked)}
                  className="w-3.5 h-3.5 accent-[#25CDB6]"
                />
                <span>Same loader emblem as primary logo</span>
              </label>
              <div className={sameLoaderAsPrimary ? 'opacity-50 pointer-events-none' : ''}>
                <PortalMediaField
                  label="Loading-screen Logo"
                  description="Animated preloader emblem"
                  value={sameLoaderAsPrimary ? moaLogoUrl : loaderLogoUrl}
                  onChange={url => setBrandField('loaderLogoUrl', url)}
                  allowedTypes={['image']}
                  uploadFolder="Brand"
                  pickerTitle="Select Loader Logo"
                />
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#06302F]/50 border border-white/10 space-y-3">
              <PortalMediaField
                label="Favicon"
                description="Square PNG/ICO (512×512 recommended)"
                value={faviconUrl}
                onChange={url => setBrandField('faviconUrl', url)}
                allowedTypes={['image']}
                uploadFolder="Brand"
                pickerTitle="Select Favicon"
              />
              {faviconUrl !== DEFAULT_BRAND_URLS.faviconUrl && (
                <button
                  type="button"
                  onClick={() => setBrandField('faviconUrl', DEFAULT_BRAND_URLS.faviconUrl)}
                  className="h-8 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] font-semibold text-[#EDE9E0]/80 inline-flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset default</span>
                </button>
              )}
            </div>

            <div className="p-4 rounded-2xl bg-[#06302F]/50 border border-white/10 space-y-3 md:col-span-2 lg:col-span-1">
              <PortalMediaField
                label="Default Share Image"
                description="OpenGraph social card (recommended 1200×630)"
                value={shareImageUrl}
                onChange={url => setBrandField('shareImageUrl', url)}
                allowedTypes={['image']}
                uploadFolder="Brand"
                aspectClass="aspect-[1200/630]"
                pickerTitle="Select Default Share Image"
              />
            </div>
          </div>
        </div>
      </PortalSection>

      <PortalSection
        title="Floating Announcement Bar"
        description="Site-wide public callout banner with optional schedule window."
        actions={
          <label className="inline-flex items-center gap-2 text-xs font-bold text-[#EDE9E0] cursor-pointer">
            <input
              type="checkbox"
              checked={announcement.enabled}
              onChange={e => setAnnouncement(prev => ({ ...prev, enabled: e.target.checked }))}
              className="w-4 h-4 accent-[#25CDB6]"
            />
            <span>{announcement.enabled ? 'Enabled' : 'Disabled'}</span>
          </label>
        }
      >
        <form onSubmit={e => void handleSaveAll(e)} className="space-y-4 text-xs">
          {annMsg && (
            <div
              className={`p-3 rounded-xl border flex items-center gap-2 ${
                annMsg.type === 'err'
                  ? 'bg-red-950/60 border-red-500/40 text-red-200'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              }`}
            >
              {annMsg.type === 'err' ? <AlertCircle className="w-4 h-4" /> : <Check className="w-4 h-4" />}
              <span>{annMsg.text}</span>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Announcement Message</label>
              <input
                type="text"
                value={announcement.text}
                onChange={e => setAnnouncement(prev => ({ ...prev, text: e.target.value }))}
                placeholder="Applications open for the Autumn 2026 Fellowship."
                className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
              />
            </div>
            <div>
              <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Link Label (optional)</label>
              <input
                type="text"
                value={announcement.linkLabel || ''}
                onChange={e => setAnnouncement(prev => ({ ...prev, linkLabel: e.target.value }))}
                placeholder="Read announcement"
                className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
              />
            </div>
            <div>
              <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Link URL (optional)</label>
              <input
                type="text"
                value={announcement.linkUrl || ''}
                onChange={e => setAnnouncement(prev => ({ ...prev, linkUrl: e.target.value }))}
                placeholder="/projects or https://..."
                className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 font-mono text-[#EDE9E0]"
              />
            </div>
            <div>
              <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Start Date (optional)</label>
              <input
                type="date"
                value={announcement.startDate || ''}
                onChange={e => setAnnouncement(prev => ({ ...prev, startDate: e.target.value }))}
                className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
              />
            </div>
            <div>
              <label className="block text-[#EDE9E0]/75 font-semibold mb-1">End Date (optional)</label>
              <input
                type="date"
                value={announcement.endDate || ''}
                onChange={e => setAnnouncement(prev => ({ ...prev, endDate: e.target.value }))}
                className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
              />
            </div>
          </div>

          {announcement.text.trim() && (
            <div className="p-3 rounded-xl bg-[#06302F] border border-white/10 space-y-1.5">
              <span className="text-[10px] uppercase tracking-wider font-bold text-[#EDE9E0]/45 block">
                Live Banner Preview {announcement.enabled ? '' : '(currently disabled)'}
              </span>
              <div className="px-4 py-2 rounded-full bg-[#17A491] text-[#031D1C] font-semibold inline-flex flex-wrap items-center gap-2 shadow">
                <span>{announcement.text}</span>
                {announcement.linkLabel && (
                  <span className="underline font-bold">{announcement.linkLabel} →</span>
                )}
              </div>
            </div>
          )}
        </form>
      </PortalSection>

      <PortalSection
        title="Official Social Channels"
        description="Reorder channels or toggle visibility for the public Footer and Contact page."
      >
        <div className="space-y-4 text-xs">
          {socialMsg && (
            <div
              className={`p-3 rounded-xl border flex items-center gap-2 ${
                socialMsg.type === 'err'
                  ? 'bg-red-950/60 border-red-500/40 text-red-200'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              }`}
            >
              {socialMsg.type === 'err' ? <AlertCircle className="w-4 h-4" /> : <Check className="w-4 h-4" />}
              <span>{socialMsg.text}</span>
            </div>
          )}

          <div className="space-y-2.5">
            {socialLinks.map((link, idx) => (
              <div
                key={link.id}
                draggable
                onDragStart={() => setDragSocialIdx(idx)}
                onDragOver={e => e.preventDefault()}
                onDrop={() => {
                  if (dragSocialIdx !== null) moveSocial(dragSocialIdx, idx);
                  setDragSocialIdx(null);
                }}
                onDragEnd={() => setDragSocialIdx(null)}
                className="p-3 rounded-xl bg-[#06302F] border border-white/10 flex flex-wrap items-center gap-2.5"
              >
                <span className="text-[#EDE9E0]/40 cursor-grab">
                  <GripVertical className="w-4 h-4" />
                </span>
                <button
                  type="button"
                  disabled={idx === 0}
                  onClick={() => moveSocial(idx, idx - 1)}
                  className="p-1 rounded bg-white/5 hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                >
                  <MoveUp className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  disabled={idx === socialLinks.length - 1}
                  onClick={() => moveSocial(idx, idx + 1)}
                  className="p-1 rounded bg-white/5 hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                >
                  <MoveDown className="w-3.5 h-3.5" />
                </button>

                <input
                  type="text"
                  value={link.platform}
                  onChange={e =>
                    setSocialLinks(prev =>
                      prev.map((s, i) => (i === idx ? { ...s, platform: e.target.value, icon: e.target.value.toLowerCase() } : s))
                    )
                  }
                  placeholder="Platform"
                  className="w-32 bg-[#031D1C] border border-white/10 rounded-lg px-2.5 py-1.5 font-semibold text-[#EDE9E0]"
                />
                <input
                  type="url"
                  value={link.url}
                  onChange={e =>
                    setSocialLinks(prev => prev.map((s, i) => (i === idx ? { ...s, url: e.target.value } : s)))
                  }
                  placeholder="https://..."
                  className={`flex-1 min-w-[180px] bg-[#031D1C] border rounded-lg px-3 py-1.5 font-mono text-[#EDE9E0] ${
                    isHttpUrl(link.url) ? 'border-white/10' : 'border-red-500/60'
                  }`}
                />

                <button
                  type="button"
                  onClick={() =>
                    setSocialLinks(prev =>
                      prev.map((s, i) => (i === idx ? { ...s, visible: s.visible === false } : s))
                    )
                  }
                  className={`px-2.5 py-1.5 rounded-lg border font-semibold inline-flex items-center gap-1 cursor-pointer ${
                    link.visible !== false
                      ? 'bg-[#25CDB6]/15 border-[#25CDB6]/30 text-[#25CDB6]'
                      : 'bg-white/5 border-white/10 text-[#EDE9E0]/55'
                  }`}
                >
                  {link.visible !== false ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                  <span>{link.visible !== false ? 'Visible' : 'Hidden'}</span>
                </button>

                {isHttpUrl(link.url) && (
                  <a
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[#25CDB6]"
                    title="Test link"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}

                <button
                  type="button"
                  onClick={() => setSocialLinks(prev => prev.filter((_, i) => i !== idx))}
                  aria-label={`Remove ${link.platform}`}
                  className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-300 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-white/10 flex flex-wrap items-center gap-2">
            <select
              value={newPlatform}
              onChange={e => setNewPlatform(e.target.value)}
              className="h-9 bg-[#06302F] border border-white/10 rounded-xl px-3 text-[#EDE9E0]"
            >
              <option value="LinkedIn">LinkedIn</option>
              <option value="GitHub">GitHub</option>
              <option value="X">X</option>
              <option value="Instagram">Instagram</option>
              <option value="YouTube">YouTube</option>
              <option value="Discord">Discord</option>
              <option value="Custom">Custom</option>
            </select>
            <input
              type="url"
              value={newUrl}
              onChange={e => setNewUrl(e.target.value)}
              placeholder="https://linkedin.com/company/..."
              className="flex-1 min-w-[200px] h-9 bg-[#06302F] border border-white/10 rounded-xl px-3 font-mono text-[#EDE9E0]"
            />
            <button
              type="button"
              onClick={handleAddSocialChannel}
              className="h-9 px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[#25CDB6] font-bold inline-flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Channel</span>
            </button>
          </div>
        </div>
      </PortalSection>

      <PortalFloatingSaveBar
        visible={isDirty}
        saving={savingAll}
        error={activeError}
        title="Unsaved brand & site-wide changes"
        subtitle="Save brand identity, announcement bar, and channel updates."
        onDiscard={handleDiscardAll}
        onSave={() => void handleSaveAll()}
      />
    </div>
  );
};
