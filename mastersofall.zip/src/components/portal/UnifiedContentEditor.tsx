import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  Check,
  Copy,
  ExternalLink,
  FileText,
  History,
  Image as ImageIcon,
  Layers,
  Loader2,
  MoreHorizontal,
  Plus,
  RotateCcw,
  Send,
  Sparkles,
  Trash2,
  Upload,
  X,
  AlertCircle
} from 'lucide-react';
import {
  AreaOfFocusCard,
  Department,
  DepartmentGlyph,
  InitiativeItem,
  MediaAsset,
  PageBlock,
  Product,
  ProductPricingType,
  ProductSpec,
  ProductStage,
  Project,
  ProjectVersion,
  Publication,
  PublicationStatus,
  RoleDefinition,
  User
} from '../../types';
import { can } from '../../shared/permissions';
import { sanitizeSafeUrl } from '../../shared/url';
import { api } from '../../services/api';
import { getSectorParentId, getUnitHref, isRddDepartment, isSector } from '../../utils/orgHelpers';
import { renderPdfPageOneDataUrl } from '../../utils/pdfThumbnail';
import { GLYPH_OPTIONS } from '../DepartmentIcon';
import { DepartmentLogo } from '../DepartmentLogo';
import { MediaPicker } from '../MediaPicker';
import { ModularBlockEditor } from './ModularBlockEditor';
import { normalizeBlocksForEditor } from '../PublicBlocksRenderer';
import {
  PortalConfirmDialog,
  PortalFloatingSaveBar,
  PortalMediaField,
  PortalSection,
  PortalStatusBadge
} from './ui';

export type UnifiedEditorKind = 'department' | 'sector' | 'project' | 'publication' | 'product';

export interface UnifiedContentEditorProps {
  kind: UnifiedEditorKind;
  item: Department | Project | Publication | Product | null;
  initialParentDepartmentId?: string;
  departments: Department[];
  projects: Project[];
  currentUser: User;
  roles?: RoleDefinition[];
  onBack: () => void;
  onSaved: (
    kind: UnifiedEditorKind,
    saved: Department | Project | Publication | Product
  ) => Promise<void> | void;
  onDuplicated?: (
    kind: UnifiedEditorKind,
    cloned: Department | Project | Publication | Product
  ) => void;
  onDeleted?: () => Promise<void> | void;
  onNavigateSite: (path?: string) => void;
}

interface EditorFormState {
  // Common identity & copy
  title: string;
  shortName: string;
  slug: string;
  tagline: string;
  shortDescription: string;
  fullDescription: string;
  abstract: string;
  // Department / Sector
  parentDepartmentId: string;
  iconGlyph: DepartmentGlyph;
  iconUrl: string;
  customLogoUrl: string;
  heroImage: string;
  colorHex: string;
  iconBgHex: string;
  introduction: string;
  purpose: string;
  mission: string;
  structuredAreasOfFocus: AreaOfFocusCard[];
  structuredInitiatives: InitiativeItem[];
  template: NonNullable<Department['template']>;
  published: boolean;
  showInTree: boolean;
  // Project / Publication / Product common
  coverImage: string;
  thumbnailUrl: string;
  galleryImages: string[];
  departmentIds: string[];
  sectorIds: string[];
  primaryDepartmentId: string;
  publicationStatus: PublicationStatus;
  category: string;
  // Project fields
  projectStatus: string;
  visibility: 'Public' | 'Unlisted' | 'Members only';
  featured: boolean;
  startDate: string;
  completionDate: string;
  pdfUrl: string;
  videoUrl: string;
  audioUrl: string;
  documents: { label: string; url: string; size?: string }[];
  externalLinks: { label: string; url: string }[];
  credits: string;
  tagsText: string;
  // Publication fields
  authors: string;
  publicationType: string;
  publicationDate: string;
  doiOrUrl: string;
  relatedProjectId: string;
  // Product fields
  version: string;
  releaseDate: string;
  productStage: ProductStage;
  availabilityPricing: ProductPricingType;
  priceText: string;
  demoVideoUrl: string;
  downloadLink: string;
  websiteLink: string;
  repositoryLink: string;
  documentationPdf: string;
  keyFeatures: string[];
  specs: ProductSpec[];
  relatedProjectIds: string[];
  // Modular blocks + SEO
  blocks: PageBlock[];
  seoTitle: string;
  seoDescription: string;
  seoShareImage: string;
  seoNoindex: boolean;
}

function slugifyLocal(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function formatSavedTime(iso?: string): string {
  if (!iso) return '';
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return '';
  return dt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function buildInitialState(
  kind: UnifiedEditorKind,
  item: Department | Project | Publication | Product | null,
  departments: Department[],
  initialParentDepartmentId?: string
): EditorFormState {
  if (kind === 'department' || kind === 'sector') {
    const dept = item as Department | null;
    const defaultParent =
      initialParentDepartmentId ||
      departments.find(d => !d.deletedAt && !isSector(d) && isRddDepartment(d))?.id ||
      departments.find(d => !d.deletedAt && !isSector(d))?.id ||
      'dept-rdd';

    const focusCards: AreaOfFocusCard[] =
      dept?.structuredAreasOfFocus && dept.structuredAreasOfFocus.length > 0
        ? dept.structuredAreasOfFocus
        : (dept?.areasOfFocus || []).filter(Boolean).map((title, idx) => ({
            id: `focus-${idx}`,
            title,
            description: ''
          }));

    const initItems: InitiativeItem[] =
      dept?.structuredInitiatives && dept.structuredInitiatives.length > 0
        ? dept.structuredInitiatives
        : (dept?.initiatives || []).filter(Boolean).map((title, idx) => ({
            id: `init-${idx}`,
            title,
            status: 'Active',
            summary: '',
            link: ''
          }));

    return {
      title: dept?.name || '',
      shortName: dept?.shortName || '',
      slug: dept?.slug || '',
      tagline: dept?.tagline || '',
      shortDescription: '',
      fullDescription: '',
      abstract: '',
      parentDepartmentId:
        kind === 'sector'
          ? (dept ? getSectorParentId(dept) : defaultParent)
          : '',
      iconGlyph: dept?.iconGlyph || 'tech',
      iconUrl: dept?.iconUrl || '',
      customLogoUrl: dept?.customLogoUrl || '',
      heroImage: dept?.heroImage || '',
      colorHex: dept?.colorHex || '#25CDB6',
      iconBgHex: dept?.iconBgHex || '#0A3D3C',
      introduction: dept?.introduction || '',
      purpose: dept?.purpose || '',
      mission: dept?.mission || '',
      structuredAreasOfFocus: focusCards,
      structuredInitiatives: initItems,
      template: dept?.template || 'Standard',
      published: dept ? Boolean(dept.published) : false,
      showInTree: dept ? dept.showInTree !== false : true,
      coverImage: '',
      thumbnailUrl: '',
      galleryImages: [...(dept?.galleryImages || [])],
      departmentIds: [],
      sectorIds: [],
      primaryDepartmentId: '',
      publicationStatus: dept?.published ? 'Published' : 'Draft',
      category: '',
      projectStatus: 'In Development',
      visibility: 'Public',
      featured: false,
      startDate: '',
      completionDate: '',
      pdfUrl: '',
      videoUrl: '',
      audioUrl: '',
      documents: [],
      externalLinks: [],
      credits: '',
      tagsText: '',
      authors: '',
      publicationType: 'Paper',
      publicationDate: '',
      doiOrUrl: '',
      relatedProjectId: '',
      version: '',
      releaseDate: '',
      productStage: 'Concept',
      availabilityPricing: 'free',
      priceText: '',
      demoVideoUrl: '',
      downloadLink: '',
      websiteLink: '',
      repositoryLink: '',
      documentationPdf: '',
      keyFeatures: [],
      specs: [],
      relatedProjectIds: [],
      blocks: normalizeBlocksForEditor(dept?.blocks),
      seoTitle: dept?.seoTitle || '',
      seoDescription: dept?.seoDescription || '',
      seoShareImage: dept?.seoShareImage || '',
      seoNoindex: Boolean(dept?.seoNoindex)
    };
  }

  if (kind === 'project') {
    const p = item as Project | null;
    const rawBlocks = p?.blocks && p.blocks.length > 0 ? p.blocks : p?.storyBlocks;
    return {
      title: p?.title || '',
      shortName: '',
      slug: p?.slug || '',
      tagline: '',
      shortDescription: p?.shortDescription || '',
      fullDescription: p?.fullDescription || '',
      abstract: '',
      parentDepartmentId: '',
      iconGlyph: 'tech',
      iconUrl: '',
      customLogoUrl: '',
      heroImage: '',
      colorHex: '#25CDB6',
      iconBgHex: '#0A3D3C',
      introduction: '',
      purpose: '',
      mission: '',
      structuredAreasOfFocus: [],
      structuredInitiatives: [],
      template: 'Standard',
      published: p?.publicationStatus === 'Published',
      showInTree: true,
      coverImage: p?.coverImage || '',
      thumbnailUrl: '',
      galleryImages: [...(p?.galleryImages || [])],
      departmentIds: [...(p?.departmentIds || [])],
      sectorIds: [...(p?.sectorIds || [])],
      primaryDepartmentId: p?.primaryDepartmentId || '',
      publicationStatus: p?.publicationStatus || 'Draft',
      category: p?.category || 'Research',
      projectStatus: p?.status || 'Active',
      visibility: p?.visibility || 'Public',
      featured: Boolean(p?.featured),
      startDate: p?.startDate || new Date().toISOString().slice(0, 10),
      completionDate: p?.completionDate || '',
      pdfUrl: p?.pdfUrl || '',
      videoUrl: p?.videoUrl || '',
      audioUrl: p?.audioUrl || '',
      documents: [...(p?.documents || [])],
      externalLinks: [...(p?.externalLinks || [])],
      credits: p?.credits || '',
      tagsText: (p?.tags || []).join(', '),
      authors: '',
      publicationType: 'Paper',
      publicationDate: '',
      doiOrUrl: '',
      relatedProjectId: '',
      version: '',
      releaseDate: '',
      productStage: 'Concept',
      availabilityPricing: 'free',
      priceText: '',
      demoVideoUrl: '',
      downloadLink: '',
      websiteLink: '',
      repositoryLink: '',
      documentationPdf: '',
      keyFeatures: [],
      specs: [],
      relatedProjectIds: [...(p?.relatedProjectIds || [])],
      blocks: normalizeBlocksForEditor(rawBlocks),
      seoTitle: p?.seoTitle || '',
      seoDescription: p?.seoDescription || '',
      seoShareImage: p?.seoShareImage || '',
      seoNoindex: Boolean(p?.seoNoindex)
    };
  }

  if (kind === 'publication') {
    const pub = item as Publication | null;
    return {
      title: pub?.title || '',
      shortName: '',
      slug: pub?.slug || '',
      tagline: '',
      shortDescription: '',
      fullDescription: '',
      abstract: pub?.abstract || '',
      parentDepartmentId: '',
      iconGlyph: 'book',
      iconUrl: '',
      customLogoUrl: '',
      heroImage: '',
      colorHex: '#D0A873',
      iconBgHex: '#0A3D3C',
      introduction: '',
      purpose: '',
      mission: '',
      structuredAreasOfFocus: [],
      structuredInitiatives: [],
      template: 'Standard',
      published: pub?.publicationStatus === 'Published',
      showInTree: true,
      coverImage: '',
      thumbnailUrl: pub?.thumbnailUrl || '',
      galleryImages: [],
      departmentIds: [...(pub?.departmentIds || [])],
      sectorIds: [...(pub?.sectorIds || [])],
      primaryDepartmentId: '',
      publicationStatus: pub?.publicationStatus || 'Draft',
      category: '',
      projectStatus: 'Active',
      visibility: 'Public',
      featured: false,
      startDate: '',
      completionDate: '',
      pdfUrl: pub?.pdfUrl || '',
      videoUrl: '',
      audioUrl: '',
      documents: [],
      externalLinks: [],
      credits: '',
      tagsText: (pub?.tags || []).join(', '),
      authors: pub?.authors || '',
      publicationType: pub?.publicationType || 'Paper',
      publicationDate: pub?.publicationDate || new Date().toISOString().slice(0, 10),
      doiOrUrl: pub?.doiOrUrl || '',
      relatedProjectId: pub?.relatedProjectId || '',
      version: '',
      releaseDate: '',
      productStage: 'Concept',
      availabilityPricing: 'free',
      priceText: '',
      demoVideoUrl: '',
      downloadLink: '',
      websiteLink: '',
      repositoryLink: '',
      documentationPdf: '',
      keyFeatures: [],
      specs: [],
      relatedProjectIds: [],
      blocks: normalizeBlocksForEditor(pub?.blocks),
      seoTitle: pub?.seoTitle || '',
      seoDescription: pub?.seoDescription || '',
      seoShareImage: pub?.seoShareImage || '',
      seoNoindex: Boolean(pub?.seoNoindex)
    };
  }

  const prod = item as Product | null;
  return {
    title: prod?.name || '',
    shortName: '',
    slug: prod?.slug || '',
    tagline: prod?.tagline || '',
    shortDescription: prod?.shortDescription || '',
    fullDescription: prod?.fullDescription || '',
    abstract: '',
    parentDepartmentId: '',
    iconGlyph: 'layers',
    iconUrl: '',
    customLogoUrl: '',
    heroImage: '',
    colorHex: '#25CDB6',
    iconBgHex: '#0A3D3C',
    introduction: '',
    purpose: '',
    mission: '',
    structuredAreasOfFocus: [],
    structuredInitiatives: [],
    template: 'Standard',
    published: prod?.publicationStatus === 'Published',
    showInTree: true,
    coverImage: prod?.coverImage || '',
    thumbnailUrl: '',
    galleryImages: [...(prod?.galleryImages || [])],
    departmentIds: [...(prod?.departmentIds || [])],
    sectorIds: [...(prod?.sectorIds || [])],
    primaryDepartmentId: '',
    publicationStatus: prod?.publicationStatus || 'Draft',
    category: prod?.category || 'Software & Tools',
    projectStatus: 'Active',
    visibility: 'Public',
    featured: false,
    startDate: '',
    completionDate: '',
    pdfUrl: '',
    videoUrl: '',
    audioUrl: '',
    documents: [],
    externalLinks: [],
    credits: prod?.credits || '',
    tagsText: (prod?.tags || []).join(', '),
    authors: '',
    publicationType: 'Paper',
    publicationDate: '',
    doiOrUrl: '',
    relatedProjectId: '',
    version: prod?.version || '',
    releaseDate: prod?.releaseDate || '',
    productStage: prod?.status || 'Concept',
    availabilityPricing: prod?.availabilityPricing || 'free',
    priceText: prod?.priceText || '',
    demoVideoUrl: prod?.demoVideoUrl || '',
    downloadLink: prod?.links?.download || '',
    websiteLink: prod?.links?.website || '',
    repositoryLink: prod?.links?.repository || '',
    documentationPdf: prod?.links?.documentationPdf || '',
    keyFeatures: [...(prod?.keyFeatures || [])],
    specs: [...(prod?.specs || [])],
    relatedProjectIds: [...(prod?.relatedProjectIds || [])],
    blocks: normalizeBlocksForEditor(prod?.blocks),
    seoTitle: prod?.seoTitle || '',
    seoDescription: prod?.seoDescription || '',
    seoShareImage: prod?.seoShareImage || '',
    seoNoindex: Boolean(prod?.seoNoindex)
  };
}

export const UnifiedContentEditor: React.FC<UnifiedContentEditorProps> = ({
  kind,
  item,
  initialParentDepartmentId,
  departments,
  projects,
  currentUser,
  roles,
  onBack,
  onSaved,
  onDuplicated,
  onDeleted,
  onNavigateSite
}) => {
  const isNew = !item;
  const itemId = item?.id;
  const initialSnapshotRef = useRef<EditorFormState>(
    buildInitialState(kind, item, departments, initialParentDepartmentId)
  );
  const [form, setForm] = useState<EditorFormState>(initialSnapshotRef.current);
  const [slugManuallyEdited, setSlugManuallyEdited] = useState<boolean>(() => Boolean(item));
  const [slugCheck, setSlugCheck] = useState<{
    checking: boolean;
    available: boolean;
    conflictTitle?: string;
    normalizedSlug?: string;
  }>({ checking: false, available: true });

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [leaveConfirmOpen, setLeaveConfirmOpen] = useState(false);
  const [trashConfirmOpen, setTrashConfirmOpen] = useState(false);
  const [trashHandling, setTrashHandling] = useState<'leave' | 'reassign'>('leave');
  const [trashTargetDeptId, setTrashTargetDeptId] = useState('');
  const [trashBusy, setTrashBusy] = useState(false);
  const [duplicating, setDuplicating] = useState(false);
  const [restoringVersionId, setRestoringVersionId] = useState<string | null>(null);
  const [generatingThumb, setGeneratingThumb] = useState(false);
  const [galleryPickerOpen, setGalleryPickerOpen] = useState(false);
  const [uploadingGallery, setUploadingGallery] = useState(false);
  const galleryFileRef = useRef<HTMLInputElement | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);

  // Sync baseline when item prop changes (e.g. switching to duplicate or restored version)
  useEffect(() => {
    const nextInit = buildInitialState(kind, item, departments, initialParentDepartmentId);
    initialSnapshotRef.current = nextInit;
    setForm(nextInit);
    setSlugManuallyEdited(Boolean(item));
    setSaveError(null);
  }, [kind, item?.id, item?.updatedAt, initialParentDepartmentId]);

  const isDirty = useMemo(
    () => JSON.stringify(form) !== JSON.stringify(initialSnapshotRef.current),
    [form]
  );

  // Close actions menu on outside click / Escape
  useEffect(() => {
    if (!menuOpen) return;
    const onOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    document.addEventListener('mousedown', onOutside);
    window.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onOutside);
      window.removeEventListener('keydown', onKey);
    };
  }, [menuOpen]);

  // Debounced live slug check
  useEffect(() => {
    const candidate = form.slug.trim();
    if (!candidate) {
      setSlugCheck({ checking: false, available: false });
      return;
    }
    let cancelled = false;
    setSlugCheck(prev => ({ ...prev, checking: true }));
    const timer = window.setTimeout(async () => {
      try {
        const res = await api.checkContentSlug(kind, candidate, itemId);
        if (!cancelled) {
          setSlugCheck({
            checking: false,
            available: res.available,
            conflictTitle: res.conflictTitle,
            normalizedSlug: res.normalizedSlug
          });
        }
      } catch {
        if (!cancelled) setSlugCheck({ checking: false, available: true });
      }
    }, 320);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [form.slug, kind, itemId]);

  const canPublish = can(currentUser, 'projects.publish', roles);
  const canManageDepts = can(currentUser, 'departments.manage', roles);
  const canCreateProj = can(currentUser, 'projects.create', roles);
  const canManagePubs = can(currentUser, 'publications.manage', roles) || canPublish;
  const canManageProds = can(currentUser, 'products.manage', roles) || canPublish;

  const canDuplicate =
    !isNew &&
    ((kind === 'department' || kind === 'sector')
      ? canManageDepts
      : kind === 'project'
        ? canCreateProj
        : kind === 'publication'
          ? canManagePubs
          : canManageProds);

  const canDeleteItem = !isNew;

  const activeDepartments = useMemo(
    () =>
      departments
        .filter(d => !d.deletedAt && !isSector(d))
        .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0)),
    [departments]
  );

  const activeSectors = useMemo(
    () =>
      departments
        .filter(d => !d.deletedAt && isSector(d))
        .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0)),
    [departments]
  );

  const reassignTargetOptions = useMemo(
    () => activeDepartments.filter(d => d.id !== itemId),
    [activeDepartments, itemId]
  );

  const entityProjectsCount = useMemo(() => {
    if (!itemId || (kind !== 'department' && kind !== 'sector')) return 0;
    return projects.filter(
      p => !p.deletedAt && (p.departmentIds?.includes(itemId) || p.sectorIds?.includes(itemId))
    ).length;
  }, [projects, itemId, kind]);

  const publicHref = useMemo(() => {
    if (!form.slug.trim()) return '/home';
    if (kind === 'department') return `/departments/${form.slug.trim()}`;
    if (kind === 'sector') {
      const parent = activeDepartments.find(d => d.id === form.parentDepartmentId);
      return `/departments/${parent?.slug || 'rdd'}/${form.slug.trim()}`;
    }
    if (kind === 'project') return `/projects/${form.slug.trim()}`;
    if (kind === 'publication') return `/work`;
    return `/products/${form.slug.trim()}`;
  }, [kind, form.slug, form.parentDepartmentId, activeDepartments]);

  const breadcrumbArea =
    kind === 'department' || kind === 'sector'
      ? 'Departments'
      : kind === 'project'
        ? 'Projects'
        : kind === 'publication'
          ? 'Publications'
          : 'Products';

  const statusBadgeValue = useMemo(() => {
    if (kind === 'department' || kind === 'sector') {
      return form.published ? 'Published' : 'Hidden';
    }
    return form.publicationStatus;
  }, [kind, form.published, form.publicationStatus]);

  const updateField = useCallback(<K extends keyof EditorFormState>(key: K, value: EditorFormState[K]) => {
    setForm(prev => {
      const next = { ...prev, [key]: value };
      if (key === 'title' && !slugManuallyEdited) {
        next.slug = slugifyLocal(String(value));
      }
      return next;
    });
  }, [slugManuallyEdited]);

  const handleBlocksChange = (nextBlocks: PageBlock[]) => {
    // Re-key modified mig11-* blocks so detail views know the user customized modular content
    const normalized = nextBlocks.map(blk => {
      if (!blk.id.startsWith('mig11-')) return blk;
      const orig = initialSnapshotRef.current.blocks.find(b => b.id === blk.id);
      if (orig && JSON.stringify(orig.config) === JSON.stringify(blk.config)) {
        return blk;
      }
      return {
        ...blk,
        id: `blk-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`
      };
    });
    updateField('blocks', normalized);
  };

  const toggleIdInList = (field: 'departmentIds' | 'sectorIds' | 'relatedProjectIds', targetId: string) => {
    setForm(prev => {
      const list = prev[field];
      const next = list.includes(targetId)
        ? list.filter(x => x !== targetId)
        : [...list, targetId];
      return { ...prev, [field]: next };
    });
  };

  const handleGalleryUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingGallery(true);
    try {
      const uploaded = await api.uploadMedia({
        file,
        name: file.name,
        altText: file.name.replace(/\.[^.]+$/, ''),
        folder: breadcrumbArea
      });
      updateField('galleryImages', [...form.galleryImages, uploaded.url]);
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Image upload failed.');
    } finally {
      setUploadingGallery(false);
      if (galleryFileRef.current) galleryFileRef.current.value = '';
    }
  };

  const handleGeneratePdfThumb = async () => {
    const safePdf = sanitizeSafeUrl(form.pdfUrl);
    if (!safePdf) {
      setSaveError('Upload or select a PDF document first.');
      return;
    }
    setGeneratingThumb(true);
    setSaveError(null);
    try {
      const dataUrl = await renderPdfPageOneDataUrl(safePdf, {
        scale: 1.15,
        format: 'image/jpeg',
        quality: 0.85
      });
      const uploaded = await api.uploadMedia({
        name: `${form.slug || 'publication'}-cover.jpg`,
        dataUrl,
        altText: `${form.title || 'Publication'} cover`,
        folder: 'Publications'
      });
      updateField('thumbnailUrl', uploaded.url);
    } catch (err) {
      setSaveError(
        err instanceof Error ? err.message : 'Could not render PDF thumbnail automatically.'
      );
    } finally {
      setGeneratingThumb(false);
    }
  };

  const parseTags = (raw: string) =>
    raw
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);

  const handleSave = async (mode: 'primary' | 'draft') => {
    if (!form.title.trim()) {
      setSaveError(kind === 'department' || kind === 'sector' || kind === 'product' ? 'Name is required.' : 'Title is required.');
      return;
    }
    if (!form.slug.trim()) {
      setSaveError('URL slug is required.');
      return;
    }
    if (!slugCheck.available && slugCheck.conflictTitle) {
      setSaveError(`URL slug is already used by "${slugCheck.conflictTitle}".`);
      return;
    }

    setSaving(true);
    setSaveError(null);
    try {
      let saved: Department | Project | Publication | Product;

      if (kind === 'department' || kind === 'sector') {
        const nextPublished = mode === 'draft' ? false : isNew ? true : form.published;
        const payload: Partial<Department> = {
          name: form.title.trim(),
          shortName: form.shortName.trim() || undefined,
          slug: form.slug.trim(),
          kind,
          parentDepartmentId: kind === 'sector' ? form.parentDepartmentId || 'dept-rdd' : undefined,
          tagline: form.tagline.trim(),
          iconGlyph: form.iconGlyph,
          iconUrl: form.iconUrl || undefined,
          customLogoUrl: form.customLogoUrl || undefined,
          heroImage: form.heroImage || undefined,
          colorHex: form.colorHex,
          iconBgHex: form.iconBgHex,
          introduction: form.introduction.trim(),
          purpose: form.purpose.trim(),
          mission: form.mission.trim(),
          structuredAreasOfFocus: form.structuredAreasOfFocus.filter(c => c.title.trim() || c.description.trim()),
          areasOfFocus: form.structuredAreasOfFocus.map(c => c.title.trim()).filter(Boolean),
          structuredInitiatives: form.structuredInitiatives.filter(i => i.title.trim()),
          initiatives: form.structuredInitiatives.map(i => i.title.trim()).filter(Boolean),
          galleryImages: form.galleryImages,
          template: form.template,
          published: nextPublished,
          showInTree: form.showInTree,
          blocks: form.blocks,
          seoTitle: form.seoTitle.trim() || undefined,
          seoDescription: form.seoDescription.trim() || undefined,
          seoShareImage: form.seoShareImage || undefined,
          seoNoindex: form.seoNoindex
        };
        saved = itemId
          ? await api.updateDepartment(itemId, payload)
          : await api.createDepartment(payload);
      } else if (kind === 'project') {
        const existingProj = item as Project | null;
        const submitRevision = Boolean(
          !canPublish && existingProj?.publicationStatus === 'Published' && mode === 'primary'
        );
        const nextPubStatus: PublicationStatus =
          mode === 'draft'
            ? 'Draft'
            : canPublish
              ? 'Published'
              : 'Pending Review';

        const payload: Partial<Project> & { submitRevision?: boolean } = {
          title: form.title.trim(),
          slug: form.slug.trim(),
          shortDescription: form.shortDescription.trim(),
          fullDescription: form.fullDescription.trim(),
          blocks: form.blocks,
          coverImage: form.coverImage,
          galleryImages: form.galleryImages,
          departmentIds: form.departmentIds,
          sectorIds: form.sectorIds,
          primaryDepartmentId: form.primaryDepartmentId || form.departmentIds[0] || undefined,
          category: form.category.trim() || 'Research',
          status: form.projectStatus,
          visibility: form.visibility,
          featured: form.featured,
          publicationStatus: nextPubStatus,
          startDate: form.startDate,
          completionDate: form.completionDate.trim() || undefined,
          pdfUrl: form.pdfUrl || undefined,
          videoUrl: form.videoUrl.trim() || undefined,
          audioUrl: form.audioUrl || undefined,
          documents: form.documents.filter(d => d.label.trim() && d.url.trim()),
          externalLinks: form.externalLinks.filter(l => l.label.trim() && l.url.trim()),
          credits: form.credits.trim() || undefined,
          tags: parseTags(form.tagsText),
          seoTitle: form.seoTitle.trim() || undefined,
          seoDescription: form.seoDescription.trim() || undefined,
          seoShareImage: form.seoShareImage || undefined,
          seoNoindex: form.seoNoindex,
          ...(submitRevision ? { submitRevision: true } : {})
        };
        saved = itemId
          ? await api.updateProject(itemId, payload)
          : await api.createProject(payload);
      } else if (kind === 'publication') {
        const existingPub = item as Publication | null;
        const submitRevision = Boolean(
          !canPublish && existingPub?.publicationStatus === 'Published' && mode === 'primary'
        );
        const nextPubStatus: PublicationStatus =
          mode === 'draft'
            ? 'Draft'
            : canPublish
              ? 'Published'
              : 'Pending Review';

        const payload: Partial<Publication> & { submitRevision?: boolean } = {
          title: form.title.trim(),
          slug: form.slug.trim(),
          authors: form.authors.trim(),
          abstract: form.abstract.trim(),
          publicationType: form.publicationType,
          publicationDate: form.publicationDate,
          pdfUrl: form.pdfUrl,
          thumbnailUrl: form.thumbnailUrl || undefined,
          doiOrUrl: form.doiOrUrl.trim() || undefined,
          departmentIds: form.departmentIds,
          sectorIds: form.sectorIds,
          relatedProjectId: form.relatedProjectId || undefined,
          tags: parseTags(form.tagsText),
          blocks: form.blocks,
          publicationStatus: nextPubStatus,
          seoTitle: form.seoTitle.trim() || undefined,
          seoDescription: form.seoDescription.trim() || undefined,
          seoShareImage: form.seoShareImage || undefined,
          seoNoindex: form.seoNoindex,
          ...(submitRevision ? { submitRevision: true } : {})
        };
        saved = itemId
          ? await api.updatePublication(itemId, payload)
          : await api.createPublication(payload);
      } else {
        const existingProd = item as Product | null;
        const submitRevision = Boolean(
          !canPublish && existingProd?.publicationStatus === 'Published' && mode === 'primary'
        );
        const nextPubStatus: PublicationStatus =
          mode === 'draft'
            ? 'Draft'
            : canPublish
              ? 'Published'
              : 'Pending Review';

        const payload: Partial<Product> & { submitRevision?: boolean } = {
          name: form.title.trim(),
          slug: form.slug.trim(),
          tagline: form.tagline.trim(),
          shortDescription: form.shortDescription.trim(),
          fullDescription: form.fullDescription.trim(),
          category: form.category.trim() || 'Software & Tools',
          status: form.productStage,
          version: form.version.trim() || undefined,
          releaseDate: form.releaseDate.trim() || undefined,
          availabilityPricing: form.availabilityPricing,
          priceText: form.availabilityPricing === 'paid' ? form.priceText.trim() || undefined : undefined,
          coverImage: form.coverImage,
          galleryImages: form.galleryImages,
          demoVideoUrl: form.demoVideoUrl.trim() || undefined,
          links: {
            download: form.downloadLink.trim() || undefined,
            website: form.websiteLink.trim() || undefined,
            repository: form.repositoryLink.trim() || undefined,
            documentationPdf: form.documentationPdf || undefined
          },
          keyFeatures: form.keyFeatures.map(k => k.trim()).filter(Boolean),
          specs: form.specs.filter(s => s.label.trim() && s.value.trim()),
          departmentIds: form.departmentIds,
          sectorIds: form.sectorIds,
          relatedProjectIds: form.relatedProjectIds,
          credits: form.credits.trim() || undefined,
          tags: parseTags(form.tagsText),
          blocks: form.blocks,
          publicationStatus: nextPubStatus,
          seoTitle: form.seoTitle.trim() || undefined,
          seoDescription: form.seoDescription.trim() || undefined,
          seoShareImage: form.seoShareImage || undefined,
          seoNoindex: form.seoNoindex,
          ...(submitRevision ? { submitRevision: true } : {})
        };
        saved = itemId
          ? await api.updateProduct(itemId, payload)
          : await api.createProduct(payload);
      }

      const nextBaseline = buildInitialState(kind, saved, departments, form.parentDepartmentId || undefined);
      initialSnapshotRef.current = nextBaseline;
      setForm(nextBaseline);
      setSlugManuallyEdited(true);
      setSavedNotice(`Saved ${formatSavedTime(new Date().toISOString())}`);
      await onSaved(kind, saved);
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Failed to save changes.');
    } finally {
      setSaving(false);
    }
  };

  const handleDuplicate = async () => {
    if (!itemId || !canDuplicate) return;
    setMenuOpen(false);
    setDuplicating(true);
    setSaveError(null);
    try {
      const cloned =
        kind === 'department' || kind === 'sector'
          ? await api.duplicateDepartment(itemId)
          : kind === 'project'
            ? await api.duplicateProject(itemId)
            : kind === 'publication'
              ? await api.duplicatePublication(itemId)
              : await api.duplicateProduct(itemId);
      setSavedNotice('Duplicated to draft');
      onDuplicated?.(kind, cloned);
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Duplicate failed.');
    } finally {
      setDuplicating(false);
    }
  };

  const handleConfirmTrash = async () => {
    if (!itemId) return;
    setTrashBusy(true);
    setSaveError(null);
    try {
      if (kind === 'department' || kind === 'sector') {
        await api.deleteDepartment(itemId, {
          projectHandling: trashHandling,
          targetDeptId: trashHandling === 'reassign' ? trashTargetDeptId || undefined : undefined
        });
      } else if (kind === 'project') {
        await api.deleteProject(itemId);
      } else if (kind === 'publication') {
        await api.deletePublication(itemId);
      } else {
        await api.deleteProduct(itemId);
      }
      setTrashConfirmOpen(false);
      await onDeleted?.();
      onBack();
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Failed to move item to trash.');
    } finally {
      setTrashBusy(false);
    }
  };

  const handleRestoreVersion = async (versionId: string) => {
    if (!itemId) return;
    setRestoringVersionId(versionId);
    setSaveError(null);
    try {
      const restored =
        kind === 'department' || kind === 'sector'
          ? await api.restoreDepartmentVersion(itemId, versionId)
          : kind === 'project'
            ? await api.restoreProjectVersion(itemId, versionId)
            : kind === 'publication'
              ? await api.restorePublicationVersion(itemId, versionId)
              : await api.restoreProductVersion(itemId, versionId);
      const nextState = buildInitialState(kind, restored, departments, form.parentDepartmentId || undefined);
      initialSnapshotRef.current = nextState;
      setForm(nextState);
      setSavedNotice(`Restored snapshot ${formatSavedTime(new Date().toISOString())}`);
      await onSaved(kind, restored);
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Failed to restore snapshot.');
    } finally {
      setRestoringVersionId(null);
    }
  };

  const versionsList: ProjectVersion[] = useMemo(() => {
    const raw = (item as { versions?: ProjectVersion[] } | null)?.versions;
    return Array.isArray(raw) ? raw : [];
  }, [item]);

  const pendingRev = (item as Project | Publication | Product | null)?.pendingRevision;
  const reviewComment = (item as Project | Publication | Product | null)?.reviewComment;

  const isOrgUnit = kind === 'department' || kind === 'sector';
  const primarySaveLabel = isOrgUnit
    ? isNew
      ? 'Create & publish'
      : 'Save changes'
    : canPublish
      ? isNew
        ? 'Create & publish'
        : 'Publish changes'
      : 'Submit for review';

  const secondarySaveAction = isOrgUnit
    ? {
        label: 'Save hidden draft',
        onClick: () => handleSave('draft'),
        disabled: saving
      }
    : {
        label: 'Save draft',
        onClick: () => handleSave('draft'),
        disabled: saving
      };

  const previewImageUrl =
    form.coverImage || form.thumbnailUrl || form.heroImage || form.customLogoUrl || '';

  return (
    <div className="space-y-6 pb-24">
      {/* Top Editor Header */}
      <div className="px-4 py-3.5 rounded-2xl bg-[#031D1C] border border-white/10 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => (isDirty ? setLeaveConfirmOpen(true) : onBack())}
            className="h-9 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>

          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-[#EDE9E0]/55">
              <span>Content</span>
              <span>/</span>
              <span>{breadcrumbArea}</span>
              <span>/</span>
              <span className="text-[#EDE9E0]/85 truncate max-w-[200px]">
                {form.title || `New ${kind}`}
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2 mt-0.5">
              <h1 className="text-base sm:text-lg font-bold text-[#EDE9E0] truncate max-w-md">
                {form.title || `Untitled ${kind}`}
              </h1>
              <PortalStatusBadge status={statusBadgeValue} />
              {pendingRev && (
                <PortalStatusBadge status="In review" labelOverride="Pending revision" />
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {savedNotice && !isDirty && (
            <span className="h-8 px-2.5 rounded-lg bg-[#17A491]/15 border border-[#25CDB6]/30 text-[11px] font-medium text-[#25CDB6] inline-flex items-center gap-1.5">
              <Check className="w-3 h-3" />
              <span>{savedNotice}</span>
            </span>
          )}

          {!isNew && (
            <button
              type="button"
              onClick={() => onNavigateSite(publicHref)}
              className="h-9 px-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5 text-[#25CDB6]" />
              <span>Preview</span>
            </button>
          )}

          {!isNew && (
            <div className="relative" ref={menuRef}>
              <button
                type="button"
                aria-label="More item actions"
                aria-expanded={menuOpen}
                onClick={() => setMenuOpen(v => !v)}
                className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0] inline-flex items-center justify-center cursor-pointer"
              >
                <MoreHorizontal className="w-4 h-4" />
              </button>
              {menuOpen && (
                <div
                  role="menu"
                  className="absolute right-0 top-11 z-30 min-w-[180px] rounded-xl bg-[#06302F] border border-white/15 shadow-2xl py-1.5"
                >
                  {canDuplicate && (
                    <button
                      type="button"
                      role="menuitem"
                      disabled={duplicating}
                      onClick={() => void handleDuplicate()}
                      className="w-full px-3 py-2 text-xs font-medium text-[#EDE9E0] hover:bg-white/10 flex items-center gap-2 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5 text-[#25CDB6]" />
                      <span>{duplicating ? 'Duplicating...' : 'Duplicate to draft'}</span>
                    </button>
                  )}
                  {canDeleteItem && (
                    <button
                      type="button"
                      role="menuitem"
                      onClick={() => {
                        setMenuOpen(false);
                        setTrashTargetDeptId(reassignTargetOptions[0]?.id || '');
                        setTrashConfirmOpen(true);
                      }}
                      className="w-full px-3 py-2 text-xs font-medium text-red-300 hover:bg-red-500/15 flex items-center gap-2 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Move to trash</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {reviewComment && (
        <div className="p-3.5 rounded-2xl bg-[#D0A873]/10 border border-[#D0A873]/30 text-xs text-[#EDE9E0] flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-[#D0A873] shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-[#D0A873]">Latest reviewer note</p>
            <p className="text-[#EDE9E0]/85 mt-0.5">{reviewComment}</p>
          </div>
        </div>
      )}

      {/* Two-Column Editor Body */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Main Form Column */}
        <div className="lg:col-span-8 space-y-5 min-w-0">
          {/* Basics */}
          <PortalSection
            title="Basics"
            description="Core identity, URL slug, short summary, and organizational placement."
          >
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3.5">
                <div className={isOrgUnit ? 'sm:col-span-8' : 'sm:col-span-12'}>
                  <label className="block text-xs font-semibold text-[#EDE9E0] mb-1.5">
                    {kind === 'department'
                      ? 'Department Name *'
                      : kind === 'sector'
                        ? 'Sector Name *'
                        : kind === 'product'
                          ? 'Product Name *'
                          : 'Title *'}
                  </label>
                  <input
                    type="text"
                    value={form.title}
                    onChange={e => updateField('title', e.target.value)}
                    placeholder={`Enter ${kind} name...`}
                    className="w-full h-10 px-3.5 rounded-xl bg-[#06302F] border border-white/15 focus:border-[#25CDB6]/70 text-sm text-[#EDE9E0] focus:outline-none"
                  />
                </div>

                {isOrgUnit && (
                  <div className="sm:col-span-4">
                    <label className="block text-xs font-semibold text-[#EDE9E0] mb-1.5">
                      Short Name / Code
                    </label>
                    <input
                      type="text"
                      value={form.shortName}
                      onChange={e => updateField('shortName', e.target.value)}
                      placeholder="e.g. RDD"
                      className="w-full h-10 px-3.5 rounded-xl bg-[#06302F] border border-white/15 focus:border-[#25CDB6]/70 text-sm text-[#EDE9E0] focus:outline-none"
                    />
                  </div>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <label className="text-xs font-semibold text-[#EDE9E0]">URL Slug *</label>
                  <span className="text-[11px] font-mono">
                    {slugCheck.checking ? (
                      <span className="text-[#EDE9E0]/50">Checking availability...</span>
                    ) : !form.slug.trim() ? (
                      <span className="text-[#D0A873]">Slug required</span>
                    ) : slugCheck.available ? (
                      <span className="text-[#25CDB6]">Available</span>
                    ) : (
                      <span className="text-red-300">
                        In use{slugCheck.conflictTitle ? ` by "${slugCheck.conflictTitle}"` : ''}
                      </span>
                    )}
                  </span>
                </div>
                <div className="flex items-center rounded-xl bg-[#06302F] border border-white/15 focus-within:border-[#25CDB6]/70 overflow-hidden">
                  <span className="px-3 py-2 text-xs font-mono text-[#EDE9E0]/45 bg-[#021413] border-r border-white/10 shrink-0">
                    {kind === 'department' || kind === 'sector'
                      ? '/departments/'
                      : kind === 'project'
                        ? '/projects/'
                        : kind === 'publication'
                          ? '/publications/'
                          : '/products/'}
                  </span>
                  <input
                    type="text"
                    value={form.slug}
                    onChange={e => {
                      setSlugManuallyEdited(true);
                      updateField('slug', slugifyLocal(e.target.value));
                    }}
                    placeholder="url-friendly-slug"
                    className="flex-1 h-10 px-3 bg-transparent text-xs font-mono text-[#EDE9E0] focus:outline-none min-w-0"
                  />
                </div>
              </div>

              {kind === 'sector' && (
                <div>
                  <label className="block text-xs font-semibold text-[#EDE9E0] mb-1.5">
                    Parent Department *
                  </label>
                  <select
                    value={form.parentDepartmentId}
                    onChange={e => updateField('parentDepartmentId', e.target.value)}
                    className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-xs text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]/70 cursor-pointer"
                  >
                    {activeDepartments.map(dept => (
                      <option key={dept.id} value={dept.id} className="bg-[#031D1C]">
                        {dept.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              {(kind === 'department' || kind === 'sector' || kind === 'product') && (
                <div>
                  <label className="block text-xs font-semibold text-[#EDE9E0] mb-1.5">
                    Tagline
                  </label>
                  <input
                    type="text"
                    value={form.tagline}
                    onChange={e => updateField('tagline', e.target.value)}
                    placeholder="Concise one-line positioning statement"
                    className="w-full h-10 px-3.5 rounded-xl bg-[#06302F] border border-white/15 text-sm text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]/70"
                  />
                </div>
              )}

              {(kind === 'project' || kind === 'product') && (
                <div>
                  <label className="block text-xs font-semibold text-[#EDE9E0] mb-1.5">
                    Short Description
                  </label>
                  <textarea
                    rows={3}
                    value={form.shortDescription}
                    onChange={e => updateField('shortDescription', e.target.value)}
                    placeholder="Brief summary displayed on directory cards and previews."
                    className="w-full p-3 rounded-xl bg-[#06302F] border border-white/15 text-sm text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]/70"
                  />
                </div>
              )}

              {kind === 'publication' && (
                <div>
                  <label className="block text-xs font-semibold text-[#EDE9E0] mb-1.5">
                    Abstract
                  </label>
                  <textarea
                    rows={4}
                    value={form.abstract}
                    onChange={e => updateField('abstract', e.target.value)}
                    placeholder="Executive summary and abstract of this publication."
                    className="w-full p-3 rounded-xl bg-[#06302F] border border-white/15 text-sm text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]/70"
                  />
                </div>
              )}

              {!isOrgUnit && (
                <div className="space-y-3 pt-1">
                  <div>
                    <span className="block text-xs font-semibold text-[#EDE9E0] mb-2">
                      Assigned Departments
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {activeDepartments.map(dept => {
                        const selected = form.departmentIds.includes(dept.id);
                        return (
                          <button
                            key={dept.id}
                            type="button"
                            onClick={() => toggleIdInList('departmentIds', dept.id)}
                            aria-pressed={selected}
                            className={`h-8 px-3 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                              selected
                                ? 'bg-[#17A491] text-[#031D1C] border-[#25CDB6]'
                                : 'bg-[#06302F] text-[#EDE9E0]/80 border-white/15 hover:border-white/30'
                            }`}
                          >
                            {dept.name}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {activeSectors.length > 0 && (
                    <div>
                      <span className="block text-xs font-semibold text-[#EDE9E0] mb-2">
                        Assigned Sectors
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {activeSectors.map(sector => {
                          const selected = form.sectorIds.includes(sector.id);
                          return (
                            <button
                              key={sector.id}
                              type="button"
                              onClick={() => toggleIdInList('sectorIds', sector.id)}
                              aria-pressed={selected}
                              className={`h-8 px-3 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                                selected
                                  ? 'bg-[#D0A873] text-[#031D1C] border-[#D0A873]'
                                  : 'bg-[#06302F] text-[#EDE9E0]/80 border-white/15 hover:border-white/30'
                              }`}
                            >
                              {sector.name}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </PortalSection>

          {/* Media */}
          <PortalSection
            title="Media"
            description="Visual covers, documents, and gallery frames selected from the library or uploaded directly."
          >
            <div className="space-y-4">
              {isOrgUnit ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <PortalMediaField
                    label="Logo / Emblem"
                    description="Primary circular or square unit mark."
                    value={form.customLogoUrl}
                    onChange={url => updateField('customLogoUrl', url)}
                    allowedTypes={['image']}
                    uploadFolder="Departments"
                    aspectClass="aspect-[16/10]"
                  />
                  <PortalMediaField
                    label="Hero Banner"
                    description="Wide visual displayed across header areas."
                    value={form.heroImage}
                    onChange={url => updateField('heroImage', url)}
                    allowedTypes={['image']}
                    uploadFolder="Departments"
                    aspectClass="aspect-[16/10]"
                  />
                </div>
              ) : kind === 'publication' ? (
                <div className="space-y-4">
                  <PortalMediaField
                    label="Publication PDF *"
                    description="Upload or choose a PDF document from the Media Library."
                    value={form.pdfUrl}
                    onChange={url => updateField('pdfUrl', url)}
                    allowedTypes={['document']}
                    uploadFolder="Publications"
                    compact
                  />
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold text-[#EDE9E0]">
                        Publication Cover Thumbnail
                      </span>
                      <button
                        type="button"
                        disabled={!form.pdfUrl || generatingThumb}
                        onClick={() => void handleGeneratePdfThumb()}
                        className="h-8 px-3 rounded-xl bg-[#17A491]/15 hover:bg-[#17A491]/25 border border-[#25CDB6]/30 text-xs font-semibold text-[#25CDB6] inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-45"
                      >
                        {generatingThumb ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Sparkles className="w-3.5 h-3.5" />
                        )}
                        <span>{generatingThumb ? 'Rendering...' : 'Generate from PDF'}</span>
                      </button>
                    </div>
                    <PortalMediaField
                      label="Thumbnail Image"
                      value={form.thumbnailUrl}
                      onChange={url => updateField('thumbnailUrl', url)}
                      allowedTypes={['image']}
                      uploadFolder="Publications"
                      compact
                    />
                  </div>
                </div>
              ) : (
                <PortalMediaField
                  label="Cover Image"
                  description="Primary cover visual displayed in listings and detail headers."
                  value={form.coverImage}
                  onChange={url => updateField('coverImage', url)}
                  allowedTypes={['image']}
                  uploadFolder={breadcrumbArea}
                />
              )}

              {(isOrgUnit || kind === 'project' || kind === 'product') && (
                <div className="space-y-2.5 pt-2 border-t border-white/10">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-semibold text-[#EDE9E0] block">
                        Gallery Showcase
                      </span>
                      <span className="text-[11px] text-[#EDE9E0]/55">
                        {form.galleryImages.length} frame{form.galleryImages.length === 1 ? '' : 's'} attached
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        ref={galleryFileRef}
                        type="file"
                        accept="image/*"
                        onChange={handleGalleryUpload}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => setGalleryPickerOpen(true)}
                        className="h-8 px-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <ImageIcon className="w-3.5 h-3.5 text-[#25CDB6]" />
                        <span>Add from library</span>
                      </button>
                      <button
                        type="button"
                        disabled={uploadingGallery}
                        onClick={() => galleryFileRef.current?.click()}
                        className="h-8 px-3 rounded-xl bg-[#17A491]/15 hover:bg-[#17A491]/25 border border-[#25CDB6]/30 text-xs font-semibold text-[#25CDB6] inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        {uploadingGallery ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Upload className="w-3.5 h-3.5" />
                        )}
                        <span>{uploadingGallery ? 'Uploading...' : 'Upload'}</span>
                      </button>
                    </div>
                  </div>

                  {form.galleryImages.length > 0 && (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {form.galleryImages.map((imgUrl, idx) => (
                        <div
                          key={`${imgUrl}-${idx}`}
                          className="relative aspect-[4/3] rounded-xl overflow-hidden border border-white/15 bg-[#06302F]"
                        >
                          <img
                            src={imgUrl}
                            alt={`Gallery frame ${idx + 1}`}
                            className="w-full h-full object-cover"
                          />
                          <button
                            type="button"
                            onClick={() =>
                              updateField(
                                'galleryImages',
                                form.galleryImages.filter((_, i) => i !== idx)
                              )
                            }
                            aria-label={`Remove gallery image ${idx + 1}`}
                            className="absolute top-1.5 right-1.5 w-7 h-7 rounded-lg bg-black/75 hover:bg-red-600 text-white flex items-center justify-center cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </PortalSection>

          {/* Content (ModularBlockEditor + Overview Charter / Narrative) */}
          <PortalSection
            title="Content"
            description="Compose modular content blocks alongside core overview narrative."
          >
            <div className="space-y-5">
              {isOrgUnit && (
                <div className="space-y-3 pb-4 border-b border-white/10">
                  <div>
                    <label className="block text-xs font-semibold text-[#EDE9E0] mb-1.5">
                      Overview Introduction
                    </label>
                    <textarea
                      rows={4}
                      value={form.introduction}
                      onChange={e => updateField('introduction', e.target.value)}
                      placeholder="Primary overview shown at the top of the public detail view."
                      className="w-full p-3 rounded-xl bg-[#06302F] border border-white/15 text-sm text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]/70"
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                    <div>
                      <label className="block text-xs font-semibold text-[#EDE9E0] mb-1.5">
                        Mandate &amp; Purpose
                      </label>
                      <textarea
                        rows={3}
                        value={form.purpose}
                        onChange={e => updateField('purpose', e.target.value)}
                        className="w-full p-3 rounded-xl bg-[#06302F] border border-white/15 text-xs text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]/70"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-[#EDE9E0] mb-1.5">
                        Mission Statement
                      </label>
                      <textarea
                        rows={3}
                        value={form.mission}
                        onChange={e => updateField('mission', e.target.value)}
                        className="w-full p-3 rounded-xl bg-[#06302F] border border-white/15 text-xs text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]/70"
                      />
                    </div>
                  </div>
                </div>
              )}

              {(kind === 'project' || kind === 'product') && (
                <div className="pb-4 border-b border-white/10">
                  <label className="block text-xs font-semibold text-[#EDE9E0] mb-1.5">
                    Summary Narrative
                  </label>
                  <textarea
                    rows={4}
                    value={form.fullDescription}
                    onChange={e => updateField('fullDescription', e.target.value)}
                    placeholder="Detailed narrative overview..."
                    className="w-full p-3 rounded-xl bg-[#06302F] border border-white/15 text-sm text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]/70"
                  />
                </div>
              )}

              <div>
                <span className="block text-xs font-semibold text-[#EDE9E0] mb-2">
                  Modular Page Blocks
                </span>
                <ModularBlockEditor blocks={form.blocks} onChange={handleBlocksChange} />
              </div>
            </div>
          </PortalSection>

          {/* Type Details */}
          <PortalSection
            title="Type Details"
            description="Structured metadata, links, classifications, and attributes specific to this entry."
          >
            {isOrgUnit && (
              <div className="space-y-5 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Glyph Icon</label>
                    <select
                      value={form.iconGlyph}
                      onChange={e => updateField('iconGlyph', e.target.value as DepartmentGlyph)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    >
                      {GLYPH_OPTIONS.map(opt => (
                        <option key={opt.id} value={opt.id} className="bg-[#031D1C]">
                          {opt.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Accent Color</label>
                    <div className="flex items-center gap-2 h-10 px-2.5 rounded-xl bg-[#06302F] border border-white/15">
                      <input
                        type="color"
                        value={form.colorHex}
                        onChange={e => updateField('colorHex', e.target.value)}
                        className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                      />
                      <span className="font-mono text-[#EDE9E0]/80">{form.colorHex}</span>
                    </div>
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Badge Surface</label>
                    <div className="flex items-center gap-2 h-10 px-2.5 rounded-xl bg-[#06302F] border border-white/15">
                      <input
                        type="color"
                        value={form.iconBgHex}
                        onChange={e => updateField('iconBgHex', e.target.value)}
                        className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                      />
                      <span className="font-mono text-[#EDE9E0]/80">{form.iconBgHex}</span>
                    </div>
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Layout Style</label>
                    <select
                      value={form.template}
                      onChange={e =>
                        updateField('template', e.target.value as NonNullable<Department['template']>)
                      }
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    >
                      <option value="Standard" className="bg-[#031D1C]">Standard</option>
                      <option value="Research-heavy" className="bg-[#031D1C]">Research-heavy</option>
                      <option value="Media-heavy" className="bg-[#031D1C]">Media-heavy</option>
                      <option value="Programmes-heavy" className="bg-[#031D1C]">Programmes-heavy</option>
                    </select>
                  </div>
                </div>

                <PortalMediaField
                  label="Custom Vector / Glyph Asset"
                  value={form.iconUrl}
                  onChange={url => updateField('iconUrl', url)}
                  allowedTypes={['image']}
                  uploadFolder="Departments"
                  compact
                />

                {/* Areas of Focus */}
                <div className="space-y-2.5 pt-2 border-t border-white/10">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-[#EDE9E0]">Areas of Focus</span>
                    <button
                      type="button"
                      onClick={() =>
                        updateField('structuredAreasOfFocus', [
                          ...form.structuredAreasOfFocus,
                          { id: `focus-${Date.now()}`, title: '', description: '' }
                        ])
                      }
                      className="text-[#25CDB6] font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add area
                    </button>
                  </div>
                  {form.structuredAreasOfFocus.map((card, idx) => (
                    <div key={card.id || idx} className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-center">
                      <input
                        type="text"
                        placeholder="Area title"
                        value={card.title}
                        onChange={e => {
                          const next = [...form.structuredAreasOfFocus];
                          next[idx] = { ...next[idx], title: e.target.value };
                          updateField('structuredAreasOfFocus', next);
                        }}
                        className="sm:col-span-4 h-9 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                      />
                      <input
                        type="text"
                        placeholder="Description"
                        value={card.description}
                        onChange={e => {
                          const next = [...form.structuredAreasOfFocus];
                          next[idx] = { ...next[idx], description: e.target.value };
                          updateField('structuredAreasOfFocus', next);
                        }}
                        className="sm:col-span-7 h-9 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          updateField(
                            'structuredAreasOfFocus',
                            form.structuredAreasOfFocus.filter((_, i) => i !== idx)
                          )
                        }
                        aria-label="Remove area of focus"
                        className="sm:col-span-1 p-2 text-red-300 hover:text-red-200 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Initiatives */}
                <div className="space-y-2.5 pt-2 border-t border-white/10">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-[#EDE9E0]">Initiatives</span>
                    <button
                      type="button"
                      onClick={() =>
                        updateField('structuredInitiatives', [
                          ...form.structuredInitiatives,
                          { id: `init-${Date.now()}`, title: '', status: 'Active', summary: '' }
                        ])
                      }
                      className="text-[#25CDB6] font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add initiative
                    </button>
                  </div>
                  {form.structuredInitiatives.map((init, idx) => (
                    <div key={init.id || idx} className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-center">
                      <input
                        type="text"
                        placeholder="Initiative title"
                        value={init.title}
                        onChange={e => {
                          const next = [...form.structuredInitiatives];
                          next[idx] = { ...next[idx], title: e.target.value };
                          updateField('structuredInitiatives', next);
                        }}
                        className="sm:col-span-4 h-9 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                      />
                      <select
                        value={init.status}
                        onChange={e => {
                          const next = [...form.structuredInitiatives];
                          next[idx] = {
                            ...next[idx],
                            status: e.target.value as InitiativeItem['status']
                          };
                          updateField('structuredInitiatives', next);
                        }}
                        className="sm:col-span-3 h-9 px-2.5 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                      >
                        <option value="Active" className="bg-[#031D1C]">Active</option>
                        <option value="In Development" className="bg-[#031D1C]">In Development</option>
                        <option value="Planned" className="bg-[#031D1C]">Planned</option>
                        <option value="Completed" className="bg-[#031D1C]">Completed</option>
                      </select>
                      <input
                        type="text"
                        placeholder="Summary"
                        value={init.summary || ''}
                        onChange={e => {
                          const next = [...form.structuredInitiatives];
                          next[idx] = { ...next[idx], summary: e.target.value };
                          updateField('structuredInitiatives', next);
                        }}
                        className="sm:col-span-4 h-9 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          updateField(
                            'structuredInitiatives',
                            form.structuredInitiatives.filter((_, i) => i !== idx)
                          )
                        }
                        aria-label="Remove initiative"
                        className="sm:col-span-1 p-2 text-red-300 hover:text-red-200 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {kind === 'project' && (
              <div className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Category</label>
                    <input
                      type="text"
                      value={form.category}
                      onChange={e => updateField('category', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Project Status</label>
                    <select
                      value={form.projectStatus}
                      onChange={e => updateField('projectStatus', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    >
                      <option value="Concept" className="bg-[#031D1C]">Concept</option>
                      <option value="In Development" className="bg-[#031D1C]">In Development</option>
                      <option value="Active" className="bg-[#031D1C]">Active</option>
                      <option value="Completed" className="bg-[#031D1C]">Completed</option>
                      <option value="On Hold" className="bg-[#031D1C]">On Hold</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Visibility</label>
                    <select
                      value={form.visibility}
                      onChange={e =>
                        updateField('visibility', e.target.value as EditorFormState['visibility'])
                      }
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    >
                      <option value="Public" className="bg-[#031D1C]">Public</option>
                      <option value="Unlisted" className="bg-[#031D1C]">Unlisted</option>
                      <option value="Members only" className="bg-[#031D1C]">Members only</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Start Date</label>
                    <input
                      type="date"
                      value={form.startDate}
                      onChange={e => updateField('startDate', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Completion Date</label>
                    <input
                      type="date"
                      value={form.completionDate}
                      onChange={e => updateField('completionDate', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <PortalMediaField
                    label="Project Brief PDF"
                    value={form.pdfUrl}
                    onChange={url => updateField('pdfUrl', url)}
                    allowedTypes={['document']}
                    uploadFolder="Projects"
                    compact
                  />
                  <PortalMediaField
                    label="Audio Recording"
                    value={form.audioUrl}
                    onChange={url => updateField('audioUrl', url)}
                    allowedTypes={['audio']}
                    uploadFolder="Projects"
                    compact
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Video URL</label>
                    <input
                      type="url"
                      placeholder="https://youtube.com/..."
                      value={form.videoUrl}
                      onChange={e => updateField('videoUrl', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 font-mono text-[#EDE9E0]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Tags (comma separated)</label>
                    <input
                      type="text"
                      placeholder="research, computation, design"
                      value={form.tagsText}
                      onChange={e => updateField('tagsText', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-[#EDE9E0] mb-1.5">Credits</label>
                  <input
                    type="text"
                    value={form.credits}
                    onChange={e => updateField('credits', e.target.value)}
                    placeholder="Contributors and researchers"
                    className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                  />
                </div>

                {/* External Links */}
                <div className="space-y-2 pt-2 border-t border-white/10">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[#EDE9E0]">External Links</span>
                    <button
                      type="button"
                      onClick={() =>
                        updateField('externalLinks', [
                          ...form.externalLinks,
                          { label: '', url: '' }
                        ])
                      }
                      className="text-[#25CDB6] font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add link
                    </button>
                  </div>
                  {form.externalLinks.map((lnk, idx) => (
                    <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                      <input
                        type="text"
                        placeholder="Label"
                        value={lnk.label}
                        onChange={e => {
                          const next = [...form.externalLinks];
                          next[idx] = { ...next[idx], label: e.target.value };
                          updateField('externalLinks', next);
                        }}
                        className="col-span-4 h-9 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                      />
                      <input
                        type="url"
                        placeholder="https://..."
                        value={lnk.url}
                        onChange={e => {
                          const next = [...form.externalLinks];
                          next[idx] = { ...next[idx], url: e.target.value };
                          updateField('externalLinks', next);
                        }}
                        className="col-span-7 h-9 px-3 rounded-xl bg-[#06302F] border border-white/15 font-mono text-[#EDE9E0]"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          updateField(
                            'externalLinks',
                            form.externalLinks.filter((_, i) => i !== idx)
                          )
                        }
                        className="col-span-1 p-2 text-red-300 cursor-pointer"
                        aria-label="Remove external link"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {kind === 'publication' && (
              <div className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Authors *</label>
                    <input
                      type="text"
                      value={form.authors}
                      onChange={e => updateField('authors', e.target.value)}
                      placeholder="e.g. A. Researcher, B. Collaborator"
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Publication Type</label>
                    <select
                      value={form.publicationType}
                      onChange={e => updateField('publicationType', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    >
                      <option value="Paper" className="bg-[#031D1C]">Paper</option>
                      <option value="Monograph" className="bg-[#031D1C]">Monograph</option>
                      <option value="Whitepaper" className="bg-[#031D1C]">Whitepaper</option>
                      <option value="Report" className="bg-[#031D1C]">Report</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Publication Date</label>
                    <input
                      type="date"
                      value={form.publicationDate}
                      onChange={e => updateField('publicationDate', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">DOI or Reference URL</label>
                    <input
                      type="text"
                      placeholder="https://doi.org/..."
                      value={form.doiOrUrl}
                      onChange={e => updateField('doiOrUrl', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 font-mono text-[#EDE9E0]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Related Project</label>
                    <select
                      value={form.relatedProjectId}
                      onChange={e => updateField('relatedProjectId', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    >
                      <option value="" className="bg-[#031D1C]">None</option>
                      {projects
                        .filter(p => !p.deletedAt)
                        .map(p => (
                          <option key={p.id} value={p.id} className="bg-[#031D1C]">
                            {p.title}
                          </option>
                        ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Tags (comma separated)</label>
                    <input
                      type="text"
                      value={form.tagsText}
                      onChange={e => updateField('tagsText', e.target.value)}
                      placeholder="policy, journal, monograph"
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    />
                  </div>
                </div>
              </div>
            )}

            {kind === 'product' && (
              <div className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Stage</label>
                    <select
                      value={form.productStage}
                      onChange={e => updateField('productStage', e.target.value as ProductStage)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    >
                      <option value="Concept" className="bg-[#031D1C]">Concept</option>
                      <option value="In development" className="bg-[#031D1C]">In development</option>
                      <option value="Released" className="bg-[#031D1C]">Released</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Version</label>
                    <input
                      type="text"
                      placeholder="1.0.0"
                      value={form.version}
                      onChange={e => updateField('version', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 font-mono text-[#EDE9E0]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Release Date</label>
                    <input
                      type="date"
                      value={form.releaseDate}
                      onChange={e => updateField('releaseDate', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Category</label>
                    <input
                      type="text"
                      value={form.category}
                      onChange={e => updateField('category', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Availability</label>
                    <select
                      value={form.availabilityPricing}
                      onChange={e =>
                        updateField('availabilityPricing', e.target.value as ProductPricingType)
                      }
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    >
                      <option value="free" className="bg-[#031D1C]">Open / Free</option>
                      <option value="paid" className="bg-[#031D1C]">Commercial / Paid</option>
                      <option value="contact" className="bg-[#031D1C]">Contact for access</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Demo Video URL</label>
                    <input
                      type="url"
                      placeholder="https://..."
                      value={form.demoVideoUrl}
                      onChange={e => updateField('demoVideoUrl', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 font-mono text-[#EDE9E0]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Download URL</label>
                    <input
                      type="url"
                      value={form.downloadLink}
                      onChange={e => updateField('downloadLink', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 font-mono text-[#EDE9E0]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Website URL</label>
                    <input
                      type="url"
                      value={form.websiteLink}
                      onChange={e => updateField('websiteLink', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 font-mono text-[#EDE9E0]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Repository URL</label>
                    <input
                      type="url"
                      value={form.repositoryLink}
                      onChange={e => updateField('repositoryLink', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 font-mono text-[#EDE9E0]"
                    />
                  </div>
                </div>

                <PortalMediaField
                  label="Documentation PDF"
                  value={form.documentationPdf}
                  onChange={url => updateField('documentationPdf', url)}
                  allowedTypes={['document']}
                  uploadFolder="Products"
                  compact
                />

                {/* Key Features */}
                <div className="space-y-2 pt-2 border-t border-white/10">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[#EDE9E0]">Key Features</span>
                    <button
                      type="button"
                      onClick={() => updateField('keyFeatures', [...form.keyFeatures, ''])}
                      className="text-[#25CDB6] font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add feature
                    </button>
                  </div>
                  {form.keyFeatures.map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <input
                        type="text"
                        value={feat}
                        placeholder="Feature capability..."
                        onChange={e => {
                          const next = [...form.keyFeatures];
                          next[idx] = e.target.value;
                          updateField('keyFeatures', next);
                        }}
                        className="flex-1 h-9 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          updateField(
                            'keyFeatures',
                            form.keyFeatures.filter((_, i) => i !== idx)
                          )
                        }
                        aria-label="Remove feature"
                        className="p-2 text-red-300 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* Specs */}
                <div className="space-y-2 pt-2 border-t border-white/10">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[#EDE9E0]">Specifications</span>
                    <button
                      type="button"
                      onClick={() => updateField('specs', [...form.specs, { label: '', value: '' }])}
                      className="text-[#25CDB6] font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add spec
                    </button>
                  </div>
                  {form.specs.map((sp, idx) => (
                    <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                      <input
                        type="text"
                        placeholder="Attribute"
                        value={sp.label}
                        onChange={e => {
                          const next = [...form.specs];
                          next[idx] = { ...next[idx], label: e.target.value };
                          updateField('specs', next);
                        }}
                        className="col-span-4 h-9 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                      />
                      <input
                        type="text"
                        placeholder="Value"
                        value={sp.value}
                        onChange={e => {
                          const next = [...form.specs];
                          next[idx] = { ...next[idx], value: e.target.value };
                          updateField('specs', next);
                        }}
                        className="col-span-7 h-9 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          updateField(
                            'specs',
                            form.specs.filter((_, i) => i !== idx)
                          )
                        }
                        aria-label="Remove spec"
                        className="col-span-1 p-2 text-red-300 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Credits</label>
                    <input
                      type="text"
                      value={form.credits}
                      onChange={e => updateField('credits', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#EDE9E0] mb-1.5">Tags (comma separated)</label>
                    <input
                      type="text"
                      value={form.tagsText}
                      onChange={e => updateField('tagsText', e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                    />
                  </div>
                </div>
              </div>
            )}
          </PortalSection>

          {/* Collapsible SEO */}
          <PortalSection
            title="SEO"
            description="Search snippet title, meta description, social share graphic, and indexing rules."
            collapsible
            defaultOpen={false}
          >
            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-[#EDE9E0] mb-1.5">SEO Title</label>
                <input
                  type="text"
                  value={form.seoTitle}
                  onChange={e => updateField('seoTitle', e.target.value)}
                  placeholder={form.title || 'Defaults to entry title'}
                  className="w-full h-10 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#EDE9E0] mb-1.5">Meta Description</label>
                <textarea
                  rows={3}
                  value={form.seoDescription}
                  onChange={e => updateField('seoDescription', e.target.value)}
                  placeholder={form.tagline || form.shortDescription || form.abstract || 'Concise summary for search results.'}
                  className="w-full p-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                />
              </div>

              <PortalMediaField
                label="Social Share Image (OpenGraph)"
                value={form.seoShareImage}
                onChange={url => updateField('seoShareImage', url)}
                allowedTypes={['image']}
                uploadFolder="SEO"
                compact
              />

              <label className="flex items-center gap-2.5 p-3 rounded-xl bg-[#06302F]/60 border border-white/10 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.seoNoindex}
                  onChange={e => updateField('seoNoindex', e.target.checked)}
                  className="w-4 h-4 rounded accent-[#25CDB6]"
                />
                <span>Exclude this page from search engine indexing (noindex)</span>
              </label>

              {/* Search Result Preview */}
              <div className="p-4 rounded-xl bg-[#06302F] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#EDE9E0]/45 block">
                  Search snippet preview
                </span>
                <p className="text-sm font-bold text-[#25CDB6] truncate">
                  {form.seoTitle.trim() || form.title || 'Untitled Entry'} — Masters Of All
                </p>
                <p className="text-[11px] font-mono text-[#EDE9E0]/55 truncate">
                  https://mastersofall.org{publicHref}
                </p>
                <p className="text-xs text-[#EDE9E0]/75 line-clamp-2">
                  {form.seoDescription.trim() ||
                    form.tagline.trim() ||
                    form.shortDescription.trim() ||
                    form.abstract.trim() ||
                    'Explore research, publications, and institutional initiatives from Masters Of All.'}
                </p>
              </div>
            </div>
          </PortalSection>
        </div>

        {/* Right Column */}
        <div className="lg:col-span-4 space-y-5">
          {/* Publish Status Card */}
          <PortalSection title="Publish" description="Visibility and workflow state.">
            <div className="space-y-3 text-xs">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[#EDE9E0]/65">Current status</span>
                <PortalStatusBadge status={statusBadgeValue} />
              </div>

              {isOrgUnit ? (
                <div className="space-y-2.5 pt-2 border-t border-white/10">
                  <label className="flex items-center justify-between gap-2 cursor-pointer">
                    <span className="text-[#EDE9E0]">Published on website</span>
                    <input
                      type="checkbox"
                      checked={form.published}
                      onChange={e => updateField('published', e.target.checked)}
                      className="w-4 h-4 rounded accent-[#25CDB6]"
                    />
                  </label>
                  <label className="flex items-center justify-between gap-2 cursor-pointer">
                    <span className="text-[#EDE9E0]">Show in hierarchy tree</span>
                    <input
                      type="checkbox"
                      checked={form.showInTree}
                      onChange={e => updateField('showInTree', e.target.checked)}
                      className="w-4 h-4 rounded accent-[#25CDB6]"
                    />
                  </label>
                </div>
              ) : (
                <div className="space-y-2 pt-2 border-t border-white/10">
                  <label className="block text-[#EDE9E0]/70 font-semibold">Workflow status</label>
                  <select
                    value={form.publicationStatus}
                    disabled={!canPublish && form.publicationStatus === 'Published'}
                    onChange={e =>
                      updateField('publicationStatus', e.target.value as PublicationStatus)
                    }
                    className="w-full h-9 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                  >
                    <option value="Draft" className="bg-[#031D1C]">Draft</option>
                    <option value="Pending Review" className="bg-[#031D1C]">In review</option>
                    {canPublish && (
                      <>
                        <option value="Published" className="bg-[#031D1C]">Published</option>
                        <option value="Archived" className="bg-[#031D1C]">Archived</option>
                      </>
                    )}
                  </select>
                </div>
              )}
            </div>
          </PortalSection>

          {/* Always-visible Live Preview Card */}
          <PortalSection title="Live preview" description="Summary appearance on public directory.">
            <div className="rounded-xl bg-[#06302F] border border-white/10 overflow-hidden">
              {previewImageUrl ? (
                <div className="aspect-[16/9] w-full bg-[#021413] overflow-hidden border-b border-white/10">
                  <img
                    src={previewImageUrl}
                    alt={form.title || 'Preview'}
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : isOrgUnit ? (
                <div className="p-4 bg-[#021413]/70 border-b border-white/10 flex items-center gap-3">
                  <DepartmentLogo
                    department={{
                      id: itemId || 'preview',
                      name: form.title || 'Unit',
                      slug: form.slug || 'unit',
                      customLogoUrl: form.customLogoUrl,
                      iconUrl: form.iconUrl,
                      iconGlyph: form.iconGlyph,
                      colorHex: form.colorHex,
                      iconBgHex: form.iconBgHex
                    }}
                    size={42}
                    fallbackMode="icon"
                  />
                  <span className="text-xs font-mono text-[#EDE9E0]/60 truncate">{publicHref}</span>
                </div>
              ) : (
                <div className="aspect-[16/9] w-full bg-[#021413] border-b border-white/10 flex items-center justify-center text-[#25CDB6]/40">
                  {kind === 'publication' ? (
                    <FileText className="w-8 h-8" />
                  ) : (
                    <Layers className="w-8 h-8" />
                  )}
                </div>
              )}

              <div className="p-4 space-y-1.5">
                <div className="flex items-center justify-between gap-2 text-[11px]">
                  <span className="font-mono text-[#25CDB6] truncate">{publicHref}</span>
                  <PortalStatusBadge status={statusBadgeValue} />
                </div>
                <h3 className="text-sm font-bold text-[#EDE9E0] break-words">
                  {form.title || `Untitled ${kind}`}
                </h3>
                <p className="text-xs text-[#EDE9E0]/70 line-clamp-3 leading-relaxed">
                  {form.tagline ||
                    form.shortDescription ||
                    form.abstract ||
                    form.introduction ||
                    'Add a tagline or short summary to preview how this item appears on the public site.'}
                </p>
              </div>
            </div>
          </PortalSection>

          {/* History Snapshots */}
          {!isNew && (
            <PortalSection
              title="History"
              badge={
                <span className="text-[11px] font-mono text-[#EDE9E0]/55 tabular-nums">
                  {versionsList.length}
                </span>
              }
              description="Snapshots recorded before updates."
            >
              {versionsList.length === 0 ? (
                <p className="text-xs text-[#EDE9E0]/55">No saved snapshots yet.</p>
              ) : (
                <div className="space-y-2.5 max-h-[320px] overflow-y-auto pr-1">
                  {versionsList.slice(0, 12).map(ver => (
                    <div
                      key={ver.versionId}
                      className="p-3 rounded-xl bg-[#06302F] border border-white/10 space-y-1.5 text-xs"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-semibold text-[#EDE9E0] truncate">
                          {ver.author || 'System'}
                        </span>
                        <span className="text-[10px] font-mono text-[#EDE9E0]/50 tabular-nums shrink-0">
                          {ver.timestamp ? new Date(ver.timestamp).toLocaleDateString() : ''}
                        </span>
                      </div>
                      {ver.summary && (
                        <p className="text-[11px] text-[#EDE9E0]/65 break-words">{ver.summary}</p>
                      )}
                      <button
                        type="button"
                        disabled={restoringVersionId === ver.versionId}
                        onClick={() => void handleRestoreVersion(ver.versionId)}
                        className="h-7 px-2.5 rounded-lg bg-white/8 hover:bg-white/15 border border-white/10 text-[11px] font-semibold text-[#25CDB6] inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                      >
                        {restoringVersionId === ver.versionId ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <History className="w-3 h-3" />
                        )}
                        <span>Restore snapshot</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </PortalSection>
          )}
        </div>
      </div>

      {/* Universal Floating Save Bar */}
      <PortalFloatingSaveBar
        visible={isDirty || isNew}
        title={isNew ? `New ${kind}` : 'Unsaved changes'}
        subtitle={
          isDirty
            ? 'You have unsaved edits in this entry.'
            : 'Fill in required details and save.'
        }
        error={saveError}
        saving={saving}
        saveLabel={primarySaveLabel}
        secondaryAction={secondarySaveAction}
        onDiscard={() => {
          if (isNew) {
            onBack();
          } else {
            setForm(initialSnapshotRef.current);
            setSaveError(null);
          }
        }}
        onSave={() => handleSave('primary')}
        enableShortcut
      />

      {/* Unsaved Exit Guard */}
      <PortalConfirmDialog
        isOpen={leaveConfirmOpen}
        title="Discard unsaved changes?"
        message="You have unsaved changes in this editor. Leaving now will discard them."
        confirmLabel="Discard & leave"
        cancelLabel="Stay in editor"
        isDestructive
        onConfirm={() => {
          setLeaveConfirmOpen(false);
          onBack();
        }}
        onCancel={() => setLeaveConfirmOpen(false)}
      />

      {/* Move to Trash Confirmation (with project reassignment for org units) */}
      <PortalConfirmDialog
        isOpen={trashConfirmOpen}
        title={`Move ${kind} to trash?`}
        message={`"${form.title || kind}" will be hidden from the public site and moved to Trash, where it can be restored later.`}
        confirmLabel="Move to trash"
        cancelLabel="Cancel"
        isDestructive
        loading={trashBusy}
        confirmDisabled={
          isOrgUnit && entityProjectsCount > 0 && trashHandling === 'reassign' && !trashTargetDeptId
        }
        onConfirm={() => void handleConfirmTrash()}
        onCancel={() => setTrashConfirmOpen(false)}
      >
        {isOrgUnit && entityProjectsCount > 0 && (
          <div className="p-3.5 rounded-xl bg-[#031D1C] border border-white/10 space-y-2.5 text-xs">
            <p className="font-semibold text-[#D0A873]">
              {entityProjectsCount} related project{entityProjectsCount === 1 ? '' : 's'} assigned
            </p>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                name="trash-project-handling"
                checked={trashHandling === 'leave'}
                onChange={() => setTrashHandling('leave')}
                className="accent-[#25CDB6]"
              />
              <span>Leave projects unassigned</span>
            </label>
            {reassignTargetOptions.length > 0 && (
              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="trash-project-handling"
                    checked={trashHandling === 'reassign'}
                    onChange={() => setTrashHandling('reassign')}
                    className="accent-[#25CDB6]"
                  />
                  <span>Reassign projects to another department</span>
                </label>
                {trashHandling === 'reassign' && (
                  <select
                    value={trashTargetDeptId}
                    onChange={e => setTrashTargetDeptId(e.target.value)}
                    className="w-full h-9 px-3 rounded-xl bg-[#06302F] border border-white/15 text-[#EDE9E0]"
                  >
                    {reassignTargetOptions.map(d => (
                      <option key={d.id} value={d.id} className="bg-[#031D1C]">
                        {d.name}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            )}
          </div>
        )}
      </PortalConfirmDialog>

      <MediaPicker
        isOpen={galleryPickerOpen}
        onClose={() => setGalleryPickerOpen(false)}
        onSelect={(asset: MediaAsset) => {
          updateField('galleryImages', [...form.galleryImages, asset.url]);
          setGalleryPickerOpen(false);
        }}
        allowedTypes={['image']}
        title="Add Gallery Image"
      />
    </div>
  );
};
