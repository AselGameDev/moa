import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Building2,
  ShieldCheck,
  Inbox,
  Database,
  History,
  Activity,
  Trash2,
  Check,
  Download,
  Upload,
  Lock,
  RefreshCw,
  Shield,
  KeyRound,
  AlertCircle,
  Archive,
  Copy,
  ChevronLeft,
  ChevronRight,
  MailOpen,
  RotateCcw
} from 'lucide-react';
import QRCode from 'qrcode';
import { api } from '../../../services/api';
import {
  FormSubmission,
  SiteSettings,
  Department,
  Project,
  SiteContent,
  User,
  RoleDefinition,
  ActivityRecord,
  SecurityLogRecord,
  SiteHealthItem,
  TrashItemsResponse
} from '../../../types';
import { can } from '../../../shared/permissions';
import { getVisibleSubTabs } from '../portalRegistry';
import { DeleteButton, DESTRUCTIVE_LABEL_BTN_CLASS } from '../DeleteButton';
import {
  PortalConfirmDialog,
  PortalEmptyState,
  PortalFilterBar,
  PortalFloatingSaveBar,
  PortalPageHeader,
  PortalSection,
  PortalStatusBadge,
  PortalTable,
  PortalTabs,
  type PortalStatusVariant,
  type PortalTabItem,
  type PortalTableColumn
} from '../ui';

export type SettingsSubTab =
  | 'organization'
  | 'security'
  | 'inbox'
  | 'audit'
  | 'health'
  | 'backups'
  | 'trash';

interface SettingsTabProps {
  currentSubTab: SettingsSubTab;
  onSubTabChange: (sub: SettingsSubTab) => void;
  currentUser: User;
  roles?: RoleDefinition[];
  settings?: SiteSettings;
  onUpdateSettings?: (settings: Partial<SiteSettings>) => Promise<void>;
  departments?: Department[];
  projects?: Project[];
  siteContent?: SiteContent;
  onRefreshData?: () => Promise<void>;
  onNavigateTab?: (tab: string, subTab?: string, pageId?: string, drawerTab?: string) => void;
  onUserUpdated?: (user: User) => void;
}

type TrashEntityType =
  | 'department'
  | 'project'
  | 'publication'
  | 'product'
  | 'page'
  | 'media'
  | 'submission';

interface FlattenedTrashItem {
  id: string;
  entityType: TrashEntityType;
  labelType: 'Department' | 'Project' | 'Publication' | 'Product' | 'Page' | 'Media' | 'Submission';
  title: string;
  deletedAt: string;
  daysLeftLabel: string;
}

const SUBTAB_ICONS: Record<SettingsSubTab, React.ComponentType<{ className?: string }>> = {
  organization: Building2,
  security: ShieldCheck,
  inbox: Inbox,
  audit: History,
  health: Activity,
  backups: Database,
  trash: Trash2
};

function escapeCsvCell(value: string): string {
  let clean = String(value ?? '');
  if (/^[=+\-@\t\r]/.test(clean)) {
    clean = `'${clean}`;
  }
  return `"${clean.replace(/"/g, '""')}"`;
}

function mapSubmissionStatusToBadge(status: FormSubmission['status']): {
  variant: PortalStatusVariant;
  label: string;
} {
  if (status === 'new') return { variant: 'In review', label: 'New' };
  if (status === 'read') return { variant: 'Published', label: 'Read' };
  return { variant: 'Archived', label: 'Archived' };
}

function mapHealthTypeToBadge(type: SiteHealthItem['type']): {
  variant: PortalStatusVariant;
  label: string;
} {
  if (type === 'error') return { variant: 'Archived', label: 'Error' };
  if (type === 'warning') return { variant: 'In review', label: 'Warning' };
  return { variant: 'Published', label: 'Info' };
}

export const SettingsTab: React.FC<SettingsTabProps> = ({
  currentSubTab,
  onSubTabChange,
  currentUser,
  roles,
  settings,
  onUpdateSettings,
  onRefreshData,
  onNavigateTab,
  onUserUpdated
}) => {
  const canManageSettings = can(currentUser, 'settings.manage', roles);
  const canViewInbox = can(currentUser, 'inbox.view', roles);
  const canViewAudit = can(currentUser, 'audit.view', roles);
  const canViewHealth =
    canViewAudit ||
    canManageSettings ||
    can(currentUser, 'website.edit', roles) ||
    can(currentUser, 'pages.manage', roles) ||
    can(currentUser, 'seo.manage', roles);
  const canManageBackups = can(currentUser, 'backups.manage', roles);
  const canManageTrash = can(currentUser, 'trash.manage', roles);

  const visibleSubTabs = useMemo(
    () => getVisibleSubTabs('settings', currentUser, roles),
    [currentUser, roles]
  );

  // Global status/error feedback
  const [bannerError, setBannerError] = useState<string | null>(null);
  const [bannerSuccess, setBannerSuccess] = useState<string | null>(null);

  const showSuccess = (msg: string) => {
    setBannerError(null);
    setBannerSuccess(msg);
    setTimeout(() => setBannerSuccess(prev => (prev === msg ? null : prev)), 4000);
  };

  // 1. Organization Profile State
  const [orgData, setOrgData] = useState({
    name: settings?.siteName || 'Masters Of All',
    tagline: settings?.tagline || '',
    contactEmail: settings?.contactEmail || '',
    organizationAddress: settings?.organizationAddress || '',
    timezone: settings?.timezone || 'UTC',
    primaryLanguage: settings?.language || 'en-GB'
  });
  const [orgSaving, setOrgSaving] = useState(false);

  // 2. Security Policy State
  const [securityConfig, setSecurityConfig] = useState({
    enforce2FAForAdmins: settings?.securityPolicy?.enforce2FAForAdmins ?? false,
    minPasswordLength: Math.max(12, settings?.securityPolicy?.minPasswordLength ?? 12),
    requireUppercase: settings?.securityPolicy?.requireUppercase ?? true,
    requireNumber: settings?.securityPolicy?.requireNumber ?? true,
    requireSymbol: settings?.securityPolicy?.requireSymbol ?? true,
    sessionTimeoutMinutes: settings?.securityPolicy?.sessionTimeoutMinutes ?? 120,
    maxLoginAttempts: settings?.securityPolicy?.maxLoginAttempts ?? 5,
    lockoutDurationMinutes: settings?.securityPolicy?.lockoutDurationMinutes ?? 15
  });
  const [securitySaving, setSecuritySaving] = useState(false);

  useEffect(() => {
    if (settings) {
      setOrgData({
        name: settings.siteName || 'Masters Of All',
        tagline: settings.tagline || '',
        contactEmail: settings.contactEmail || '',
        organizationAddress: settings.organizationAddress || '',
        timezone: settings.timezone || 'UTC',
        primaryLanguage: settings.language || 'en-GB'
      });
      if (settings.securityPolicy) {
        setSecurityConfig({
          enforce2FAForAdmins: Boolean(settings.securityPolicy.enforce2FAForAdmins),
          minPasswordLength: Math.max(12, settings.securityPolicy.minPasswordLength ?? 12),
          requireUppercase: Boolean(settings.securityPolicy.requireUppercase),
          requireNumber: Boolean(settings.securityPolicy.requireNumber),
          requireSymbol: Boolean(settings.securityPolicy.requireSymbol),
          sessionTimeoutMinutes: settings.securityPolicy.sessionTimeoutMinutes ?? 120,
          maxLoginAttempts: settings.securityPolicy.maxLoginAttempts ?? 5,
          lockoutDurationMinutes: settings.securityPolicy.lockoutDurationMinutes ?? 15
        });
      }
    }
  }, [settings]);

  const orgDirty = useMemo(() => {
    const baseName = settings?.siteName || 'Masters Of All';
    const baseTagline = settings?.tagline || '';
    const baseEmail = settings?.contactEmail || '';
    const baseAddr = settings?.organizationAddress || '';
    const baseTz = settings?.timezone || 'UTC';
    const baseLang = settings?.language || 'en-GB';
    return (
      orgData.name !== baseName ||
      orgData.tagline !== baseTagline ||
      orgData.contactEmail !== baseEmail ||
      orgData.organizationAddress !== baseAddr ||
      orgData.timezone !== baseTz ||
      orgData.primaryLanguage !== baseLang
    );
  }, [orgData, settings]);

  const securityDirty = useMemo(() => {
    const baseEnforce = settings?.securityPolicy?.enforce2FAForAdmins ?? false;
    const baseMinLen = Math.max(12, settings?.securityPolicy?.minPasswordLength ?? 12);
    const baseUpper = settings?.securityPolicy?.requireUppercase ?? true;
    const baseNum = settings?.securityPolicy?.requireNumber ?? true;
    const baseSym = settings?.securityPolicy?.requireSymbol ?? true;
    const baseSession = settings?.securityPolicy?.sessionTimeoutMinutes ?? 120;
    const baseAttempts = settings?.securityPolicy?.maxLoginAttempts ?? 5;
    const baseLockout = settings?.securityPolicy?.lockoutDurationMinutes ?? 15;
    return (
      Boolean(securityConfig.enforce2FAForAdmins) !== Boolean(baseEnforce) ||
      Number(securityConfig.minPasswordLength) !== Number(baseMinLen) ||
      Boolean(securityConfig.requireUppercase) !== Boolean(baseUpper) ||
      Boolean(securityConfig.requireNumber) !== Boolean(baseNum) ||
      Boolean(securityConfig.requireSymbol) !== Boolean(baseSym) ||
      Number(securityConfig.sessionTimeoutMinutes) !== Number(baseSession) ||
      Number(securityConfig.maxLoginAttempts) !== Number(baseAttempts) ||
      Number(securityConfig.lockoutDurationMinutes) !== Number(baseLockout)
    );
  }, [securityConfig, settings]);

  // 2b. Personal Account Email & Password State
  const [credEmail, setCredEmail] = useState<string>(currentUser?.email || '');
  const [credCurrentPassword, setCredCurrentPassword] = useState('');
  const [credNewPassword, setCredNewPassword] = useState('');
  const [credConfirmPassword, setCredConfirmPassword] = useState('');
  const [credSaving, setCredSaving] = useState(false);
  const [credError, setCredError] = useState<string | null>(null);
  const [credSuccess, setCredSuccess] = useState<string | null>(null);

  const credDirty = useMemo(() => {
    if (!currentUser?.isFounder) return false;
    const normalizedNextEmail = credEmail.trim().toLowerCase();
    const currentNormalizedEmail = (currentUser?.email || '').trim().toLowerCase();
    return (
      normalizedNextEmail !== currentNormalizedEmail ||
      credCurrentPassword !== '' ||
      credNewPassword !== '' ||
      credConfirmPassword !== ''
    );
  }, [currentUser?.isFounder, currentUser?.email, credEmail, credCurrentPassword, credNewPassword, credConfirmPassword]);

  useEffect(() => {
    const hasUnsaved =
      (currentSubTab === 'organization' && orgDirty) ||
      (currentSubTab === 'security' && (securityDirty || credDirty));
    if (!hasUnsaved) return;
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', onBeforeUnload);
    return () => window.removeEventListener('beforeunload', onBeforeUnload);
  }, [currentSubTab, orgDirty, securityDirty, credDirty]);

  const handleDiscardOrg = () => {
    setBannerError(null);
    setOrgData({
      name: settings?.siteName || 'Masters Of All',
      tagline: settings?.tagline || '',
      contactEmail: settings?.contactEmail || '',
      organizationAddress: settings?.organizationAddress || '',
      timezone: settings?.timezone || 'UTC',
      primaryLanguage: settings?.language || 'en-GB'
    });
  };

  const handleDiscardSecurity = () => {
    setBannerError(null);
    setSecurityConfig({
      enforce2FAForAdmins: settings?.securityPolicy?.enforce2FAForAdmins ?? false,
      minPasswordLength: Math.max(12, settings?.securityPolicy?.minPasswordLength ?? 12),
      requireUppercase: settings?.securityPolicy?.requireUppercase ?? true,
      requireNumber: settings?.securityPolicy?.requireNumber ?? true,
      requireSymbol: settings?.securityPolicy?.requireSymbol ?? true,
      sessionTimeoutMinutes: settings?.securityPolicy?.sessionTimeoutMinutes ?? 120,
      maxLoginAttempts: settings?.securityPolicy?.maxLoginAttempts ?? 5,
      lockoutDurationMinutes: settings?.securityPolicy?.lockoutDurationMinutes ?? 15
    });
  };

  const handleDiscardCredentials = () => {
    setCredEmail(currentUser?.email || '');
    setCredCurrentPassword('');
    setCredNewPassword('');
    setCredConfirmPassword('');
    setCredError(null);
    setCredSuccess(null);
  };

  useEffect(() => {
    if (currentUser?.email) {
      setCredEmail(currentUser.email);
    }
  }, [currentUser?.email]);

  // 2c. Personal Account TOTP 2FA State
  const [totpEnabled, setTotpEnabled] = useState<boolean>(
    Boolean(currentUser?.twoFactorEnabled ?? api.getCurrentUser()?.twoFactorEnabled)
  );
  const [totpSetupData, setTotpSetupData] = useState<{
    secret: string;
    qrDataUrl: string;
    recoveryCodes: string[];
  } | null>(null);
  const [totpCode, setTotpCode] = useState('');
  const [totpLoading, setTotpLoading] = useState(false);
  const [totpError, setTotpError] = useState<string | null>(null);
  const [totpSuccess, setTotpSuccess] = useState<string | null>(null);
  const [showDisable2FA, setShowDisable2FA] = useState(false);
  const [disablePassword, setDisablePassword] = useState('');
  const [disableCode, setDisableCode] = useState('');

  useEffect(() => {
    if (typeof currentUser?.twoFactorEnabled === 'boolean') {
      setTotpEnabled(currentUser.twoFactorEnabled);
    }
  }, [currentUser?.twoFactorEnabled]);

  // 3. Read-Only Contact Inbox State
  const [submissions, setSubmissions] = useState<FormSubmission[]>([]);
  const [inboxUnreadCount, setInboxUnreadCount] = useState(0);
  const [inboxFilter, setInboxFilter] = useState<'all' | 'new' | 'read' | 'archived'>('all');
  const [inboxSearch, setInboxSearch] = useState('');
  const [inboxPage, setInboxPage] = useState(1);
  const [inboxTotalPages, setInboxTotalPages] = useState(1);
  const [inboxLoading, setInboxLoading] = useState(false);
  const [inboxError, setInboxError] = useState<string | null>(null);
  const [selectedSubmission, setSelectedSubmission] = useState<FormSubmission | null>(null);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [confirmDeleteSub, setConfirmDeleteSub] = useState<FormSubmission | null>(null);

  // 4. Backups State
  const [backupInProgress, setBackupInProgress] = useState(false);
  const [pendingImportPayload, setPendingImportPayload] = useState<{
    filename: string;
    file: File;
  } | null>(null);

  // 5. Audit & Security Log State
  const [auditView, setAuditView] = useState<'activity' | 'security'>('activity');
  const [auditLogs, setAuditLogs] = useState<ActivityRecord[]>([]);
  const [auditArea, setAuditArea] = useState<string>('all');
  const [auditSearch, setAuditSearch] = useState('');
  const [auditPage, setAuditPage] = useState(1);
  const [auditTotalPages, setAuditTotalPages] = useState(1);
  const [auditTotalItems, setAuditTotalItems] = useState(0);
  const [auditLoading, setAuditLoading] = useState(false);
  const [auditError, setAuditError] = useState<string | null>(null);
  const [securityLogs, setSecurityLogs] = useState<SecurityLogRecord[]>([]);
  const [securityLogsLoading, setSecurityLogsLoading] = useState(false);

  // 6. Site Health State
  const [healthItems, setHealthItems] = useState<SiteHealthItem[]>([]);
  const [healthLoading, setHealthLoading] = useState(false);
  const [healthError, setHealthError] = useState<string | null>(null);

  // 7. Trash State
  const [trashData, setTrashData] = useState<TrashItemsResponse>({
    departments: [],
    projects: [],
    publications: [],
    products: [],
    pages: []
  });
  const [trashLoading, setTrashLoading] = useState(false);
  const [trashError, setTrashError] = useState<string | null>(null);
  const [confirmDeleteTrashItem, setConfirmDeleteTrashItem] = useState<FlattenedTrashItem | null>(null);
  const [confirmEmptyTrash, setConfirmEmptyTrash] = useState(false);

  // Load real operational data
  const loadSubmissions = useCallback(async () => {
    if (!canViewInbox) return;
    setInboxLoading(true);
    setInboxError(null);
    try {
      const res = await api.getSubmissions({
        page: inboxPage,
        limit: 20,
        status: inboxFilter,
        q: inboxSearch.trim() || undefined
      });
      if (Array.isArray(res)) {
        setSubmissions(res);
        setInboxTotalPages(1);
        setInboxUnreadCount(res.filter(s => s.status === 'new').length);
      } else {
        setSubmissions(res.items || []);
        setInboxTotalPages(res.totalPages || 1);
        setInboxUnreadCount(res.unreadCount ?? 0);
      }
    } catch (err: unknown) {
      setInboxError(err instanceof Error ? err.message : 'Could not fetch contact inbox.');
    } finally {
      setInboxLoading(false);
    }
  }, [canViewInbox, inboxPage, inboxFilter, inboxSearch]);

  const loadAuditLogs = useCallback(async () => {
    if (!canViewAudit) return;
    setAuditLoading(true);
    setAuditError(null);
    try {
      const res = await api.getActivityLog({
        page: auditPage,
        limit: 25,
        area: auditArea,
        q: auditSearch.trim() || undefined
      });
      if (Array.isArray(res)) {
        setAuditLogs(res);
        setAuditTotalPages(1);
        setAuditTotalItems(res.length);
      } else {
        const items = res.items || [];
        setAuditLogs(items);
        setAuditTotalPages(res.totalPages || 1);
        setAuditTotalItems(typeof res.total === 'number' ? res.total : items.length);
      }
    } catch (err: unknown) {
      setAuditError(err instanceof Error ? err.message : 'Could not load activity log.');
    } finally {
      setAuditLoading(false);
    }
  }, [canViewAudit, auditPage, auditArea, auditSearch]);

  const loadSecurityLogs = useCallback(async () => {
    if (!canViewAudit) return;
    setSecurityLogsLoading(true);
    setAuditError(null);
    try {
      const list = await api.getSecurityLog();
      setSecurityLogs(list);
    } catch (err: unknown) {
      setAuditError(err instanceof Error ? err.message : 'Could not load security event log.');
    } finally {
      setSecurityLogsLoading(false);
    }
  }, [canViewAudit]);

  const loadHealth = useCallback(async () => {
    if (!canViewHealth) return;
    setHealthLoading(true);
    setHealthError(null);
    try {
      const list = await api.getSiteHealth();
      setHealthItems(list);
    } catch (err: unknown) {
      setHealthError(err instanceof Error ? err.message : 'Could not run site health check.');
    } finally {
      setHealthLoading(false);
    }
  }, [canViewHealth]);

  const loadTrash = useCallback(async () => {
    if (!canManageTrash) return;
    setTrashLoading(true);
    setTrashError(null);
    try {
      const data = await api.getTrashItems();
      setTrashData({
        departments: data.departments || [],
        projects: data.projects || [],
        publications: data.publications || [],
        products: data.products || [],
        pages: data.pages || []
      });
    } catch (err: unknown) {
      setTrashError(err instanceof Error ? err.message : 'Could not load Trash items.');
    } finally {
      setTrashLoading(false);
    }
  }, [canManageTrash]);

  useEffect(() => {
    if (canViewInbox) void loadSubmissions();
    if (canManageTrash) void loadTrash();
    if (canViewHealth) void loadHealth();
  }, [canViewInbox, canManageTrash, canViewHealth, loadSubmissions, loadTrash, loadHealth]);

  useEffect(() => {
    if (currentSubTab === 'audit') {
      if (auditView === 'activity') void loadAuditLogs();
      else void loadSecurityLogs();
    }
    if (currentSubTab === 'health') void loadHealth();
    if (currentSubTab === 'trash') void loadTrash();
    if (currentSubTab === 'inbox') void loadSubmissions();
  }, [currentSubTab, auditView, loadAuditLogs, loadSecurityLogs, loadHealth, loadTrash, loadSubmissions]);

  // 2FA Handlers
  const handleStart2FASetup = async () => {
    setTotpLoading(true);
    setTotpError(null);
    setTotpSuccess(null);
    try {
      const data = await api.setup2FA();
      const qrDataUrl = await QRCode.toDataURL(data.otpauthUri, { width: 192, margin: 1 });
      setTotpSetupData({
        secret: data.secret,
        qrDataUrl,
        recoveryCodes: data.recoveryCodes
      });
      setTotpCode('');
    } catch (err: unknown) {
      setTotpError(err instanceof Error ? err.message : 'Failed to initialize 2FA setup.');
    } finally {
      setTotpLoading(false);
    }
  };

  const handleVerify2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!totpCode.trim()) return;
    setTotpLoading(true);
    setTotpError(null);
    try {
      const res = await api.verify2FA(totpCode.trim());
      setTotpEnabled(Boolean(res.twoFactorEnabled));
      if (res.user && onUserUpdated) onUserUpdated(res.user);
      setTotpSetupData(null);
      setTotpCode('');
      setTotpSuccess('Two-factor authentication is now enabled on your account.');
    } catch (err: unknown) {
      setTotpError(err instanceof Error ? err.message : 'Invalid verification code.');
    } finally {
      setTotpLoading(false);
    }
  };

  const handleDisable2FA = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!disablePassword || !disableCode.trim()) {
      setTotpError('Password and current 2FA or recovery code are required.');
      return;
    }
    setTotpLoading(true);
    setTotpError(null);
    try {
      const res = await api.disable2FA(disablePassword, disableCode.trim());
      setTotpEnabled(Boolean(res.twoFactorEnabled));
      if (res.user && onUserUpdated) onUserUpdated(res.user);
      setShowDisable2FA(false);
      setDisablePassword('');
      setDisableCode('');
      setTotpSuccess('Two-factor authentication has been disabled.');
    } catch (err: unknown) {
      setTotpError(err instanceof Error ? err.message : 'Could not disable 2FA.');
    } finally {
      setTotpLoading(false);
    }
  };

  // Account Email & Password Update Handler
  const saveCredentials = async (): Promise<boolean> => {
    setCredError(null);
    setCredSuccess(null);

    const normalizedNextEmail = credEmail.trim().toLowerCase();
    const currentNormalizedEmail = (currentUser?.email || '').trim().toLowerCase();
    const emailChanged = Boolean(normalizedNextEmail && normalizedNextEmail !== currentNormalizedEmail);
    const passwordChanged = Boolean(credNewPassword);

    if (!credCurrentPassword) {
      setCredError('Enter your current password to confirm credential changes.');
      return false;
    }

    if (!emailChanged && !passwordChanged) {
      setCredError('Change your email address or enter a new password before saving.');
      return false;
    }

    if (passwordChanged && credNewPassword !== credConfirmPassword) {
      setCredError('New password and confirmation do not match.');
      return false;
    }

    setCredSaving(true);
    try {
      const res = await api.updateCredentials({
        currentPassword: credCurrentPassword,
        newEmail: emailChanged ? normalizedNextEmail : undefined,
        newPassword: passwordChanged ? credNewPassword : undefined
      });
      if (res.user && onUserUpdated) {
        onUserUpdated(res.user);
      }
      setCredCurrentPassword('');
      setCredNewPassword('');
      setCredConfirmPassword('');
      setCredSuccess(res.message || 'Account credentials updated.');
      showSuccess(res.message || 'Account credentials updated.');
      return true;
    } catch (err: unknown) {
      setCredError(err instanceof Error ? err.message : 'Could not update credentials.');
      return false;
    } finally {
      setCredSaving(false);
    }
  };

  const handleUpdateCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    await saveCredentials();
  };

  // Organization Save
  const saveOrg = async () => {
    setBannerError(null);

    setOrgSaving(true);
    try {
      const updatedSettings: Partial<SiteSettings> = {
        siteName: orgData.name.trim(),
        tagline: orgData.tagline.trim(),
        contactEmail: orgData.contactEmail.trim(),
        organizationAddress: orgData.organizationAddress.trim(),
        language: orgData.primaryLanguage.trim() || 'en-GB',
        timezone: orgData.timezone.trim() || 'UTC'
      };

      if (onUpdateSettings) {
        await onUpdateSettings(updatedSettings);
      } else {
        await api.updateSettings(updatedSettings);
      }
      if (onRefreshData) await onRefreshData();
      showSuccess('Organization profile saved.');
    } catch (err: unknown) {
      setBannerError(err instanceof Error ? err.message : 'Failed to save organization settings.');
    } finally {
      setOrgSaving(false);
    }
  };

  const handleSaveOrg = async (e: React.FormEvent) => {
    e.preventDefault();
    await saveOrg();
  };

  // Security Policy Save
  const saveSecurity = async () => {
    setSecuritySaving(true);
    setBannerError(null);
    try {
      const updatedSettings: Partial<SiteSettings> = {
        securityPolicy: {
          minPasswordLength: Math.max(12, Number(securityConfig.minPasswordLength)),
          requireUppercase: Boolean(securityConfig.requireUppercase),
          requireNumber: Boolean(securityConfig.requireNumber),
          requireSymbol: Boolean(securityConfig.requireSymbol),
          sessionTimeoutMinutes: Number(securityConfig.sessionTimeoutMinutes),
          enforce2FAForAdmins: Boolean(securityConfig.enforce2FAForAdmins),
          maxLoginAttempts: Number(securityConfig.maxLoginAttempts),
          lockoutDurationMinutes: Number(securityConfig.lockoutDurationMinutes)
        }
      };

      if (onUpdateSettings) {
        await onUpdateSettings(updatedSettings);
      } else {
        await api.updateSettings(updatedSettings);
      }
      if (onRefreshData) await onRefreshData();
      showSuccess('Security and authentication policy saved.');
    } catch (err: unknown) {
      setBannerError(err instanceof Error ? err.message : 'Failed to save security configuration.');
    } finally {
      setSecuritySaving(false);
    }
  };

  const handleSaveSecurity = async (e: React.FormEvent) => {
    e.preventDefault();
    await saveSecurity();
  };

  // Backups (SQLite Snapshots)
  const triggerBlobDownload = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadBackup = async () => {
    setBackupInProgress(true);
    setBannerError(null);
    try {
      const snapshotBlob = await api.exportEverything();
      triggerBlobDownload(snapshotBlob, `moa_backup_${new Date().toISOString().split('T')[0]}.sqlite`);
      showSuccess('SQLite database snapshot exported from server.');
    } catch (err: unknown) {
      setBannerError(err instanceof Error ? err.message : 'Failed to export SQLite database snapshot.');
    } finally {
      setBackupInProgress(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setBannerError(null);

    try {
      if (file.size < 100) {
        setBannerError('Invalid snapshot: only valid SQLite database snapshots (.sqlite) are accepted.');
        return;
      }
      const headerBuf = await file.slice(0, 16).arrayBuffer();
      const header = new TextDecoder().decode(headerBuf);
      if (header !== 'SQLite format 3\0') {
        setBannerError('Only valid SQLite database snapshots (.sqlite / .db) are accepted for restore.');
        return;
      }
      setPendingImportPayload({ filename: file.name, file });
    } catch {
      setBannerError('Unable to read the selected SQLite snapshot file.');
    }
  };

  // Read-Only Inbox Status Updates
  const handleUpdateSubmissionStatus = async (sub: FormSubmission, status: FormSubmission['status']) => {
    setBannerError(null);
    try {
      const updated = await api.updateSubmission(sub.id, { status });
      setSubmissions(prev => prev.map(s => (s.id === sub.id ? updated : s)));
      if (selectedSubmission?.id === sub.id) {
        setSelectedSubmission(updated);
      }
      await loadSubmissions();
      if (onRefreshData) await onRefreshData();
      showSuccess(`Inquiry marked as ${status}.`);
    } catch (err: unknown) {
      setBannerError(err instanceof Error ? err.message : 'Failed to update inquiry status.');
    }
  };

  const handleSelectSubmission = (sub: FormSubmission) => {
    setSelectedSubmission(sub);
    setCopiedEmail(false);
    if (sub.status === 'new') {
      void handleUpdateSubmissionStatus(sub, 'read');
    }
  };

  const handleCopySenderEmail = async (email: string) => {
    try {
      await navigator.clipboard.writeText(email);
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2000);
    } catch {
      setBannerError('Could not copy email address to clipboard.');
    }
  };

  // Trash Flattening & Actions
  const flattenedTrash: FlattenedTrashItem[] = useMemo(() => {
    const calcRemaining = (deletedAt?: string) => {
      if (!deletedAt) return '30 days left';
      const elapsedDays = Math.floor((Date.now() - new Date(deletedAt).getTime()) / (1000 * 60 * 60 * 24));
      const remaining = Math.max(0, 30 - elapsedDays);
      return `${remaining} day${remaining === 1 ? '' : 's'} left`;
    };

    return [
      ...(trashData.departments || []).map(d => ({
        id: d.id,
        entityType: 'department' as const,
        labelType: 'Department' as const,
        title: d.name,
        deletedAt: d.deletedAt || '',
        daysLeftLabel: calcRemaining(d.deletedAt)
      })),
      ...(trashData.projects || []).map(p => ({
        id: p.id,
        entityType: 'project' as const,
        labelType: 'Project' as const,
        title: p.title,
        deletedAt: p.deletedAt || '',
        daysLeftLabel: calcRemaining(p.deletedAt)
      })),
      ...(trashData.publications || []).map(pub => ({
        id: pub.id,
        entityType: 'publication' as const,
        labelType: 'Publication' as const,
        title: pub.title,
        deletedAt: pub.deletedAt || '',
        daysLeftLabel: calcRemaining(pub.deletedAt)
      })),
      ...(trashData.products || []).map(prod => ({
        id: prod.id,
        entityType: 'product' as const,
        labelType: 'Product' as const,
        title: prod.name,
        deletedAt: prod.deletedAt || '',
        daysLeftLabel: calcRemaining(prod.deletedAt)
      })),
      ...(trashData.pages || []).map(pg => ({
        id: pg.id,
        entityType: 'page' as const,
        labelType: 'Page' as const,
        title: pg.title,
        deletedAt: pg.deletedAt || '',
        daysLeftLabel: calcRemaining(pg.deletedAt)
      })),
      ...(trashData.media || []).map(m => ({
        id: m.id,
        entityType: 'media' as const,
        labelType: 'Media' as const,
        title: m.name,
        deletedAt: m.deletedAt || '',
        daysLeftLabel: calcRemaining(m.deletedAt)
      })),
      ...(trashData.submissions || []).map(s => ({
        id: s.id,
        entityType: 'submission' as const,
        labelType: 'Submission' as const,
        title: `${s.name} — ${s.subject || s.email}`,
        deletedAt: s.deletedAt || '',
        daysLeftLabel: calcRemaining(s.deletedAt)
      }))
    ];
  }, [trashData]);

  const handleRestoreTrash = useCallback(
    async (item: FlattenedTrashItem) => {
      setBannerError(null);
      try {
        await api.restoreTrashItem(item.entityType, item.id);
        await loadTrash();
        if (onRefreshData) await onRefreshData();
        showSuccess(`Restored ${item.labelType.toLowerCase()} "${item.title}" to workspace.`);
      } catch (err: unknown) {
        setBannerError(err instanceof Error ? err.message : 'Failed to restore item from Trash.');
      }
    },
    [loadTrash, onRefreshData]
  );

  const handleExportActivityCsv = () => {
    const header = 'Timestamp,ActorEmail,Area,Action,Target,Details';
    const rows = auditLogs.map(l =>
      [
        escapeCsvCell(l.timestamp),
        escapeCsvCell(l.userEmail),
        escapeCsvCell(l.area),
        escapeCsvCell(l.action),
        escapeCsvCell(l.target),
        escapeCsvCell(l.details || '')
      ].join(',')
    );
    const csv = [header, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit_log_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const healthScore = Math.max(0, 100 - healthItems.length * 10);

  const settingsTabs: PortalTabItem<SettingsSubTab>[] = useMemo(() => {
    const counts: Partial<Record<SettingsSubTab, number>> = {
      inbox: inboxUnreadCount,
      health: healthItems.length,
      trash: flattenedTrash.length
    };
    return visibleSubTabs.map(tabDef => {
      const key = tabDef.id as SettingsSubTab;
      const count = counts[key];
      return {
        id: key,
        label: tabDef.label,
        icon: SUBTAB_ICONS[key] || Building2,
        badge: typeof count === 'number' && count > 0 ? count : undefined
      };
    });
  }, [visibleSubTabs, inboxUnreadCount, healthItems.length, flattenedTrash.length]);

  const auditViewTabs: PortalTabItem<'activity' | 'security'>[] = useMemo(
    () => [
      { id: 'activity', label: 'Activity Log', icon: History },
      { id: 'security', label: 'Security Events', icon: Shield }
    ],
    []
  );

  const activityColumns: PortalTableColumn<ActivityRecord>[] = useMemo(
    () => [
      {
        key: 'timestamp',
        header: 'Timestamp',
        render: log => (
          <span className="font-mono text-[11px] text-[#EDE9E0]/65 whitespace-nowrap tabular-nums">
            {new Date(log.timestamp).toLocaleString()}
          </span>
        )
      },
      {
        key: 'operator',
        header: 'Operator',
        render: log => (
          <span className="font-mono text-[11px] text-[#EDE9E0]">{log.userEmail}</span>
        )
      },
      {
        key: 'area',
        header: 'Area',
        render: log => (
          <PortalStatusBadge
            status="Draft"
            labelOverride={log.area}
            showDot={false}
          />
        )
      },
      {
        key: 'action',
        header: 'Event Description',
        render: log => <span className="text-[#25CDB6] font-medium">{log.action}</span>
      },
      {
        key: 'target',
        header: 'Target Entity',
        align: 'right',
        hideOnMobile: true,
        render: log => (
          <span className="font-mono text-[11px] text-[#EDE9E0]/70">{log.target}</span>
        )
      }
    ],
    []
  );

  const securityColumns: PortalTableColumn<SecurityLogRecord>[] = useMemo(
    () => [
      {
        key: 'timestamp',
        header: 'Timestamp',
        render: log => (
          <span className="font-mono text-[11px] text-[#EDE9E0]/65 whitespace-nowrap tabular-nums">
            {new Date(log.timestamp).toLocaleString()}
          </span>
        )
      },
      {
        key: 'event',
        header: 'Security Event',
        render: log => (
          <span className="text-[#25CDB6] font-mono text-[11px] font-semibold">{log.event}</span>
        )
      },
      {
        key: 'email',
        header: 'Account Email',
        render: log => <span className="font-mono text-[11px] text-[#EDE9E0]">{log.email}</span>
      },
      {
        key: 'ip',
        header: 'IP Address',
        align: 'right',
        render: log => (
          <span className="font-mono text-[11px] text-[#EDE9E0]/65 tabular-nums">{log.ip}</span>
        )
      }
    ],
    []
  );

  const trashColumns: PortalTableColumn<FlattenedTrashItem>[] = useMemo(
    () => [
      {
        key: 'title',
        header: 'Item Name',
        render: item => <span className="font-bold text-[#EDE9E0]">{item.title}</span>
      },
      {
        key: 'type',
        header: 'Entity Type',
        render: item => (
          <PortalStatusBadge
            status="Published"
            labelOverride={item.labelType}
            showDot={false}
          />
        )
      },
      {
        key: 'deletedAt',
        header: 'Deleted At',
        hideOnMobile: true,
        render: item => (
          <span className="font-mono text-[11px] text-[#EDE9E0]/65 tabular-nums whitespace-nowrap">
            {item.deletedAt ? new Date(item.deletedAt).toLocaleString() : 'Unknown'}
          </span>
        )
      },
      {
        key: 'retention',
        header: 'Retention Window',
        render: item => (
          <span className="font-mono text-[11px] text-amber-300 tabular-nums whitespace-nowrap">
            {item.daysLeftLabel}
          </span>
        )
      },
      {
        key: 'actions',
        header: 'Actions',
        align: 'right',
        render: item => (
          <div className="inline-flex items-center gap-2">
            <button
              type="button"
              onClick={() => void handleRestoreTrash(item)}
              className="h-8 px-3 bg-[#17A491]/15 hover:bg-[#17A491] text-[#25CDB6] hover:text-[#06302F] border border-[#25CDB6]/25 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Restore</span>
            </button>
            <DeleteButton
              onClick={() => setConfirmDeleteTrashItem(item)}
              label="Delete Permanently"
              title="Delete item permanently"
            />
          </div>
        )
      }
    ],
    [handleRestoreTrash]
  );

  const isCurrentTabAllowed = visibleSubTabs.some(st => st.id === currentSubTab);

  return (
    <div className="space-y-6">
      <PortalPageHeader
        title="System Settings & Foundation"
        subtitle="Configure organization details, security policy, and workspace diagnostics."
      />

      {bannerError && (
        <div className="p-3.5 rounded-2xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{bannerError}</span>
          </div>
          <button type="button" onClick={() => setBannerError(null)} className="text-red-300 hover:text-white font-semibold cursor-pointer">
            Dismiss
          </button>
        </div>
      )}

      {bannerSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
          <Check className="w-4 h-4 shrink-0" />
          <span>{bannerSuccess}</span>
        </div>
      )}

      <PortalTabs
        items={settingsTabs}
        activeId={currentSubTab}
        onChange={onSubTabChange}
        ariaLabel="Settings sections"
      />

      {!isCurrentTabAllowed && (
        <PortalEmptyState
          icon={Lock}
          title="Access Restricted"
          description="Your current role does not grant access to this settings panel. You can still configure your personal two-factor authentication in Security & Auth."
          action={
            <button
              type="button"
              onClick={() => onSubTabChange('security')}
              className="h-9 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] text-xs font-bold cursor-pointer transition-all shadow-md"
            >
              Go to Security &amp; Auth
            </button>
          }
        />
      )}

      {/* ===================================================================
          1. SUB-TAB: ORGANIZATION PROFILE
          =================================================================== */}
      {canManageSettings && currentSubTab === 'organization' && (
        <form onSubmit={handleSaveOrg} className={`space-y-6 ${orgDirty ? 'pb-24' : ''}`}>
          <PortalSection
            title="Organization Profile"
            description="Public identity, language/timezone preferences, and contact coordinates."
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">Public Name</label>
                <input
                  type="text"
                  value={orgData.name}
                  onChange={e => setOrgData({ ...orgData, name: e.target.value })}
                  className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                />
              </div>

              <div>
                <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">Official Tagline</label>
                <input
                  type="text"
                  value={orgData.tagline}
                  onChange={e => setOrgData({ ...orgData, tagline: e.target.value })}
                  className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                />
              </div>

              <div>
                <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">Primary Contact Email</label>
                <input
                  type="email"
                  value={orgData.contactEmail}
                  onChange={e => setOrgData({ ...orgData, contactEmail: e.target.value })}
                  className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                />
              </div>

              <div>
                <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">Address (optional)</label>
                <input
                  type="text"
                  value={orgData.organizationAddress}
                  onChange={e => setOrgData({ ...orgData, organizationAddress: e.target.value })}
                  placeholder="Leave blank if hidden from public Contact & Footer"
                  className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] placeholder-[#EDE9E0]/35 focus:outline-none focus:border-[#25CDB6]"
                />
              </div>

              <div>
                <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">Primary Language</label>
                <input
                  type="text"
                  value={orgData.primaryLanguage}
                  onChange={e => setOrgData({ ...orgData, primaryLanguage: e.target.value })}
                  placeholder="en-GB"
                  className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 font-mono text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                />
              </div>

              <div>
                <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">Timezone</label>
                <input
                  type="text"
                  value={orgData.timezone}
                  onChange={e => setOrgData({ ...orgData, timezone: e.target.value })}
                  placeholder="UTC"
                  className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 font-mono text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                />
              </div>
            </div>
          </PortalSection>
        </form>
      )}

      {/* ===================================================================
          2. SUB-TAB: SECURITY & AUTH
          =================================================================== */}
      {currentSubTab === 'security' && (
        <div className={`space-y-6 ${securityDirty || credDirty ? 'pb-24' : ''}`}>
          {canManageSettings && (
            <form onSubmit={handleSaveSecurity}>
              <PortalSection
                title="Access & Security Policy"
                description="Authentication parameters enforced by the server: password policy, session timeout, and login lockout thresholds."
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-4 p-4 bg-[#06302F] border border-white/10 rounded-xl">
                    <div>
                      <span className="text-xs font-bold text-[#EDE9E0] block">
                        Enforce Two-Factor Authentication (2FA)
                      </span>
                      <span className="text-[11px] text-[#EDE9E0]/60 block mt-0.5">
                        Require TOTP authentication for administrative accounts before Control Room access (enforced globally in production).
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={securityConfig.enforce2FAForAdmins}
                      onChange={e => setSecurityConfig({ ...securityConfig, enforce2FAForAdmins: e.target.checked })}
                      className="w-4 h-4 accent-[#25CDB6] cursor-pointer shrink-0"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <label className="flex items-center justify-between p-3.5 bg-[#06302F] border border-white/10 rounded-xl cursor-pointer">
                      <span className="font-semibold text-[#EDE9E0]">Require Uppercase (A-Z)</span>
                      <input
                        type="checkbox"
                        checked={securityConfig.requireUppercase}
                        onChange={e => setSecurityConfig({ ...securityConfig, requireUppercase: e.target.checked })}
                        className="w-4 h-4 accent-[#25CDB6]"
                      />
                    </label>
                    <label className="flex items-center justify-between p-3.5 bg-[#06302F] border border-white/10 rounded-xl cursor-pointer">
                      <span className="font-semibold text-[#EDE9E0]">Require Number (0-9)</span>
                      <input
                        type="checkbox"
                        checked={securityConfig.requireNumber}
                        onChange={e => setSecurityConfig({ ...securityConfig, requireNumber: e.target.checked })}
                        className="w-4 h-4 accent-[#25CDB6]"
                      />
                    </label>
                    <label className="flex items-center justify-between p-3.5 bg-[#06302F] border border-white/10 rounded-xl cursor-pointer">
                      <span className="font-semibold text-[#EDE9E0]">Require Symbol (!@#...)</span>
                      <input
                        type="checkbox"
                        checked={securityConfig.requireSymbol}
                        onChange={e => setSecurityConfig({ ...securityConfig, requireSymbol: e.target.checked })}
                        className="w-4 h-4 accent-[#25CDB6]"
                      />
                    </label>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">
                        Minimum Password Length (12–64)
                      </label>
                      <input
                        type="number"
                        min={12}
                        max={64}
                        value={securityConfig.minPasswordLength}
                        onChange={e => setSecurityConfig({ ...securityConfig, minPasswordLength: Number(e.target.value) })}
                        className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] tabular-nums focus:outline-none focus:border-[#25CDB6]"
                      />
                    </div>

                    <div>
                      <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">
                        Session Timeout (Minutes)
                      </label>
                      <input
                        type="number"
                        min={15}
                        max={1440}
                        value={securityConfig.sessionTimeoutMinutes}
                        onChange={e => setSecurityConfig({ ...securityConfig, sessionTimeoutMinutes: Number(e.target.value) })}
                        className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] tabular-nums focus:outline-none focus:border-[#25CDB6]"
                      />
                    </div>

                    <div>
                      <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">
                        Max Failed Login Attempts
                      </label>
                      <input
                        type="number"
                        min={3}
                        max={20}
                        value={securityConfig.maxLoginAttempts}
                        onChange={e => setSecurityConfig({ ...securityConfig, maxLoginAttempts: Number(e.target.value) })}
                        className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] tabular-nums focus:outline-none focus:border-[#25CDB6]"
                      />
                    </div>

                    <div>
                      <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">
                        Lockout Duration (Minutes)
                      </label>
                      <input
                        type="number"
                        min={1}
                        max={120}
                        value={securityConfig.lockoutDurationMinutes}
                        onChange={e => setSecurityConfig({ ...securityConfig, lockoutDurationMinutes: Number(e.target.value) })}
                        className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] tabular-nums focus:outline-none focus:border-[#25CDB6]"
                      />
                    </div>
                  </div>
                </div>
              </PortalSection>
            </form>
          )}

          {/* Founder-Only Account Email & Password (SQLite-Persisted) */}
          {Boolean(currentUser?.isFounder) && (
            <form onSubmit={handleUpdateCredentials}>
              <PortalSection
                title="Founder Account Email & Password"
                description="Update your founder sign-in email or password. Changes persist in SQLite across restarts. To update another user's credentials, open their profile in Team."
                badge={
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-mono font-semibold bg-[#17A491]/15 border border-[#25CDB6]/25 text-[#25CDB6] break-all">
                    <KeyRound className="w-3 h-3 shrink-0" />
                    <span>{currentUser.email}</span>
                  </span>
                }
              >
                <div className="space-y-4">
                  {credError && (
                    <div className="p-3.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-start gap-2.5">
                      <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                      <span>{credError}</span>
                    </div>
                  )}

                  {credSuccess && (
                    <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                      <Check className="w-4 h-4 shrink-0" />
                      <span>{credSuccess}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">Sign-In Email Address</label>
                      <input
                        type="email"
                        required
                        value={credEmail}
                        onChange={e => setCredEmail(e.target.value)}
                        placeholder="admin@mastersofall.org"
                        className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                      />
                    </div>

                    <div>
                      <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">Current Password (Required)</label>
                      <input
                        type="password"
                        required
                        value={credCurrentPassword}
                        onChange={e => setCredCurrentPassword(e.target.value)}
                        placeholder="Enter current password to confirm"
                        className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] placeholder-[#EDE9E0]/35 focus:outline-none focus:border-[#25CDB6]"
                      />
                    </div>

                    <div>
                      <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">
                        New Password (optional — leave blank to keep current)
                      </label>
                      <input
                        type="password"
                        value={credNewPassword}
                        onChange={e => setCredNewPassword(e.target.value)}
                        placeholder={`Minimum ${securityConfig.minPasswordLength} characters`}
                        className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] placeholder-[#EDE9E0]/35 focus:outline-none focus:border-[#25CDB6]"
                      />
                    </div>

                    <div>
                      <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">Confirm New Password</label>
                      <input
                        type="password"
                        value={credConfirmPassword}
                        onChange={e => setCredConfirmPassword(e.target.value)}
                        placeholder="Re-enter new password"
                        className="w-full h-9 bg-[#06302F] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] placeholder-[#EDE9E0]/35 focus:outline-none focus:border-[#25CDB6]"
                      />
                    </div>
                  </div>

                  <div className="pt-3 border-t border-white/10">
                    <span className="text-[11px] text-[#EDE9E0]/55">
                      Requires at least {securityConfig.minPasswordLength} characters
                      {securityConfig.requireUppercase ? ', uppercase' : ''}
                      {securityConfig.requireNumber ? ', number' : ''}
                      {securityConfig.requireSymbol ? ', symbol' : ''}.
                    </span>
                  </div>
                </div>
              </PortalSection>
            </form>
          )}

          {/* Personal Account TOTP Two-Factor Authentication */}
          <PortalSection
            title="My Account Two-Factor Authentication (TOTP)"
            description="Protect your Control Room sign-in with an RFC 6238 authenticator app and single-use recovery codes."
            badge={
              <PortalStatusBadge
                status={totpEnabled ? 'Published' : 'In review'}
                labelOverride={totpEnabled ? '2FA Enabled' : '2FA Not Enrolled'}
              />
            }
          >
            <div className="space-y-4">
              {totpError && (
                <div className="p-3.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <span>{totpError}</span>
                </div>
              )}

              {totpSuccess && (
                <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 shrink-0" />
                  <span>{totpSuccess}</span>
                </div>
              )}

              {!totpEnabled && !totpSetupData && (
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl bg-[#06302F] border border-white/10">
                  <div className="text-xs text-[#EDE9E0]/80 space-y-1">
                    <p className="font-bold text-[#EDE9E0] flex items-center gap-1.5">
                      <Shield className="w-3.5 h-3.5 text-[#25CDB6]" />
                      <span>Authenticator App Enrollment</span>
                    </p>
                    <p className="text-[#EDE9E0]/60">
                      Generate a secret QR code compatible with Google Authenticator, 1Password, or Authy.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={handleStart2FASetup}
                    disabled={totpLoading}
                    className="h-9 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] text-xs font-bold transition-all shadow-md inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>{totpLoading ? 'Initializing...' : 'Set Up 2FA'}</span>
                  </button>
                </div>
              )}

              {!totpEnabled && totpSetupData && (
                <form onSubmit={handleVerify2FA} className="space-y-4 p-4 rounded-xl bg-[#06302F] border border-[#25CDB6]/30">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-center">
                    <div className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#031D1C] border border-white/10">
                      <img
                        src={totpSetupData.qrDataUrl}
                        alt="TOTP Authenticator QR Code"
                        className="w-40 h-40 rounded-lg bg-white p-2"
                      />
                      <span className="text-[10px] uppercase tracking-wider text-[#EDE9E0]/50">Manual Base32 Key</span>
                      <code className="text-xs font-mono text-[#25CDB6] break-all select-all text-center">
                        {totpSetupData.secret}
                      </code>
                    </div>

                    <div className="space-y-3 text-xs">
                      <div className="p-3.5 rounded-xl bg-[#031D1C] border border-amber-500/30 space-y-2">
                        <span className="text-[10px] uppercase tracking-wider text-amber-300 font-bold block">
                          Single-Use Recovery Codes (save securely)
                        </span>
                        <div className="grid grid-cols-2 gap-1.5 font-mono text-[11px] text-[#EDE9E0]/90 select-all">
                          {totpSetupData.recoveryCodes.map(rc => (
                            <span key={rc}>{rc}</span>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">
                          Enter 6-digit verification code from your app
                        </label>
                        <input
                          type="text"
                          inputMode="numeric"
                          maxLength={6}
                          value={totpCode}
                          onChange={e => setTotpCode(e.target.value)}
                          required
                          placeholder="123456"
                          className="w-full h-9 bg-[#031D1C] border border-white/12 rounded-xl px-3.5 text-sm font-mono tracking-widest text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                        />
                      </div>

                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="submit"
                          disabled={totpLoading}
                          className="h-9 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] font-bold text-xs cursor-pointer disabled:opacity-50"
                        >
                          {totpLoading ? 'Verifying...' : 'Verify & Enable 2FA'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setTotpSetupData(null);
                            setTotpCode('');
                            setTotpError(null);
                          }}
                          className="h-9 px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-bold text-[#EDE9E0]/75 hover:text-white cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
              )}

              {totpEnabled && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-xl bg-[#06302F] border border-emerald-500/20">
                    <div className="text-xs">
                      <p className="font-bold text-[#EDE9E0]">Authenticator App Active</p>
                      <p className="text-[#EDE9E0]/60 mt-0.5">
                        Every sign-in requires a time-based 6-digit code or an unused recovery code.
                      </p>
                    </div>
                    {!showDisable2FA && (
                      <button
                        type="button"
                        onClick={() => {
                          setShowDisable2FA(true);
                          setTotpError(null);
                        }}
                        className={`${DESTRUCTIVE_LABEL_BTN_CLASS} self-start sm:self-auto`}
                      >
                        Disable 2FA
                      </button>
                    )}
                  </div>

                  {showDisable2FA && (
                    <form onSubmit={handleDisable2FA} className="p-4 rounded-xl bg-[#06302F] border border-red-500/30 space-y-3 text-xs">
                      <p className="font-bold text-red-300">Confirm Identity to Disable 2FA</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">Current Password</label>
                          <input
                            type="password"
                            value={disablePassword}
                            onChange={e => setDisablePassword(e.target.value)}
                            required
                            className="w-full h-9 bg-[#031D1C] border border-white/12 rounded-xl px-3.5 text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                          />
                        </div>
                        <div>
                          <label className="text-[#EDE9E0]/75 block mb-1.5 font-semibold">
                            6-Digit TOTP or Recovery Code
                          </label>
                          <input
                            type="text"
                            value={disableCode}
                            onChange={e => setDisableCode(e.target.value)}
                            required
                            placeholder="123456"
                            className="w-full h-9 bg-[#031D1C] border border-white/12 rounded-xl px-3.5 font-mono text-[#EDE9E0] focus:outline-none focus:border-[#25CDB6]"
                          />
                        </div>
                      </div>
                      <div className="flex items-center gap-2 pt-1">
                        <button
                          type="submit"
                          disabled={totpLoading}
                          className={DESTRUCTIVE_LABEL_BTN_CLASS}
                        >
                          {totpLoading ? 'Disabling...' : 'Confirm Disable 2FA'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setShowDisable2FA(false);
                            setDisablePassword('');
                            setDisableCode('');
                            setTotpError(null);
                          }}
                          className="h-9 px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-bold text-[#EDE9E0]/75 hover:text-white cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}
            </div>
          </PortalSection>
        </div>
      )}

      {/* ===================================================================
          3. SUB-TAB: INBOX (READ-ONLY CONTACT SUBMISSIONS)
          =================================================================== */}
      {canViewInbox && currentSubTab === 'inbox' && (
        <div className="space-y-4">
          <PortalFilterBar
            search={inboxSearch}
            onSearchChange={val => {
              setInboxSearch(val);
              setInboxPage(1);
            }}
            searchPlaceholder="Search contact submissions..."
            filters={[
              {
                id: 'inbox-status',
                label: 'Filter by inquiry status',
                value: inboxFilter,
                onChange: val => {
                  setInboxFilter(val as 'all' | 'new' | 'read' | 'archived');
                  setInboxPage(1);
                },
                options: [
                  { value: 'all', label: 'All inquiries' },
                  { value: 'new', label: 'New' },
                  { value: 'read', label: 'Read' },
                  { value: 'archived', label: 'Archived' }
                ]
              }
            ]}
            hasActiveFilters={Boolean(inboxSearch.trim()) || inboxFilter !== 'all'}
            onResetFilters={() => {
              setInboxSearch('');
              setInboxFilter('all');
              setInboxPage(1);
            }}
            rightSlot={
              <button
                type="button"
                onClick={() => void loadSubmissions()}
                className="h-9 px-3.5 rounded-xl bg-[#06302F] hover:bg-white/10 border border-white/12 text-[#EDE9E0]/85 hover:text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                aria-label="Refresh inbox"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${inboxLoading ? 'animate-spin' : ''}`} />
                <span>Refresh</span>
              </button>
            }
          />

          {inboxError && (
            <div className="p-3.5 rounded-2xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center justify-between gap-2">
              <span>{inboxError}</span>
              <button
                type="button"
                onClick={() => void loadSubmissions()}
                className="h-8 px-3 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-white font-bold cursor-pointer"
              >
                Retry
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
            {/* List Column */}
            <div className="lg:col-span-5 bg-[#031D1C] border border-white/10 rounded-2xl overflow-hidden flex flex-col justify-between shadow-lg">
              <div className="divide-y divide-white/5 max-h-[620px] overflow-y-auto no-scrollbar">
                {inboxLoading ? (
                  <div className="p-8 text-center text-xs text-[#EDE9E0]/55">Loading submissions...</div>
                ) : submissions.length === 0 ? (
                  <div className="p-4">
                    <PortalEmptyState
                      icon={Inbox}
                      title="No matching inquiries"
                      description="No contact submissions match your current search or filter."
                      className="border-none bg-transparent py-8"
                    />
                  </div>
                ) : (
                  submissions.map(sub => {
                    const dateLabel = new Date(sub.createdAt || sub.submittedAt || Date.now()).toLocaleDateString();
                    const badgeMeta = mapSubmissionStatusToBadge(sub.status);
                    return (
                      <button
                        key={sub.id}
                        type="button"
                        onClick={() => handleSelectSubmission(sub)}
                        className={`w-full text-left p-4 cursor-pointer transition block ${
                          selectedSubmission?.id === sub.id
                            ? 'bg-[#17A491]/15 ring-1 ring-inset ring-[#25CDB6]/40'
                            : 'hover:bg-white/[0.03]'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className="font-bold text-xs text-[#EDE9E0] truncate">{sub.name}</span>
                          <div className="flex items-center gap-2 shrink-0">
                            <PortalStatusBadge status={badgeMeta.variant} labelOverride={badgeMeta.label} />
                            <span className="text-[10px] text-[#EDE9E0]/45 font-mono tabular-nums">
                              {dateLabel}
                            </span>
                          </div>
                        </div>
                        <span className="text-[11px] text-[#25CDB6] font-mono block truncate">{sub.email}</span>
                        {sub.subject && (
                          <span className="text-[11px] text-[#EDE9E0]/85 font-semibold block truncate mt-0.5">
                            {sub.subject}
                          </span>
                        )}
                        <p className="text-xs text-[#EDE9E0]/60 line-clamp-2 mt-1 leading-relaxed">
                          {sub.message}
                        </p>
                      </button>
                    );
                  })
                )}
              </div>

              {inboxTotalPages > 1 && (
                <div className="p-3 border-t border-white/10 flex items-center justify-between text-[11px] text-[#EDE9E0]/65">
                  <button
                    type="button"
                    disabled={inboxPage <= 1}
                    onClick={() => setInboxPage(p => Math.max(1, p - 1))}
                    className="h-8 px-2.5 rounded-xl bg-[#06302F] border border-white/10 hover:border-white/20 disabled:opacity-40 cursor-pointer inline-flex items-center gap-1"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" /> Prev
                  </button>
                  <span className="font-mono tabular-nums">
                    Page {inboxPage} / {inboxTotalPages}
                  </span>
                  <button
                    type="button"
                    disabled={inboxPage >= inboxTotalPages}
                    onClick={() => setInboxPage(p => Math.min(inboxTotalPages, p + 1))}
                    className="h-8 px-2.5 rounded-xl bg-[#06302F] border border-white/10 hover:border-white/20 disabled:opacity-40 cursor-pointer inline-flex items-center gap-1"
                  >
                    Next <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Detail Column (Read-Only) */}
            <div className="lg:col-span-7 p-6 bg-[#031D1C] border border-white/10 rounded-2xl shadow-lg flex flex-col justify-between">
              {selectedSubmission ? (
                <div className="space-y-4 text-xs">
                  <div className="flex flex-wrap items-start justify-between gap-3 border-b border-white/10 pb-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm font-bold text-[#EDE9E0]">{selectedSubmission.name}</h3>
                        {(() => {
                          const badgeMeta = mapSubmissionStatusToBadge(selectedSubmission.status);
                          return (
                            <PortalStatusBadge status={badgeMeta.variant} labelOverride={badgeMeta.label} />
                          );
                        })()}
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[#25CDB6] font-mono">{selectedSubmission.email}</span>
                        <button
                          type="button"
                          onClick={() => void handleCopySenderEmail(selectedSubmission.email)}
                          className="h-7 px-2.5 rounded-lg bg-[#06302F] border border-white/10 hover:border-white/20 text-[11px] text-[#EDE9E0]/85 inline-flex items-center gap-1 cursor-pointer"
                        >
                          {copiedEmail ? <Check className="w-3 h-3 text-[#25CDB6]" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedEmail ? 'Copied' : 'Copy Email'}</span>
                        </button>
                      </div>
                      <span className="text-[11px] text-[#EDE9E0]/45 block font-mono tabular-nums">
                        Received{' '}
                        {new Date(selectedSubmission.createdAt || selectedSubmission.submittedAt || Date.now()).toLocaleString()}
                        {selectedSubmission.organization ? ` · ${selectedSubmission.organization}` : ''}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          void handleUpdateSubmissionStatus(
                            selectedSubmission,
                            selectedSubmission.status === 'new' ? 'read' : 'new'
                          )
                        }
                        className="h-9 px-3 rounded-xl bg-[#06302F] hover:bg-white/10 border border-white/12 text-[#EDE9E0]/90 inline-flex items-center gap-1.5 font-semibold cursor-pointer"
                      >
                        <MailOpen className="w-3.5 h-3.5" />
                        <span>{selectedSubmission.status === 'new' ? 'Mark Read' : 'Mark Unread'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          void handleUpdateSubmissionStatus(
                            selectedSubmission,
                            selectedSubmission.status === 'archived' ? 'read' : 'archived'
                          )
                        }
                        className="h-9 px-3 rounded-xl bg-[#06302F] hover:bg-white/10 border border-white/12 text-[#EDE9E0]/90 inline-flex items-center gap-1.5 font-semibold cursor-pointer"
                      >
                        <Archive className="w-3.5 h-3.5" />
                        <span>{selectedSubmission.status === 'archived' ? 'Unarchive' : 'Archive'}</span>
                      </button>

                      <DeleteButton
                        onClick={() => setConfirmDeleteSub(selectedSubmission)}
                        title="Delete submission"
                        ariaLabel="Delete submission"
                      />
                    </div>
                  </div>

                  {selectedSubmission.subject && (
                    <div className="text-xs font-bold text-[#EDE9E0]">
                      Subject: <span className="font-normal text-[#EDE9E0]/85">{selectedSubmission.subject}</span>
                    </div>
                  )}

                  <div className="p-4 rounded-xl bg-[#06302F] border border-white/10 text-[#EDE9E0]/90 leading-relaxed whitespace-pre-wrap">
                    {selectedSubmission.message}
                  </div>
                </div>
              ) : (
                <PortalEmptyState
                  icon={Inbox}
                  title="Select an inquiry"
                  description="Choose a message on the left to read contact details, copy the sender address, or change its status."
                  className="border-none bg-transparent my-auto"
                />
              )}
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================
          4. SUB-TAB: BACKUPS & SNAPSHOTS
          =================================================================== */}
      {canManageBackups && currentSubTab === 'backups' && (
        <div className="space-y-4">
          <PortalSection
            title="SQLite Database Snapshots"
            description="Portable binary .sqlite exports and restores of departments, projects, publications, products, site copy, settings, pages, and media records. Session tokens, password hashes, and 2FA secrets are never included."
            actions={
              <div className="flex flex-wrap items-center gap-2">
                <label className="h-9 px-3.5 bg-[#06302F] hover:bg-white/10 border border-white/12 text-[#EDE9E0] rounded-xl text-xs font-semibold cursor-pointer inline-flex items-center justify-center gap-1.5 whitespace-nowrap">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Restore SQLite Snapshot</span>
                  <input
                    type="file"
                    accept=".sqlite,.db,application/x-sqlite3,application/vnd.sqlite3"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>

                <button
                  type="button"
                  onClick={handleDownloadBackup}
                  disabled={backupInProgress}
                  className="h-9 px-3.5 bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] rounded-xl text-xs font-bold transition-all shadow-md inline-flex items-center justify-center gap-1.5 whitespace-nowrap cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{backupInProgress ? 'Exporting...' : 'Export Snapshot (.sqlite)'}</span>
                </button>
              </div>
            }
          >
            <div className="p-4 bg-[#06302F] border border-white/10 rounded-xl flex items-start gap-3 text-xs text-[#EDE9E0]/80">
              <Database className="w-4 h-4 text-[#25CDB6] shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold text-[#EDE9E0]">Primary Storage: SQLite (`data/moa.sqlite`)</p>
                <p className="text-[#EDE9E0]/65 leading-relaxed">
                  All Control Room records, published pages, live editor drafts, and settings persist directly in SQLite. Use Export Snapshot above whenever you want a portable archive for backup or migration.
                </p>
              </div>
            </div>
          </PortalSection>
        </div>
      )}

      {/* ===================================================================
          5. SUB-TAB: AUDIT & SECURITY LOGS
          =================================================================== */}
      {canViewAudit && currentSubTab === 'audit' && (
        <div className="space-y-4">
          <PortalTabs
            items={auditViewTabs}
            activeId={auditView}
            onChange={setAuditView}
            ariaLabel="Audit and security views"
          />

          {auditView === 'activity' ? (
            <>
              <PortalFilterBar
                search={auditSearch}
                onSearchChange={val => {
                  setAuditSearch(val);
                  setAuditPage(1);
                }}
                searchPlaceholder="Search activity trail..."
                filters={[
                  {
                    id: 'audit-area',
                    label: 'Filter by audit area',
                    value: auditArea,
                    onChange: val => {
                      setAuditArea(val);
                      setAuditPage(1);
                    },
                    options: [
                      { value: 'all', label: 'All Areas' },
                      ...[
                        'Projects',
                        'Publications',
                        'Products',
                        'Departments',
                        'Website',
                        'Media',
                        'Team',
                        'Settings',
                        'Auth',
                        'System'
                      ].map(area => ({ value: area, label: area }))
                    ]
                  }
                ]}
                hasActiveFilters={Boolean(auditSearch.trim()) || auditArea !== 'all'}
                onResetFilters={() => {
                  setAuditSearch('');
                  setAuditArea('all');
                  setAuditPage(1);
                }}
                rightSlot={
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => void loadAuditLogs()}
                      className="h-9 px-3.5 rounded-xl bg-[#06302F] hover:bg-white/10 border border-white/12 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${auditLoading ? 'animate-spin' : ''}`} />
                      <span>Refresh</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleExportActivityCsv}
                      className="h-9 px-3.5 rounded-xl bg-[#06302F] hover:bg-white/10 border border-white/12 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export CSV</span>
                    </button>
                  </div>
                }
              />

              <PortalTable
                columns={activityColumns}
                items={auditLogs}
                getRowKey={log => log.id}
                loading={auditLoading}
                error={auditError}
                onRetry={() => void loadAuditLogs()}
                page={auditPage}
                totalPages={auditTotalPages}
                totalItems={auditTotalItems}
                pageSize={25}
                onPageChange={setAuditPage}
                emptyState={
                  <PortalEmptyState
                    icon={History}
                    title="No activity records found"
                    description="Try clearing your search or selecting All Areas."
                  />
                }
              />
            </>
          ) : (
            <PortalSection
              title="Security Events"
              description="Recent sign-in, lockout, 2FA, and credential change audit records."
              actions={
                <button
                  type="button"
                  onClick={() => void loadSecurityLogs()}
                  className="h-9 px-3.5 rounded-xl bg-[#06302F] hover:bg-white/10 border border-white/12 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${securityLogsLoading ? 'animate-spin' : ''}`} />
                  <span>Refresh</span>
                </button>
              }
            >
              <PortalTable
                columns={securityColumns}
                items={securityLogs}
                getRowKey={log => log.id}
                loading={securityLogsLoading}
                error={auditError}
                onRetry={() => void loadSecurityLogs()}
                stickyHeader={false}
                emptyState={
                  <PortalEmptyState
                    icon={Shield}
                    title="No security events recorded"
                    description="Authentication events will appear here as operators sign in."
                    className="border-none bg-transparent"
                  />
                }
              />
            </PortalSection>
          )}
        </div>
      )}

      {/* ===================================================================
          6. SUB-TAB: SITE HEALTH CHECK (Real API Diagnostics)
          =================================================================== */}
      {canViewHealth && currentSubTab === 'health' && (
        <PortalSection
          title="Site Health Diagnostics"
          description="Scans live server data for page & SEO issues, missing department copy, alt text gaps, unused uploaded files, and stalled drafts."
          badge={
            <PortalStatusBadge
              status={healthItems.length === 0 ? 'Published' : 'In review'}
              labelOverride={
                healthItems.length === 0
                  ? 'All Diagnostics Passing (100/100)'
                  : `${healthItems.length} Alert${healthItems.length === 1 ? '' : 's'} (${healthScore}/100)`
              }
            />
          }
          actions={
            <button
              type="button"
              onClick={() => void loadHealth()}
              disabled={healthLoading}
              className="h-9 px-3.5 rounded-xl bg-[#06302F] hover:bg-white/10 border border-white/12 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 whitespace-nowrap cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${healthLoading ? 'animate-spin' : ''}`} />
              <span>Re-run Scan</span>
            </button>
          }
        >
          <div className="space-y-4">
            {healthError && (
              <div className="p-3.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center justify-between gap-2">
                <span>{healthError}</span>
                <button
                  type="button"
                  onClick={() => void loadHealth()}
                  className="h-8 px-3 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-white font-bold cursor-pointer"
                >
                  Retry
                </button>
              </div>
            )}

            {healthLoading ? (
              <div className="p-12 text-center text-xs text-[#EDE9E0]/55">Running site health scan...</div>
            ) : healthItems.length === 0 ? (
              <PortalEmptyState
                icon={Activity}
                title="All Checks Passing"
                description="No missing page metadata, introductions, alt attributes, unused uploads, or SEO gaps detected."
                className="border-none bg-transparent"
              />
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {healthItems.map(item => {
                  const severityBadge = mapHealthTypeToBadge(item.type);
                  return (
                    <div
                      key={item.id}
                      className="p-4 sm:p-5 bg-[#06302F] border border-white/10 rounded-2xl flex flex-col justify-between gap-3"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="text-sm font-bold text-[#EDE9E0]">{item.title}</h4>
                          <div className="flex items-center gap-1.5 shrink-0">
                            {item.category && (
                              <PortalStatusBadge
                                status="Draft"
                                labelOverride={item.category === 'website' ? 'Website' : 'Operations'}
                                showDot={false}
                              />
                            )}
                            <PortalStatusBadge
                              status={severityBadge.variant}
                              labelOverride={severityBadge.label}
                            />
                          </div>
                        </div>
                        <p className="text-xs text-[#EDE9E0]/65 leading-relaxed">{item.message}</p>
                      </div>

                      {item.actionText && (
                        <div className="pt-2.5 border-t border-white/10 flex justify-end">
                          <button
                            type="button"
                            onClick={() => {
                              if (item.actionTab === 'settings') {
                                onSubTabChange((item.actionSubTab as SettingsSubTab) || 'organization');
                              } else if (onNavigateTab && item.actionTab) {
                                if (
                                  item.actionTab === 'departments' ||
                                  item.actionTab === 'projects' ||
                                  item.actionTab === 'publications' ||
                                  item.actionTab === 'products'
                                ) {
                                  onNavigateTab('content', item.actionTab);
                                } else if (item.actionTab === 'website') {
                                  onNavigateTab(
                                    'website',
                                    item.actionSubTab || 'seo',
                                    item.targetPageId,
                                    item.targetDrawerTab
                                  );
                                } else {
                                  onNavigateTab(item.actionTab);
                                }
                              }
                            }}
                            className="h-8 px-3 rounded-xl bg-[#17A491]/15 hover:bg-[#17A491] text-[#25CDB6] hover:text-[#06302F] border border-[#25CDB6]/25 text-xs font-bold transition-colors cursor-pointer"
                          >
                            {item.actionText}
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </PortalSection>
      )}

      {/* ===================================================================
          7. SUB-TAB: TRASH BIN (Real API Soft-Deleted Records)
          =================================================================== */}
      {canManageTrash && currentSubTab === 'trash' && (
        <PortalSection
          title="Trash Bin"
          description="Soft-deleted departments, projects, publications, products, pages, media assets, and inbox submissions are retained for 30 days before permanent removal."
          badge={
            flattenedTrash.length > 0 ? (
              <span className="px-2 py-0.5 rounded-full text-[11px] font-mono font-semibold bg-white/10 text-[#EDE9E0]/80 tabular-nums">
                {flattenedTrash.length}
              </span>
            ) : undefined
          }
          actions={
            flattenedTrash.length > 0 ? (
              <DeleteButton
                onClick={() => setConfirmEmptyTrash(true)}
                label="Empty Trash Permanently"
                title="Empty Trash Permanently"
              />
            ) : undefined
          }
        >
          <PortalTable
            columns={trashColumns}
            items={flattenedTrash}
            getRowKey={item => `${item.entityType}-${item.id}`}
            loading={trashLoading}
            error={trashError}
            onRetry={() => void loadTrash()}
            stickyHeader={false}
            emptyState={
              <PortalEmptyState
                icon={Trash2}
                title="Trash bin is empty"
                description="Soft-deleted records remain here for 30 days before permanent removal."
                className="border-none bg-transparent"
              />
            }
          />
        </PortalSection>
      )}

      {/* Confirmation Dialogs */}
      <PortalConfirmDialog
        isOpen={Boolean(confirmDeleteSub)}
        title="Move Inquiry to Trash"
        message={
          confirmDeleteSub
            ? `Move submission from ${confirmDeleteSub.name} (${confirmDeleteSub.email}) to Trash? You can restore it or delete it permanently from Settings -> Trash.`
            : ''
        }
        confirmLabel="Move to Trash"
        onCancel={() => setConfirmDeleteSub(null)}
        onConfirm={async () => {
          if (!confirmDeleteSub) return;
          const target = confirmDeleteSub;
          setConfirmDeleteSub(null);
          try {
            await api.deleteSubmission(target.id);
            if (selectedSubmission?.id === target.id) setSelectedSubmission(null);
            await loadSubmissions();
            if (onRefreshData) await onRefreshData();
            showSuccess('Submission moved to Trash.');
          } catch (err: unknown) {
            setBannerError(err instanceof Error ? err.message : 'Failed to move submission to Trash.');
          }
        }}
      />

      <PortalConfirmDialog
        isOpen={Boolean(pendingImportPayload)}
        title="Restore SQLite Database Snapshot"
        message={
          pendingImportPayload
            ? `Restoring SQLite snapshot "${pendingImportPayload.filename}" will replace departments, projects, publications, products, media, pages, content, roles, and settings.`
            : ''
        }
        confirmLabel="Validate & Restore"
        onCancel={() => setPendingImportPayload(null)}
        onConfirm={async () => {
          if (!pendingImportPayload) return;
          const payload = pendingImportPayload;
          setPendingImportPayload(null);
          try {
            const res = await api.importEverything(payload.file);
            if (onRefreshData) await onRefreshData();
            showSuccess(res.message || `Restored SQLite snapshot "${payload.filename}".`);
          } catch (err: unknown) {
            setBannerError(err instanceof Error ? err.message : 'SQLite snapshot validation or restore failed.');
          }
        }}
      />

      <PortalConfirmDialog
        isOpen={Boolean(confirmDeleteTrashItem)}
        title="Delete Permanently"
        message={
          confirmDeleteTrashItem
            ? `Permanently delete ${confirmDeleteTrashItem.labelType.toLowerCase()} "${confirmDeleteTrashItem.title}"? This removes the record and cannot be undone.`
            : ''
        }
        confirmLabel="Delete Permanently"
        onCancel={() => setConfirmDeleteTrashItem(null)}
        onConfirm={async () => {
          if (!confirmDeleteTrashItem) return;
          const item = confirmDeleteTrashItem;
          setConfirmDeleteTrashItem(null);
          try {
            await api.deleteTrashItem(item.entityType, item.id);
            await loadTrash();
            if (onRefreshData) await onRefreshData();
            showSuccess(`Permanently deleted "${item.title}".`);
          } catch (err: unknown) {
            setBannerError(err instanceof Error ? err.message : 'Failed to permanently delete item.');
          }
        }}
      />

      <PortalConfirmDialog
        isOpen={confirmEmptyTrash}
        title="Empty Trash Permanently"
        message={`Permanently purge all ${flattenedTrash.length} item${flattenedTrash.length === 1 ? '' : 's'} from Trash and remove any orphaned uploaded files? This action cannot be undone.`}
        confirmLabel="Empty Trash"
        onCancel={() => setConfirmEmptyTrash(false)}
        onConfirm={async () => {
          setConfirmEmptyTrash(false);
          try {
            await api.emptyTrash();
            await loadTrash();
            if (onRefreshData) await onRefreshData();
            showSuccess('Trash bin permanently emptied.');
          } catch (err: unknown) {
            setBannerError(err instanceof Error ? err.message : 'Failed to empty Trash.');
          }
        }}
      />

      <PortalFloatingSaveBar
        visible={canManageSettings && currentSubTab === 'organization' && orgDirty}
        saving={orgSaving}
        error={bannerError}
        title="Unsaved organization profile changes"
        saveLabel="Save Organization Profile"
        onDiscard={handleDiscardOrg}
        onSave={() => void saveOrg()}
      />

      <PortalFloatingSaveBar
        visible={currentSubTab === 'security' && ((canManageSettings && securityDirty) || credDirty)}
        saving={securitySaving || credSaving}
        error={credError || bannerError}
        title={
          canManageSettings && securityDirty && credDirty
            ? 'Unsaved security policy & credential changes'
            : credDirty
            ? 'Unsaved account credential changes'
            : 'Unsaved security policy changes'
        }
        saveLabel={
          canManageSettings && securityDirty && credDirty
            ? 'Save Security & Credentials'
            : credDirty
            ? 'Save Credentials'
            : 'Save Security Policy'
        }
        onDiscard={() => {
          if (canManageSettings && securityDirty) handleDiscardSecurity();
          if (credDirty) handleDiscardCredentials();
        }}
        onSave={() => {
          void (async () => {
            if (canManageSettings && securityDirty) {
              await saveSecurity();
            }
            if (credDirty) {
              await saveCredentials();
            }
          })();
        }}
      />
    </div>
  );
};
