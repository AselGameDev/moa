import React, { useEffect, useRef } from 'react';
import { AlertTriangle, Loader2, X } from 'lucide-react';

export interface PortalConfirmDialogProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  isDestructive?: boolean;
  confirmDisabled?: boolean;
  loading?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  children?: React.ReactNode;
}

export const PortalConfirmDialog: React.FC<PortalConfirmDialogProps> = ({
  isOpen,
  title,
  message,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  isDestructive = true,
  confirmDisabled = false,
  loading = false,
  onConfirm,
  onCancel,
  children
}) => {
  const cancelBtnRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    cancelBtnRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !loading) {
        e.preventDefault();
        onCancel();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, loading, onCancel]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[110] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150"
      role="dialog"
      aria-modal="true"
      aria-label={title}
      onClick={() => {
        if (!loading) onCancel();
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        className="w-full max-w-md max-h-[90dvh] overflow-y-auto bg-[#0A3D3C] border border-[#EDE9E0]/20 rounded-2xl shadow-2xl p-4 sm:p-6 space-y-5 text-[#EDE9E0]"
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                isDestructive
                  ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                  : 'bg-[#17A491]/20 text-[#25CDB6]'
              }`}
            >
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-[#EDE9E0] tracking-tight break-words">
              {title}
            </h3>
          </div>
          <button
            type="button"
            disabled={loading}
            onClick={onCancel}
            aria-label="Close dialog"
            className="text-[#EDE9E0]/40 hover:text-[#EDE9E0] transition-colors p-1 shrink-0 cursor-pointer disabled:opacity-40"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-sm text-[#EDE9E0]/80 leading-relaxed break-words">{message}</p>

        {children}

        <div className="flex flex-wrap items-center justify-end gap-2.5 sm:gap-3 pt-3 border-t border-[#EDE9E0]/10">
          <button
            ref={cancelBtnRef}
            type="button"
            disabled={loading}
            onClick={onCancel}
            className="px-4 py-2.5 rounded-xl border border-white/10 hover:bg-white/5 text-xs font-semibold text-[#EDE9E0] transition-colors cursor-pointer disabled:opacity-40"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            disabled={loading || confirmDisabled}
            onClick={onConfirm}
            className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all shadow-lg cursor-pointer border inline-flex items-center gap-1.5 disabled:opacity-45 disabled:cursor-not-allowed ${
              isDestructive
                ? 'bg-red-600/90 hover:bg-red-500 border-red-400/40 text-white shadow-red-950/50'
                : 'bg-[#17A491] hover:bg-[#25CDB6] border-[#25CDB6]/40 text-[#06302F]'
            }`}
          >
            {loading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
            <span>{confirmLabel}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
