import React, { useEffect, useMemo, useState } from 'react';
import {
  Edit3,
  ExternalLink,
  Search,
  Layers,
  FileText,
  History,
  ArrowRightLeft,
  Settings as SettingsIcon,
  RotateCcw,
  GitCompare,
  AlertCircle,
  Loader2,
  Check,
  Plus
} from 'lucide-react';
import {
  ContentHistorySnapshot,
  PageBlock,
  PageRecord,
  WebsitePageSettingsResponse
} from '../../../types';
import { api, HttpError } from '../../../services/api';
import { formatSeoTitle } from '../../../shared/pageRegistry';
import { isSafeUrl } from '../../../shared/url';
import { ModularBlockEditor } from '../ModularBlockEditor';
import {
  PortalConfirmDialog,
  PortalDrawer,
  PortalFloatingSaveBar,
  PortalMediaField,
  PortalTabItem,
  PortalTabs
} from '../ui';

export type DrawerTabKey = 'general' | 'seo' | 'content' | 'text' | 'history' | 'redirects';

interface PageSettingsDrawerProps {
  isOpen: boolean;
  pageId: string | null;
  initialTab?: DrawerTabKey;
  titleTemplate: string;
  siteName: string;
  defaultShareImage: string;
  canEditWebsite: boolean;
  canManageSeo: boolean;
  onClose: () => void;
  onSaved: () => Promise<void>;
  onEditOnSite: (path: string, sectionAnchorId?: string) => void | Promise<void>;
  onNavigateSite: (path: string) => void;
  onOpenSeoSubTab: () => void;
}

function formatDateTime(iso?: string): string {
  if (!iso) return '—';
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return '—';
  return dt.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}

export const PageSettingsDrawer: React.FC<PageSettingsDrawerProps> = ({
  isOpen,
  pageId,
  initialTab = 'general',
  titleTemplate,
  siteName,
  defaultShareImage,
  canEditWebsite,
  canManageSeo,
  onClose,
  onSaved,
  onEditOnSite,
  onNavigateSite,
  onOpenSeoSubTab
}) => {
  const [activeTab, setActiveTab] = useState<DrawerTabKey>(initialTab);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [details, setDetails] = useState<WebsitePageSettingsResponse | null>(null);

  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [template, setTemplate] = useState<PageRecord['template']>('Standard');
  const [status, setStatus] = useState<PageRecord['status']>('Published');
  const [inHeader, setInHeader] = useState(false);
  const [inFooter, setInFooter] = useState(false);

  const [seoTitle, setSeoTitle] = useState('');
  const [seoDescription, setSeoDescription] = useState('');
  const [seoShareImage, setSeoShareImage] = useState('');
  const [noindex, setNoindex] = useState(false);

  const [textValues, setTextValues] = useState<Record<string, string>>({});
  const [blocks, setBlocks] = useState<PageBlock[]>([]);

  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [conflictError, setConflictError] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);

  const [mediaPickerOpen, setMediaPickerOpen] = useState(false);

  const [versions, setVersions] = useState<ContentHistorySnapshot[]>([]);
  const [compareVersionId, setCompareVersionId] = useState<string | null>(null);
  const [confirmRestore, setConfirmRestore] = useState<ContentHistorySnapshot | null>(null);
  const [restoring, setRestoring] = useState(false);

  const [newRedirectFrom, setNewRedirectFrom] = useState('');
  const [newRedirectTo, setNewRedirectTo] = useState('');
  const [redirectAdding, setRedirectAdding] = useState(false);

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab, pageId]);

  const hydrateFromResponse = (res: WebsitePageSettingsResponse, loadedVersions?: ContentHistorySnapshot[]) => {
    setDetails(res);
    const cp = res.page.customPage;
    setTitle(res.page.name || '');
    setSlug(cp?.slug || res.page.path.replace(/^\//, ''));
    setTemplate(cp?.template || 'Standard');
    setStatus(cp?.status || 'Published');
    setInHeader(Boolean(res.page.inHeader));
    setInFooter(Boolean(res.page.inFooter));
    setSeoTitle(res.page.seo?.title || '');
    setSeoDescription(res.page.seo?.description || '');
    setSeoShareImage(res.page.seo?.shareImage || '');
    setNoindex(Boolean(res.page.seo?.noindex));
    setTextValues({ ...(res.textValues || {}), ...(res.draftTextValues || {}) });
    setBlocks(cp?.blocks ? JSON.parse(JSON.stringify(cp.blocks)) : []);
    if (loadedVersions) {
      setVersions(loadedVersions);
    }
    setCompareVersionId(null);
    setConflictError(false);
    setSaveError(null);
  };

  const fetchDetails = async (targetId: string) => {
    setLoading(true);
    setLoadError(null);
    try {
      const [res, hist] = await Promise.all([
        api.getWebsitePageSettings(targetId),
        canEditWebsite ? api.getWebsitePageVersions(targetId).catch(() => []) : Promise.resolve([])
      ]);
      hydrateFromResponse(res, hist);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Failed to load page settings.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!isOpen || !pageId) return;
    setSaveSuccess(null);
    void fetchDetails(pageId);
  }, [isOpen, pageId]);

  const effectivePreviewTitle = useMemo(() => {
    if (seoTitle.trim()) return seoTitle.trim();
    return formatSeoTitle(titleTemplate, title || details?.page.name || 'Page', siteName);
  }, [seoTitle, titleTemplate, title, details?.page.name, siteName]);

  const effectivePreviewPath = useMemo(() => {
    if (!details) return '/';
    if (details.page.kind === 'custom') {
      const clean = slug.trim().replace(/^\/+/, '');
      return clean ? `/${clean}` : details.page.path;
    }
    return details.page.path;
  }, [details, slug]);

  const comparedDiffs = useMemo(() => {
    if (!compareVersionId) return [];
    const snap = versions.find(v => v.id === compareVersionId);
    if (!snap || !snap.snapshot) return [];
    const rows: Array<{ key: string; snapshotVal: string; currentVal: string }> = [];
    const snapObj = snap.snapshot as Record<string, unknown>;

    if (details?.page.kind === 'custom') {
      const snapTitle = typeof snapObj.title === 'string' ? snapObj.title : '';
      const snapBlocks = Array.isArray(snapObj.blocks) ? snapObj.blocks.length : 0;
      if (snapTitle !== title) {
        rows.push({ key: 'Title', snapshotVal: snapTitle, currentVal: title });
      }
      if (snapBlocks !== blocks.length) {
        rows.push({
          key: 'Blocks count',
          snapshotVal: `${snapBlocks} blocks`,
          currentVal: `${blocks.length} blocks`
        });
      }
    } else {
      for (const field of details?.textFields || []) {
        const [sec, key] = field.path.split('.');
        const directVal = snapObj[field.path];
        const secData = (snapObj[sec] as Record<string, unknown> | undefined) || {};
        const snapVal =
          typeof directVal === 'string'
            ? directVal
            : typeof secData[key] === 'string'
              ? (secData[key] as string)
              : '';
        const currVal = textValues[field.path] || '';
        if (snapVal !== currVal) {
          rows.push({ key: field.label, snapshotVal: snapVal, currentVal: currVal });
        }
      }
    }
    return rows;
  }, [compareVersionId, versions, details, title, blocks.length, textValues]);

  const isDirty = useMemo(() => {
    if (!details) return false;
    const cp = details.page.customPage;
    const baseName = details.page.name || '';
    const baseSlug = cp?.slug || details.page.path.replace(/^\//, '');
    const baseTemplate = cp?.template || 'Standard';
    const baseStatus = cp?.status || 'Published';
    const baseInHeader = Boolean(details.page.inHeader);
    const baseInFooter = Boolean(details.page.inFooter);
    const baseSeoTitle = details.page.seo?.title || '';
    const baseSeoDesc = details.page.seo?.description || '';
    const baseSeoShare = details.page.seo?.shareImage || '';
    const baseNoindex = Boolean(details.page.seo?.noindex);
    const baseTextValues = { ...(details.textValues || {}), ...(details.draftTextValues || {}) };
    const baseBlocks = cp?.blocks || [];

    if (inHeader !== baseInHeader || inFooter !== baseInFooter) return true;
    if (
      seoTitle !== baseSeoTitle ||
      seoDescription !== baseSeoDesc ||
      seoShareImage !== baseSeoShare ||
      noindex !== baseNoindex
    ) {
      return true;
    }
    if (details.page.kind === 'custom') {
      if (
        title !== baseName ||
        slug !== baseSlug ||
        template !== baseTemplate ||
        status !== baseStatus ||
        JSON.stringify(blocks) !== JSON.stringify(baseBlocks)
      ) {
        return true;
      }
    } else if (JSON.stringify(textValues) !== JSON.stringify(baseTextValues)) {
      return true;
    }
    return false;
  }, [
    details,
    title,
    slug,
    template,
    status,
    inHeader,
    inFooter,
    seoTitle,
    seoDescription,
    seoShareImage,
    noindex,
    textValues,
    blocks
  ]);

  if (!isOpen || !pageId) return null;

  const isCustom = details?.page.kind === 'custom';
  const isHome = pageId === 'home';
  const canSave = canEditWebsite || canManageSeo;

  const handleDiscard = () => {
    if (!details) return;
    hydrateFromResponse(details);
    setSaveSuccess(null);
  };

  const handleSave = async (asDraft = false) => {
    if (!details) return;
    setSaving(true);
    setSaveError(null);
    setConflictError(false);
    setSaveSuccess(null);

    try {
      const payload: Parameters<typeof api.updateWebsitePageSettings>[1] = {
        version: details.page.version,
        inHeader,
        inFooter
      };
      if (canEditWebsite && isCustom) {
        payload.title = title.trim();
        payload.slug = slug.trim();
        payload.template = template;
        payload.status = status;
        payload.blocks = blocks;
      }
      if (canManageSeo || canEditWebsite) {
        payload.seo = {
          title: seoTitle.trim() || undefined,
          description: seoDescription.trim() || undefined,
          shareImage: seoShareImage.trim() || undefined,
          noindex
        };
      }
      if (canEditWebsite && !isCustom) {
        payload.textValues = textValues;
        if (asDraft) {
          payload.saveAsDraft = true;
        } else {
          payload.publishDraft = true;
        }
      }

      const updated = await api.updateWebsitePageSettings(details.page.id, payload);
      const hist = canEditWebsite
        ? await api.getWebsitePageVersions(details.page.id).catch(() => versions)
        : versions;
      hydrateFromResponse(updated, hist);
      await onSaved();
      setSaveSuccess(
        asDraft ? 'Saved as unpublished draft.' : 'Saved and committed to database.'
      );
    } catch (err) {
      if (err instanceof HttpError && err.status === 409) {
        setConflictError(true);
        setSaveError('Another editor updated this page after you opened it. Reload latest changes before saving.');
      } else {
        setSaveError(err instanceof Error ? err.message : 'Failed to save page settings.');
      }
    } finally {
      setSaving(false);
    }
  };

  const handleRestoreVersion = async () => {
    if (!details || !confirmRestore) return;
    setRestoring(true);
    setSaveError(null);
    try {
      const updated = await api.restoreWebsitePageVersion(details.page.id, confirmRestore.id);
      const hist = await api.getWebsitePageVersions(details.page.id).catch(() => versions);
      hydrateFromResponse(updated, hist);
      setConfirmRestore(null);
      await onSaved();
      setSaveSuccess('Version restored and published.');
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Failed to restore version.');
    } finally {
      setRestoring(false);
    }
  };

  const handleQuickAddRedirect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!details) return;
    const fromClean = newRedirectFrom.trim();
    const toClean = newRedirectTo.trim() || details.page.path;
    if (!fromClean.startsWith('/')) {
      setSaveError('Redirect source path must begin with /.');
      return;
    }
    if (!isSafeUrl(toClean)) {
      setSaveError('Redirect destination must be a safe internal path or http/https URL.');
      return;
    }
    setRedirectAdding(true);
    setSaveError(null);
    try {
      await api.createWebsiteRedirect({ from: fromClean, to: toClean, type: '301' });
      setNewRedirectFrom('');
      setNewRedirectTo('');
      await fetchDetails(details.page.id);
      await onSaved();
      setSaveSuccess('Redirect added.');
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Could not add redirect.');
    } finally {
      setRedirectAdding(false);
    }
  };

  const drawerTabs: PortalTabItem<DrawerTabKey>[] = [
    { id: 'general', label: 'General', icon: SettingsIcon },
    { id: 'seo', label: 'SEO', icon: Search },
    { id: 'content', label: 'Content map', icon: Layers },
    { id: 'text', label: isCustom ? 'Blocks' : 'Page text', icon: FileText },
    { id: 'history', label: 'History', icon: History },
    { id: 'redirects', label: 'Redirects', icon: ArrowRightLeft }
  ];

  return (
    <>
      <PortalDrawer
        isOpen={isOpen}
        onClose={onClose}
        title={details?.page.name || 'Page Settings'}
        subtitle={details?.page.description}
        headerBadge={
          details && (
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-white/10 text-[#25CDB6]">
              {details.page.path}
            </span>
          )
        }
        headerActions={
          details && (
            <button
              type="button"
              onClick={() => onNavigateSite(details.page.path)}
              className="w-8 h-8 rounded-lg inline-flex items-center justify-center text-[#EDE9E0]/75 hover:text-[#25CDB6] hover:bg-white/10 cursor-pointer"
              title="View public page"
              aria-label="View public page"
            >
              <ExternalLink className="w-4 h-4" />
            </button>
          )
        }
        blockEscape={mediaPickerOpen || Boolean(confirmRestore)}
        zIndexClass="z-[95]"
      >
        <div className={`space-y-4 ${isDirty && canSave ? 'pb-24' : ''}`}>
          <PortalTabs
            items={drawerTabs}
            activeId={activeTab}
            onChange={setActiveTab}
            ariaLabel="Page settings sections"
          />

          {(loadError || saveError || saveSuccess) && (
            <div className="space-y-2">
              {(loadError || saveError) && (
                <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                    <span>{loadError || saveError}</span>
                  </div>
                  {conflictError && pageId && (
                    <button
                      type="button"
                      onClick={() => void fetchDetails(pageId)}
                      className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 font-bold text-white cursor-pointer"
                    >
                      Reload latest
                    </button>
                  )}
                </div>
              )}
              {saveSuccess && (
                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4 shrink-0" />
                  <span>{saveSuccess}</span>
                </div>
              )}
            </div>
          )}

          {loading ? (
            <div className="py-16 flex flex-col items-center justify-center gap-2 text-xs text-[#EDE9E0]/60">
              <Loader2 className="w-5 h-5 animate-spin text-[#25CDB6]" />
              <span>Loading page settings...</span>
            </div>
          ) : !details ? null : (
            <>
              {activeTab === 'general' && (
                <div className="space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[#EDE9E0]/70 font-semibold mb-1">Page Title</label>
                      {isCustom ? (
                        <input
                          type="text"
                          value={title}
                          onChange={e => setTitle(e.target.value)}
                          className="w-full bg-[#031D1C] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                        />
                      ) : (
                        <input
                          type="text"
                          value={details.page.name}
                          readOnly
                          className="w-full bg-[#031D1C]/60 border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]/65 cursor-not-allowed"
                        />
                      )}
                    </div>

                    <div>
                      <label className="block text-[#EDE9E0]/70 font-semibold mb-1">
                        URL Path {!isCustom && <span className="text-[10px] text-[#EDE9E0]/45">(read-only)</span>}
                      </label>
                      {isCustom ? (
                        <input
                          type="text"
                          value={slug}
                          onChange={e => setSlug(e.target.value)}
                          className="w-full bg-[#031D1C] border border-white/10 rounded-xl px-3.5 py-2.5 font-mono text-[#EDE9E0]"
                        />
                      ) : (
                        <input
                          type="text"
                          value={details.page.path}
                          readOnly
                          className="w-full bg-[#031D1C]/60 border border-white/10 rounded-xl px-3.5 py-2.5 font-mono text-[#EDE9E0]/65 cursor-not-allowed"
                        />
                      )}
                    </div>
                  </div>

                  {isCustom && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[#EDE9E0]/70 font-semibold mb-1">Visibility Status</label>
                        <select
                          value={status}
                          onChange={e => setStatus(e.target.value as PageRecord['status'])}
                          className="w-full bg-[#031D1C] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                        >
                          <option value="Published">Published</option>
                          <option value="Draft">Draft</option>
                          <option value="Hidden">Hidden</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[#EDE9E0]/70 font-semibold mb-1">Template</label>
                        <select
                          value={template}
                          onChange={e => setTemplate(e.target.value as PageRecord['template'])}
                          className="w-full bg-[#031D1C] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                        >
                          <option value="Standard">Standard</option>
                          <option value="Landing">Landing</option>
                          <option value="Article">Article</option>
                          <option value="Gallery">Gallery</option>
                        </select>
                      </div>
                    </div>
                  )}

                  {details.page.id !== 'notFound' && (
                    <div className="p-4 rounded-xl bg-[#031D1C] border border-white/10 space-y-3">
                      <h4 className="font-bold text-[#EDE9E0]">Menu Placement</h4>
                      <label className="flex items-center justify-between gap-3 cursor-pointer">
                        <div>
                          <span className="font-semibold block">Show in header menu</span>
                          <span className="text-[11px] text-[#EDE9E0]/55">
                            {isHome ? 'Home is required in the primary navigation bar.' : 'Display or hide this page in the top navbar.'}
                          </span>
                        </div>
                        <input
                          type="checkbox"
                          checked={inHeader}
                          disabled={isHome}
                          onChange={e => setInHeader(e.target.checked)}
                          className="w-4 h-4 accent-[#25CDB6] cursor-pointer disabled:opacity-50"
                        />
                      </label>

                      <label className="flex items-center justify-between gap-3 pt-2 border-t border-white/10 cursor-pointer">
                        <div>
                          <span className="font-semibold block">Show in footer</span>
                          <span className="text-[11px] text-[#EDE9E0]/55">
                            Include this page in the footer Explore links column.
                          </span>
                        </div>
                        <input
                          type="checkbox"
                          checked={inFooter}
                          onChange={e => setInFooter(e.target.checked)}
                          className="w-4 h-4 accent-[#25CDB6] cursor-pointer"
                        />
                      </label>
                    </div>
                  )}

                  <div className="p-4 rounded-xl bg-[#031D1C]/70 border border-white/10 grid grid-cols-2 gap-3 text-[11px]">
                    <div>
                      <span className="text-[#EDE9E0]/50 block">Last Edited</span>
                      <span className="font-semibold text-[#EDE9E0]">
                        {formatDateTime(details.page.lastEditedAt)} · {details.page.lastEditedByName || 'System'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[#EDE9E0]/50 block">Last Published</span>
                      <span className="font-semibold text-[#EDE9E0]">
                        {formatDateTime(details.page.lastPublishedAt)} · {details.page.lastPublishedByName || 'System'}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'seo' && (
                <div className="space-y-4 text-xs">
                  <div>
                    <label className="block text-[#EDE9E0]/70 font-semibold mb-1">
                      SEO Title Override (optional)
                    </label>
                    <input
                      type="text"
                      value={seoTitle}
                      onChange={e => setSeoTitle(e.target.value)}
                      placeholder={formatSeoTitle(titleTemplate, title || details.page.name, siteName)}
                      className="w-full bg-[#031D1C] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[#EDE9E0]/70 font-semibold">Meta Description</label>
                      <span
                        className={`font-mono text-[11px] font-bold ${
                          seoDescription.length > 160 ? 'text-amber-300' : 'text-[#25CDB6]'
                        }`}
                      >
                        {seoDescription.length} / 160
                      </span>
                    </div>
                    <textarea
                      rows={3}
                      value={seoDescription}
                      onChange={e => setSeoDescription(e.target.value)}
                      placeholder="Concise summary for search engines and social cards (recommended 120–160 characters)..."
                      className="w-full bg-[#031D1C] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                    />
                  </div>

                  <PortalMediaField
                    label="Social Share Image (OpenGraph)"
                    description="Recommended 1200×630 (1.91:1). Uses site default if unset."
                    value={seoShareImage || defaultShareImage}
                    onChange={url => setSeoShareImage(url)}
                    allowedTypes={['image']}
                    uploadFolder="SEO"
                    aspectClass="aspect-[1200/630]"
                    clearLabel="Reset default"
                    pickerTitle="Select Page Share Image"
                    onPickerOpenChange={setMediaPickerOpen}
                  />

                  <label className="p-4 rounded-xl bg-[#031D1C] border border-white/10 flex items-center justify-between gap-3 cursor-pointer">
                    <div>
                      <span className="font-bold text-[#EDE9E0] block">Hide from search engines (noindex)</span>
                      <span className="text-[11px] text-[#EDE9E0]/55">
                        Adds a noindex meta tag and excludes this page from sitemap.xml.
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={noindex}
                      onChange={e => setNoindex(e.target.checked)}
                      className="w-4 h-4 accent-[#25CDB6] cursor-pointer"
                    />
                  </label>

                  <div className="p-4 rounded-xl bg-[#11191a] border border-white/10 space-y-1">
                    <span className="text-[10px] uppercase tracking-wider text-[#EDE9E0]/45 font-bold block mb-2">
                      Search Result Preview
                    </span>
                    <p className="text-[11px] text-[#bdc1c6] font-mono truncate">
                      mastersofall.org{effectivePreviewPath === '/' ? '' : effectivePreviewPath}
                    </p>
                    <p className="text-base font-medium text-[#8ab4f8] leading-snug line-clamp-1">
                      {effectivePreviewTitle}
                    </p>
                    <p className="text-xs text-[#bdc1c6]/85 leading-relaxed line-clamp-2">
                      {seoDescription.trim() || 'No meta description set for this page yet.'}
                    </p>
                  </div>
                </div>
              )}

              {activeTab === 'content' && (
                <div className="space-y-3 text-xs">
                  <p className="text-[#EDE9E0]/65">
                    Real sections rendered on <span className="font-mono text-[#25CDB6]">{details.page.path}</span>. Jump straight to any section in the live editor.
                  </p>
                  {details.sections.length === 0 ? (
                    <div className="p-6 rounded-xl bg-[#031D1C] border border-white/10 text-center text-[#EDE9E0]/60">
                      No structured sections yet. Switch to the Blocks tab to compose content blocks.
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {details.sections.map(sec => (
                        <div
                          key={sec.id}
                          className="p-3.5 rounded-xl bg-[#031D1C] border border-white/10 flex items-center justify-between gap-3"
                        >
                          <div className="min-w-0">
                            <span className="font-bold text-[#EDE9E0] block truncate">{sec.name}</span>
                            <span className="text-[11px] text-[#EDE9E0]/55 font-mono">
                              {sec.type} · #{sec.anchorId}
                            </span>
                          </div>
                          {canEditWebsite && (
                            <button
                              type="button"
                              onClick={() => void onEditOnSite(details.page.path, sec.anchorId)}
                              className="px-3 py-1.5 rounded-lg bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold inline-flex items-center gap-1.5 shrink-0 cursor-pointer"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                              <span>Edit on page</span>
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'text' && (
                <div className="space-y-4 text-xs">
                  {isCustom ? (
                    <ModularBlockEditor blocks={blocks} onChange={setBlocks} />
                  ) : (
                    <>
                      <p className="text-[#EDE9E0]/65">
                        Fixed copy fields belonging exclusively to <span className="font-bold text-[#EDE9E0]">{details.page.name}</span>. Matches inline edits in the live editor.
                      </p>
                      {details.page.hasDraft && (
                        <div className="p-3 rounded-xl bg-[#D0A873]/15 border border-[#D0A873]/30 text-[#D0A873] text-[11px]">
                          Showing unpublished draft edits overlaid on live copy. Click Save &amp; Publish to push live.
                        </div>
                      )}
                      <div className="space-y-3">
                        {details.textFields.map(field => (
                          <div key={field.path}>
                            <label className="block text-[#EDE9E0]/75 font-semibold mb-1">{field.label}</label>
                            {field.multiline ? (
                              <textarea
                                rows={3}
                                value={textValues[field.path] ?? ''}
                                onChange={e =>
                                  setTextValues(prev => ({ ...prev, [field.path]: e.target.value }))
                                }
                                placeholder={field.placeholder || ''}
                                className="w-full bg-[#031D1C] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                              />
                            ) : (
                              <input
                                type="text"
                                value={textValues[field.path] ?? ''}
                                onChange={e =>
                                  setTextValues(prev => ({ ...prev, [field.path]: e.target.value }))
                                }
                                placeholder={field.placeholder || ''}
                                className="w-full bg-[#031D1C] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
                              />
                            )}
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )}

              {activeTab === 'history' && (
                <div className="space-y-3 text-xs">
                  {versions.length === 0 ? (
                    <div className="p-6 rounded-xl bg-[#031D1C] border border-white/10 text-center text-[#EDE9E0]/60">
                      No saved version snapshots for this page yet. Versions are recorded whenever this page is updated or published.
                    </div>
                  ) : (
                    versions.map(v => {
                      const isComparing = compareVersionId === v.id;
                      return (
                        <div key={v.id} className="p-3.5 rounded-xl bg-[#031D1C] border border-white/10 space-y-2.5">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div>
                              <span className="font-bold text-[#EDE9E0] block">
                                {v.changeNote || `Version ${v.versionNumber || ''}`.trim()}
                              </span>
                              <span className="text-[11px] text-[#EDE9E0]/60">
                                {formatDateTime(v.timestamp)} · {v.author || v.authorEmail || 'Editor'}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                type="button"
                                onClick={() => setCompareVersionId(isComparing ? null : v.id)}
                                className={`px-2.5 py-1.5 rounded-lg border text-[11px] font-semibold inline-flex items-center gap-1 cursor-pointer ${
                                  isComparing
                                    ? 'bg-[#25CDB6]/15 border-[#25CDB6]/40 text-[#25CDB6]'
                                    : 'bg-white/5 hover:bg-white/10 border-white/10 text-[#EDE9E0]/80'
                                }`}
                              >
                                <GitCompare className="w-3 h-3" />
                                <span>{isComparing ? 'Hide compare' : 'Compare'}</span>
                              </button>
                              {canEditWebsite && (
                                <button
                                  type="button"
                                  onClick={() => setConfirmRestore(v)}
                                  className="px-2.5 py-1.5 rounded-lg bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                                >
                                  <RotateCcw className="w-3 h-3" />
                                  <span>Restore</span>
                                </button>
                              )}
                            </div>
                          </div>

                          {isComparing && (
                            <div className="p-3 rounded-lg bg-[#06302F] border border-white/10 space-y-2">
                              {comparedDiffs.length === 0 ? (
                                <p className="text-[11px] text-[#EDE9E0]/60">No differences vs current page state.</p>
                              ) : (
                                comparedDiffs.map((d, idx) => (
                                  <div key={idx} className="text-[11px] space-y-1 border-b border-white/5 pb-1.5 last:border-b-0 last:pb-0">
                                    <span className="font-bold text-[#25CDB6] block">{d.key}</span>
                                    <p className="text-[#D0A873]">Snapshot: {d.snapshotVal || '—'}</p>
                                    <p className="text-[#EDE9E0]/80">Current: {d.currentVal || '—'}</p>
                                  </div>
                                ))
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              )}

              {activeTab === 'redirects' && (
                <div className="space-y-4 text-xs">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-[#EDE9E0]/65">
                      Redirect rules targeting or originating from <span className="font-mono text-[#25CDB6]">{details.page.path}</span>.
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenSeoSubTab();
                      }}
                      className="text-[#25CDB6] hover:underline font-semibold cursor-pointer shrink-0"
                    >
                      Manage all redirects
                    </button>
                  </div>

                  {details.redirects.length === 0 ? (
                    <div className="p-5 rounded-xl bg-[#031D1C] border border-white/10 text-center text-[#EDE9E0]/60">
                      No redirect rules reference this page.
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {details.redirects.map(r => (
                        <div
                          key={r.id}
                          className="p-3 rounded-xl bg-[#031D1C] border border-white/10 flex items-center justify-between gap-3 font-mono text-[11px]"
                        >
                          <span className="truncate">
                            <span className="text-[#D0A873]">{r.from}</span> → <span className="text-[#25CDB6]">{r.to}</span>
                          </span>
                          <span className="px-2 py-0.5 rounded bg-white/10 text-[#EDE9E0] shrink-0">
                            {r.type} · {r.source === 'auto' ? 'Auto' : 'Manual'}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}

                  {canManageSeo && (
                    <form onSubmit={handleQuickAddRedirect} className="p-4 rounded-xl bg-[#031D1C] border border-white/10 space-y-3">
                      <span className="font-bold text-[#EDE9E0] block">Add redirect to this page</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        <input
                          type="text"
                          placeholder="/old-path"
                          value={newRedirectFrom}
                          onChange={e => setNewRedirectFrom(e.target.value)}
                          className="bg-[#06302F] border border-white/10 rounded-lg px-3 py-2 font-mono text-[#EDE9E0]"
                        />
                        <input
                          type="text"
                          placeholder={details.page.path}
                          value={newRedirectTo || details.page.path}
                          onChange={e => setNewRedirectTo(e.target.value)}
                          className="bg-[#06302F] border border-white/10 rounded-lg px-3 py-2 font-mono text-[#EDE9E0]"
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={redirectAdding}
                        className="px-3.5 py-2 rounded-lg bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>{redirectAdding ? 'Adding...' : 'Add 301 Redirect'}</span>
                      </button>
                    </form>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </PortalDrawer>

      <PortalFloatingSaveBar
        visible={Boolean(
          isOpen &&
            canSave &&
            details &&
            isDirty &&
            (activeTab === 'general' || activeTab === 'seo' || activeTab === 'text')
        )}
        zIndexClass="z-[97]"
        title="Unsaved page settings"
        subtitle={
          isCustom
            ? 'Save page settings, SEO, and modular blocks.'
            : 'Publish updates live or save page text as an unpublished draft.'
        }
        error={saveError}
        saving={saving}
        saveLabel="Save & Publish"
        secondaryAction={
          activeTab === 'text' && !isCustom && canEditWebsite
            ? {
                label: 'Save Draft',
                onClick: () => handleSave(true)
              }
            : undefined
        }
        onDiscard={handleDiscard}
        onSave={() => handleSave(false)}
      />

      <PortalConfirmDialog
        isOpen={Boolean(confirmRestore)}
        title="Restore Version Snapshot"
        message={`Restore "${details?.page.name}" to the snapshot from ${formatDateTime(confirmRestore?.timestamp)}? Current live values will be overwritten and recorded in history.`}
        confirmLabel={restoring ? 'Restoring...' : 'Restore Version'}
        loading={restoring}
        onCancel={() => setConfirmRestore(null)}
        onConfirm={() => void handleRestoreVersion()}
      />
    </>
  );
};
