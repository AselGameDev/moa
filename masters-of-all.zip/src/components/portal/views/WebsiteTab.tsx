import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  FileText,
  Menu,
  Sparkles,
  Search,
  AlertCircle,
  Loader2,
  RefreshCw
} from 'lucide-react';
import {
  PageRecord,
  RoleDefinition,
  SiteContent,
  SiteSettings,
  User,
  WebsiteOverviewResponse
} from '../../../types';
import { api } from '../../../services/api';
import { can } from '../../../shared/permissions';
import { getVisibleSubTabs } from '../portalRegistry';
import { ConfirmDialog } from '../ConfirmDialog';
import { WebsiteStatusStrip } from '../website/WebsiteStatusStrip';
import { PagesManagerTab } from '../website/PagesManagerTab';
import { DrawerTabKey, PageSettingsDrawer } from '../website/PageSettingsDrawer';
import { MenusManagerTab } from '../website/MenusManagerTab';
import { BrandSitewideTab } from '../website/BrandSitewideTab';
import { SeoRedirectsTab } from '../website/SeoRedirectsTab';

export type WebsiteSubTab = 'pages' | 'menus' | 'brand' | 'seo';

export interface WebsiteRequestedAction {
  subTab: WebsiteSubTab;
  pageId?: string;
  drawerTab?: DrawerTabKey;
  nonce: number;
}

interface WebsiteTabProps {
  initialSubTab?: WebsiteSubTab | string;
  onSubTabChange?: (sub: WebsiteSubTab) => void;
  requestedAction?: WebsiteRequestedAction | null;
  currentUser: User;
  roles?: RoleDefinition[];
  pages: PageRecord[];
  onSavePage?: (page: PageRecord) => Promise<void>;
  onDeletePage?: (id: string) => Promise<void>;
  settings?: SiteSettings;
  onUpdateSettings?: (settings: Partial<SiteSettings>) => Promise<void>;
  siteContent?: SiteContent;
  onUpdateSiteContent?: (content: SiteContent) => Promise<void>;
  onRefreshData?: () => Promise<void>;
  onEnterEditMode?: (targetRoute?: string) => void | Promise<void>;
  onNavigateSite: (path?: string) => void;
}

const SUBTAB_ICONS: Record<WebsiteSubTab, React.ComponentType<{ className?: string }>> = {
  pages: FileText,
  menus: Menu,
  brand: Sparkles,
  seo: Search
};

export const WebsiteTab: React.FC<WebsiteTabProps> = ({
  initialSubTab = 'pages',
  onSubTabChange,
  requestedAction,
  currentUser,
  roles,
  pages,
  onRefreshData,
  onEnterEditMode,
  onNavigateSite
}) => {
  const visibleSubTabs = useMemo(
    () => getVisibleSubTabs('website', currentUser, roles),
    [currentUser, roles]
  );

  const validIds = useMemo(
    () => visibleSubTabs.map(st => st.id as WebsiteSubTab),
    [visibleSubTabs]
  );

  const normalizeRequestedSubTab = useCallback(
    (req: string | undefined): WebsiteSubTab => {
      if (req === 'navigation' || req === 'footer') return validIds.includes('menus') ? 'menus' : validIds[0] || 'pages';
      if (req === 'editor') return validIds.includes('pages') ? 'pages' : validIds[0] || 'pages';
      if (req && validIds.includes(req as WebsiteSubTab)) return req as WebsiteSubTab;
      return validIds[0] || 'pages';
    },
    [validIds]
  );

  const [subTab, setSubTab] = useState<WebsiteSubTab>(() => normalizeRequestedSubTab(initialSubTab));
  const [overview, setOverview] = useState<WebsiteOverviewResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Page settings drawer state
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerPageId, setDrawerPageId] = useState<string | null>(null);
  const [drawerInitialTab, setDrawerInitialTab] = useState<DrawerTabKey>('general');

  // Unsaved changes guard across sub-tabs
  const [menusDirty, setMenusDirty] = useState(false);
  const [brandDirty, setBrandDirty] = useState(false);
  const [seoDirty, setSeoDirty] = useState(false);
  const [pendingSubTab, setPendingSubTab] = useState<WebsiteSubTab | null>(null);

  useEffect(() => {
    setSubTab(normalizeRequestedSubTab(initialSubTab));
  }, [initialSubTab, normalizeRequestedSubTab]);

  useEffect(() => {
    if (!requestedAction) return;
    const normalized = normalizeRequestedSubTab(requestedAction.subTab);
    setPendingSubTab(null);
    setMenusDirty(false);
    setBrandDirty(false);
    setSeoDirty(false);
    setSubTab(normalized);
    onSubTabChange?.(normalized);
    if (requestedAction.pageId) {
      setDrawerPageId(requestedAction.pageId);
      setDrawerInitialTab(requestedAction.drawerTab || 'general');
      setDrawerOpen(true);
    }
  }, [requestedAction, normalizeRequestedSubTab, onSubTabChange]);

  const canEditWebsite = can(currentUser, 'website.edit', roles);
  const canManagePages = can(currentUser, 'pages.manage', roles);
  const canManageSeo = can(currentUser, 'seo.manage', roles);
  const canAccessBrand = validIds.includes('brand');

  const fetchOverview = useCallback(async (quiet = false) => {
    if (!quiet) setLoading(true);
    setLoadError(null);
    try {
      const data = await api.getWebsiteOverview();
      setOverview(data);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Failed to load Website hub overview.');
    } finally {
      if (!quiet) setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchOverview();
  }, [fetchOverview]);

  const syncAfterWebsiteMutation = useCallback(async () => {
    await fetchOverview(true);
    if (onRefreshData) {
      await onRefreshData();
    }
  }, [fetchOverview, onRefreshData]);

  const isCurrentSubTabDirty =
    (subTab === 'menus' && menusDirty) ||
    (subTab === 'brand' && brandDirty) ||
    (subTab === 'seo' && seoDirty);

  const selectSubTab = (target: WebsiteSubTab) => {
    if (target === subTab) return;
    if (isCurrentSubTabDirty) {
      setPendingSubTab(target);
      return;
    }
    setSubTab(target);
    onSubTabChange?.(target);
  };

  const handleConfirmLeaveDirtySubTab = () => {
    if (!pendingSubTab) return;
    const next = pendingSubTab;
    setPendingSubTab(null);
    setMenusDirty(false);
    setBrandDirty(false);
    setSeoDirty(false);
    setSubTab(next);
    onSubTabChange?.(next);
  };

  const handleOpenDrawer = (pageId: string, tab: DrawerTabKey = 'general') => {
    setDrawerPageId(pageId);
    setDrawerInitialTab(tab);
    setDrawerOpen(true);
  };

  const handleOpenAttentionSubTab = (
    targetSubTab: 'pages' | 'menus' | 'brand' | 'seo',
    pageId?: string,
    drawerTab?: DrawerTabKey
  ) => {
    if (validIds.includes(targetSubTab)) {
      if (subTab === 'menus' && menusDirty && targetSubTab !== 'menus') {
        setMenusDirty(false);
      }
      setSubTab(targetSubTab);
      onSubTabChange?.(targetSubTab);
    }
    if (targetSubTab === 'pages' && pageId) {
      handleOpenDrawer(pageId, drawerTab || 'general');
    }
  };

  const handleOpenLiveEditor = async (path?: string, sectionAnchorId?: string) => {
    if (!onEnterEditMode) return;
    const cleanPath = path || '/';
    const route = sectionAnchorId
      ? `${cleanPath}${cleanPath.includes('?') ? '&' : '?'}section=${encodeURIComponent(sectionAnchorId)}`
      : cleanPath;
    setDrawerOpen(false);
    await onEnterEditMode(route);
  };

  const handlePublishPageDraft = async (pageId: string) => {
    const updated = await api.publishWebsitePageDraft(pageId);
    setOverview(updated);
    if (onRefreshData) await onRefreshData();
  };

  const handleDiscardPageDraft = async (pageId: string) => {
    const updated = await api.discardWebsitePageDraft(pageId);
    setOverview(updated);
    if (onRefreshData) await onRefreshData();
  };

  const handlePublishAllDrafts = async () => {
    const updated = await api.publishAllWebsiteDrafts();
    setOverview(updated);
    if (onRefreshData) await onRefreshData();
  };

  if (visibleSubTabs.length === 0) {
    return (
      <div className="p-8 rounded-2xl bg-[#031D1C] border border-white/10 text-center text-xs text-[#EDE9E0]/65">
        You do not have permissions to manage Website sections.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Header (consistent with Team & Settings) */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#EDE9E0]">Website &amp; Publishing</h1>
          <p className="text-xs text-[#EDE9E0]/60 mt-1">
            Manage site pages, navigation menus, brand identity, announcement bar, and SEO redirects.
          </p>
        </div>
      </div>

      {/* Persistent W2 Status Strip */}
      <WebsiteStatusStrip
        overview={overview}
        canEditWebsite={canEditWebsite}
        onPublishPageDraft={handlePublishPageDraft}
        onDiscardPageDraft={handleDiscardPageDraft}
        onPublishAllDrafts={handlePublishAllDrafts}
        onOpenLiveEditor={() => handleOpenLiveEditor('/')}
        onViewPublicSite={() => onNavigateSite('/')}
      />

      {/* W1 Registry-Driven Sub-Tabs (Pages | Menus | Brand & site-wide | SEO & redirects) */}
      <div
        className="flex items-center gap-1.5 p-1 bg-[#031D1C] rounded-2xl border border-white/10 w-full sm:w-fit max-w-full overflow-x-auto no-scrollbar [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden text-xs"
        role="tablist"
        aria-label="Website management sections"
      >
        {visibleSubTabs.map(tab => {
          const id = tab.id as WebsiteSubTab;
          const Icon = SUBTAB_ICONS[id] || FileText;
          const isActive = subTab === id;
          const count = id === 'pages' ? overview?.pages.length : undefined;
          return (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={isActive}
              onClick={() => selectSubTab(id)}
              className={`h-9 px-3.5 rounded-xl font-bold inline-flex items-center gap-2 whitespace-nowrap transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#17A491] text-[#06302F] shadow-sm'
                  : 'text-[#EDE9E0]/65 hover:text-white hover:bg-white/5'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span>{tab.label}</span>
              {typeof count === 'number' && (
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono tabular-nums ${
                    isActive ? 'bg-[#06302F]/20 text-[#06302F]' : 'bg-white/10 text-[#EDE9E0]/75'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Loading / Error State */}
      {loading && !overview ? (
        <div className="p-12 rounded-2xl bg-[#031D1C] border border-white/10 flex flex-col items-center justify-center gap-3 text-xs text-[#EDE9E0]/65">
          <Loader2 className="w-6 h-6 animate-spin text-[#25CDB6]" />
          <span>Loading Website workspace...</span>
        </div>
      ) : loadError && !overview ? (
        <div className="p-6 rounded-2xl bg-red-950/50 border border-red-500/30 text-xs text-red-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{loadError}</span>
          </div>
          <button
            type="button"
            onClick={() => void fetchOverview()}
            className="h-8 px-3 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold inline-flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Retry</span>
          </button>
        </div>
      ) : overview ? (
        <>
          {subTab === 'pages' && (
            <PagesManagerTab
              overview={overview}
              pages={pages}
              canEditWebsite={canEditWebsite}
              canManagePages={canManagePages}
              onOpenDrawer={handleOpenDrawer}
              onEditOnSite={handleOpenLiveEditor}
              onViewPage={path => onNavigateSite(path)}
              onOpenAttentionSubTab={handleOpenAttentionSubTab}
              onRefresh={syncAfterWebsiteMutation}
            />
          )}

          {subTab === 'menus' && (
            <MenusManagerTab
              overview={overview}
              onDirtyChange={setMenusDirty}
              onSaved={syncAfterWebsiteMutation}
            />
          )}

          {subTab === 'brand' && (
            <BrandSitewideTab
              overview={overview}
              onDirtyChange={setBrandDirty}
              onSaved={syncAfterWebsiteMutation}
            />
          )}

          {subTab === 'seo' && (
            <SeoRedirectsTab
              overview={overview}
              canAccessBrand={canAccessBrand}
              onDirtyChange={setSeoDirty}
              onOpenPageSeoDrawer={pageId => handleOpenDrawer(pageId, 'seo')}
              onOpenBrandTab={() => selectSubTab('brand')}
              onSaved={syncAfterWebsiteMutation}
            />
          )}
        </>
      ) : null}

      {/* W3 Accessible Right-Side Page Settings Drawer */}
      <PageSettingsDrawer
        isOpen={drawerOpen}
        pageId={drawerPageId}
        initialTab={drawerInitialTab}
        titleTemplate={overview?.seo.titleTemplate || '{page} · {site}'}
        siteName={overview?.seo.siteName || 'Masters Of All'}
        defaultShareImage={overview?.brand.shareImageUrl || ''}
        canEditWebsite={canEditWebsite || canManagePages}
        canManageSeo={canManageSeo}
        onClose={() => setDrawerOpen(false)}
        onSaved={syncAfterWebsiteMutation}
        onEditOnSite={handleOpenLiveEditor}
        onNavigateSite={path => onNavigateSite(path)}
        onOpenSeoSubTab={() => {
          setDrawerOpen(false);
          if (validIds.includes('seo')) selectSubTab('seo');
        }}
      />

      <ConfirmDialog
        isOpen={pendingSubTab !== null}
        title="Unsaved Changes"
        message="You have unsaved changes in this section. Leave anyway and discard your edits?"
        confirmLabel="Discard & Switch"
        isDestructive
        onCancel={() => setPendingSubTab(null)}
        onConfirm={handleConfirmLeaveDirtySubTab}
      />
    </div>
  );
};
