import crypto from 'crypto';
import {
  CORE_AND_SYSTEM_PAGES,
  CORE_PAGE_IDS,
  extractPageDraftSlice,
  extractPageTextValues,
  applyPageTextValues,
  formatSeoTitle,
  getCorePageDefinition,
  validateSeoTitleTemplate
} from '../../src/shared/pageRegistry';
import { isSafeUrl, normalizeSlug } from '../../src/shared/url';
import type {
  AnnouncementBarConfig,
  ContentHistorySnapshot,
  FooterColumn,
  NavigationItem,
  PageRecord,
  RedirectRule,
  SiteContent,
  SocialLink,
  WebsiteAttentionItem,
  WebsiteDraftSummary,
  WebsiteFooterColumnConfig,
  WebsiteMenusConfig,
  WebsiteOverviewResponse,
  WebsitePageListEntry,
  WebsitePageSettingsResponse,
  WebsiteState
} from '../../src/types/index';
import type { DatabaseState } from './schema';
import {
  ConflictError,
  addAutoRedirect,
  appendActivity,
  normalizeRedirectPath,
  wouldCreateRedirectChain,
  wouldCreateRedirectLoop
} from './repositories';
import {
  buildDefaultFooterColumns,
  createDefaultWebsiteState,
  normalizeHeaderMenuItems
} from './websiteDefaults';
import { validateBlocksUrls, validateSafeUrlField } from '../utils/urlValidation';

export function ensureWebsiteState(db: DatabaseState): WebsiteState {
  if (!db.website || typeof db.website !== 'object') {
    db.website = createDefaultWebsiteState(db.settings, db.pageContent);
  }
  if (!db.website.pagesMeta) {
    db.website.pagesMeta = createDefaultWebsiteState(db.settings, db.pageContent).pagesMeta;
  }
  if (!db.website.pageDrafts) {
    db.website.pageDrafts = {};
  }
  if (!db.website.menus) {
    db.website.menus = createDefaultWebsiteState(db.settings, db.pageContent).menus;
  }
  return db.website;
}

export function getEffectiveDraftPages(db: DatabaseState): WebsiteDraftSummary[] {
  const website = ensureWebsiteState(db);
  const byId = new Map<string, WebsiteDraftSummary>();

  for (const [pageId, draft] of Object.entries(website.pageDrafts || {})) {
    const core = getCorePageDefinition(pageId);
    const custom = !core ? (db.pages || []).find(p => p.id === pageId && !p.deletedAt) : undefined;
    if (!core && !custom) continue;
    const path = core ? core.path : `/pages/${custom!.slug}`;
    byId.set(pageId, {
      pageId,
      pageName: core ? core.name : custom!.title,
      path,
      updatedAt: draft.updatedAt || new Date().toISOString(),
      updatedByName: draft.updatedByName || 'Editor',
      changedFieldsCount: Object.keys(draft.data || {}).length || 1
    });
  }

  // Include any legacy draftContent slices not yet reflected in pageDrafts
  if (db.draftContent && typeof db.draftContent === 'object') {
    const nowIso = new Date().toISOString();
    for (const core of CORE_AND_SYSTEM_PAGES) {
      if (byId.has(core.id)) continue;
      const changed = extractPageDraftSlice(db.pageContent, db.draftContent, core.id);
      const count = Object.keys(changed).length;
      if (count > 0) {
        byId.set(core.id, {
          pageId: core.id,
          pageName: core.name,
          path: core.path,
          updatedAt: nowIso,
          updatedByName: 'Editor',
          changedFieldsCount: count
        });
      }
    }
  }

  return Array.from(byId.values());
}

export function computeSitemapUrls(
  db: DatabaseState,
  baseUrl: string
): Array<{ loc: string; priority: string; lastmod?: string }> {
  const website = ensureWebsiteState(db);
  const settings = db.settings;
  if (settings.seoDefaults?.sitemapEnabled === false) return [];

  const urls: Array<{ loc: string; priority: string; lastmod?: string }> = [];
  const corePriority: Record<string, string> = {
    home: '1.0',
    about: '0.8',
    departments: '0.9',
    projects: '0.9',
    products: '0.8',
    contact: '0.7'
  };

  const activeProducts = (db.products || []).filter(p => p.publicationStatus === 'Published' && !p.deletedAt);

  for (const core of CORE_AND_SYSTEM_PAGES) {
    if (core.kind === 'system') continue;
    if (core.id === 'products' && activeProducts.length === 0 && !settings.alwaysShowProducts) continue;
    if (website.pagesMeta[core.id]?.noindex) continue;
    urls.push({
      loc: `${baseUrl}${core.path === '/' ? '/' : core.path}`,
      priority: corePriority[core.id] || '0.7'
    });
  }

  const publishedDepts = (db.departments || []).filter(d => d.published && !d.deletedAt);
  for (const dept of publishedDepts) {
    let pathSegment = `departments/${encodeURIComponent(dept.slug)}`;
    if (dept.kind === 'sector') {
      const parentId = dept.parentDepartmentId || 'dept-rdd';
      const parentDept = publishedDepts.find(d => d.id === parentId && d.kind !== 'sector');
      const parentSlug = parentDept?.slug || 'rdd';
      pathSegment = `departments/${encodeURIComponent(parentSlug)}/${encodeURIComponent(dept.slug)}`;
    }
    urls.push({
      loc: `${baseUrl}/${pathSegment}`,
      priority: '0.8',
      lastmod: (dept.updatedAt || dept.createdAt || '').split('T')[0] || undefined
    });
  }

  for (const proj of (db.projects || []).filter(p => p.publicationStatus === 'Published' && !p.deletedAt)) {
    if (proj.visibility !== 'Members only') {
      urls.push({
        loc: `${baseUrl}/projects/${encodeURIComponent(proj.slug)}`,
        priority: '0.8',
        lastmod: (proj.updatedAt || proj.createdAt || '').split('T')[0] || undefined
      });
    }
  }

  for (const prod of activeProducts) {
    urls.push({
      loc: `${baseUrl}/products/${encodeURIComponent(prod.slug)}`,
      priority: '0.8',
      lastmod: (prod.updatedAt || prod.createdAt || '').split('T')[0] || undefined
    });
  }

  for (const pg of (db.pages || []).filter(p => p.status === 'Published' && !p.deletedAt)) {
    if (!pg.seo?.noindex) {
      urls.push({
        loc: `${baseUrl}/pages/${encodeURIComponent(pg.slug)}`,
        priority: '0.7',
        lastmod: (pg.updatedAt || pg.createdAt || '').split('T')[0] || undefined
      });
    }
  }

  return urls;
}

function isPathInHeader(header: NavigationItem[], pathStr: string, pageId: string): boolean {
  const normTarget = normalizeRedirectPath(pathStr).toLowerCase();
  return header.some(item => {
    if (item.visible === false) return false;
    if (item.pageId === pageId) return true;
    const itemPath = normalizeRedirectPath(item.path || '').toLowerCase();
    if (normTarget === '/' && (itemPath === '/' || itemPath === '/home')) return true;
    return itemPath === normTarget;
  });
}

function isPathInFooter(menus: WebsiteMenusConfig, pathStr: string, pageId: string): boolean {
  const normTarget = normalizeRedirectPath(pathStr).toLowerCase();
  for (const col of menus.footer.columns || []) {
    if (!col.visible) continue;
    if (col.kind === 'auto-header' && col.sameAsHeader !== false) {
      if (isPathInHeader(menus.header, pathStr, pageId)) return true;
    } else if (Array.isArray(col.links)) {
      const hit = col.links.some(l => {
        const u = normalizeRedirectPath(l.url || '').toLowerCase();
        if (normTarget === '/' && (u === '/' || u === '/home')) return true;
        return u === normTarget;
      });
      if (hit) return true;
    }
  }
  return false;
}

export function buildWebsitePageEntries(db: DatabaseState): WebsitePageListEntry[] {
  const website = ensureWebsiteState(db);
  const settings = db.settings;
  const siteName = settings.siteName || 'Masters Of All';
  const tpl = settings.seoDefaults?.titleTemplate || '{page} · {site}';
  const hasPublishedProducts = (db.products || []).some(p => p.publicationStatus === 'Published' && !p.deletedAt);
  const drafts = getEffectiveDraftPages(db);
  const draftMap = new Map(drafts.map(d => [d.pageId, d]));

  const entries: WebsitePageListEntry[] = [];

  for (const core of CORE_AND_SYSTEM_PAGES) {
    const meta = website.pagesMeta[core.id] || { pageId: core.id, version: 1 };
    const draft = draftMap.get(core.id);
    let status: WebsitePageListEntry['status'] = 'Published';
    if (draft) {
      status = 'Draft changes';
    } else if (core.id === 'products') {
      if (settings.alwaysShowProducts) status = 'Published';
      else status = hasPublishedProducts ? 'Auto-visible' : 'Hidden';
    }

    entries.push({
      id: core.id,
      name: core.name,
      path: core.path,
      kind: core.kind,
      description: core.description,
      status,
      hasDraft: Boolean(draft),
      lastEditedAt: meta.lastEditedAt || website.lastPublishedAt,
      lastEditedByName: meta.lastEditedByName || website.lastPublishedByName || 'System',
      lastPublishedAt: meta.lastPublishedAt || website.lastPublishedAt,
      lastPublishedByName: meta.lastPublishedByName || website.lastPublishedByName || 'System',
      inHeader: isPathInHeader(website.menus.header, core.path, core.id),
      inFooter: isPathInFooter(website.menus, core.path, core.id),
      seo: {
        title: meta.seoTitle || '',
        description: meta.seoDescription || '',
        shareImage: meta.seoShareImage || '',
        noindex: Boolean(meta.noindex)
      },
      resolvedSeoTitle: meta.seoTitle?.trim()
        ? meta.seoTitle.trim()
        : core.id === 'home'
        ? formatSeoTitle(tpl, siteName, siteName)
        : formatSeoTitle(tpl, core.name, siteName),
      version: meta.version || 1
    });
  }

  for (const pg of (db.pages || []).filter(p => !p.deletedAt)) {
    const pagePath = `/pages/${pg.slug}`;
    const draft = draftMap.get(pg.id);
    let status: WebsitePageListEntry['status'] = pg.status === 'Published' ? 'Published' : pg.status === 'Hidden' ? 'Hidden' : 'Draft changes';
    if (draft) status = 'Draft changes';

    entries.push({
      id: pg.id,
      name: pg.title,
      path: pagePath,
      kind: 'custom',
      description: `${pg.template} custom page (${pg.blocks?.length || 0} blocks)`,
      status,
      hasDraft: Boolean(draft),
      lastEditedAt: pg.lastEditedAt || pg.updatedAt || pg.createdAt,
      lastEditedByName: pg.lastEditedByName || 'Editor',
      lastPublishedAt: pg.lastPublishedAt || (pg.status === 'Published' ? pg.updatedAt : undefined),
      lastPublishedByName: pg.lastPublishedByName || 'Editor',
      inHeader: isPathInHeader(website.menus.header, pagePath, pg.id),
      inFooter: isPathInFooter(website.menus, pagePath, pg.id),
      seo: {
        title: pg.seo?.title || '',
        description: pg.seo?.description || '',
        shareImage: pg.seo?.shareImage || '',
        noindex: Boolean(pg.seo?.noindex)
      },
      resolvedSeoTitle: pg.seo?.title?.trim()
        ? pg.seo.title.trim()
        : formatSeoTitle(tpl, pg.title, siteName),
      version: pg.version || 1,
      customPage: pg
    });
  }

  return entries;
}

export function buildWebsiteOverview(db: DatabaseState): WebsiteOverviewResponse {
  const website = ensureWebsiteState(db);
  const settings = db.settings;
  const pages = buildWebsitePageEntries(db);
  const draftPages = getEffectiveDraftPages(db);
  const redirects = settings.redirects || [];
  const hasPublishedProducts = (db.products || []).some(p => p.publicationStatus === 'Published' && !p.deletedAt);

  const attentionItems: WebsiteAttentionItem[] = [];

  for (const pg of pages) {
    if (pg.kind !== 'system' && (!pg.seo.description || !pg.seo.description.trim())) {
      attentionItems.push({
        id: `att-meta-${pg.id}`,
        kind: 'missing_meta',
        severity: 'warning',
        pageId: pg.id,
        pageName: pg.name,
        title: `${pg.name} has no meta description`,
        message: 'Search engines will fall back to your site default or page excerpt.',
        fixAction: { subTab: 'pages', pageId: pg.id, drawerTab: 'seo' }
      });
    }
    if (pg.hasDraft) {
      attentionItems.push({
        id: `att-draft-${pg.id}`,
        kind: 'unpublished_draft',
        severity: 'info',
        pageId: pg.id,
        pageName: pg.name,
        title: `${pg.name} has unpublished changes`,
        message: 'Review draft edits and publish or discard them.',
        fixAction: { subTab: 'pages', pageId: pg.id }
      });
    }
    if (pg.kind === 'custom' && pg.status === 'Published' && !pg.inHeader && !pg.inFooter) {
      attentionItems.push({
        id: `att-orphan-${pg.id}`,
        kind: 'unlinked_custom_page',
        severity: 'info',
        pageId: pg.id,
        pageName: pg.name,
        title: `"${pg.name}" is not in any menu`,
        message: 'Add this custom page to Header or Footer menu so visitors can find it.',
        fixAction: { subTab: 'pages', pageId: pg.id, drawerTab: 'general' }
      });
    }
  }

  if (!settings.shareImageUrl || !settings.shareImageUrl.trim()) {
    attentionItems.push({
      id: 'att-share-image',
      kind: 'missing_share_image',
      severity: 'warning',
      title: 'Default social share image is missing',
      message: 'Set a 1200×630 share image under Brand & site-wide.',
      fixAction: { subTab: 'brand' }
    });
  }

  for (const r of redirects) {
    if (
      wouldCreateRedirectLoop(redirects, r.from, r.to, r.id) ||
      wouldCreateRedirectChain(redirects, r.from, r.to, r.id)
    ) {
      attentionItems.push({
        id: `att-redir-${r.id}`,
        kind: 'redirect_problem',
        severity: 'error',
        title: `Redirect issue: ${r.from} → ${r.to}`,
        message: 'This rule forms a multi-hop chain or redirect loop.',
        fixAction: { subTab: 'seo' }
      });
    }
  }

  const ab = settings.announcementBar || { enabled: false, text: '' };
  const sitemapUrlCount = computeSitemapUrls(db, '').length;

  return {
    siteStatus: 'Live',
    lastPublishedAt: website.lastPublishedAt,
    lastPublishedByName: website.lastPublishedByName || 'System',
    unpublishedCount: draftPages.length,
    draftPages,
    attentionItems,
    pages,
    menus: website.menus,
    alwaysShowProducts: Boolean(settings.alwaysShowProducts),
    hasPublishedProducts,
    brand: {
      version: website.brandVersion || 1,
      moaLogoUrl: settings.moaLogoUrl || '/drawing1.png',
      rddLogoUrl: settings.rddLogoUrl || '/5320.jpg',
      loaderLogoUrl: website.sameLoaderAsPrimary ? (settings.moaLogoUrl || '/drawing1.png') : (settings.loaderLogoUrl || settings.moaLogoUrl || '/drawing1.png'),
      sameLoaderAsPrimary: Boolean(website.sameLoaderAsPrimary),
      faviconUrl: settings.faviconUrl || '/drawing1.png',
      shareImageUrl: settings.shareImageUrl || ''
    },
    announcement: {
      version: website.announcementVersion || 1,
      enabled: Boolean(ab.enabled),
      text: ab.text || '',
      linkUrl: ab.linkUrl || '',
      linkLabel: ab.linkLabel || '',
      startDate: ab.startDate || '',
      endDate: ab.endDate || ab.expiresAt || '',
      expiresAt: ab.expiresAt || ab.endDate || ''
    },
    social: {
      version: website.socialVersion || 1,
      links: (settings.socialLinks || []).map(l => ({
        ...l,
        visible: typeof l.visible === 'boolean' ? l.visible : true
      }))
    },
    seo: {
      version: website.seoVersion || 1,
      siteName: settings.siteName || 'Masters Of All',
      tagline: settings.tagline || '',
      titleTemplate: settings.seoDefaults?.titleTemplate || '{page} · {site}',
      description: settings.seoDefaults?.description || '',
      shareImageUrl: settings.shareImageUrl || '',
      sitemapEnabled: settings.seoDefaults?.sitemapEnabled !== false,
      robotsEnabled: settings.seoDefaults?.robotsEnabled !== false,
      sitemapUrlCount
    },
    redirects
  };
}

export function buildPageSettingsResponse(db: DatabaseState, pageId: string): WebsitePageSettingsResponse | null {
  const entries = buildWebsitePageEntries(db);
  const entry = entries.find(p => p.id === pageId);
  if (!entry) return null;

  const coreDef = getCorePageDefinition(pageId);
  const redirects = (db.settings.redirects || []).filter(r => {
    const f = normalizeRedirectPath(r.from).toLowerCase();
    const t = normalizeRedirectPath(r.to).toLowerCase();
    const p = normalizeRedirectPath(entry.path).toLowerCase();
    return f === p || t === p;
  });

  if (coreDef) {
    const draftSlice = extractPageDraftSlice(db.pageContent, db.draftContent, pageId);
    const storedDraft = db.website?.pageDrafts?.[pageId]?.data || {};
    return {
      page: entry,
      sections: coreDef.sections,
      textFields: coreDef.textFields,
      textValues: extractPageTextValues(db.pageContent, pageId),
      draftTextValues: { ...draftSlice, ...storedDraft },
      redirects,
      defaultShareImageUrl: db.settings.shareImageUrl || '',
      siteName: db.settings.siteName || 'Masters Of All',
      titleTemplate: db.settings.seoDefaults?.titleTemplate || '{page} · {site}'
    };
  }

  // Custom page sections map cleanly to its blocks
  const customSections = (entry.customPage?.blocks || []).map((blk, i) => ({
    id: blk.id,
    name: `${blk.type.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}: ${String(blk.config?.heading || blk.config?.text || `Block ${i + 1}`).slice(0, 40)}`,
    type: blk.type,
    anchorId: blk.sectionSettings?.anchorId || `block-${blk.id}`
  }));

  return {
    page: entry,
    sections: customSections,
    textFields: [],
    textValues: {},
    draftTextValues: {},
    redirects,
    defaultShareImageUrl: db.settings.shareImageUrl || '',
    siteName: db.settings.siteName || 'Masters Of All',
    titleTemplate: db.settings.seoDefaults?.titleTemplate || '{page} · {site}'
  };
}

export function getPageHistoryList(db: DatabaseState, pageId: string): ContentHistorySnapshot[] {
  const all = db.contentHistory || [];
  const coreDef = getCorePageDefinition(pageId);
  const list = all.filter(snap => {
    if (snap.entityId === pageId) return true;
    if (coreDef && snap.entityId === 'pageContent' && snap.snapshot && typeof snap.snapshot === 'object') {
      const key = coreDef.contentSectionKey as string;
      return key in snap.snapshot;
    }
    return false;
  });

  return list.map(snap => {
    if (coreDef && snap.entityId === 'pageContent') {
      return {
        ...snap,
        snapshot: extractPageTextValues(snap.snapshot as unknown as SiteContent, pageId)
      };
    }
    return snap;
  });
}

function recordPageSnapshot(
  db: DatabaseState,
  pageId: string,
  title: string,
  snapshotData: Record<string, unknown>,
  actor: { id: string; email: string; name: string },
  changeNote: string
): void {
  if (!Array.isArray(db.contentHistory)) db.contentHistory = [];
  const existingCount = db.contentHistory.filter(h => h.entityId === pageId).length;
  db.contentHistory.unshift({
    id: `snap-${Date.now()}-${crypto.randomBytes(2).toString('hex')}`,
    entityType: 'page',
    entityId: pageId,
    title,
    versionNumber: existingCount + 1,
    author: actor.name,
    authorEmail: actor.email,
    timestamp: new Date().toISOString(),
    snapshot: snapshotData,
    changeNote
  });
  db.contentHistory = db.contentHistory.slice(0, 120);
}

function syncLegacyNavigationFromMenus(db: DatabaseState, menus: WebsiteMenusConfig): void {
  db.website!.menus = menus;
  db.settings.navigation = menus.header.filter(item => item.visible !== false);
  db.settings.footerText = menus.footer.blurb;
  const exploreCol = menus.footer.columns.find(c => c.id === 'explore');
  const exploreLinks =
    exploreCol && exploreCol.sameAsHeader === false
      ? (exploreCol.links || [])
      : menus.header
          .filter(i => i.visible !== false)
          .map(i => ({ label: i.label, url: i.path, isExternal: i.isExternal, newTab: i.newTab }));
  const legalCol = menus.footer.columns.find(c => c.id === 'legal');
  const legacyCols: FooterColumn[] = [
    { id: 'explore', title: exploreCol?.title || 'Explore', links: exploreLinks }
  ];
  if (legalCol && legalCol.visible && Array.isArray(legalCol.links)) {
    legacyCols.push({ id: 'legal', title: legalCol.title || 'Legal', links: legalCol.links });
  }
  db.settings.footerColumns = legacyCols;
  db.pageContent.footer = {
    ...db.pageContent.footer,
    exploreHeading: exploreCol?.title || db.pageContent.footer.exploreHeading,
    departmentsHeading:
      menus.footer.columns.find(c => c.id === 'departments')?.title || db.pageContent.footer.departmentsHeading,
    sectorsHeading:
      menus.footer.columns.find(c => c.id === 'sectors')?.title || db.pageContent.footer.sectorsHeading,
    communityHeading:
      menus.footer.columns.find(c => c.id === 'community')?.title || db.pageContent.footer.communityHeading,
    blurb: menus.footer.blurb,
    copyrightSuffix: menus.footer.copyrightText
  };
}

function togglePageMenuMembership(
  db: DatabaseState,
  pageId: string,
  pageLabel: string,
  pagePath: string,
  options: { inHeader?: boolean; inFooter?: boolean },
  actorName: string
): void {
  const website = ensureWebsiteState(db);
  const menus = JSON.parse(JSON.stringify(website.menus)) as WebsiteMenusConfig;
  const normPath = normalizeRedirectPath(pagePath).toLowerCase();

  if (typeof options.inHeader === 'boolean') {
    const idx = menus.header.findIndex(
      i => i.pageId === pageId || normalizeRedirectPath(i.path).toLowerCase() === normPath
    );
    if (options.inHeader) {
      if (idx >= 0) {
        menus.header[idx].visible = true;
      } else {
        menus.header.push({
          id: `nav-${pageId}-${Date.now()}`,
          label: pageLabel,
          path: pagePath,
          pageId,
          visible: true,
          isCore: CORE_PAGE_IDS.has(pageId),
          newTab: false
        });
      }
    } else if (pagePath !== '/') {
      if (idx >= 0) {
        if (menus.header[idx].isCore) {
          menus.header[idx].visible = false;
        } else {
          menus.header.splice(idx, 1);
        }
      }
    }
  }

  if (typeof options.inFooter === 'boolean') {
    const exploreCol = menus.footer.columns.find(c => c.id === 'explore');
    if (exploreCol) {
      if (exploreCol.sameAsHeader !== false) {
        const currentlyIn = isPathInHeader(menus.header, pagePath, pageId);
        if (options.inFooter !== currentlyIn) {
          // Materialize explore links so header and footer can differ independently
          exploreCol.sameAsHeader = false;
          exploreCol.links = menus.header
            .filter(i => i.visible !== false)
            .map(i => ({ label: i.label, url: i.path, isExternal: i.isExternal, newTab: i.newTab }));
        }
      }
      if (exploreCol.sameAsHeader === false) {
        const links = exploreCol.links || [];
        const existingIdx = links.findIndex(l => normalizeRedirectPath(l.url).toLowerCase() === normPath);
        if (options.inFooter && existingIdx < 0) {
          links.push({ label: pageLabel, url: pagePath, isExternal: false, newTab: false });
        } else if (!options.inFooter && existingIdx >= 0) {
          links.splice(existingIdx, 1);
        }
        exploreCol.links = links;
      }
    }
  }

  menus.updatedAt = new Date().toISOString();
  menus.updatedByName = actorName;
  syncLegacyNavigationFromMenus(db, menus);
}

export function updatePageSettingsInDb(
  db: DatabaseState,
  pageId: string,
  payload: Record<string, unknown>,
  actor: { id: string; email: string; name: string }
): WebsitePageSettingsResponse {
  const website = ensureWebsiteState(db);
  const coreDef = getCorePageDefinition(pageId);
  const nowIso = new Date().toISOString();
  const expectedVersion = typeof payload.version === 'number' ? payload.version : undefined;

  const urlErr =
    validateSafeUrlField((payload.seo as Record<string, unknown> | undefined)?.shareImage, 'seo.shareImage') ||
    validateBlocksUrls(payload.blocks, 'blocks');
  if (urlErr) throw new Error(urlErr);

  if (coreDef) {
    const meta = website.pagesMeta[pageId] || { pageId, version: 1 };
    if (expectedVersion !== undefined && meta.version !== expectedVersion) {
      throw new ConflictError(`"${coreDef.name}" was edited by someone else. Reload the drawer to get the latest version.`);
    }

    const seoIn = (payload.seo && typeof payload.seo === 'object' ? payload.seo : null) as Record<string, unknown> | null;
    if (seoIn) {
      if (typeof seoIn.title === 'string') meta.seoTitle = seoIn.title;
      if (typeof seoIn.description === 'string') meta.seoDescription = seoIn.description;
      if (typeof seoIn.shareImage === 'string') meta.seoShareImage = seoIn.shareImage.trim();
      if (typeof seoIn.noindex === 'boolean') meta.noindex = seoIn.noindex;
    }

    if (payload.textValues && typeof payload.textValues === 'object') {
      if (payload.saveAsDraft === true) {
        const draftSlice = extractPageDraftSlice(
          db.pageContent,
          applyPageTextValues(db.pageContent, pageId, payload.textValues as Record<string, unknown>) as unknown as Partial<SiteContent>,
          pageId
        );
        if (Object.keys(draftSlice).length > 0) {
          website.pageDrafts[pageId] = {
            pageId,
            title: coreDef.name,
            data: draftSlice,
            updatedAt: nowIso,
            updatedById: actor.id,
            updatedByName: actor.name
          };
          db.draftContent = applyPageTextValues(
            (db.draftContent as unknown as SiteContent) || ({} as SiteContent),
            pageId,
            draftSlice
          );
        } else {
          delete website.pageDrafts[pageId];
        }
      } else {
        const currentValues = extractPageTextValues(db.pageContent, pageId);
        recordPageSnapshot(db, pageId, coreDef.name, currentValues, actor, `Saved ${coreDef.name} text fields`);
        db.pageContent = applyPageTextValues(db.pageContent, pageId, payload.textValues as Record<string, unknown>);
        delete website.pageDrafts[pageId];
        if (db.draftContent && typeof db.draftContent === 'object') {
          const draftObj = db.draftContent as unknown as Record<string, Record<string, unknown> | undefined>;
          for (const field of coreDef.textFields) {
            const [sec, key] = field.path.split('.');
            if (draftObj[sec]) delete draftObj[sec]![key];
          }
        }
        meta.lastPublishedAt = nowIso;
        meta.lastPublishedByName = actor.name;
        website.lastPublishedAt = nowIso;
        website.lastPublishedById = actor.id;
        website.lastPublishedByName = actor.name;
      }
    }

    if (typeof payload.inHeader === 'boolean' || typeof payload.inFooter === 'boolean') {
      togglePageMenuMembership(
        db,
        coreDef.id,
        coreDef.name,
        coreDef.path,
        {
          inHeader: typeof payload.inHeader === 'boolean' ? payload.inHeader : undefined,
          inFooter: typeof payload.inFooter === 'boolean' ? payload.inFooter : undefined
        },
        actor.name
      );
    }

    meta.lastEditedAt = nowIso;
    meta.lastEditedByName = actor.name;
    meta.version = (meta.version || 1) + 1;
    website.pagesMeta[pageId] = meta;
    website.version = (website.version || 1) + 1;

    appendActivity(db, actor, `Updated page settings: ${coreDef.name}`, 'Website', coreDef.name);
    return buildPageSettingsResponse(db, pageId)!;
  }

  // Custom page
  const idx = (db.pages || []).findIndex(p => p.id === pageId && !p.deletedAt);
  if (idx < 0) throw new Error('Page not found.');
  const pg = db.pages[idx];
  const curVer = pg.version || 1;
  if (expectedVersion !== undefined && curVer !== expectedVersion) {
    throw new ConflictError(`"${pg.title}" was edited by someone else. Reload the drawer to get the latest version.`);
  }

  recordPageSnapshot(
    db,
    pg.id,
    pg.title,
    {
      title: pg.title,
      slug: pg.slug,
      template: pg.template,
      status: pg.status,
      blocks: JSON.parse(JSON.stringify(pg.blocks || [])),
      seo: JSON.parse(JSON.stringify(pg.seo || {}))
    },
    actor,
    `Updated ${pg.title}`
  );

  if (typeof payload.title === 'string' && payload.title.trim()) {
    pg.title = payload.title.trim();
  }
  if (payload.template === 'Standard' || payload.template === 'Landing' || payload.template === 'Article' || payload.template === 'Gallery') {
    pg.template = payload.template;
  }
  if (typeof payload.slug === 'string' && payload.slug.trim()) {
    const nextSlug = normalizeSlug(payload.slug, pg.slug || 'page');
    if (db.pages.some(p => p.id !== pg.id && !p.deletedAt && p.slug.toLowerCase() === nextSlug.toLowerCase())) {
      throw new Error('Another active custom page already uses this URL slug.');
    }
    if (nextSlug !== pg.slug) {
      addAutoRedirect(db, `/pages/${pg.slug}`, `/pages/${nextSlug}`);
      pg.slug = nextSlug;
    }
  }
  if (payload.status === 'Published' || payload.status === 'Draft' || payload.status === 'Hidden') {
    pg.status = payload.status;
    if (payload.status === 'Published') {
      pg.lastPublishedAt = nowIso;
      pg.lastPublishedByName = actor.name;
      website.lastPublishedAt = nowIso;
      website.lastPublishedById = actor.id;
      website.lastPublishedByName = actor.name;
    }
  }
  if (Array.isArray(payload.blocks)) {
    pg.blocks = payload.blocks as PageRecord['blocks'];
  }
  const seoIn = (payload.seo && typeof payload.seo === 'object' ? payload.seo : null) as Record<string, unknown> | null;
  if (seoIn) {
    pg.seo = {
      ...(pg.seo || {}),
      ...(typeof seoIn.title === 'string' ? { title: seoIn.title } : {}),
      ...(typeof seoIn.description === 'string' ? { description: seoIn.description } : {}),
      ...(typeof seoIn.shareImage === 'string' ? { shareImage: seoIn.shareImage.trim() } : {}),
      ...(typeof seoIn.noindex === 'boolean' ? { noindex: seoIn.noindex } : {})
    };
  }

  pg.updatedAt = nowIso;
  pg.lastEditedAt = nowIso;
  pg.lastEditedByName = actor.name;
  pg.version = curVer + 1;
  db.pages[idx] = pg;

  if (typeof payload.inHeader === 'boolean' || typeof payload.inFooter === 'boolean') {
    togglePageMenuMembership(
      db,
      pg.id,
      pg.title,
      `/pages/${pg.slug}`,
      {
        inHeader: typeof payload.inHeader === 'boolean' ? payload.inHeader : undefined,
        inFooter: typeof payload.inFooter === 'boolean' ? payload.inFooter : undefined
      },
      actor.name
    );
  }

  website.version = (website.version || 1) + 1;
  appendActivity(db, actor, `Updated custom page settings: ${pg.title}`, 'Website', pg.title);
  return buildPageSettingsResponse(db, pageId)!;
}

export function publishSinglePageDraftInDb(
  db: DatabaseState,
  pageId: string,
  actor: { id: string; email: string; name: string }
): void {
  const website = ensureWebsiteState(db);
  const nowIso = new Date().toISOString();
  const coreDef = getCorePageDefinition(pageId);

  if (coreDef) {
    const storedDraft = website.pageDrafts[pageId]?.data;
    const legacySlice = extractPageDraftSlice(db.pageContent, db.draftContent, pageId);
    const mergedDraft = { ...legacySlice, ...(storedDraft || {}) };
    if (Object.keys(mergedDraft).length === 0) {
      throw new Error(`No unpublished draft changes for ${coreDef.name}.`);
    }

    const prevValues = extractPageTextValues(db.pageContent, pageId);
    recordPageSnapshot(db, pageId, coreDef.name, prevValues, actor, `Published ${coreDef.name} draft edits`);

    db.pageContent = applyPageTextValues(db.pageContent, pageId, mergedDraft);
    delete website.pageDrafts[pageId];

    if (db.draftContent && typeof db.draftContent === 'object') {
      const draftObj = db.draftContent as unknown as Record<string, Record<string, unknown> | undefined>;
      for (const field of coreDef.textFields) {
        const [sec, key] = field.path.split('.');
        if (draftObj[sec]) delete draftObj[sec]![key];
      }
      if (Object.values(draftObj).every(sec => !sec || Object.keys(sec).length === 0)) {
        delete db.draftContent;
      }
    }

    const meta = website.pagesMeta[pageId] || { pageId, version: 1 };
    meta.lastPublishedAt = nowIso;
    meta.lastPublishedByName = actor.name;
    meta.lastEditedAt = nowIso;
    meta.lastEditedByName = actor.name;
    meta.version = (meta.version || 1) + 1;
    website.pagesMeta[pageId] = meta;
    website.lastPublishedAt = nowIso;
    website.lastPublishedById = actor.id;
    website.lastPublishedByName = actor.name;
    website.version = (website.version || 1) + 1;

    appendActivity(db, actor, `Published page draft: ${coreDef.name}`, 'Website', coreDef.name);
    return;
  }

  const pg = (db.pages || []).find(p => p.id === pageId && !p.deletedAt);
  if (!pg) throw new Error('Page not found');
  delete website.pageDrafts[pageId];
  pg.status = 'Published';
  pg.lastPublishedAt = nowIso;
  pg.lastPublishedByName = actor.name;
  pg.updatedAt = nowIso;
  pg.version = (pg.version || 1) + 1;
  website.lastPublishedAt = nowIso;
  website.lastPublishedById = actor.id;
  website.lastPublishedByName = actor.name;
  appendActivity(db, actor, `Published custom page: ${pg.title}`, 'Website', pg.title);
}

export function discardSinglePageDraftInDb(
  db: DatabaseState,
  pageId: string,
  actor: { id: string; email: string; name: string }
): void {
  const website = ensureWebsiteState(db);
  const coreDef = getCorePageDefinition(pageId);
  delete website.pageDrafts[pageId];

  if (coreDef && db.draftContent && typeof db.draftContent === 'object') {
    const draftObj = db.draftContent as unknown as Record<string, Record<string, unknown> | undefined>;
    for (const field of coreDef.textFields) {
      const [sec, key] = field.path.split('.');
      if (draftObj[sec]) delete draftObj[sec]![key];
    }
    if (Object.values(draftObj).every(sec => !sec || Object.keys(sec).length === 0)) {
      delete db.draftContent;
    }
  }
  website.version = (website.version || 1) + 1;
  appendActivity(db, actor, `Discarded draft changes for ${coreDef ? coreDef.name : pageId}`, 'Website', coreDef ? coreDef.name : pageId);
}

export function publishAllPageDraftsInDb(
  db: DatabaseState,
  actor: { id: string; email: string; name: string }
): number {
  const drafts = getEffectiveDraftPages(db);
  for (const d of drafts) {
    publishSinglePageDraftInDb(db, d.pageId, actor);
  }
  if (db.draftContent && typeof db.draftContent === 'object') {
    const liveObj = db.pageContent as unknown as Record<string, Record<string, unknown>>;
    const draftObj = db.draftContent as unknown as Record<string, Record<string, unknown> | undefined>;
    for (const [secKey, secVal] of Object.entries(draftObj)) {
      if (secVal && typeof secVal === 'object' && Object.keys(secVal).length > 0) {
        liveObj[secKey] = { ...(liveObj[secKey] || {}), ...secVal };
      }
    }
    delete db.draftContent;
  }
  return drafts.length;
}

export function restorePageVersionInDb(
  db: DatabaseState,
  pageId: string,
  versionId: string,
  actor: { id: string; email: string; name: string }
): WebsitePageSettingsResponse {
  const website = ensureWebsiteState(db);
  const snap = (db.contentHistory || []).find(s => s.id === versionId);
  if (!snap || !snap.snapshot) throw new Error('Version snapshot not found');
  const nowIso = new Date().toISOString();

  const coreDef = getCorePageDefinition(pageId);
  if (coreDef) {
    const currentValues = extractPageTextValues(db.pageContent, pageId);
    recordPageSnapshot(db, pageId, coreDef.name, currentValues, actor, `Before restoring ${coreDef.name} version`);

    const restoredValues =
      snap.entityId === 'pageContent'
        ? extractPageTextValues(snap.snapshot as unknown as SiteContent, pageId)
        : (snap.snapshot as Record<string, unknown>);
    db.pageContent = applyPageTextValues(db.pageContent, pageId, restoredValues);
    delete website.pageDrafts[pageId];
    const meta = website.pagesMeta[pageId] || { pageId, version: 1 };
    meta.lastEditedAt = nowIso;
    meta.lastEditedByName = actor.name;
    meta.lastPublishedAt = nowIso;
    meta.lastPublishedByName = actor.name;
    meta.version = (meta.version || 1) + 1;
    website.pagesMeta[pageId] = meta;
    website.lastPublishedAt = nowIso;
    website.lastPublishedById = actor.id;
    website.lastPublishedByName = actor.name;
    appendActivity(db, actor, `Restored version for ${coreDef.name}`, 'Website', coreDef.name);
    return buildPageSettingsResponse(db, pageId)!;
  }

  const idx = (db.pages || []).findIndex(p => p.id === pageId && !p.deletedAt);
  if (idx < 0) throw new Error('Custom page not found');
  const pg = db.pages[idx];
  recordPageSnapshot(
    db,
    pg.id,
    pg.title,
    { title: pg.title, slug: pg.slug, status: pg.status, blocks: pg.blocks, seo: pg.seo },
    actor,
    `Before restoring ${pg.title} version`
  );
  const sObj = snap.snapshot as Record<string, unknown>;
  if (typeof sObj.title === 'string' && sObj.title.trim()) pg.title = sObj.title.trim();
  if (Array.isArray(sObj.blocks)) pg.blocks = sObj.blocks as PageRecord['blocks'];
  if (sObj.seo && typeof sObj.seo === 'object') pg.seo = sObj.seo as PageRecord['seo'];
  pg.updatedAt = nowIso;
  pg.lastEditedAt = nowIso;
  pg.lastEditedByName = actor.name;
  pg.version = (pg.version || 1) + 1;
  db.pages[idx] = pg;
  appendActivity(db, actor, `Restored version for ${pg.title}`, 'Website', pg.title);
  return buildPageSettingsResponse(db, pageId)!;
}

export function duplicateCustomPageInDb(
  db: DatabaseState,
  sourcePageId: string,
  actor: { id: string; email: string; name: string }
): PageRecord {
  const source = (db.pages || []).find(p => p.id === sourcePageId && !p.deletedAt);
  if (!source) throw new Error('Custom page not found. Core and system pages cannot be duplicated.');

  const nowIso = new Date().toISOString();
  let candidateSlug = `${source.slug}-copy`;
  let counter = 2;
  while ((db.pages || []).some(p => !p.deletedAt && p.slug.toLowerCase() === candidateSlug.toLowerCase())) {
    candidateSlug = `${source.slug}-copy-${counter++}`;
  }

  const copy: PageRecord = {
    ...JSON.parse(JSON.stringify(source)),
    id: `page-${Date.now()}-${crypto.randomBytes(2).toString('hex')}`,
    title: `${source.title} (Copy)`,
    slug: candidateSlug,
    status: 'Draft',
    version: 1,
    lastEditedAt: nowIso,
    lastEditedByName: actor.name,
    lastPublishedAt: undefined,
    lastPublishedByName: undefined,
    createdAt: nowIso,
    updatedAt: nowIso
  };

  db.pages.push(copy);
  appendActivity(db, actor, `Duplicated custom page: ${copy.title}`, 'Website', copy.title);
  return copy;
}

export function updateMenusInDb(
  db: DatabaseState,
  payload: Record<string, unknown>,
  actor: { id: string; email: string; name: string }
): WebsiteMenusConfig & { alwaysShowProducts: boolean } {
  const website = ensureWebsiteState(db);
  const currentMenus = website.menus;
  const expectedVersion = typeof payload.version === 'number' ? payload.version : undefined;
  if (expectedVersion !== undefined && currentMenus.version !== expectedVersion) {
    throw new ConflictError('Menus were modified in another session. Reload before saving.');
  }

  const rawHeader = Array.isArray(payload.header) ? payload.header : currentMenus.header;
  const seenPaths = new Set<string>();
  const validatedHeader: NavigationItem[] = [];

  for (let i = 0; i < rawHeader.length; i++) {
    const raw = rawHeader[i] as Record<string, unknown>;
    if (!raw || typeof raw !== 'object') continue;
    const label = typeof raw.label === 'string' ? raw.label.trim() : '';
    if (!label) throw new Error(`Header item #${i + 1} requires a label.`);

    let pathVal = typeof raw.path === 'string' ? raw.path.trim() : '';
    if (!pathVal) throw new Error(`Header item "${label}" requires a destination URL or page.`);
    const lower = pathVal.toLowerCase();
    if (lower === '/login' || lower === '/signin' || lower === '/admin' || lower === '/portal') {
      throw new Error(`Destination "${pathVal}" cannot be added to public navigation.`);
    }
    if (!isSafeUrl(pathVal)) {
      throw new Error(`Header item "${label}" has an unsafe URL.`);
    }
    if (lower === '/home') pathVal = '/';
    const dedupKey = pathVal.toLowerCase();
    if (seenPaths.has(dedupKey)) {
      throw new Error(`Duplicate destination "${pathVal}" in header menu.`);
    }
    seenPaths.add(dedupKey);

    validatedHeader.push({
      id: typeof raw.id === 'string' && raw.id ? raw.id : `nav-${Date.now()}-${i}`,
      label,
      path: pathVal,
      pageId: typeof raw.pageId === 'string' ? raw.pageId : undefined,
      isExternal: Boolean(raw.isExternal || /^https?:\/\//i.test(pathVal)),
      newTab: Boolean(raw.newTab),
      visible: typeof raw.visible === 'boolean' ? raw.visible : true,
      isCore: Boolean(raw.isCore)
    });
  }

  if (!validatedHeader.some(item => item.path === '/')) {
    throw new Error('Home (/) is required in the header menu.');
  }

  const footerIn = (payload.footer && typeof payload.footer === 'object' ? payload.footer : {}) as Record<string, unknown>;
  const blurb = typeof footerIn.blurb === 'string' ? footerIn.blurb : currentMenus.footer.blurb;
  const copyrightText =
    typeof footerIn.copyrightText === 'string' && footerIn.copyrightText.trim()
      ? footerIn.copyrightText.trim()
      : currentMenus.footer.copyrightText || 'All rights reserved.';
  const showContactEmail =
    typeof footerIn.showContactEmail === 'boolean' ? footerIn.showContactEmail : currentMenus.footer.showContactEmail;

  const rawCols = Array.isArray(footerIn.columns)
    ? (footerIn.columns as WebsiteFooterColumnConfig[])
    : currentMenus.footer.columns || buildDefaultFooterColumns();

  const validColIds = new Set(['explore', 'departments', 'sectors', 'community', 'legal']);
  const validatedCols: WebsiteFooterColumnConfig[] = [];
  const seenCols = new Set<string>();

  for (const c of rawCols) {
    if (!c || typeof c !== 'object' || !validColIds.has(c.id) || seenCols.has(c.id)) continue;
    seenCols.add(c.id);
    const links = Array.isArray(c.links)
      ? c.links
          .filter(l => l && typeof l.label === 'string' && typeof l.url === 'string')
          .map(l => {
            const urlTrim = l.url.trim() === '/home' ? '/' : l.url.trim();
            if (!l.label.trim() || !isSafeUrl(urlTrim, true)) {
              throw new Error(`Invalid footer link "${l.label}" (${l.url}).`);
            }
            if (urlTrim.toLowerCase() === '/login' || urlTrim.toLowerCase() === '/signin') {
              throw new Error('The /login page cannot be added to footer menus.');
            }
            return {
              label: l.label.trim(),
              url: urlTrim,
              isExternal: Boolean(l.isExternal || /^https?:\/\//i.test(urlTrim)),
              newTab: Boolean(l.newTab)
            };
          })
      : [];

    validatedCols.push({
      id: c.id,
      title: typeof c.title === 'string' && c.title.trim() ? c.title.trim() : c.id,
      visible: typeof c.visible === 'boolean' ? c.visible : true,
      kind: c.kind,
      sameAsHeader: c.id === 'explore' ? (typeof c.sameAsHeader === 'boolean' ? c.sameAsHeader : true) : undefined,
      links: c.id === 'explore' || c.id === 'legal' ? links : undefined
    });
  }

  for (const defCol of buildDefaultFooterColumns()) {
    if (!seenCols.has(defCol.id)) validatedCols.push(defCol);
  }

  if (typeof payload.alwaysShowProducts === 'boolean') {
    db.settings.alwaysShowProducts = payload.alwaysShowProducts;
  }

  const nowIso = new Date().toISOString();
  const nextMenus: WebsiteMenusConfig = {
    version: (currentMenus.version || 1) + 1,
    updatedAt: nowIso,
    updatedByName: actor.name,
    header: normalizeHeaderMenuItems(validatedHeader),
    footer: {
      blurb,
      copyrightText,
      showContactEmail,
      columns: validatedCols
    }
  };

  syncLegacyNavigationFromMenus(db, nextMenus);
  website.version = (website.version || 1) + 1;
  appendActivity(db, actor, 'Updated Website header & footer menus', 'Website', 'Menus');
  return { ...nextMenus, alwaysShowProducts: Boolean(db.settings.alwaysShowProducts) };
}

export function updateBrandInDb(
  db: DatabaseState,
  payload: Record<string, unknown>,
  actor: { id: string; email: string; name: string }
) {
  const website = ensureWebsiteState(db);
  const curVer = website.brandVersion || 1;
  if (typeof payload.version === 'number' && payload.version !== curVer) {
    throw new ConflictError('Brand assets were updated by another user. Reload before saving.');
  }

  const urlErr =
    validateSafeUrlField(payload.moaLogoUrl, 'moaLogoUrl') ||
    validateSafeUrlField(payload.rddLogoUrl, 'rddLogoUrl') ||
    validateSafeUrlField(payload.loaderLogoUrl, 'loaderLogoUrl') ||
    validateSafeUrlField(payload.faviconUrl, 'faviconUrl') ||
    validateSafeUrlField(payload.shareImageUrl, 'shareImageUrl');
  if (urlErr) throw new Error(urlErr);

  if (typeof payload.moaLogoUrl === 'string') {
    if (!payload.moaLogoUrl.trim()) throw new Error('Primary logo cannot be empty.');
    db.settings.moaLogoUrl = payload.moaLogoUrl.trim();
  }
  if (typeof payload.rddLogoUrl === 'string') {
    if (!payload.rddLogoUrl.trim()) throw new Error('RDD logo cannot be empty.');
    db.settings.rddLogoUrl = payload.rddLogoUrl.trim();
    const rddDept = db.departments.find(d => d.isRdd || d.id === 'dept-rdd');
    if (rddDept) rddDept.customLogoUrl = db.settings.rddLogoUrl;
  }
  if (typeof payload.sameLoaderAsPrimary === 'boolean') {
    website.sameLoaderAsPrimary = payload.sameLoaderAsPrimary;
    db.settings.sameLoaderAsPrimary = payload.sameLoaderAsPrimary;
  }
  if (website.sameLoaderAsPrimary) {
    db.settings.loaderLogoUrl = db.settings.moaLogoUrl;
  } else if (typeof payload.loaderLogoUrl === 'string') {
    if (!payload.loaderLogoUrl.trim()) throw new Error('Loading screen logo cannot be empty.');
    db.settings.loaderLogoUrl = payload.loaderLogoUrl.trim();
  }
  if (typeof payload.faviconUrl === 'string') {
    if (!payload.faviconUrl.trim()) throw new Error('Favicon cannot be empty.');
    db.settings.faviconUrl = payload.faviconUrl.trim();
  }
  if (typeof payload.shareImageUrl === 'string') {
    db.settings.shareImageUrl = payload.shareImageUrl.trim();
  }

  website.brandVersion = curVer + 1;
  website.version = (website.version || 1) + 1;
  appendActivity(db, actor, 'Updated Brand & visual identity assets', 'Website', 'Brand Assets');
  return buildWebsiteOverview(db).brand;
}

export function updateAnnouncementInDb(
  db: DatabaseState,
  payload: Record<string, unknown>,
  actor: { id: string; email: string; name: string }
): AnnouncementBarConfig & { version: number } {
  const website = ensureWebsiteState(db);
  const curVer = website.announcementVersion || 1;
  if (typeof payload.version === 'number' && payload.version !== curVer) {
    throw new ConflictError('Announcement settings were updated in another session.');
  }

  const linkUrl = typeof payload.linkUrl === 'string' ? payload.linkUrl.trim() : '';
  if (linkUrl && !isSafeUrl(linkUrl)) {
    throw new Error('Announcement link URL must use http(s) or an internal path.');
  }
  const startDate = typeof payload.startDate === 'string' ? payload.startDate.trim() : '';
  const endDate = typeof payload.endDate === 'string' ? payload.endDate.trim() : (typeof payload.expiresAt === 'string' ? payload.expiresAt.trim() : '');
  if (startDate && endDate) {
    const startMs = Date.parse(startDate);
    const endMs = Date.parse(endDate);
    if (Number.isFinite(startMs) && Number.isFinite(endMs) && endMs < startMs) {
      throw new Error('Announcement end date must be after start date.');
    }
  }

  db.settings.announcementBar = {
    enabled: Boolean(payload.enabled),
    text: typeof payload.text === 'string' ? payload.text : '',
    linkUrl,
    linkLabel: typeof payload.linkLabel === 'string' ? payload.linkLabel.trim() : '',
    startDate,
    endDate,
    expiresAt: endDate
  };

  website.announcementVersion = curVer + 1;
  website.version = (website.version || 1) + 1;
  appendActivity(db, actor, 'Updated site-wide announcement bar', 'Website', 'Announcement Bar');
  return buildWebsiteOverview(db).announcement;
}

export function updateSocialInDb(
  db: DatabaseState,
  payload: Record<string, unknown>,
  actor: { id: string; email: string; name: string }
): { version: number; links: SocialLink[] } {
  const website = ensureWebsiteState(db);
  const curVer = website.socialVersion || 1;
  if (typeof payload.version === 'number' && payload.version !== curVer) {
    throw new ConflictError('Social channels were updated in another session.');
  }

  if (!Array.isArray(payload.links)) {
    throw new Error('Social links list is required.');
  }
  const cleanLinks: SocialLink[] = [];
  for (let i = 0; i < payload.links.length; i++) {
    const item = payload.links[i] as Record<string, unknown>;
    if (!item || typeof item !== 'object') continue;
    const platform = typeof item.platform === 'string' ? item.platform.trim() : '';
    const url = typeof item.url === 'string' ? item.url.trim() : '';
    if (!platform) throw new Error(`Social channel #${i + 1} requires a platform name.`);
    if (!url || !isSafeUrl(url, true) || !/^https?:\/\//i.test(url)) {
      throw new Error(`Social channel "${platform}" must have a valid http:// or https:// URL.`);
    }
    cleanLinks.push({
      id: typeof item.id === 'string' && item.id ? item.id : `soc-${Date.now()}-${i}`,
      platform,
      icon: typeof item.icon === 'string' && item.icon ? item.icon : platform.toLowerCase(),
      url,
      visible: typeof item.visible === 'boolean' ? item.visible : true
    });
  }

  db.settings.socialLinks = cleanLinks;
  website.socialVersion = curVer + 1;
  website.version = (website.version || 1) + 1;
  appendActivity(db, actor, 'Updated social media channels', 'Website', 'Social Channels');
  return buildWebsiteOverview(db).social;
}

export function updateSeoDefaultsInDb(
  db: DatabaseState,
  payload: Record<string, unknown>,
  actor: { id: string; email: string; name: string }
) {
  const website = ensureWebsiteState(db);
  const curVer = website.seoVersion || 1;
  if (typeof payload.version === 'number' && payload.version !== curVer) {
    throw new ConflictError('SEO settings were updated by another session.');
  }
  if ('keywords' in payload) {
    // Never store keywords
    delete payload.keywords;
  }

  if (typeof payload.titleTemplate === 'string') {
    const err = validateSeoTitleTemplate(payload.titleTemplate);
    if (err) throw new Error(err);
    db.settings.seoDefaults.titleTemplate = payload.titleTemplate.trim();
  }
  if (typeof payload.description === 'string') {
    db.settings.seoDefaults.description = payload.description;
  }
  if (typeof payload.sitemapEnabled === 'boolean') {
    db.settings.seoDefaults.sitemapEnabled = payload.sitemapEnabled;
  }
  if (typeof payload.robotsEnabled === 'boolean') {
    db.settings.seoDefaults.robotsEnabled = payload.robotsEnabled;
  }

  website.seoVersion = curVer + 1;
  website.version = (website.version || 1) + 1;
  appendActivity(db, actor, 'Updated site-wide SEO defaults', 'Website', 'SEO Settings');
  return buildWebsiteOverview(db).seo;
}

export function addOrUpdateRedirectInDb(
  db: DatabaseState,
  ruleInput: { id?: string; from: string; to: string; type?: string },
  actor: { id: string; email: string; name: string }
): RedirectRule {
  if (!ruleInput.from || !ruleInput.from.trim().startsWith('/')) {
    throw new Error('Redirect "From" path must start with "/".');
  }
  if (!ruleInput.to || !ruleInput.to.trim() || !isSafeUrl(ruleInput.to.trim())) {
    throw new Error('Redirect "To" destination must be an internal path starting with "/" or a valid https:// URL.');
  }

  const normFrom = normalizeRedirectPath(ruleInput.from);
  const normTo = normalizeRedirectPath(ruleInput.to);
  if (['/login', '/admin', '/portal'].includes(normFrom.toLowerCase())) {
    throw new Error(`Protected route "${normFrom}" cannot be redirected.`);
  }

  const redirects = db.settings.redirects || [];
  if (redirects.some(r => r.id !== ruleInput.id && normalizeRedirectPath(r.from).toLowerCase() === normFrom.toLowerCase())) {
    throw new Error(`A redirect from "${normFrom}" already exists.`);
  }
  if (wouldCreateRedirectLoop(redirects, normFrom, normTo, ruleInput.id)) {
    throw new Error(`Redirect rule "${normFrom}" → "${normTo}" creates a redirect loop.`);
  }
  if (wouldCreateRedirectChain(redirects, normFrom, normTo, ruleInput.id)) {
    throw new Error(`Redirect rule "${normFrom}" → "${normTo}" creates a multi-hop chain. Point directly to the final destination instead.`);
  }

  const nowIso = new Date().toISOString();
  const type: '301' | '302' = ruleInput.type === '302' ? '302' : '301';

  if (ruleInput.id) {
    const existing = redirects.find(r => r.id === ruleInput.id);
    if (!existing) throw new Error('Redirect rule not found.');
    existing.from = normFrom;
    existing.to = normTo;
    existing.type = type;
    appendActivity(db, actor, `Updated redirect ${normFrom} → ${normTo}`, 'Website', 'Redirects');
    return existing;
  }

  const created: RedirectRule = {
    id: `red-${Date.now()}-${crypto.randomBytes(2).toString('hex')}`,
    from: normFrom,
    to: normTo,
    type,
    source: 'manual',
    createdAt: nowIso,
    hits: 0
  };
  db.settings.redirects.unshift(created);
  appendActivity(db, actor, `Added redirect ${normFrom} → ${normTo}`, 'Website', 'Redirects');
  return created;
}

export function deleteRedirectInDb(
  db: DatabaseState,
  redirectId: string,
  actor: { id: string; email: string; name: string }
): void {
  const before = db.settings.redirects || [];
  const target = before.find(r => r.id === redirectId);
  if (!target) throw new Error('Redirect rule not found.');
  db.settings.redirects = before.filter(r => r.id !== redirectId);
  appendActivity(db, actor, `Deleted redirect ${target.from} → ${target.to}`, 'Website', 'Redirects');
}

export function deleteAutoRedirectsInDb(
  db: DatabaseState,
  actor: { id: string; email: string; name: string }
): number {
  const before = db.settings.redirects || [];
  const kept = before.filter(r => r.source !== 'auto');
  const removed = before.length - kept.length;
  db.settings.redirects = kept;
  if (removed > 0) {
    appendActivity(db, actor, `Removed ${removed} auto-generated redirects`, 'Website', 'Redirects');
  }
  return removed;
}
