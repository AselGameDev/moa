import React from 'react';

export interface PortalPageHeaderProps {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  actions?: React.ReactNode;
  titleClassName?: string;
  className?: string;
}

export const PortalPageHeader: React.FC<PortalPageHeaderProps> = ({
  title,
  subtitle,
  badge,
  actions,
  titleClassName = 'text-xl font-bold tracking-tight text-[#EDE9E0]',
  className = ''
}) => {
  return (
    <div
      className={`flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-white/10 ${className}`}
    >
      <div className="min-w-0">
        <div className="flex flex-wrap items-center gap-2.5">
          <h1 className={titleClassName}>{title}</h1>
          {badge}
        </div>
        {subtitle && (
          <p className="text-xs text-[#EDE9E0]/65 mt-1 leading-relaxed break-words">{subtitle}</p>
        )}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2 shrink-0">{actions}</div>}
    </div>
  );
};
