import React from 'react';
import { FolderOpen } from 'lucide-react';

export interface PortalEmptyStateProps {
  icon?: React.ComponentType<{ className?: string }>;
  title: string;
  description?: string;
  action?: React.ReactNode;
  compact?: boolean;
  className?: string;
}

export const PortalEmptyState: React.FC<PortalEmptyStateProps> = ({
  icon: Icon = FolderOpen,
  title,
  description,
  action,
  compact = false,
  className = ''
}) => {
  return (
    <div
      className={`rounded-2xl border border-dashed border-white/15 bg-[#031D1C]/50 text-center flex flex-col items-center justify-center ${
        compact ? 'px-5 py-8' : 'px-6 py-14'
      } ${className}`}
    >
      <div className="w-11 h-11 rounded-2xl bg-[#17A491]/12 border border-[#25CDB6]/25 flex items-center justify-center text-[#25CDB6] mb-3">
        <Icon className="w-5 h-5" />
      </div>
      <h3 className="text-sm font-bold text-[#EDE9E0]">{title}</h3>
      {description && (
        <p className="text-xs text-[#EDE9E0]/60 max-w-md mt-1 leading-relaxed break-words">
          {description}
        </p>
      )}
      {action && <div className="mt-4 flex flex-wrap items-center justify-center gap-2">{action}</div>}
    </div>
  );
};
