import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  MoreHorizontal,
  RefreshCw
} from 'lucide-react';
import { PortalEmptyState } from './PortalEmptyState';

export interface PortalTableColumn<T> {
  key: string;
  header: React.ReactNode;
  align?: 'left' | 'right' | 'center';
  widthClass?: string;
  hideOnMobile?: boolean;
  render: (item: T) => React.ReactNode;
}

export interface PortalTableRowAction {
  id: string;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  destructive?: boolean;
  disabled?: boolean;
  hidden?: boolean;
  onClick: () => void;
}

export interface PortalTableBulkAction {
  id: string;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  destructive?: boolean;
  disabled?: boolean;
  onClick: (selectedIds: string[]) => void;
}

export interface PortalTableProps<T> {
  columns: PortalTableColumn<T>[];
  items: T[];
  getRowKey: (item: T) => string;
  onRowClick?: (item: T) => void;
  rowActions?: (item: T) => PortalTableRowAction[];
  selectable?: boolean;
  selectedIds?: string[];
  onSelectionChange?: (ids: string[]) => void;
  bulkActions?: PortalTableBulkAction[];
  loading?: boolean;
  error?: string | null;
  onRetry?: () => void;
  emptyState?: React.ReactNode;
  page?: number;
  totalPages?: number;
  totalItems?: number;
  pageSize?: number;
  onPageChange?: (page: number) => void;
  stickyHeader?: boolean;
  className?: string;
}

export function PortalTable<T>({
  columns,
  items,
  getRowKey,
  onRowClick,
  rowActions,
  selectable = false,
  selectedIds = [],
  onSelectionChange,
  bulkActions = [],
  loading = false,
  error = null,
  onRetry,
  emptyState,
  page = 1,
  totalPages = 1,
  totalItems,
  pageSize = 20,
  onPageChange,
  stickyHeader = false,
  className = ''
}: PortalTableProps<T>) {
  const [openMenu, setOpenMenu] = useState<{
    key: string;
    top: number;
    left: number;
    openUp: boolean;
    maxHeight: number;
  } | null>(null);
  const triggerRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const portalMenuRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!openMenu) return;
    const handleOutside = (e: MouseEvent) => {
      const target = e.target as Node | null;
      if (target && portalMenuRef.current?.contains(target)) return;
      const activeTrigger = triggerRefs.current[openMenu.key];
      if (target && activeTrigger?.contains(target)) return;
      setOpenMenu(null);
    };
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpenMenu(null);
    };
    const handleResize = () => setOpenMenu(null);
    const handleScroll = (e: Event) => {
      if (portalMenuRef.current && e.target instanceof Node && portalMenuRef.current.contains(e.target)) {
        return;
      }
      setOpenMenu(null);
    };
    document.addEventListener('mousedown', handleOutside);
    window.addEventListener('keydown', handleKey);
    window.addEventListener('resize', handleResize);
    window.addEventListener('scroll', handleScroll, true);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      window.removeEventListener('keydown', handleKey);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('scroll', handleScroll, true);
    };
  }, [openMenu]);

  const openMenuForRow = (key: string, buttonEl: HTMLButtonElement, actionCount: number) => {
    if (openMenu?.key === key) {
      setOpenMenu(null);
      return;
    }
    const rect = buttonEl.getBoundingClientRect();
    const estHeight = Math.min(280, actionCount * 36 + 16);
    const spaceBelow = window.innerHeight - rect.bottom - 12;
    const spaceAbove = rect.top - 12;
    const openUp = spaceBelow < estHeight && spaceAbove > spaceBelow;
    const maxHeight = Math.max(120, Math.min(280, openUp ? spaceAbove : spaceBelow));
    const menuWidth = 192;
    const left = Math.max(8, Math.min(window.innerWidth - menuWidth - 8, rect.right - menuWidth));
    const top = openUp ? rect.top - 6 : rect.bottom + 6;
    setOpenMenu({ key, top, left, openUp, maxHeight });
  };

  const activeMenuItem = openMenu ? items.find(item => getRowKey(item) === openMenu.key) : undefined;
  const activeMenuActions =
    openMenu && activeMenuItem && rowActions
      ? rowActions(activeMenuItem).filter(a => !a.hidden)
      : [];

  const rowKeys = items.map(getRowKey);
  const allSelected = rowKeys.length > 0 && rowKeys.every(k => selectedIds.includes(k));
  const someSelected = rowKeys.some(k => selectedIds.includes(k));

  const toggleAll = () => {
    if (!onSelectionChange) return;
    if (allSelected) {
      onSelectionChange(selectedIds.filter(id => !rowKeys.includes(id)));
    } else {
      const next = Array.from(new Set([...selectedIds, ...rowKeys]));
      onSelectionChange(next);
    }
  };

  const toggleOne = (key: string) => {
    if (!onSelectionChange) return;
    if (selectedIds.includes(key)) {
      onSelectionChange(selectedIds.filter(id => id !== key));
    } else {
      onSelectionChange([...selectedIds, key]);
    }
  };

  if (error) {
    return (
      <div
        className={`rounded-2xl border border-red-500/30 bg-red-950/20 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${className}`}
      >
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-bold text-[#EDE9E0]">Failed to load records</p>
            <p className="text-xs text-red-200/80 mt-0.5 break-words">{error}</p>
          </div>
        </div>
        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            className="h-9 px-4 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-bold text-[#EDE9E0] inline-flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Retry</span>
          </button>
        )}
      </div>
    );
  }

  const effectiveTotal = typeof totalItems === 'number' ? totalItems : items.length;
  const startIndex = effectiveTotal === 0 ? 0 : (page - 1) * pageSize + 1;
  const endIndex = Math.min(effectiveTotal, (page - 1) * pageSize + items.length);

  return (
    <div className={`space-y-3 ${className}`}>
      {selectable && selectedIds.length > 0 && (
        <div className="px-4 py-2.5 rounded-2xl bg-[#0A3D3C] border border-[#25CDB6]/35 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-xs">
            <span className="font-bold text-[#25CDB6] tabular-nums">
              {selectedIds.length} selected
            </span>
            {onSelectionChange && (
              <button
                type="button"
                onClick={() => onSelectionChange([])}
                className="text-[#EDE9E0]/65 hover:text-white underline cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {bulkActions.map(action => {
              const Icon = action.icon;
              return (
                <button
                  key={action.id}
                  type="button"
                  disabled={action.disabled}
                  onClick={() => action.onClick(selectedIds)}
                  className={`h-8 px-3 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 border transition-colors cursor-pointer disabled:opacity-50 ${
                    action.destructive
                      ? 'bg-red-500/15 hover:bg-red-500/25 border-red-400/35 text-red-200'
                      : 'bg-[#031D1C] hover:bg-white/10 border-white/15 text-[#EDE9E0]'
                  }`}
                >
                  {Icon && <Icon className="w-3.5 h-3.5" />}
                  <span>{action.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {!loading && items.length === 0 ? (
        emptyState || (
          <PortalEmptyState
            title="No records found"
            description="Adjust your search or filters, or create a new item."
          />
        )
      ) : (
        <div className="rounded-2xl border border-white/10 bg-[#031D1C]">
          <div className="overflow-x-auto rounded-2xl">
            <table className="w-full border-collapse text-left text-xs">
              <thead
                className={`bg-[#06302F] border-b border-white/10 text-[11px] uppercase tracking-wider text-[#EDE9E0]/60 ${
                  stickyHeader ? 'sticky top-0 z-10' : ''
                }`}
              >
                <tr>
                  {selectable && (
                    <th className="w-11 px-4 py-3">
                      <input
                        type="checkbox"
                        checked={allSelected}
                        ref={el => {
                          if (el) el.indeterminate = !allSelected && someSelected;
                        }}
                        onChange={toggleAll}
                        aria-label="Select all rows on this page"
                        className="w-4 h-4 rounded accent-[#25CDB6] cursor-pointer"
                      />
                    </th>
                  )}
                  {columns.map(col => (
                    <th
                      key={col.key}
                      className={`px-4 py-3 font-semibold whitespace-nowrap ${
                        col.align === 'right'
                          ? 'text-right'
                          : col.align === 'center'
                            ? 'text-center'
                            : 'text-left'
                      } ${col.hideOnMobile ? 'hidden md:table-cell' : ''} ${col.widthClass || ''}`}
                    >
                      {col.header}
                    </th>
                  ))}
                  {rowActions && <th className="w-12 px-3 py-3 text-right font-semibold">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {loading
                  ? Array.from({ length: 5 }).map((_, idx) => (
                      <tr key={`skeleton-${idx}`} className="h-14 animate-pulse">
                        {selectable && (
                          <td className="px-4">
                            <div className="w-4 h-4 rounded bg-white/10" />
                          </td>
                        )}
                        {columns.map(col => (
                          <td
                            key={col.key}
                            className={`px-4 ${col.hideOnMobile ? 'hidden md:table-cell' : ''}`}
                          >
                            <div className="h-3.5 w-3/4 rounded bg-white/10" />
                          </td>
                        ))}
                        {rowActions && (
                          <td className="px-3 text-right">
                            <div className="w-6 h-6 rounded-lg bg-white/10 ml-auto" />
                          </td>
                        )}
                      </tr>
                    ))
                  : items.map(item => {
                      const key = getRowKey(item);
                      const isSelected = selectedIds.includes(key);
                      const actions = rowActions ? rowActions(item).filter(a => !a.hidden) : [];
                      const isMenuOpen = openMenu?.key === key;

                      return (
                        <tr
                          key={key}
                          onClick={onRowClick ? () => onRowClick(item) : undefined}
                          className={`h-14 transition-colors ${
                            onRowClick ? 'cursor-pointer' : ''
                          } ${isSelected ? 'bg-[#17A491]/10' : 'hover:bg-white/[0.03]'}`}
                        >
                          {selectable && (
                            <td
                              className="px-4"
                              onClick={e => {
                                e.stopPropagation();
                              }}
                            >
                              <input
                                type="checkbox"
                                checked={isSelected}
                                onChange={() => toggleOne(key)}
                                aria-label="Select row"
                                className="w-4 h-4 rounded accent-[#25CDB6] cursor-pointer"
                              />
                            </td>
                          )}

                          {columns.map(col => (
                            <td
                              key={col.key}
                              className={`px-4 py-2 align-middle ${
                                col.align === 'right'
                                  ? 'text-right'
                                  : col.align === 'center'
                                    ? 'text-center'
                                    : 'text-left'
                              } ${col.hideOnMobile ? 'hidden md:table-cell' : ''} ${col.widthClass || ''}`}
                            >
                              {col.render(item)}
                            </td>
                          ))}

                          {rowActions && (
                            <td
                              className="px-3 text-right relative"
                              onClick={e => {
                                e.stopPropagation();
                              }}
                            >
                              {actions.length > 0 && (
                                <button
                                  ref={el => {
                                    triggerRefs.current[key] = el;
                                  }}
                                  type="button"
                                  aria-label="Row actions"
                                  aria-expanded={isMenuOpen}
                                  onClick={e => openMenuForRow(key, e.currentTarget, actions.length)}
                                  className="w-8 h-8 rounded-lg inline-flex items-center justify-center text-[#EDE9E0]/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                                >
                                  <MoreHorizontal className="w-4 h-4" />
                                </button>
                              )}
                            </td>
                          )}
                        </tr>
                      );
                    })}
              </tbody>
            </table>
          </div>

          {onPageChange && totalPages > 1 && (
            <div className="px-4 py-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs text-[#EDE9E0]/65">
              <span className="tabular-nums">
                Showing {startIndex}–{endIndex} of {effectiveTotal}
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={page <= 1}
                  onClick={() => onPageChange(page - 1)}
                  className="h-8 px-2.5 rounded-lg bg-[#06302F] border border-white/10 hover:border-white/20 text-[#EDE9E0] inline-flex items-center gap-1 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Prev</span>
                </button>
                <span className="px-2 font-mono text-[11px] tabular-nums">
                  {page} / {totalPages}
                </span>
                <button
                  type="button"
                  disabled={page >= totalPages}
                  onClick={() => onPageChange(page + 1)}
                  className="h-8 px-2.5 rounded-lg bg-[#06302F] border border-white/10 hover:border-white/20 text-[#EDE9E0] inline-flex items-center gap-1 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <span>Next</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {openMenu &&
        activeMenuActions.length > 0 &&
        typeof document !== 'undefined' &&
        createPortal(
          <div
            ref={portalMenuRef}
            role="menu"
            style={{
              position: 'fixed',
              top: `${openMenu.top}px`,
              left: `${openMenu.left}px`,
              transform: openMenu.openUp ? 'translateY(-100%)' : undefined,
              maxHeight: `${openMenu.maxHeight}px`,
              minWidth: '184px',
              width: '192px'
            }}
            className="z-[120] overflow-y-auto rounded-xl bg-[#06302F] border border-white/15 shadow-2xl py-1.5 text-left"
            onClick={e => e.stopPropagation()}
          >
            {activeMenuActions.map(action => {
              const Icon = action.icon;
              return (
                <button
                  key={action.id}
                  type="button"
                  role="menuitem"
                  disabled={action.disabled}
                  onClick={() => {
                    setOpenMenu(null);
                    action.onClick();
                  }}
                  className={`w-full px-3 py-2 text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer disabled:opacity-45 ${
                    action.destructive
                      ? 'text-red-300 hover:bg-red-500/15'
                      : 'text-[#EDE9E0] hover:bg-white/10'
                  }`}
                >
                  {Icon && <Icon className="w-3.5 h-3.5 shrink-0" />}
                  <span className="truncate">{action.label}</span>
                </button>
              );
            })}
          </div>,
          document.body
        )}
    </div>
  );
}
