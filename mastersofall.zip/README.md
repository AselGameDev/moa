# Masters Of All (MoA) — Portal & Platform

Official website and internal Control Room for **Masters Of All**.

**Tagline:** Believe. Build. Become.

This is a full-stack application:

- Public-facing website (home, about, departments, our work, contact, custom pages)
- Authenticated Control Room with role-based permissions for content, media, team, and settings
- Express API with a modular repository layer (`server/db/`), SQLite persistence & credential storage (`node:sqlite`), atomic writes, and rolling backups
- React 19 + Vite + Tailwind CSS v4 frontend

---

## Requirements

- **Node.js 22.13 or newer** (the server uses the built-in `node:sqlite` module; Node 24 LTS is recommended)
- npm

---

## Quick start (development)

```bash
cp .env.example .env   # then edit the values
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

---

## Initial founder account (production)

On first launch with an empty `data/` folder, a single Founder Administrator account (`admin@mastersofall.org`) is initialized with `isFounder: true` and `mustChangePassword: true`:

- Sign in with `"admin123"` (unless `INITIAL_ADMIN_PASSWORD` is explicitly set) and complete the forced strong-password update and TOTP 2FA enrollment.
- Team member accounts are created directly by administrators in **Control Room → Team → Add Member** with a temporary password, which members are required to change on first sign-in. No automated emails are sent.

---

## Production build & deployment

```bash
# 1. Build frontend assets and bundle production server to dist/
npm run build

# 2. Start production server (runs without devDependencies)
npm start
```

Verify types and tests before deploying:

```bash
npm run lint
npm run test
```

---

## Hosting on your own server

1. Install Node.js 22.13+ and clone/copy this folder to the server.
2. `cp .env.example .env` and set `NODE_ENV=production`, `APP_URL` (your real domain) and `PORT`.
3. `npm install && npm run build && npm start`
4. Run it as a service (systemd or pm2) and put nginx/Caddy in front for HTTPS. Keep `TRUST_PROXY=1` when behind one proxy.
5. The first start creates `data/moa.sqlite` and seeds the founder account. Sign in **immediately** and change the default password.
6. Back up the `data/` folder regularly. It holds all content, accounts and uploaded media.

---

## Environment variables

Copy `.env.example` to `.env` and configure values for your host:

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | HTTP port |
| `NODE_ENV` | `development` | Set to `production` in live environments |
| `APP_URL` | `http://localhost:3000` | Canonical public URL for sitemaps and CORS |
| `INITIAL_ADMIN_PASSWORD` | — | Optional strong (12+ chars) initial founder password on first empty DB boot |
| `TRUST_PROXY` | `1` | Express proxy hop setting (`1`, `true`, `false`, or subnet) |
| `ALLOWED_ORIGINS` | — | Optional comma-separated extra allowed origins |
| `MOA_DATA_DIR` | `data` | Directory holding `moa.sqlite` and rolling backups |
| `MOA_UPLOADS_DIR` | `public/uploads` | Legacy upload directory |

---

## Launch Checklist

Before going live in production, complete every step:

1. **Set `NODE_ENV=production`**: Enables strict TOTP 2FA enforcement, production static serving, HSTS headers, and CSP hardening.
2. **Update Founder Credentials & 2FA**: Sign in as Founder Admin (`admin@mastersofall.org`), replace the initial password when prompted (`mustChangePassword: true`), update your email & strong 12+ character password in Settings → Security, and save your TOTP authenticator recovery codes.
3. **Mount Persistent Storage**: Persist `MOA_DATA_DIR` (`data/`) across container restarts/deployments and configure off-site backups.
4. **Verify SEO & Content**: Review page metadata, sitemaps, contact address visibility, and legal/policy copy in Website & Settings before opening public traffic.

---

## Architecture & Operations

- Application data lives in SQLite (`data/moa.sqlite`), accessed through `server/db/` repositories with atomic writes and rolling backups in `data/backups/`. The `data/` folder holds users, password hashes, and sessions: it is git-ignored and must never be committed.
- Media uploads are validated by magic bytes (SVG and spoofed extensions rejected) and persisted in SQLite (`media_blobs`).
- Official brand logos (`/drawing1.png`, `/5320.jpg`) are locked in the Media Library (replaceable, not deletable).
- Proprietary — Masters Of All. All rights reserved.
