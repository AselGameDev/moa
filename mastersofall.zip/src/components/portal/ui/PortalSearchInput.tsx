import React, { useRef } from 'react';
import { Search, X } from 'lucide-react';

export interface PortalSearchInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  ariaLabel?: string;
  className?: string;
  autoFocus?: boolean;
}

export const PortalSearchInput: React.FC<PortalSearchInputProps> = ({
  value,
  onChange,
  placeholder = 'Search...',
  ariaLabel,
  className = '',
  autoFocus = false
}) => {
  const inputRef = useRef<HTMLInputElement | null>(null);

  return (
    <div className={`relative flex items-center ${className}`}>
      <Search
        className="w-4 h-4 text-[#EDE9E0]/45 absolute left-3 pointer-events-none shrink-0"
        aria-hidden="true"
      />
      <input
        ref={inputRef}
        type="search"
        value={value}
        autoFocus={autoFocus}
        onChange={e => onChange(e.target.value)}
        onKeyDown={e => {
          if (e.key === 'Escape' && value) {
            e.preventDefault();
            onChange('');
          }
        }}
        placeholder={placeholder}
        aria-label={ariaLabel || placeholder}
        className="w-full h-9 pl-9 pr-8 rounded-xl bg-[#031D1C] border border-white/12 hover:border-white/20 focus:border-[#25CDB6]/60 text-xs text-[#EDE9E0] placeholder:text-[#EDE9E0]/40 transition-colors focus:outline-none [&::-webkit-search-cancel-button]:hidden"
      />
      {value && (
        <button
          type="button"
          onClick={() => {
            onChange('');
            inputRef.current?.focus();
          }}
          aria-label="Clear search"
          className="absolute right-2 p-1 rounded-lg text-[#EDE9E0]/50 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  );
};
