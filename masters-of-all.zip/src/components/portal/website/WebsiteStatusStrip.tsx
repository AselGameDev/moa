import React, { useState } from 'react';
import {
  CheckCircle2,
  Edit3,
  ExternalLink,
  AlertCircle,
  Loader2,
  X,
  RotateCcw,
  UploadCloud
} from 'lucide-react';
import { WebsiteOverviewResponse } from '../../../types';

interface WebsiteStatusStripProps {
  overview: WebsiteOverviewResponse | null;
  canEditWebsite: boolean;
  onPublishPageDraft: (pageId: string) => Promise<void>;
  onDiscardPageDraft: (pageId: string) => Promise<void>;
  onPublishAllDrafts: () => Promise<void>;
  onOpenLiveEditor: () => void | Promise<void>;
  onViewPublicSite: () => void;
}

function formatDateTime(iso?: string): string {
  if (!iso) return 'Not recorded yet';
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return 'Not recorded yet';
  return dt.toLocaleString(undefined, {
    dateStyle: 'medium',
    timeStyle: 'short'
  });
}

export const WebsiteStatusStrip: React.FC<WebsiteStatusStripProps> = ({
  overview,
  canEditWebsite,
  onPublishPageDraft,
  onDiscardPageDraft,
  onPublishAllDrafts,
  onOpenLiveEditor,
  onViewPublicSite
}) => {
  const [reviewOpen, setReviewOpen] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [reviewError, setReviewError] = useState<string | null>(null);

  const draftPages = overview?.draftPages || [];
  const draftCount = overview?.unpublishedCount ?? draftPages.length;
  const lastPublishedDate = overview?.lastPublishedAt ? formatDateTime(overview.lastPublishedAt) : 'Initial release';
  const lastPublishedBy = overview?.lastPublishedByName || 'System';

  const handlePublishOne = async (pageId: string) => {
    setBusyId(`pub:${pageId}`);
    setReviewError(null);
    try {
      await onPublishPageDraft(pageId);
    } catch (err) {
      setReviewError(err instanceof Error ? err.message : 'Failed to publish draft.');
    } finally {
      setBusyId(null);
    }
  };

  const handleDiscardOne = async (pageId: string) => {
    setBusyId(`disc:${pageId}`);
    setReviewError(null);
    try {
      await onDiscardPageDraft(pageId);
    } catch (err) {
      setReviewError(err instanceof Error ? err.message : 'Failed to discard draft.');
    } finally {
      setBusyId(null);
    }
  };

  const handlePublishAll = async () => {
    setBusyId('all');
    setReviewError(null);
    try {
      await onPublishAllDrafts();
      setReviewOpen(false);
    } catch (err) {
      setReviewError(err instanceof Error ? err.message : 'Failed to publish all drafts.');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <>
      <div className="rounded-2xl bg-[#031D1C] border border-white/10 px-4 py-3.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs">
          <div className="inline-flex items-center gap-2 font-bold text-[#25CDB6]">
            <span className="w-2 h-2 rounded-full bg-[#25CDB6]" />
            <span>{overview?.siteStatus || 'Live'}</span>
          </div>

          <div className="text-[#EDE9E0]/75">
            <span className="text-[#EDE9E0]/50">Last published: </span>
            <span className="font-semibold text-[#EDE9E0]">{lastPublishedDate}</span>
            <span className="text-[#EDE9E0]/60"> by {lastPublishedBy}</span>
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`px-2.5 py-1 rounded-full font-semibold ${
                draftCount > 0
                  ? 'bg-[#D0A873]/15 border border-[#D0A873]/30 text-[#D0A873]'
                  : 'bg-white/5 border border-white/10 text-[#EDE9E0]/65'
              }`}
            >
              Unpublished changes: {draftCount} {draftCount === 1 ? 'page' : 'pages'}
            </span>
            {draftCount > 0 && canEditWebsite && (
              <button
                type="button"
                onClick={() => {
                  setReviewError(null);
                  setReviewOpen(true);
                }}
                className="px-3 py-1 rounded-lg bg-[#D0A873] hover:bg-[#e0ba85] text-[#031D1C] font-bold transition-colors cursor-pointer"
              >
                Review changes
              </button>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {canEditWebsite && (
            <button
              type="button"
              onClick={() => void onOpenLiveEditor()}
              className="h-9 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold text-xs inline-flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Open live editor</span>
            </button>
          )}
          <button
            type="button"
            onClick={onViewPublicSite}
            className="h-9 px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0] font-semibold text-xs inline-flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5 text-[#25CDB6]" />
            <span>View public site</span>
          </button>
        </div>
      </div>

      {reviewOpen && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-label="Review unpublished page changes"
          onClick={() => setReviewOpen(false)}
        >
          <div
            className="w-full max-w-xl rounded-2xl bg-[#031D1C] border border-white/15 shadow-2xl overflow-hidden text-[#EDE9E0]"
            onClick={e => e.stopPropagation()}
          >
            <div className="px-5 py-4 border-b border-white/10 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold">Unpublished Page Changes</h3>
                <p className="text-xs text-[#EDE9E0]/60">
                  Publish or discard saved drafts across {draftPages.length}{' '}
                  {draftPages.length === 1 ? 'page' : 'pages'}.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setReviewOpen(false)}
                aria-label="Close review changes modal"
                className="p-1.5 rounded-lg text-[#EDE9E0]/60 hover:text-white hover:bg-white/10 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-3 max-h-[60vh] overflow-y-auto">
              {reviewError && (
                <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{reviewError}</span>
                </div>
              )}

              {draftPages.length === 0 ? (
                <div className="py-8 text-center text-xs text-[#EDE9E0]/60 space-y-2">
                  <CheckCircle2 className="w-6 h-6 text-[#25CDB6] mx-auto" />
                  <p>All changes are currently published live.</p>
                </div>
              ) : (
                draftPages.map(draft => (
                  <div
                    key={draft.pageId}
                    className="p-3.5 rounded-xl bg-[#06302F] border border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <span className="font-bold text-[#EDE9E0] block">{draft.pageName}</span>
                      <span className="text-[11px] text-[#EDE9E0]/60">
                        {draft.path} · {draft.changedFieldsCount} modified{' '}
                        {draft.changedFieldsCount === 1 ? 'field' : 'fields'} · Edited{' '}
                        {formatDateTime(draft.updatedAt)} by {draft.updatedByName}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={busyId !== null}
                        onClick={() => void handleDiscardOne(draft.pageId)}
                        className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0]/80 font-semibold inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                      >
                        <RotateCcw className="w-3 h-3" />
                        <span>Discard</span>
                      </button>
                      <button
                        type="button"
                        disabled={busyId !== null}
                        onClick={() => void handlePublishOne(draft.pageId)}
                        className="px-3 py-1.5 rounded-lg bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                      >
                        {busyId === `pub:${draft.pageId}` ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <UploadCloud className="w-3 h-3" />
                        )}
                        <span>Publish</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {draftPages.length > 0 && (
              <div className="px-5 py-3.5 border-t border-white/10 bg-[#06302F]/60 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setReviewOpen(false)}
                  className="h-9 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold text-[#EDE9E0]/80 cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  disabled={busyId !== null}
                  onClick={() => void handlePublishAll()}
                  className="h-9 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  {busyId === 'all' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <UploadCloud className="w-3.5 h-3.5" />
                  )}
                  <span>Publish all ({draftPages.length})</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};
