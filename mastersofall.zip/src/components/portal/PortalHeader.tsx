import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  Bell,
  Plus,
  ExternalLink,
  ChevronDown,
  LogOut,
  FolderKanban,
  Building,
  FileText,
  BookOpen,
  Package,
  Users,
  Trash2
} from 'lucide-react';
import { User, RoleDefinition } from '../../types';
import { can } from '../../shared/permissions';
import { CreateActionType, getVisibleCreateActions } from './portalRegistry';

interface PortalHeaderProps {
  breadcrumbs: string[];
  currentUser: User;
  roles?: RoleDefinition[];
  onOpenSearch: () => void;
  onOpenInbox: () => void;
  onOpenTrash?: () => void;
  attentionCount?: number;
  onNavigateSite: () => void;
  onLogout: () => void;
  onCreateAction: (actionType: CreateActionType) => void;
}

const ACTION_ICONS: Record<CreateActionType, { icon: React.ComponentType<{ className?: string }>; color: string }> = {
  project: { icon: FolderKanban, color: 'text-[#25CDB6]' },
  publication: { icon: BookOpen, color: 'text-[#D0A873]' },
  product: { icon: Package, color: 'text-[#64B5D9]' },
  department: { icon: Building, color: 'text-[#CA7952]' },
  page: { icon: FileText, color: 'text-[#EDE9E0]/80' },
  member: { icon: Users, color: 'text-[#EDE9E0]/80' }
};

export const PortalHeader: React.FC<PortalHeaderProps> = ({
  breadcrumbs,
  currentUser,
  roles,
  onOpenSearch,
  onOpenInbox,
  onOpenTrash,
  attentionCount = 0,
  onNavigateSite,
  onLogout,
  onCreateAction
}) => {
  const [createMenuOpen, setCreateMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const createMenuRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  const visibleActions = getVisibleCreateActions(currentUser, roles);
  const canManageTrash = can(currentUser, 'trash.manage', roles);
  const initialLetter = (currentUser?.name || currentUser?.email || 'U').trim()[0].toUpperCase();

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (createMenuRef.current && !createMenuRef.current.contains(e.target as Node)) {
        setCreateMenuOpen(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 h-16 shrink-0 bg-[#031D1C] border-b border-white/10 px-3 sm:px-6 flex items-center justify-between gap-2 sm:gap-4 z-30">
      <div className="flex items-center gap-3 overflow-hidden min-w-0 flex-1 md:flex-initial md:max-w-[38%] lg:max-w-[36%]">
        <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs text-[#EDE9E0]/55 truncate font-medium min-w-0">
          {breadcrumbs.map((crumb, idx) => (
            <React.Fragment key={idx}>
              {idx > 0 && <span className="text-white/25 shrink-0">/</span>}
              <span className={`truncate ${idx === breadcrumbs.length - 1 ? 'text-[#EDE9E0] font-bold' : ''}`}>
                {crumb}
              </span>
            </React.Fragment>
          ))}
        </nav>
      </div>

      <div className="hidden md:block flex-1 min-w-[180px] max-w-sm lg:max-w-md mx-2">
        <button
          type="button"
          onClick={onOpenSearch}
          className="w-full h-9 bg-[#06302F] hover:bg-[#083B3A] border border-white/12 hover:border-[#25CDB6]/50 px-3.5 rounded-xl text-xs text-[#EDE9E0]/55 hover:text-[#EDE9E0]/85 flex items-center justify-between transition-colors cursor-pointer group"
        >
          <div className="flex items-center gap-2 min-w-0">
            <Search className="w-3.5 h-3.5 text-[#EDE9E0]/45 group-hover:text-[#25CDB6] transition-colors shrink-0" />
            <span className="truncate">Search workspace or jump to...</span>
          </div>
          <kbd className="hidden lg:inline-block px-1.5 py-0.5 rounded-md bg-[#031D1C] border border-white/12 text-[10px] font-mono text-[#EDE9E0]/55 shrink-0">
            /
          </kbd>
        </button>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={onOpenSearch}
          className="md:hidden w-9 h-9 rounded-full bg-[#06302F] border border-white/12 text-[#EDE9E0]/75 hover:text-white hover:border-white/25 inline-flex items-center justify-center transition-colors cursor-pointer"
          aria-label="Search Control Room"
          title="Search (/)"
        >
          <Search className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={onOpenInbox}
          className="w-9 h-9 rounded-full bg-[#06302F] hover:bg-white/10 border border-white/12 hover:border-white/25 text-[#EDE9E0]/80 hover:text-white inline-flex items-center justify-center transition-colors cursor-pointer relative shrink-0"
          aria-label="Open notifications inbox"
          title="Needs your attention inbox"
        >
          <Bell className="w-4 h-4 shrink-0" />
          {attentionCount > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-amber-500 text-[#031D1C] text-[10px] font-mono font-bold tabular-nums flex items-center justify-center shadow-sm">
              {attentionCount > 99 ? '99+' : attentionCount}
            </span>
          )}
        </button>

        {canManageTrash && onOpenTrash && (
          <button
            type="button"
            onClick={onOpenTrash}
            className="w-9 h-9 rounded-full bg-[#06302F] hover:bg-white/10 border border-white/12 hover:border-white/25 text-[#EDE9E0]/80 hover:text-white inline-flex items-center justify-center transition-colors cursor-pointer shrink-0"
            aria-label="Open Trash drawer"
            title="Trash"
          >
            <Trash2 className="w-4 h-4 shrink-0" />
          </button>
        )}

        {visibleActions.length > 0 && (
          <div className="relative" ref={createMenuRef}>
            <button
              type="button"
              onClick={() => setCreateMenuOpen(!createMenuOpen)}
              className="h-9 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] text-xs font-bold inline-flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
              <span className="hidden sm:inline">Create</span>
              <ChevronDown className="w-3.5 h-3.5 text-[#031D1C]/70" />
            </button>

            {createMenuOpen && (
              <div className="absolute right-0 mt-2 w-60 max-w-[calc(100vw-1.5rem)] bg-[#031D1C] border border-white/15 rounded-2xl shadow-2xl p-1.5 space-y-0.5 text-xs text-[#EDE9E0] z-50">
                {visibleActions.map(action => {
                  const meta = ACTION_ICONS[action.id];
                  const Icon = meta.icon;
                  return (
                    <button
                      key={action.id}
                      type="button"
                      onClick={() => {
                        setCreateMenuOpen(false);
                        onCreateAction(action.id);
                      }}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl hover:bg-white/10 text-left transition-colors cursor-pointer"
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${meta.color}`} />
                      <div className="min-w-0">
                        <span className="font-bold block truncate">{action.label}</span>
                        <span className="text-[10px] text-[#EDE9E0]/50 block truncate">{action.description}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        <button
          type="button"
          onClick={onNavigateSite}
          className="hidden sm:inline-flex h-9 items-center gap-1.5 px-3.5 rounded-xl bg-[#06302F] hover:bg-white/10 border border-white/12 hover:border-white/25 text-xs font-semibold text-[#EDE9E0] transition-colors cursor-pointer"
          title="Open live public website"
        >
          <span>Live Site</span>
          <ExternalLink className="w-3.5 h-3.5 text-[#EDE9E0]/60" />
        </button>

        <div className="relative" ref={userMenuRef}>
          <button
            type="button"
            onClick={() => setUserMenuOpen(!userMenuOpen)}
            aria-label="Account menu"
            className="w-9 h-9 rounded-full bg-[#17A491]/20 hover:bg-[#17A491]/30 border border-[#25CDB6]/40 text-[#25CDB6] font-bold text-xs flex items-center justify-center cursor-pointer transition-colors shrink-0"
            title={currentUser?.name || currentUser?.email}
          >
            {initialLetter}
          </button>

          {userMenuOpen && (
            <div className="absolute right-0 mt-2 w-56 max-w-[calc(100vw-1.5rem)] bg-[#031D1C] border border-white/15 rounded-2xl shadow-2xl p-2 space-y-1 text-xs text-[#EDE9E0] z-50">
              <div className="px-3 py-2 border-b border-white/10">
                <span className="font-bold block text-[#EDE9E0] truncate">{currentUser?.name}</span>
                <span className="text-[10px] text-[#EDE9E0]/50 truncate block font-mono">{currentUser?.email}</span>
                <span className="inline-block mt-1 px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#17A491]/20 text-[#25CDB6] capitalize">
                  {currentUser?.role}
                </span>
              </div>

              <button
                type="button"
                onClick={() => {
                  setUserMenuOpen(false);
                  onNavigateSite();
                }}
                className="sm:hidden w-full flex items-center gap-2 px-3 py-2 rounded-xl text-[#EDE9E0] hover:bg-white/10 text-left transition-colors cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5 text-[#25CDB6]" />
                <span>Open Live Site</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setUserMenuOpen(false);
                  onLogout();
                }}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-red-300 hover:bg-red-500/10 text-left transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
