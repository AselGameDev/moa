import React, { useRef, useState } from 'react';
import { FileText, Film, FolderOpen, Image as ImageIcon, Loader2, Music, Trash2, Upload } from 'lucide-react';
import { MediaAsset, MediaType } from '../../../types';
import { api } from '../../../services/api';
import { MediaPicker } from '../../MediaPicker';

export interface PortalMediaFieldProps {
  label: string;
  description?: string;
  value: string;
  onChange: (url: string, asset?: MediaAsset) => void;
  allowedTypes?: MediaType[];
  pickerTitle?: string;
  uploadFolder?: string;
  aspectClass?: string;
  clearLabel?: string;
  compact?: boolean;
  onPickerOpenChange?: (open: boolean) => void;
  className?: string;
}

export const PortalMediaField: React.FC<PortalMediaFieldProps> = ({
  label,
  description,
  value,
  onChange,
  allowedTypes = ['image'],
  pickerTitle = 'Select Media Asset',
  uploadFolder = 'General',
  aspectClass = 'aspect-[16/9]',
  clearLabel = 'Remove',
  compact = false,
  onPickerOpenChange,
  className = ''
}) => {
  const [pickerOpen, setPickerOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const setPickerVisible = (open: boolean) => {
    setPickerOpen(open);
    onPickerOpenChange?.(open);
  };

  const acceptAttr =
    allowedTypes.length === 1
      ? allowedTypes[0] === 'image'
        ? 'image/*'
        : allowedTypes[0] === 'document'
          ? 'application/pdf,.pdf'
          : allowedTypes[0] === 'video'
            ? 'video/*'
            : 'audio/*'
      : 'image/*,video/*,audio/*,application/pdf,.pdf';

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setUploadProgress(0);
    setUploadError(null);
    try {
      const uploaded = await api.uploadMedia(
        {
          file,
          name: file.name,
          altText: file.name.replace(/\.[^.]+$/, ''),
          folder: uploadFolder
        },
        pct => setUploadProgress(pct)
      );
      onChange(uploaded.url, uploaded);
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Upload failed.');
    } finally {
      setUploading(false);
      setUploadProgress(0);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const cleanFileName = value ? value.split('/').pop()?.split('?')[0] || value : '';
  const isPdf = value.toLowerCase().endsWith('.pdf') || allowedTypes.every(t => t === 'document');
  const isVideo = /\.(mp4|webm|mov|m4v)(\?|$)/i.test(value);
  const isAudio = /\.(mp3|wav|ogg|m4a)(\?|$)/i.test(value);

  return (
    <div className={`space-y-2 ${className}`}>
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-xs font-semibold text-[#EDE9E0]">{label}</span>
        {cleanFileName && (
          <span className="text-[11px] font-mono text-[#EDE9E0]/50 truncate max-w-[200px]">
            {cleanFileName}
          </span>
        )}
      </div>
      {description && <p className="text-[11px] text-[#EDE9E0]/55 break-words">{description}</p>}

      <div
        className={`rounded-2xl border border-white/12 bg-[#06302F]/60 overflow-hidden ${
          compact ? 'flex items-center gap-3 p-3' : 'flex flex-col'
        }`}
      >
        <div
          className={`bg-[#031D1C] flex items-center justify-center relative overflow-hidden shrink-0 ${
            compact ? 'w-20 h-16 rounded-xl border border-white/10' : `${aspectClass} w-full border-b border-white/10`
          }`}
        >
          {value ? (
            isPdf ? (
              <div className="flex flex-col items-center gap-1.5 text-[#D0A873] p-3 text-center">
                <FileText className="w-7 h-7" />
                {!compact && (
                  <span className="text-[11px] font-mono text-[#EDE9E0]/80 truncate max-w-full px-3">
                    {cleanFileName}
                  </span>
                )}
              </div>
            ) : isVideo ? (
              <div className="flex flex-col items-center gap-1.5 text-[#25CDB6] p-3 text-center">
                <Film className="w-7 h-7" />
                {!compact && (
                  <span className="text-[11px] font-mono text-[#EDE9E0]/80 truncate max-w-full px-3">
                    {cleanFileName}
                  </span>
                )}
              </div>
            ) : isAudio ? (
              <div className="flex flex-col items-center gap-1.5 text-[#17A491] p-3 text-center">
                <Music className="w-7 h-7" />
                {!compact && (
                  <span className="text-[11px] font-mono text-[#EDE9E0]/80 truncate max-w-full px-3">
                    {cleanFileName}
                  </span>
                )}
              </div>
            ) : (
              <img
                src={value}
                alt={label}
                className="w-full h-full object-cover"
              />
            )
          ) : (
            <div className="flex flex-col items-center gap-1 text-[#EDE9E0]/35 p-3 text-center">
              <ImageIcon className={compact ? 'w-5 h-5' : 'w-7 h-7'} />
              {!compact && <span className="text-[11px]">No asset selected</span>}
            </div>
          )}
        </div>

        <div className={`flex flex-wrap items-center gap-2 ${compact ? 'flex-1 min-w-0' : 'p-3'}`}>
          <input
            ref={fileInputRef}
            type="file"
            accept={acceptAttr}
            onChange={handleFileChange}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => setPickerVisible(true)}
            className="h-9 px-3 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FolderOpen className="w-3.5 h-3.5 text-[#25CDB6]" />
            <span>{value ? 'Replace from library' : 'Choose from library'}</span>
          </button>

          <button
            type="button"
            disabled={uploading}
            onClick={() => fileInputRef.current?.click()}
            className="h-9 px-3 rounded-xl bg-[#17A491]/15 hover:bg-[#17A491]/25 border border-[#25CDB6]/30 text-xs font-semibold text-[#25CDB6] inline-flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
          >
            {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
            <span>{uploading ? `Uploading ${uploadProgress}%` : 'Upload'}</span>
          </button>

          {value && (
            <button
              type="button"
              onClick={() => onChange('')}
              aria-label={`${clearLabel} ${label}`}
              className="h-9 px-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-400/25 text-xs font-semibold text-red-300 inline-flex items-center gap-1.5 transition-colors cursor-pointer ml-auto"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{clearLabel}</span>
            </button>
          )}
        </div>
      </div>

      {uploadError && (
        <p className="text-[11px] text-red-300 break-words">{uploadError}</p>
      )}

      <MediaPicker
        isOpen={pickerOpen}
        onClose={() => setPickerVisible(false)}
        onSelect={asset => {
          onChange(asset.url, asset);
          setPickerVisible(false);
        }}
        allowedTypes={allowedTypes}
        title={pickerTitle}
        currentUrl={value}
      />
    </div>
  );
};
