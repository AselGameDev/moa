import React from 'react';

export type PortalStatusVariant =
  | 'Draft'
  | 'Pending Review'
  | 'In review'
  | 'Published'
  | 'Archived'
  | 'Hidden'
  | 'Draft changes'
  | 'Auto-visible'
  | string;

const STATUS_STYLE_MAP: Record<
  string,
  { label: string; badgeClass: string; dotClass: string }
> = {
  published: {
    label: 'Published',
    badgeClass: 'bg-[#17A491]/15 border-[#25CDB6]/35 text-[#25CDB6]',
    dotClass: 'bg-[#25CDB6]'
  },
  'auto-visible': {
    label: 'Auto-visible',
    badgeClass: 'bg-[#17A491]/15 border-[#25CDB6]/35 text-[#25CDB6]',
    dotClass: 'bg-[#25CDB6]'
  },
  'pending review': {
    label: 'In review',
    badgeClass: 'bg-[#D0A873]/15 border-[#D0A873]/40 text-[#D0A873]',
    dotClass: 'bg-[#D0A873]'
  },
  'in review': {
    label: 'In review',
    badgeClass: 'bg-[#D0A873]/15 border-[#D0A873]/40 text-[#D0A873]',
    dotClass: 'bg-[#D0A873]'
  },
  'draft changes': {
    label: 'Draft changes',
    badgeClass: 'bg-[#D0A873]/15 border-[#D0A873]/40 text-[#D0A873]',
    dotClass: 'bg-[#D0A873]'
  },
  draft: {
    label: 'Draft',
    badgeClass: 'bg-white/8 border-white/15 text-[#EDE9E0]/85',
    dotClass: 'bg-[#EDE9E0]/60'
  },
  archived: {
    label: 'Archived',
    badgeClass: 'bg-amber-500/12 border-amber-400/25 text-amber-200/80',
    dotClass: 'bg-amber-400/75'
  },
  hidden: {
    label: 'Hidden',
    badgeClass: 'bg-white/5 border-white/10 text-[#EDE9E0]/55',
    dotClass: 'bg-[#EDE9E0]/35'
  }
};

export interface PortalStatusBadgeProps {
  status: PortalStatusVariant;
  labelOverride?: string;
  showDot?: boolean;
  className?: string;
}

export const PortalStatusBadge: React.FC<PortalStatusBadgeProps> = ({
  status,
  labelOverride,
  showDot = true,
  className = ''
}) => {
  const key = String(status || 'Draft').trim().toLowerCase();
  const entry = STATUS_STYLE_MAP[key] || {
    label: status || 'Draft',
    badgeClass: 'bg-white/8 border-white/15 text-[#EDE9E0]/80',
    dotClass: 'bg-[#EDE9E0]/50'
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border text-[11px] font-semibold whitespace-nowrap ${entry.badgeClass} ${className}`}
    >
      {showDot && <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${entry.dotClass}`} aria-hidden="true" />}
      <span>{labelOverride || entry.label}</span>
    </span>
  );
};

export interface PortalStatusLegendProps {
  statuses?: PortalStatusVariant[];
  className?: string;
}

export const PortalStatusLegend: React.FC<PortalStatusLegendProps> = ({
  statuses = ['Published', 'In review', 'Draft', 'Archived', 'Hidden'],
  className = ''
}) => {
  return (
    <div
      className={`flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-[#EDE9E0]/65 ${className}`}
      aria-label="Status indicator legend"
    >
      {statuses.map(st => {
        const key = String(st).toLowerCase();
        const entry = STATUS_STYLE_MAP[key] || {
          label: st,
          badgeClass: '',
          dotClass: 'bg-[#EDE9E0]/50'
        };
        return (
          <span key={st} className="inline-flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full shrink-0 ${entry.dotClass}`} aria-hidden="true" />
            <span>{entry.label}</span>
          </span>
        );
      })}
    </div>
  );
};
