import {
  User,
  RoleDefinition,
  Department,
  Project,
  Publication,
  Product,
  MediaAsset,
  MediaUploadLimits,
  SiteContent,
  SiteSettings,
  ActivityRecord,
  SecurityLogRecord,
  SiteHealthItem,
  ContentHistorySnapshot,
  PageRecord,
  FormSubmission,
  TrashItemsResponse,
  PaginatedResult,
  RedirectRule,
  AnnouncementBarConfig,
  SocialLink,
  WebsiteMenusConfig,
  WebsiteOverviewResponse,
  WebsitePageSettingsResponse,
  RedirectTestResult,
  ContentListParams,
  BulkContentAction
} from '../types';

export type { RedirectTestResult };

const TOKEN_KEY = 'moa_control_room_token';
const USER_KEY = 'moa_control_room_user';

export class HttpError extends Error {
  status: number;
  data?: Record<string, unknown>;

  constructor(message: string, status: number, data?: Record<string, unknown>) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
    this.data = data;
  }
}

export interface SubmissionsPaginatedResponse extends PaginatedResult<FormSubmission> {
  unreadCount: number;
}

export interface HealthResponse {
  ok: boolean;
  status: string;
  timestamp: string;
  schemaVersion?: number;
  contentVersion?: number;
}

class ApiService {
  private token: string | null = null;
  private user: User | null = null;
  private unauthorizedHandler: (() => void) | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.token = localStorage.getItem(TOKEN_KEY);
      const userJson = localStorage.getItem(USER_KEY);
      if (userJson) {
        try {
          this.user = JSON.parse(userJson) as User;
        } catch {
          this.user = null;
        }
      }
    }
  }

  public registerUnauthorizedHandler(cb: (() => void) | null) {
    this.unauthorizedHandler = cb;
  }

  public getToken(): string | null {
    return this.token;
  }

  public getCurrentUser(): User | null {
    return this.user;
  }

  public setSession(token: string, user: User) {
    this.token = token;
    this.user = user;
    if (typeof window !== 'undefined') {
      localStorage.setItem(TOKEN_KEY, token);
      localStorage.setItem(USER_KEY, JSON.stringify(user));
    }
  }

  public clearSession() {
    this.token = null;
    this.user = null;
    if (typeof window !== 'undefined') {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
    }
  }

  /**
   * Security note (Token storage tradeoff):
   * The session token is stored in localStorage and sent explicitly via
   * `Authorization: Bearer <token>` + `X-MoA-Request: 1` rather than an
   * httpOnly SameSite=Strict cookie so authenticated Control Room requests work
   * inside cross-site iframe preview environments where SameSite=Strict cookies
   * are suppressed by browsers.
   */
  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'X-MoA-Request': '1',
      ...(options.headers as Record<string, string> | undefined)
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const res = await fetch(endpoint, {
      ...options,
      headers
    });

    if (!res.ok) {
      let errMsg = `Request failed (${res.status})`;
      let errorData: Record<string, unknown> | undefined;
      try {
        const parsed = (await res.json()) as Record<string, unknown>;
        errorData = parsed;
        if (typeof parsed.error === 'string' && parsed.error) {
          errMsg = parsed.error;
        }
      } catch {
        // fallback to status text
      }

      if (res.status === 401 && !endpoint.includes('/api/auth/signin')) {
        const hadToken = Boolean(this.token);
        this.clearSession();
        if (hadToken && this.unauthorizedHandler) {
          this.unauthorizedHandler();
        }
      }

      throw new HttpError(errMsg, res.status, errorData);
    }

    return (await res.json()) as T;
  }

  // Health & Version
  async getHealth(): Promise<HealthResponse> {
    return this.request<HealthResponse>('/api/health');
  }

  async getContentVersion(): Promise<{ version: number }> {
    return this.request<{ version: number }>('/api/content-version');
  }

  // Auth Endpoints
  async signIn(
    email: string,
    password: string,
    twoFactorCode?: string
  ): Promise<{ token?: string; user?: User; requires2FA?: boolean; requires2FASetup?: boolean }> {
    const cleanEmail = email.trim().toLowerCase();

    const data = await this.request<{
      token?: string;
      user?: User;
      requires2FA?: boolean;
      requires2FASetup?: boolean;
    }>('/api/auth/signin', {
      method: 'POST',
      body: JSON.stringify({ email: cleanEmail, password, twoFactorCode })
    });

    if (data.requires2FA) {
      return data;
    }

    if (!data.token || !data.user) {
      throw new Error('Authentication failed: server did not return a valid session token.');
    }

    this.setSession(data.token, data.user);
    return data;
  }

  async changePassword(newPassword: string): Promise<{ success: boolean; message: string; user?: User }> {
    const data = await this.request<{ success: boolean; message: string; user?: User }>('/api/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ newPassword })
    });
    if (data.user && this.token) {
      this.setSession(this.token, data.user);
    }
    return data;
  }

  async updateCredentials(payload: {
    currentPassword: string;
    newEmail?: string;
    newPassword?: string;
  }): Promise<{ success: boolean; message: string; user?: User }> {
    const data = await this.request<{ success: boolean; message: string; user?: User }>('/api/auth/update-credentials', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    if (data.user && this.token) {
      this.setSession(this.token, data.user);
    }
    return data;
  }

  async getMe(): Promise<{ user: User }> {
    const data = await this.request<{ user: User }>('/api/auth/me');
    if (data.user) {
      this.user = data.user;
      if (typeof window !== 'undefined') {
        localStorage.setItem(USER_KEY, JSON.stringify(data.user));
      }
    }
    return data;
  }

  async updateProfile(payload: { name?: string }): Promise<{ user: User }> {
    const data = await this.request<{ user: User }>('/api/auth/profile', {
      method: 'PATCH',
      body: JSON.stringify(payload)
    });
    if (data.user && this.token) {
      this.setSession(this.token, data.user);
    }
    return data;
  }

  async signOut(): Promise<void> {
    try {
      await this.request('/api/auth/signout', { method: 'POST' });
    } catch {
      // Ignore error on signout cleanup
    } finally {
      this.clearSession();
    }
  }

  async setup2FA(): Promise<{ secret: string; otpauthUri: string; recoveryCodes: string[] }> {
    return this.request('/api/auth/2fa/setup', { method: 'POST' });
  }

  async verify2FA(code: string): Promise<{ success: boolean; twoFactorEnabled: boolean; user: User }> {
    const res = await this.request<{ success: boolean; twoFactorEnabled: boolean; user: User }>('/api/auth/2fa/verify', {
      method: 'POST',
      body: JSON.stringify({ code })
    });
    if (res.user && this.token) {
      this.setSession(this.token, res.user);
    }
    return res;
  }

  async disable2FA(password: string, code: string): Promise<{ success: boolean; twoFactorEnabled: boolean; user: User }> {
    const res = await this.request<{ success: boolean; twoFactorEnabled: boolean; user: User }>('/api/auth/2fa/disable', {
      method: 'POST',
      body: JSON.stringify({ password, code })
    });
    if (res.user && this.token) {
      this.setSession(this.token, res.user);
    }
    return res;
  }

  // Roles & Permissions
  async getRoles(): Promise<RoleDefinition[]> {
    return this.request<RoleDefinition[]>('/api/roles');
  }

  async createRole(payload: { name: string; permissions: string[] }): Promise<RoleDefinition> {
    return this.request<RoleDefinition>('/api/roles', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async updateRole(id: string, payload: { name?: string; permissions?: string[] }): Promise<RoleDefinition> {
    return this.request<RoleDefinition>(`/api/roles/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async deleteRole(id: string): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>(`/api/roles/${id}`, {
      method: 'DELETE'
    });
  }

  // Members
  async getMembers(): Promise<User[]> {
    return this.request<User[]>('/api/members');
  }

  async createMember(payload: {
    name: string;
    email: string;
    temporaryPassword?: string;
    roleId?: string;
    role?: string;
    departmentScope?: string[];
  }): Promise<User & { temporaryPassword?: string }> {
    return this.request('/api/members', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async updateMember(
    id: string,
    payload: Partial<User> & { email?: string; password?: string }
  ): Promise<User> {
    return this.request(`/api/members/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async resetMemberPassword(id: string): Promise<{ success: boolean; temporaryPassword: string }> {
    return this.request(`/api/members/${id}/reset-password`, {
      method: 'POST'
    });
  }

  async deleteMember(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/members/${id}`, {
      method: 'DELETE'
    });
  }

  // Departments
  async getDepartments(): Promise<Department[]> {
    return this.request<Department[]>('/api/departments');
  }

  async getAllDepartments(): Promise<Department[]> {
    return this.request<Department[]>('/api/departments/all');
  }

  async createDepartment(payload: Partial<Department>): Promise<Department> {
    return this.request<Department>('/api/departments', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async updateDepartment(id: string, payload: Partial<Department>): Promise<Department> {
    return this.request<Department>(`/api/departments/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async reorderDepartments(orderedIds: string[]): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>('/api/departments/reorder', {
      method: 'POST',
      body: JSON.stringify({ orderedIds })
    });
  }

  async deleteDepartment(
    id: string,
    options?: { projectHandling: 'leave' | 'reassign'; targetDeptId?: string }
  ): Promise<{ success: boolean }> {
    return this.request(`/api/departments/${id}`, {
      method: 'DELETE',
      body: JSON.stringify(options || {})
    });
  }

  async restoreDepartment(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/departments/${id}/restore`, {
      method: 'POST'
    });
  }

  async restoreDepartmentVersion(id: string, versionId: string): Promise<Department> {
    return this.request<Department>(`/api/departments/${encodeURIComponent(id)}/restore-version`, {
      method: 'POST',
      body: JSON.stringify({ versionId })
    });
  }

  async duplicateDepartment(id: string): Promise<Department> {
    return this.request<Department>(`/api/departments/${encodeURIComponent(id)}/duplicate`, {
      method: 'POST'
    });
  }

  // Projects
  async getProjects(): Promise<Project[]> {
    return this.request<Project[]>('/api/projects');
  }

  async getProjectBySlug(slug: string): Promise<Project> {
    return this.request<Project>(`/api/projects/by-slug/${encodeURIComponent(slug)}`);
  }

  async getProjectsAdmin(): Promise<Project[]>;
  async getProjectsAdmin(params: ContentListParams & { page: number }): Promise<PaginatedResult<Project>>;
  async getProjectsAdmin(params?: ContentListParams): Promise<Project[] | PaginatedResult<Project>> {
    const qs = this.buildContentQuery(params);
    return this.request<Project[] | PaginatedResult<Project>>(`/api/projects/admin${qs}`);
  }

  async createProject(payload: Partial<Project>): Promise<Project> {
    return this.request<Project>('/api/projects', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async updateProject(id: string, payload: Partial<Project>): Promise<Project> {
    return this.request<Project>(`/api/projects/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async reviewProject(
    id: string,
    payload: { action: 'approved' | 'rejected' | 'requested_changes'; comment?: string }
  ): Promise<Project> {
    return this.request<Project>(`/api/projects/${id}/review`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async deleteProject(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/projects/${id}`, {
      method: 'DELETE'
    });
  }

  async restoreProject(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/projects/${id}/restore`, {
      method: 'POST'
    });
  }

  async restoreProjectVersion(id: string, versionId: string): Promise<Project> {
    return this.request<Project>(`/api/projects/${id}/restore-version`, {
      method: 'POST',
      body: JSON.stringify({ versionId })
    });
  }

  async duplicateProject(id: string): Promise<Project> {
    return this.request<Project>(`/api/projects/${encodeURIComponent(id)}/duplicate`, {
      method: 'POST'
    });
  }

  // Publications
  async getPublications(): Promise<Publication[]> {
    return this.request<Publication[]>('/api/publications');
  }

  async getPublicationsAdmin(): Promise<Publication[]>;
  async getPublicationsAdmin(params: ContentListParams & { page: number }): Promise<PaginatedResult<Publication>>;
  async getPublicationsAdmin(params?: ContentListParams): Promise<Publication[] | PaginatedResult<Publication>> {
    const qs = this.buildContentQuery(params);
    return this.request<Publication[] | PaginatedResult<Publication>>(`/api/publications/admin${qs}`);
  }

  async createPublication(payload: Partial<Publication>): Promise<Publication> {
    return this.request<Publication>('/api/publications', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async updatePublication(id: string, payload: Partial<Publication>): Promise<Publication> {
    return this.request<Publication>(`/api/publications/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async reviewPublication(
    id: string,
    payload: { action: 'approved' | 'rejected' | 'requested_changes'; comment?: string }
  ): Promise<Publication> {
    return this.request<Publication>(`/api/publications/${id}/review`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async deletePublication(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/publications/${id}`, {
      method: 'DELETE'
    });
  }

  async restorePublicationVersion(id: string, versionId: string): Promise<Publication> {
    return this.request<Publication>(`/api/publications/${encodeURIComponent(id)}/restore-version`, {
      method: 'POST',
      body: JSON.stringify({ versionId })
    });
  }

  async duplicatePublication(id: string): Promise<Publication> {
    return this.request<Publication>(`/api/publications/${encodeURIComponent(id)}/duplicate`, {
      method: 'POST'
    });
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return this.request<Product[]>('/api/products');
  }

  async getProductBySlug(slug: string): Promise<Product> {
    return this.request<Product>(`/api/products/by-slug/${encodeURIComponent(slug)}`);
  }

  async getProductsAdmin(): Promise<Product[]>;
  async getProductsAdmin(params: ContentListParams & { page: number }): Promise<PaginatedResult<Product>>;
  async getProductsAdmin(params?: ContentListParams): Promise<Product[] | PaginatedResult<Product>> {
    const qs = this.buildContentQuery(params);
    return this.request<Product[] | PaginatedResult<Product>>(`/api/products/admin${qs}`);
  }

  async createProduct(payload: Partial<Product>): Promise<Product> {
    return this.request<Product>('/api/products', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async updateProduct(id: string, payload: Partial<Product>): Promise<Product> {
    return this.request<Product>(`/api/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async reviewProduct(
    id: string,
    payload: { action: 'approved' | 'rejected' | 'requested_changes'; comment?: string }
  ): Promise<Product> {
    return this.request<Product>(`/api/products/${id}/review`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async deleteProduct(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/products/${id}`, {
      method: 'DELETE'
    });
  }

  async restoreProductVersion(id: string, versionId: string): Promise<Product> {
    return this.request<Product>(`/api/products/${encodeURIComponent(id)}/restore-version`, {
      method: 'POST',
      body: JSON.stringify({ versionId })
    });
  }

  async duplicateProduct(id: string): Promise<Product> {
    return this.request<Product>(`/api/products/${encodeURIComponent(id)}/duplicate`, {
      method: 'POST'
    });
  }

  private buildContentQuery(params?: ContentListParams): string {
    if (!params) return '';
    const qs = new URLSearchParams();
    if (params.page) qs.set('page', String(params.page));
    if (params.limit) qs.set('limit', String(params.limit));
    if (params.q?.trim()) qs.set('q', params.q.trim());
    if (params.status && params.status !== 'all') qs.set('status', params.status);
    if (params.departmentId && params.departmentId !== 'all') qs.set('departmentId', params.departmentId);
    if (params.sectorId && params.sectorId !== 'all') qs.set('sectorId', params.sectorId);
    if (params.authorId && params.authorId !== 'all') qs.set('authorId', params.authorId);
    if (params.sortBy) qs.set('sortBy', params.sortBy);
    if (params.sortDir) qs.set('sortDir', params.sortDir);
    const built = qs.toString();
    return built ? `?${built}` : '';
  }

  async checkContentSlug(
    entityType: 'department' | 'sector' | 'project' | 'publication' | 'product',
    slug: string,
    excludeId?: string
  ): Promise<{ available: boolean; normalizedSlug: string; conflictTitle?: string }> {
    const qs = new URLSearchParams({ entityType, slug });
    if (excludeId) qs.set('excludeId', excludeId);
    return this.request(`/api/content/slug-check?${qs.toString()}`);
  }

  async bulkContentAction(
    entityType: 'project' | 'publication' | 'product',
    ids: string[],
    action: BulkContentAction
  ): Promise<{ updated: number; ids: string[] }> {
    return this.request(`/api/content/${encodeURIComponent(entityType)}/bulk`, {
      method: 'POST',
      body: JSON.stringify({ ids, action })
    });
  }

  // Media Library
  async getMedia(): Promise<MediaAsset[]> {
    return this.request<MediaAsset[]>('/api/media');
  }

  async getMediaLimits(): Promise<MediaUploadLimits> {
    return this.request<MediaUploadLimits>('/api/media/limits');
  }

  async uploadMedia(
    payload: {
      name: string;
      dataUrl?: string;
      file?: File;
      altText?: string;
      caption?: string;
      credit?: string;
      folder?: string;
      tags?: string[];
      type?: string;
    },
    onProgress?: (percent: number) => void
  ): Promise<MediaAsset> {
    let resolvedDataUrl = payload.dataUrl || '';
    if (!resolvedDataUrl && payload.file) {
      const file = payload.file;
      resolvedDataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('Failed to read selected file.'));
        reader.readAsDataURL(file);
      });
    }
    const { file: _ignoredFile, ...restPayload } = payload;
    const bodyPayload = { ...restPayload, dataUrl: resolvedDataUrl };

    if (!onProgress || typeof XMLHttpRequest === 'undefined') {
      return this.request<MediaAsset>('/api/media', {
        method: 'POST',
        body: JSON.stringify(bodyPayload)
      });
    }

    return new Promise<MediaAsset>((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', '/api/media');
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.setRequestHeader('X-MoA-Request', '1');
      if (this.token) {
        xhr.setRequestHeader('Authorization', `Bearer ${this.token}`);
      }

      xhr.upload.onprogress = (evt) => {
        if (evt.lengthComputable && evt.total > 0) {
          onProgress(Math.min(99, Math.round((evt.loaded / evt.total) * 100)));
        }
      };

      xhr.onload = () => {
        onProgress(100);
        try {
          const parsed = JSON.parse(xhr.responseText || '{}') as Record<string, unknown>;
          if (xhr.status >= 200 && xhr.status < 300) {
            resolve(parsed as unknown as MediaAsset);
          } else {
            if (xhr.status === 401) {
              const hadToken = Boolean(this.token);
              this.clearSession();
              if (hadToken && this.unauthorizedHandler) {
                this.unauthorizedHandler();
              }
            }
            const errMsg = typeof parsed.error === 'string' && parsed.error ? parsed.error : `Request failed (${xhr.status})`;
            reject(new HttpError(errMsg, xhr.status, parsed));
          }
        } catch {
          reject(new HttpError(`Request failed (${xhr.status})`, xhr.status));
        }
      };

      xhr.onerror = () => {
        reject(new HttpError('Network error while uploading media.', 0));
      };

      xhr.send(JSON.stringify(bodyPayload));
    });
  }

  async updateMedia(id: string, payload: Partial<MediaAsset>): Promise<MediaAsset> {
    return this.request<MediaAsset>(`/api/media/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async replaceMedia(id: string, payload: { dataUrl: string; name?: string }): Promise<MediaAsset> {
    return this.request<MediaAsset>(`/api/media/${id}/replace`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async deleteMedia(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/media/${id}`, {
      method: 'DELETE'
    });
  }

  // Site Content
  async getPageContent(): Promise<SiteContent> {
    return this.request<SiteContent>('/api/page-content');
  }

  async updatePageContent(payload: Partial<SiteContent>): Promise<SiteContent> {
    return this.request<SiteContent>('/api/page-content', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async getDraftContent(): Promise<{ draft: Partial<SiteContent> | null; isDraft: boolean }> {
    return this.request('/api/page-content/draft');
  }

  async saveDraftContent(draft: Partial<SiteContent>): Promise<{ success: boolean }> {
    return this.request('/api/page-content/draft', {
      method: 'POST',
      body: JSON.stringify({ draft })
    });
  }

  async publishDraftContent(): Promise<SiteContent> {
    return this.request<SiteContent>('/api/page-content/publish-draft', {
      method: 'POST'
    });
  }

  async getContentHistory(): Promise<ContentHistorySnapshot[]> {
    return this.request<ContentHistorySnapshot[]>('/api/page-content/history');
  }

  async restoreContentHistory(snapshotId: string): Promise<SiteContent> {
    return this.request<SiteContent>(`/api/page-content/history/${snapshotId}/restore`, {
      method: 'POST'
    });
  }

  // Site Settings & Redirect Tester
  async getSettings(): Promise<SiteSettings> {
    return this.request<SiteSettings>('/api/settings');
  }

  async updateSettings(payload: Partial<SiteSettings>): Promise<SiteSettings> {
    return this.request<SiteSettings>('/api/settings', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async testRedirect(path: string): Promise<RedirectTestResult> {
    return this.request<RedirectTestResult>('/api/redirects/test', {
      method: 'POST',
      body: JSON.stringify({ path })
    });
  }

  // Website Hub Redesign Endpoints
  async getWebsiteOverview(): Promise<WebsiteOverviewResponse> {
    return this.request<WebsiteOverviewResponse>('/api/website/overview');
  }

  async getWebsitePageSettings(pageId: string): Promise<WebsitePageSettingsResponse> {
    return this.request<WebsitePageSettingsResponse>(`/api/website/pages/${encodeURIComponent(pageId)}/settings`);
  }

  async updateWebsitePageSettings(
    pageId: string,
    payload: {
      version?: number;
      title?: string;
      slug?: string;
      template?: PageRecord['template'];
      status?: PageRecord['status'];
      blocks?: PageRecord['blocks'];
      inHeader?: boolean;
      inFooter?: boolean;
      seo?: {
        title?: string;
        description?: string;
        shareImage?: string;
        noindex?: boolean;
      };
      textValues?: Record<string, string>;
      saveAsDraft?: boolean;
      publishDraft?: boolean;
    }
  ): Promise<WebsitePageSettingsResponse> {
    return this.request<WebsitePageSettingsResponse>(`/api/website/pages/${encodeURIComponent(pageId)}/settings`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async getWebsitePageVersions(pageId: string): Promise<ContentHistorySnapshot[]> {
    return this.request<ContentHistorySnapshot[]>(`/api/website/pages/${encodeURIComponent(pageId)}/versions`);
  }

  async restoreWebsitePageVersion(pageId: string, versionId: string): Promise<WebsitePageSettingsResponse> {
    return this.request<WebsitePageSettingsResponse>(
      `/api/website/pages/${encodeURIComponent(pageId)}/versions/${encodeURIComponent(versionId)}/restore`,
      { method: 'POST' }
    );
  }

  async publishWebsitePageDraft(pageId: string): Promise<WebsiteOverviewResponse> {
    return this.request<WebsiteOverviewResponse>(`/api/website/pages/${encodeURIComponent(pageId)}/publish`, {
      method: 'POST'
    });
  }

  async discardWebsitePageDraft(pageId: string): Promise<WebsiteOverviewResponse> {
    return this.request<WebsiteOverviewResponse>(`/api/website/pages/${encodeURIComponent(pageId)}/discard`, {
      method: 'POST'
    });
  }

  async publishAllWebsiteDrafts(): Promise<WebsiteOverviewResponse> {
    return this.request<WebsiteOverviewResponse>('/api/website/publish-all', { method: 'POST' });
  }

  async duplicateWebsitePage(pageId: string): Promise<PageRecord> {
    return this.request<PageRecord>(`/api/website/pages/${encodeURIComponent(pageId)}/duplicate`, {
      method: 'POST'
    });
  }

  async getWebsiteMenus(): Promise<{
    menus: WebsiteMenusConfig;
    alwaysShowProducts: boolean;
    hasPublishedProducts: boolean;
  }> {
    return this.request('/api/website/menus');
  }

  async updateWebsiteMenus(payload: WebsiteMenusConfig & { alwaysShowProducts?: boolean }): Promise<WebsiteMenusConfig & { alwaysShowProducts: boolean }> {
    return this.request('/api/website/menus', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async updateWebsiteBrand(payload: {
    version?: number;
    moaLogoUrl?: string;
    rddLogoUrl?: string;
    loaderLogoUrl?: string;
    sameLoaderAsPrimary?: boolean;
    faviconUrl?: string;
    shareImageUrl?: string;
  }): Promise<WebsiteOverviewResponse['brand']> {
    return this.request('/api/website/brand', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async updateWebsiteAnnouncement(
    payload: AnnouncementBarConfig & { version?: number }
  ): Promise<AnnouncementBarConfig & { version: number }> {
    return this.request('/api/website/announcement', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async updateWebsiteSocial(payload: {
    version?: number;
    links: SocialLink[];
  }): Promise<{ version: number; links: SocialLink[] }> {
    return this.request('/api/website/social', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async updateWebsiteSeo(payload: {
    version?: number;
    titleTemplate?: string;
    description?: string;
    sitemapEnabled?: boolean;
    robotsEnabled?: boolean;
  }): Promise<WebsiteOverviewResponse['seo']> {
    return this.request('/api/website/seo', {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async getWebsiteRedirects(): Promise<RedirectRule[]> {
    return this.request<RedirectRule[]>('/api/website/redirects');
  }

  async createWebsiteRedirect(payload: { from: string; to: string; type: '301' | '302' }): Promise<RedirectRule> {
    return this.request<RedirectRule>('/api/website/redirects', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  async updateWebsiteRedirect(
    id: string,
    payload: { from: string; to: string; type: '301' | '302' }
  ): Promise<RedirectRule> {
    return this.request<RedirectRule>(`/api/website/redirects/${encodeURIComponent(id)}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  async deleteWebsiteRedirect(id: string): Promise<{ success: boolean }> {
    return this.request(`/api/website/redirects/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
  }

  async deleteAutoWebsiteRedirects(): Promise<{ success: boolean; removed: number }> {
    return this.request('/api/website/redirects/auto', {
      method: 'DELETE'
    });
  }

  // Activity Log, Security Log & Site Health
  async getActivityLog(params?: {
    page?: number;
    limit?: number;
    area?: string;
    q?: string;
  }): Promise<ActivityRecord[] | PaginatedResult<ActivityRecord>> {
    if (params && params.page) {
      const qs = new URLSearchParams({
        page: String(params.page),
        limit: String(params.limit || 25)
      });
      if (params.area && params.area !== 'all') qs.set('area', params.area);
      if (params.q) qs.set('q', params.q);
      return this.request<PaginatedResult<ActivityRecord>>(`/api/activity-log?${qs.toString()}`);
    }
    return this.request<ActivityRecord[]>('/api/activity-log');
  }

  async getSecurityLog(): Promise<SecurityLogRecord[]> {
    return this.request<SecurityLogRecord[]>('/api/security-log');
  }

  async getSiteHealth(): Promise<SiteHealthItem[]> {
    return this.request<SiteHealthItem[]>('/api/site-health');
  }

  // Backup & Restore (SQLite Snapshots)
  async exportEverything(): Promise<Blob> {
    const headers: Record<string, string> = {
      'X-MoA-Request': '1'
    };
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const res = await fetch('/api/backup/export', {
      method: 'GET',
      headers
    });

    if (!res.ok) {
      let errMsg = `Export failed (${res.status})`;
      let errorData: Record<string, unknown> | undefined;
      try {
        const parsed = (await res.json()) as Record<string, unknown>;
        errorData = parsed;
        if (typeof parsed.error === 'string' && parsed.error) errMsg = parsed.error;
      } catch {
        // ignore parse fallback
      }
      if (res.status === 401) {
        const hadToken = Boolean(this.token);
        this.clearSession();
        if (hadToken && this.unauthorizedHandler) this.unauthorizedHandler();
      }
      throw new HttpError(errMsg, res.status, errorData);
    }

    return res.blob();
  }

  async importEverything(file: File): Promise<{ success: boolean; message: string }> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/x-sqlite3',
      'X-MoA-Request': '1'
    };
    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const buffer = await file.arrayBuffer();
    const res = await fetch('/api/backup/import', {
      method: 'POST',
      headers,
      body: buffer
    });

    if (!res.ok) {
      let errMsg = `Restore failed (${res.status})`;
      let errorData: Record<string, unknown> | undefined;
      try {
        const parsed = (await res.json()) as Record<string, unknown>;
        errorData = parsed;
        if (typeof parsed.error === 'string' && parsed.error) errMsg = parsed.error;
      } catch {
        // ignore parse fallback
      }
      if (res.status === 401) {
        const hadToken = Boolean(this.token);
        this.clearSession();
        if (hadToken && this.unauthorizedHandler) this.unauthorizedHandler();
      }
      throw new HttpError(errMsg, res.status, errorData);
    }

    return (await res.json()) as { success: boolean; message: string };
  }

  // Custom Pages
  async getPages(): Promise<PageRecord[]> {
    return this.request<PageRecord[]>('/api/pages');
  }

  async savePage(page: Partial<PageRecord>): Promise<PageRecord> {
    return this.request<PageRecord>('/api/pages', {
      method: 'POST',
      body: JSON.stringify(page)
    });
  }

  async deletePage(id: string): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>(`/api/pages/${id}`, {
      method: 'DELETE'
    });
  }

  // Forms & Inquiries (read-only inbox)
  async getSubmissions(params?: {
    page?: number;
    limit?: number;
    status?: string;
    q?: string;
  }): Promise<FormSubmission[] | SubmissionsPaginatedResponse> {
    if (params && params.page) {
      const qs = new URLSearchParams({
        page: String(params.page),
        limit: String(params.limit || 25)
      });
      if (params.status && params.status !== 'all') qs.set('status', params.status);
      if (params.q) qs.set('q', params.q);
      return this.request<SubmissionsPaginatedResponse>(`/api/submissions?${qs.toString()}`);
    }
    return this.request<FormSubmission[]>('/api/submissions');
  }

  async updateSubmission(
    id: string,
    payload: { status: FormSubmission['status'] }
  ): Promise<FormSubmission> {
    return this.request<FormSubmission>(`/api/submissions/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(payload)
    });
  }

  async deleteSubmission(id: string): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>(`/api/submissions/${id}`, {
      method: 'DELETE'
    });
  }

  async submitContactForm(data: {
    formType?: FormSubmission['formType'];
    name: string;
    email: string;
    organization?: string;
    subject?: string;
    message: string;
    website?: string;
  }): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>('/api/submissions', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  }

  // Trash & Restore
  async getTrashItems(): Promise<TrashItemsResponse> {
    return this.request<TrashItemsResponse>('/api/trash');
  }

  async restoreTrashItem(
    type: 'department' | 'project' | 'publication' | 'product' | 'page' | 'media' | 'submission',
    id: string
  ): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>('/api/trash/restore', {
      method: 'POST',
      body: JSON.stringify({ type, id })
    });
  }

  async deleteTrashItem(
    type: 'department' | 'project' | 'publication' | 'product' | 'page' | 'media' | 'submission',
    id: string
  ): Promise<{ success: boolean }> {
    return this.request<{ success: boolean }>(`/api/trash/item/${encodeURIComponent(type)}/${encodeURIComponent(id)}`, {
      method: 'DELETE'
    });
  }

  async emptyTrash(): Promise<{ success: boolean; removed?: number }> {
    return this.request<{ success: boolean; removed?: number }>('/api/trash/empty', {
      method: 'DELETE'
    });
  }
}

export const api = new ApiService();
