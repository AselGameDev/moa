import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  FileText,
  Menu,
  Sparkles,
  Search,
  AlertCircle,
  Loader2,
  RefreshCw,
  Lock
} from 'lucide-react';
import {
  PageRecord,
  RoleDefinition,
  SiteContent,
  SiteSettings,
  User,
  WebsiteOverviewResponse
} from '../../../types';
import { api } from '../../../services/api';
import { can } from '../../../shared/permissions';
import { getVisibleSubTabs } from '../portalRegistry';
import {
  PortalConfirmDialog,
  PortalEmptyState,
  PortalPageHeader,
  PortalTabItem,
  PortalTabs
} from '../ui';
import { WebsiteStatusStrip } from '../website/WebsiteStatusStrip';
import { PagesManagerTab } from '../website/PagesManagerTab';
import { DrawerTabKey, PageSettingsDrawer } from '../website/PageSettingsDrawer';
import { MenusManagerTab } from '../website/MenusManagerTab';
import { BrandSitewideTab } from '../website/BrandSitewideTab';
import { SeoRedirectsTab } from '../website/SeoRedirectsTab';

export type WebsiteSubTab = 'pages' | 'menus' | 'brand' | 'seo';

export interface WebsiteRequestedAction {
  subTab: WebsiteSubTab;
  pageId?: string;
  drawerTab?: DrawerTabKey;
  nonce: number;
}

interface WebsiteTabProps {
  initialSubTab?: WebsiteSubTab | string;
  onSubTabChange?: (sub: WebsiteSubTab) => void;
  requestedAction?: WebsiteRequestedAction | null;
  onConsumeRequestedAction?: () => void;
  currentUser: User;
  roles?: RoleDefinition[];
  pages: PageRecord[];
  onSavePage?: (page: PageRecord) => Promise<void>;
  onDeletePage?: (id: string) => Promise<void>;
  settings?: SiteSettings;
  onUpdateSettings?: (settings: Partial<SiteSettings>) => Promise<void>;
  siteContent?: SiteContent;
  onUpdateSiteContent?: (content: SiteContent) => Promise<void>;
  onRefreshData?: () => Promise<void>;
  onEnterEditMode?: (targetRoute?: string) => void | Promise<void>;
  onNavigateSite: (path?: string) => void;
}

const SUBTAB_ICONS: Record<WebsiteSubTab, React.ComponentType<{ className?: string }>> = {
  pages: FileText,
  menus: Menu,
  brand: Sparkles,
  seo: Search
};

export const WebsiteTab: React.FC<WebsiteTabProps> = ({
  initialSubTab = 'pages',
  onSubTabChange,
  requestedAction,
  onConsumeRequestedAction,
  currentUser,
  roles,
  pages,
  onRefreshData,
  onEnterEditMode,
  onNavigateSite
}) => {
  const visibleSubTabs = useMemo(
    () => getVisibleSubTabs('website', currentUser, roles),
    [currentUser, roles]
  );

  const validIdsKey = visibleSubTabs.map(st => st.id).join(',');
  const validIds = useMemo(
    () => (validIdsKey ? (validIdsKey.split(',') as WebsiteSubTab[]) : []),
    [validIdsKey]
  );

  const normalizeRequestedSubTab = useCallback(
    (req: string | undefined): WebsiteSubTab => {
      if (req === 'navigation' || req === 'footer') return validIds.includes('menus') ? 'menus' : validIds[0] || 'pages';
      if (req === 'editor') return validIds.includes('pages') ? 'pages' : validIds[0] || 'pages';
      if (req && validIds.includes(req as WebsiteSubTab)) return req as WebsiteSubTab;
      return validIds[0] || 'pages';
    },
    [validIds]
  );

  const [subTab, setSubTab] = useState<WebsiteSubTab>(() => normalizeRequestedSubTab(initialSubTab));
  const [overview, setOverview] = useState<WebsiteOverviewResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerPageId, setDrawerPageId] = useState<string | null>(null);
  const [drawerInitialTab, setDrawerInitialTab] = useState<DrawerTabKey>('general');

  const [menusDirty, setMenusDirty] = useState(false);
  const [brandDirty, setBrandDirty] = useState(false);
  const [seoDirty, setSeoDirty] = useState(false);
  const [pendingSubTab, setPendingSubTab] = useState<WebsiteSubTab | null>(null);

  const prevInitialSubTabRef = useRef(initialSubTab);
  const handledActionNonceRef = useRef<number | null>(null);

  useEffect(() => {
    const initialChanged = prevInitialSubTabRef.current !== initialSubTab;
    prevInitialSubTabRef.current = initialSubTab;
    if (initialChanged) {
      setSubTab(normalizeRequestedSubTab(initialSubTab));
    } else if (validIds.length > 0 && !validIds.includes(subTab)) {
      setSubTab(validIds[0]);
    }
  }, [initialSubTab, normalizeRequestedSubTab, subTab, validIds]);

  useEffect(() => {
    if (!requestedAction) return;
    if (handledActionNonceRef.current === requestedAction.nonce) return;
    handledActionNonceRef.current = requestedAction.nonce;
    const normalized = normalizeRequestedSubTab(requestedAction.subTab);
    setPendingSubTab(null);
    setMenusDirty(false);
    setBrandDirty(false);
    setSeoDirty(false);
    setSubTab(normalized);
    onSubTabChange?.(normalized);
    if (requestedAction.pageId) {
      setDrawerPageId(requestedAction.pageId);
      setDrawerInitialTab(requestedAction.drawerTab || 'general');
      setDrawerOpen(true);
    }
    onConsumeRequestedAction?.();
  }, [requestedAction, normalizeRequestedSubTab, onSubTabChange, onConsumeRequestedAction]);

  const canEditWebsite = can(currentUser, 'website.edit', roles);
  const canManagePages = can(currentUser, 'pages.manage', roles);
  const canManageSeo = can(currentUser, 'seo.manage', roles);
  const canAccessBrand = validIds.includes('brand');

  const fetchOverview = useCallback(async (quiet = false) => {
    if (!quiet) setLoading(true);
    setLoadError(null);
    try {
      const data = await api.getWebsiteOverview();
      setOverview(data);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Failed to load Website hub overview.');
    } finally {
      if (!quiet) setLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchOverview();
  }, [fetchOverview]);

  const syncAfterWebsiteMutation = useCallback(async () => {
    await fetchOverview(true);
    if (onRefreshData) {
      await onRefreshData();
    }
  }, [fetchOverview, onRefreshData]);

  const isCurrentSubTabDirty =
    (subTab === 'menus' && menusDirty) ||
    (subTab === 'brand' && brandDirty) ||
    (subTab === 'seo' && seoDirty);

  const selectSubTab = (target: WebsiteSubTab) => {
    if (target === subTab) return;
    if (isCurrentSubTabDirty) {
      setPendingSubTab(target);
      return;
    }
    setSubTab(target);
    onSubTabChange?.(target);
  };

  const handleConfirmLeaveDirtySubTab = () => {
    if (!pendingSubTab) return;
    const next = pendingSubTab;
    setPendingSubTab(null);
    setMenusDirty(false);
    setBrandDirty(false);
    setSeoDirty(false);
    setSubTab(next);
    onSubTabChange?.(next);
  };

  const handleOpenDrawer = (pageId: string, tab: DrawerTabKey = 'general') => {
    setDrawerPageId(pageId);
    setDrawerInitialTab(tab);
    setDrawerOpen(true);
  };

  const handleOpenAttentionSubTab = (
    targetSubTab: 'pages' | 'menus' | 'brand' | 'seo',
    pageId?: string,
    drawerTab?: DrawerTabKey
  ) => {
    if (validIds.includes(targetSubTab)) {
      if (targetSubTab !== subTab) {
        setMenusDirty(false);
        setBrandDirty(false);
        setSeoDirty(false);
      }
      setSubTab(targetSubTab);
      onSubTabChange?.(targetSubTab);
    }
    if (targetSubTab === 'pages' && pageId) {
      handleOpenDrawer(pageId, drawerTab || 'general');
    }
  };

  const handleOpenLiveEditor = async (path?: string, sectionAnchorId?: string) => {
    if (!onEnterEditMode) return;
    const cleanPath = path || '/';
    const route = sectionAnchorId
      ? `${cleanPath}${cleanPath.includes('?') ? '&' : '?'}section=${encodeURIComponent(sectionAnchorId)}`
      : cleanPath;
    setDrawerOpen(false);
    await onEnterEditMode(route);
  };

  const handlePublishPageDraft = async (pageId: string) => {
    const updated = await api.publishWebsitePageDraft(pageId);
    setOverview(updated);
    if (onRefreshData) await onRefreshData();
  };

  const handleDiscardPageDraft = async (pageId: string) => {
    const updated = await api.discardWebsitePageDraft(pageId);
    setOverview(updated);
    if (onRefreshData) await onRefreshData();
  };

  const handlePublishAllDrafts = async () => {
    const updated = await api.publishAllWebsiteDrafts();
    setOverview(updated);
    if (onRefreshData) await onRefreshData();
  };

  const tabItems: PortalTabItem<WebsiteSubTab>[] = useMemo(
    () =>
      visibleSubTabs.map(tab => {
        const id = tab.id as WebsiteSubTab;
        return {
          id,
          label: tab.label,
          icon: SUBTAB_ICONS[id] || FileText,
          badge: id === 'pages' && typeof overview?.pages.length === 'number' ? overview.pages.length : undefined
        };
      }),
    [visibleSubTabs, overview?.pages.length]
  );

  if (visibleSubTabs.length === 0) {
    return (
      <PortalEmptyState
        icon={Lock}
        title="Website access restricted"
        description="You do not have permissions to manage Website sections."
      />
    );
  }

  return (
    <div className="space-y-6">
      <PortalPageHeader
        title="Website & Publishing"
        subtitle="Manage site pages, navigation menus, brand identity, announcement bar, and SEO redirects."
      />

      <PortalTabs
        items={tabItems}
        activeId={subTab}
        onChange={selectSubTab}
        ariaLabel="Website management sections"
      />

      <WebsiteStatusStrip
        overview={overview}
        canEditWebsite={canEditWebsite}
        onPublishPageDraft={handlePublishPageDraft}
        onDiscardPageDraft={handleDiscardPageDraft}
        onPublishAllDrafts={handlePublishAllDrafts}
        onOpenLiveEditor={() => handleOpenLiveEditor('/')}
        onViewPublicSite={() => onNavigateSite('/')}
      />

      {loading && !overview ? (
        <div className="p-12 rounded-2xl bg-[#031D1C] border border-white/10 flex flex-col items-center justify-center gap-3 text-xs text-[#EDE9E0]/65">
          <Loader2 className="w-6 h-6 animate-spin text-[#25CDB6]" />
          <span>Loading Website workspace...</span>
        </div>
      ) : loadError && !overview ? (
        <div className="p-6 rounded-2xl bg-red-950/50 border border-red-500/30 text-xs text-red-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{loadError}</span>
          </div>
          <button
            type="button"
            onClick={() => void fetchOverview()}
            className="h-8 px-3 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold inline-flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Retry</span>
          </button>
        </div>
      ) : overview ? (
        <>
          {subTab === 'pages' && (
            <PagesManagerTab
              overview={overview}
              pages={pages}
              canEditWebsite={canEditWebsite}
              canManagePages={canManagePages}
              onOpenDrawer={handleOpenDrawer}
              onEditOnSite={handleOpenLiveEditor}
              onViewPage={path => onNavigateSite(path)}
              onOpenAttentionSubTab={handleOpenAttentionSubTab}
              onRefresh={syncAfterWebsiteMutation}
            />
          )}

          {subTab === 'menus' && (
            <MenusManagerTab
              overview={overview}
              onDirtyChange={setMenusDirty}
              onSaved={syncAfterWebsiteMutation}
            />
          )}

          {subTab === 'brand' && (
            <BrandSitewideTab
              overview={overview}
              onDirtyChange={setBrandDirty}
              onSaved={syncAfterWebsiteMutation}
            />
          )}

          {subTab === 'seo' && (
            <SeoRedirectsTab
              overview={overview}
              canAccessBrand={canAccessBrand}
              onDirtyChange={setSeoDirty}
              onOpenPageSeoDrawer={pageId => handleOpenDrawer(pageId, 'seo')}
              onOpenBrandTab={() => selectSubTab('brand')}
              onSaved={syncAfterWebsiteMutation}
            />
          )}
        </>
      ) : null}

      <PageSettingsDrawer
        isOpen={drawerOpen}
        pageId={drawerPageId}
        initialTab={drawerInitialTab}
        titleTemplate={overview?.seo.titleTemplate || '{page} · {site}'}
        siteName={overview?.seo.siteName || 'Masters Of All'}
        defaultShareImage={overview?.brand.shareImageUrl || ''}
        canEditWebsite={canEditWebsite || canManagePages}
        canManageSeo={canManageSeo}
        onClose={() => setDrawerOpen(false)}
        onSaved={syncAfterWebsiteMutation}
        onEditOnSite={handleOpenLiveEditor}
        onNavigateSite={path => onNavigateSite(path)}
        onOpenSeoSubTab={() => {
          setDrawerOpen(false);
          if (validIds.includes('seo')) selectSubTab('seo');
        }}
      />

      <PortalConfirmDialog
        isOpen={pendingSubTab !== null}
        title="Unsaved Changes"
        message="You have unsaved changes in this section. Leave anyway and discard your edits?"
        confirmLabel="Discard & Switch"
        isDestructive
        onCancel={() => setPendingSubTab(null)}
        onConfirm={handleConfirmLeaveDirtySubTab}
      />
    </div>
  );
};
