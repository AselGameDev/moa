import React, { useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { AlertCircle, Loader2, RotateCcw, Save } from 'lucide-react';

export interface PortalFloatingSaveBarProps {
  visible: boolean;
  title?: string;
  subtitle?: string;
  error?: string | null;
  saving?: boolean;
  saveDisabled?: boolean;
  saveLabel?: string;
  discardLabel?: string;
  secondaryAction?: {
    label: string;
    onClick: () => void | Promise<void>;
    disabled?: boolean;
  };
  onDiscard: () => void;
  onSave: () => void | Promise<void>;
  zIndexClass?: string;
  enableShortcut?: boolean;
}

export const PortalFloatingSaveBar: React.FC<PortalFloatingSaveBarProps> = ({
  visible,
  title = 'Unsaved changes',
  subtitle = 'Review and save your edits or discard to revert.',
  error,
  saving = false,
  saveDisabled = false,
  saveLabel = 'Save changes',
  discardLabel = 'Discard',
  secondaryAction,
  onDiscard,
  onSave,
  zIndexClass = 'z-[90]',
  enableShortcut = true
}) => {
  useEffect(() => {
    if (!enableShortcut || !visible) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        if (!saving && !saveDisabled) {
          void onSave();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [enableShortcut, visible, saving, saveDisabled, onSave]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 18, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 14, scale: 0.98 }}
          transition={{ duration: 0.18, ease: 'easeOut' }}
          role="region"
          aria-label={title}
          className={`fixed bottom-6 left-1/2 -translate-x-1/2 ${zIndexClass} w-[calc(100%-2rem)] max-w-[640px] rounded-2xl bg-[#031D1C]/95 backdrop-blur-md border border-[#25CDB6]/40 shadow-[0_20px_50px_rgba(0,0,0,0.65)] px-4 py-3 flex flex-wrap items-center justify-between gap-3`}
        >
          <div className="min-w-0 flex-1 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#D0A873] shrink-0" aria-hidden="true" />
              <span className="font-bold text-[#EDE9E0] truncate">{title}</span>
            </div>
            {error ? (
              <span className="text-[11px] text-red-300 mt-0.5 inline-flex items-center gap-1 break-words">
                <AlertCircle className="w-3 h-3 shrink-0" />
                <span>{error}</span>
              </span>
            ) : (
              <span className="text-[11px] text-[#EDE9E0]/60 block truncate mt-0.5">{subtitle}</span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={saving}
              onClick={onDiscard}
              className="h-9 px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-[#EDE9E0]/85 inline-flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{discardLabel}</span>
            </button>

            {secondaryAction && (
              <button
                type="button"
                disabled={saving || secondaryAction.disabled}
                onClick={() => void secondaryAction.onClick()}
                className="h-9 px-3.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-bold text-[#EDE9E0] inline-flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5 text-[#25CDB6]" />
                <span>{secondaryAction.label}</span>
              </button>
            )}

            <button
              type="button"
              disabled={saving || saveDisabled}
              onClick={() => void onSave()}
              className="h-9 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] text-xs font-bold inline-flex items-center gap-1.5 shadow-md transition-colors cursor-pointer disabled:opacity-50"
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              <span>{saving ? 'Saving...' : saveLabel}</span>
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
