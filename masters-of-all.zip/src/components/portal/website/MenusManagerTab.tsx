import React, { useEffect, useMemo, useState } from 'react';
import {
  Plus,
  Trash2,
  MoveUp,
  MoveDown,
  GripVertical,
  Check,
  AlertCircle,
  ExternalLink,
  Eye,
  EyeOff,
  Lock,
  Info
} from 'lucide-react';
import {
  FooterLinkItem,
  NavigationItem,
  WebsiteFooterColumnConfig,
  WebsiteMenusConfig,
  WebsiteOverviewResponse
} from '../../../types';
import { api, HttpError } from '../../../services/api';
import { isSafeUrl } from '../../../shared/url';
import { FloatingSaveBar } from '../FloatingSaveBar';

interface MenusManagerTabProps {
  overview: WebsiteOverviewResponse;
  onDirtyChange: (dirty: boolean) => void;
  onSaved: () => Promise<void>;
}

const BLOCKED_MENU_PATHS = new Set(['/login', '/signin', '/admin', '/portal']);

function cloneMenus(m: WebsiteMenusConfig): WebsiteMenusConfig {
  return JSON.parse(JSON.stringify(m)) as WebsiteMenusConfig;
}

function normalizeCompareState(menus: WebsiteMenusConfig, alwaysShowProducts: boolean): string {
  return JSON.stringify({
    header: menus.header.map(h => ({
      id: h.id,
      label: h.label,
      path: h.path,
      pageId: h.pageId || '',
      isExternal: Boolean(h.isExternal),
      newTab: Boolean(h.newTab),
      visible: h.visible !== false,
      isCore: Boolean(h.isCore)
    })),
    footer: menus.footer,
    alwaysShowProducts: Boolean(alwaysShowProducts)
  });
}

export const MenusManagerTab: React.FC<MenusManagerTabProps> = ({
  overview,
  onDirtyChange,
  onSaved
}) => {
  const [menus, setMenus] = useState<WebsiteMenusConfig>(() => cloneMenus(overview.menus));
  const [alwaysShowProducts, setAlwaysShowProducts] = useState<boolean>(
    Boolean(overview.alwaysShowProducts)
  );
  const [baseSignature, setBaseSignature] = useState<string>(() =>
    normalizeCompareState(overview.menus, Boolean(overview.alwaysShowProducts))
  );

  // Sync from server only when version advances cleanly or initial load
  useEffect(() => {
    const incomingSig = normalizeCompareState(overview.menus, Boolean(overview.alwaysShowProducts));
    setMenus(cloneMenus(overview.menus));
    setAlwaysShowProducts(Boolean(overview.alwaysShowProducts));
    setBaseSignature(incomingSig);
  }, [overview.menus.version, overview.alwaysShowProducts]);

  const [dragHeaderIdx, setDragHeaderIdx] = useState<number | null>(null);
  const [dragColIdx, setDragColIdx] = useState<number | null>(null);
  const [customUrlMode, setCustomUrlMode] = useState<Record<string, boolean>>({});
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [conflictError, setConflictError] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const availableDestinations = useMemo(() => {
    return (overview.pages || [])
      .filter(p => p.kind !== 'system' && !BLOCKED_MENU_PATHS.has(p.path.toLowerCase()))
      .map(p => ({ id: p.id, name: p.name, path: p.path }));
  }, [overview.pages]);

  const currentSignature = useMemo(
    () => normalizeCompareState(menus, alwaysShowProducts),
    [menus, alwaysShowProducts]
  );

  const isDirty = currentSignature !== baseSignature;

  useEffect(() => {
    onDirtyChange(isDirty);
    if (!isDirty) return;
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [isDirty, onDirtyChange]);

  const validationErrors = useMemo(() => {
    const errors: string[] = [];
    const seen = new Set<string>();
    menus.header.forEach((item, idx) => {
      const lbl = (item.label || '').trim();
      const rawPath = (item.path || '').trim();
      const normPath = rawPath === '/home' ? '/' : rawPath.toLowerCase();

      if (!lbl) {
        errors.push(`Header item #${idx + 1} needs a label.`);
      }
      if (!rawPath) {
        errors.push(`Header item "${lbl || `#${idx + 1}`}" needs a destination.`);
      } else if (BLOCKED_MENU_PATHS.has(normPath)) {
        errors.push(`"${rawPath}" cannot be placed in the public navigation.`);
      } else if (!isSafeUrl(rawPath)) {
        errors.push(`Header item "${lbl || `#${idx + 1}`}" has an unsafe URL.`);
      } else if (seen.has(normPath)) {
        errors.push(`Duplicate header destination "${rawPath}".`);
      } else {
        seen.add(normPath);
      }
    });

    if (!menus.header.some(item => item.path === '/' || item.path.toLowerCase() === '/home')) {
      errors.push('Home (/) is required in the header menu.');
    }

    for (const col of menus.footer.columns) {
      if ((col.id === 'legal' || (col.id === 'explore' && col.sameAsHeader === false)) && col.links) {
        col.links.forEach((lnk, idx) => {
          if (!lnk.label.trim()) errors.push(`${col.title} link #${idx + 1} needs a label.`);
          if (!lnk.url.trim() || !isSafeUrl(lnk.url.trim(), true)) {
            errors.push(`${col.title} link "${lnk.label || `#${idx + 1}`}" has an invalid URL.`);
          }
          if (BLOCKED_MENU_PATHS.has(lnk.url.trim().toLowerCase())) {
            errors.push(`${col.title} cannot link to "${lnk.url}".`);
          }
        });
      }
    }

    return errors;
  }, [menus]);

  const updateHeaderItem = (idx: number, patch: Partial<NavigationItem>) => {
    setSuccessMsg(null);
    setMenus(prev => {
      const next = [...prev.header];
      next[idx] = { ...next[idx], ...patch };
      return { ...prev, header: next };
    });
  };

  const moveHeaderItem = (fromIdx: number, toIdx: number) => {
    if (toIdx < 0 || toIdx >= menus.header.length || fromIdx === toIdx) return;
    setSuccessMsg(null);
    setMenus(prev => {
      const next = [...prev.header];
      const [moved] = next.splice(fromIdx, 1);
      next.splice(toIdx, 0, moved);
      return { ...prev, header: next };
    });
  };

  const removeHeaderItem = (idx: number) => {
    const item = menus.header[idx];
    if (!item || item.isCore || item.path === '/') return;
    setSuccessMsg(null);
    setMenus(prev => ({
      ...prev,
      header: prev.header.filter((_, i) => i !== idx)
    }));
  };

  const addHeaderItem = () => {
    setSuccessMsg(null);
    const id = `nav-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;
    setCustomUrlMode(prev => ({ ...prev, [id]: true }));
    setMenus(prev => ({
      ...prev,
      header: [
        ...prev.header,
        {
          id,
          label: 'New Link',
          path: '/about',
          visible: true,
          isCore: false,
          newTab: false,
          isExternal: false
        }
      ]
    }));
  };

  const updateFooterColumn = (colId: WebsiteFooterColumnConfig['id'], patch: Partial<WebsiteFooterColumnConfig>) => {
    setSuccessMsg(null);
    setMenus(prev => ({
      ...prev,
      footer: {
        ...prev.footer,
        columns: prev.footer.columns.map(c => (c.id === colId ? { ...c, ...patch } : c))
      }
    }));
  };

  const moveFooterColumn = (fromIdx: number, toIdx: number) => {
    if (toIdx < 0 || toIdx >= menus.footer.columns.length || fromIdx === toIdx) return;
    setSuccessMsg(null);
    setMenus(prev => {
      const next = [...prev.footer.columns];
      const [moved] = next.splice(fromIdx, 1);
      next.splice(toIdx, 0, moved);
      return {
        ...prev,
        footer: { ...prev.footer, columns: next }
      };
    });
  };

  const addFooterColLink = (colId: 'explore' | 'legal') => {
    const col = menus.footer.columns.find(c => c.id === colId);
    const existing = col?.links || [];
    updateFooterColumn(colId, {
      links: [...existing, { label: 'New Link', url: '/', isExternal: false, newTab: false }]
    });
  };

  const updateFooterColLink = (colId: 'explore' | 'legal', linkIdx: number, patch: Partial<FooterLinkItem>) => {
    const col = menus.footer.columns.find(c => c.id === colId);
    const next = [...(col?.links || [])];
    next[linkIdx] = { ...next[linkIdx], ...patch };
    updateFooterColumn(colId, { links: next });
  };

  const removeFooterColLink = (colId: 'explore' | 'legal', linkIdx: number) => {
    const col = menus.footer.columns.find(c => c.id === colId);
    updateFooterColumn(colId, {
      links: (col?.links || []).filter((_, i) => i !== linkIdx)
    });
  };

  const moveFooterColLink = (colId: 'explore' | 'legal', fromIdx: number, toIdx: number) => {
    const col = menus.footer.columns.find(c => c.id === colId);
    const list = [...(col?.links || [])];
    if (toIdx < 0 || toIdx >= list.length) return;
    const [moved] = list.splice(fromIdx, 1);
    list.splice(toIdx, 0, moved);
    updateFooterColumn(colId, { links: list });
  };

  const handleDiscard = () => {
    setMenus(cloneMenus(overview.menus));
    setAlwaysShowProducts(Boolean(overview.alwaysShowProducts));
    setCustomUrlMode({});
    setErrorMsg(null);
    setConflictError(false);
    setSuccessMsg(null);
  };

  const handleSave = async () => {
    if (validationErrors.length > 0) {
      setErrorMsg(validationErrors[0]);
      return;
    }
    setSaving(true);
    setErrorMsg(null);
    setConflictError(false);
    setSuccessMsg(null);
    try {
      await api.updateWebsiteMenus({
        ...menus,
        alwaysShowProducts
      });
      await onSaved();
      setSuccessMsg('Header and footer menus saved to database.');
    } catch (err) {
      if (err instanceof HttpError && err.status === 409) {
        setConflictError(true);
        setErrorMsg('Menus were updated in another session. Reload the latest version before saving.');
      } else {
        setErrorMsg(err instanceof Error ? err.message : 'Failed to save menus.');
      }
    } finally {
      setSaving(false);
    }
  };

  const livePreviewHeader = useMemo(() => {
    return menus.header.filter(item => {
      if (item.visible === false) return false;
      if (BLOCKED_MENU_PATHS.has(item.path.toLowerCase())) return false;
      if ((item.pageId === 'products' || item.path === '/products') && !overview.hasPublishedProducts && !alwaysShowProducts) {
        return false;
      }
      return true;
    });
  }, [menus.header, overview.hasPublishedProducts, alwaysShowProducts]);

  return (
    <div className={`space-y-6 ${isDirty ? 'pb-24' : ''}`}>
      {(errorMsg || successMsg) && (
        <div
          className={`p-3.5 rounded-xl border text-xs flex flex-wrap items-center justify-between gap-2 ${
            errorMsg
              ? 'bg-red-950/60 border-red-500/40 text-red-200'
              : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
          }`}
        >
          <div className="flex items-center gap-2">
            {errorMsg ? <AlertCircle className="w-4 h-4 shrink-0" /> : <Check className="w-4 h-4 shrink-0" />}
            <span>{errorMsg || successMsg}</span>
          </div>
          {conflictError && (
            <button
              type="button"
              onClick={() => void onSaved()}
              className="px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white font-bold cursor-pointer"
            >
              Reload latest
            </button>
          )}
        </div>
      )}

      {/* Panel 1: Header Menu */}
      <section className="rounded-2xl bg-[#031D1C] border border-white/10 p-5 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-[#EDE9E0]">Header Menu</h2>
            <p className="text-xs text-[#EDE9E0]/60">
              Drag rows or use arrow buttons to reorder links. Core items can be hidden but never deleted.
            </p>
          </div>
          <button
            type="button"
            onClick={addHeaderItem}
            className="h-9 px-3.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add menu item</span>
          </button>
        </div>

        {/* Live Navbar Preview */}
        <div className="p-4 rounded-xl bg-[#06302F] border border-white/10 space-y-2">
          <span className="text-[10px] uppercase tracking-wider font-bold text-[#EDE9E0]/45 block">
            Live Navbar Preview
          </span>
          <div className="flex flex-wrap items-center justify-between gap-4 py-2 px-3 rounded-lg bg-[#031D1C] border border-white/10">
            <span className="text-xs font-bold text-[#EDE9E0]">{overview.seo.siteName}</span>
            <nav className="flex flex-wrap items-center gap-4 text-xs">
              {livePreviewHeader.map(item => (
                <span key={item.id} className="text-[#EDE9E0]/85 font-medium inline-flex items-center gap-1">
                  <span>{item.label || 'Untitled'}</span>
                  {(item.newTab || item.isExternal) && <ExternalLink className="w-2.5 h-2.5 text-[#25CDB6]" />}
                </span>
              ))}
            </nav>
          </div>
        </div>

        <div className="space-y-2.5">
          {menus.header.map((item, idx) => {
            const isHome = item.path === '/' || item.pageId === 'home';
            const isProducts = item.pageId === 'products' || item.path === '/products';
            const matchedDest = availableDestinations.find(d => d.path === item.path || (item.pageId && d.id === item.pageId));
            const useCustomInput = !isHome && (customUrlMode[item.id] || !matchedDest);
            const pathSafe = isSafeUrl(item.path) && !BLOCKED_MENU_PATHS.has(item.path.toLowerCase());

            return (
              <div
                key={item.id}
                draggable
                onDragStart={() => setDragHeaderIdx(idx)}
                onDragOver={e => e.preventDefault()}
                onDrop={() => {
                  if (dragHeaderIdx !== null) moveHeaderItem(dragHeaderIdx, idx);
                  setDragHeaderIdx(null);
                }}
                onDragEnd={() => setDragHeaderIdx(null)}
                className={`p-3.5 rounded-xl bg-[#06302F] border transition-colors text-xs space-y-2.5 ${
                  dragHeaderIdx === idx ? 'border-[#25CDB6]' : 'border-white/10'
                }`}
              >
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="text-[#EDE9E0]/40 cursor-grab active:cursor-grabbing" title="Drag to reorder">
                    <GripVertical className="w-4 h-4" />
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => moveHeaderItem(idx, idx - 1)}
                      aria-label={`Move ${item.label} up`}
                      className="p-1 rounded bg-white/5 hover:bg-white/10 text-[#EDE9E0]/75 disabled:opacity-30 cursor-pointer"
                    >
                      <MoveUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={idx === menus.header.length - 1}
                      onClick={() => moveHeaderItem(idx, idx + 1)}
                      aria-label={`Move ${item.label} down`}
                      className="p-1 rounded bg-white/5 hover:bg-white/10 text-[#EDE9E0]/75 disabled:opacity-30 cursor-pointer"
                    >
                      <MoveDown className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Label */}
                  <input
                    type="text"
                    value={item.label}
                    onChange={e => updateHeaderItem(idx, { label: e.target.value })}
                    placeholder="Menu label"
                    aria-label={`Label for item ${idx + 1}`}
                    className="w-36 sm:w-44 bg-[#031D1C] border border-white/10 rounded-lg px-3 py-1.5 text-[#EDE9E0] font-semibold"
                  />

                  {/* Destination Picker */}
                  {isHome ? (
                    <div className="px-3 py-1.5 rounded-lg bg-[#031D1C]/60 border border-white/10 font-mono text-[#25CDB6] inline-flex items-center gap-1.5">
                      <Lock className="w-3 h-3" />
                      <span>/ (Required Home)</span>
                    </div>
                  ) : (
                    <select
                      value={useCustomInput ? '__custom__' : matchedDest?.path || item.path}
                      onChange={e => {
                        const val = e.target.value;
                        if (val === '__custom__') {
                          setCustomUrlMode(prev => ({ ...prev, [item.id]: true }));
                          updateHeaderItem(idx, { pageId: undefined });
                        } else {
                          setCustomUrlMode(prev => ({ ...prev, [item.id]: false }));
                          const dest = availableDestinations.find(d => d.path === val);
                          updateHeaderItem(idx, {
                            path: val,
                            pageId: dest?.id,
                            isExternal: false
                          });
                        }
                      }}
                      aria-label={`Destination for ${item.label}`}
                      className="bg-[#031D1C] border border-white/10 rounded-lg px-3 py-1.5 text-[#EDE9E0]"
                    >
                      {availableDestinations.map(d => (
                        <option key={d.id} value={d.path}>
                          Page: {d.name} ({d.path})
                        </option>
                      ))}
                      <option value="__custom__">Custom URL...</option>
                    </select>
                  )}

                  {useCustomInput && (
                    <input
                      type="text"
                      value={item.path}
                      onChange={e =>
                        updateHeaderItem(idx, {
                          path: e.target.value,
                          isExternal: /^https?:\/\//i.test(e.target.value.trim())
                        })
                      }
                      placeholder="/path or https://..."
                      className={`flex-1 min-w-[160px] bg-[#031D1C] border rounded-lg px-3 py-1.5 font-mono text-[#EDE9E0] ${
                        pathSafe ? 'border-white/10' : 'border-red-500/60'
                      }`}
                    />
                  )}

                  {/* Open in new tab */}
                  {!isHome && (useCustomInput || item.isExternal || /^https?:\/\//i.test(item.path)) && (
                    <label className="inline-flex items-center gap-1.5 text-[#EDE9E0]/75 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={Boolean(item.newTab)}
                        onChange={e => updateHeaderItem(idx, { newTab: e.target.checked })}
                        className="w-3.5 h-3.5 accent-[#25CDB6]"
                      />
                      <span>New tab</span>
                    </label>
                  )}

                  <div className="ml-auto flex items-center gap-2">
                    {/* Visible toggle */}
                    <button
                      type="button"
                      disabled={isHome}
                      onClick={() => updateHeaderItem(idx, { visible: item.visible === false })}
                      className={`px-2.5 py-1.5 rounded-lg border font-semibold inline-flex items-center gap-1 cursor-pointer disabled:opacity-60 ${
                        item.visible !== false
                          ? 'bg-[#25CDB6]/15 border-[#25CDB6]/30 text-[#25CDB6]'
                          : 'bg-white/5 border-white/10 text-[#EDE9E0]/55'
                      }`}
                    >
                      {item.visible !== false ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      <span>{item.visible !== false ? 'Visible' : 'Hidden'}</span>
                    </button>

                    {item.isCore ? (
                      <span
                        title="Core navigation item cannot be deleted"
                        className="p-1.5 rounded-lg bg-white/5 border border-white/10 text-[#EDE9E0]/35"
                      >
                        <Lock className="w-3.5 h-3.5" />
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => removeHeaderItem(idx)}
                        aria-label={`Remove ${item.label}`}
                        className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 border border-red-500/25 text-red-300 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {isProducts && (
                  <div className="pl-7 pt-2 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-1.5 text-[11px] text-[#25CDB6]">
                      <Info className="w-3.5 h-3.5 shrink-0" />
                      <span>Auto: appears once a product is published</span>
                    </div>
                    <label className="inline-flex items-center gap-2 text-[11px] font-semibold text-[#EDE9E0] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={alwaysShowProducts}
                        onChange={e => setAlwaysShowProducts(e.target.checked)}
                        className="w-3.5 h-3.5 accent-[#25CDB6]"
                      />
                      <span>Always show Products in navbar &amp; sitemap</span>
                    </label>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* Panel 2: Footer */}
      <section className="rounded-2xl bg-[#031D1C] border border-white/10 p-5 space-y-5">
        <div>
          <h2 className="text-base font-bold text-[#EDE9E0]">Footer Configuration</h2>
          <p className="text-xs text-[#EDE9E0]/60">
            Customize footer blurb, copyright notice, and column ordering/visibility.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div>
            <label className="block text-[#EDE9E0]/75 font-semibold mb-1">Footer Blurb</label>
            <textarea
              rows={3}
              value={menus.footer.blurb}
              onChange={e =>
                setMenus(prev => ({
                  ...prev,
                  footer: { ...prev.footer, blurb: e.target.value }
                }))
              }
              className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
            />
          </div>
          <div className="space-y-3">
            <div>
              <label className="block text-[#EDE9E0]/75 font-semibold mb-1">
                Copyright Line <span className="text-[10px] text-[#EDE9E0]/45">(supports {'{year}'})</span>
              </label>
              <input
                type="text"
                value={menus.footer.copyrightText}
                onChange={e =>
                  setMenus(prev => ({
                    ...prev,
                    footer: { ...prev.footer, copyrightText: e.target.value }
                  }))
                }
                placeholder="All rights reserved."
                className="w-full bg-[#06302F] border border-white/10 rounded-xl px-3.5 py-2.5 text-[#EDE9E0]"
              />
            </div>
            <label className="flex items-center justify-between gap-3 p-3 rounded-xl bg-[#06302F] border border-white/10 cursor-pointer">
              <span className="font-semibold text-[#EDE9E0]">Show contact email in footer</span>
              <input
                type="checkbox"
                checked={menus.footer.showContactEmail}
                onChange={e =>
                  setMenus(prev => ({
                    ...prev,
                    footer: { ...prev.footer, showContactEmail: e.target.checked }
                  }))
                }
                className="w-4 h-4 accent-[#25CDB6]"
              />
            </label>
          </div>
        </div>

        {/* Footer Columns (Reorder + Show/Hide) */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#EDE9E0]/60">
            Footer Columns (drag or use arrows to reorder)
          </h3>

          {menus.footer.columns.map((col, idx) => (
            <div
              key={col.id}
              draggable
              onDragStart={() => setDragColIdx(idx)}
              onDragOver={e => e.preventDefault()}
              onDrop={() => {
                if (dragColIdx !== null) moveFooterColumn(dragColIdx, idx);
                setDragColIdx(null);
              }}
              onDragEnd={() => setDragColIdx(null)}
              className="p-4 rounded-xl bg-[#06302F] border border-white/10 space-y-3 text-xs"
            >
              <div className="flex flex-wrap items-center gap-2.5">
                <span className="text-[#EDE9E0]/40 cursor-grab">
                  <GripVertical className="w-4 h-4" />
                </span>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    disabled={idx === 0}
                    onClick={() => moveFooterColumn(idx, idx - 1)}
                    aria-label={`Move ${col.title} column up`}
                    className="p-1 rounded bg-white/5 hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                  >
                    <MoveUp className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    disabled={idx === menus.footer.columns.length - 1}
                    onClick={() => moveFooterColumn(idx, idx + 1)}
                    aria-label={`Move ${col.title} column down`}
                    className="p-1 rounded bg-white/5 hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                  >
                    <MoveDown className="w-3.5 h-3.5" />
                  </button>
                </div>

                <input
                  type="text"
                  value={col.title}
                  onChange={e => updateFooterColumn(col.id, { title: e.target.value })}
                  aria-label={`Column heading for ${col.id}`}
                  className="bg-[#031D1C] border border-white/10 rounded-lg px-3 py-1.5 font-bold text-[#EDE9E0]"
                />

                <span className="px-2 py-0.5 rounded bg-white/5 text-[10px] font-mono text-[#EDE9E0]/55">
                  {col.id}
                </span>

                <button
                  type="button"
                  onClick={() => updateFooterColumn(col.id, { visible: !col.visible })}
                  className={`ml-auto px-2.5 py-1.5 rounded-lg border font-semibold inline-flex items-center gap-1 cursor-pointer ${
                    col.visible
                      ? 'bg-[#25CDB6]/15 border-[#25CDB6]/30 text-[#25CDB6]'
                      : 'bg-white/5 border-white/10 text-[#EDE9E0]/55'
                  }`}
                >
                  {col.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                  <span>{col.visible ? 'Shown' : 'Hidden'}</span>
                </button>
              </div>

              {col.id === 'explore' && (
                <div className="pl-7 space-y-2.5">
                  <label className="inline-flex items-center gap-2 font-semibold text-[#EDE9E0] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={col.sameAsHeader !== false}
                      onChange={e => {
                        const nextSame = e.target.checked;
                        updateFooterColumn('explore', {
                          sameAsHeader: nextSame,
                          links:
                            !nextSame && (!col.links || col.links.length === 0)
                              ? menus.header
                                  .filter(i => i.visible !== false)
                                  .map(i => ({
                                    label: i.label,
                                    url: i.path,
                                    isExternal: i.isExternal,
                                    newTab: i.newTab
                                  }))
                              : col.links
                        });
                      }}
                      className="w-3.5 h-3.5 accent-[#25CDB6]"
                    />
                    <span>Same links as Header Menu</span>
                  </label>

                  {col.sameAsHeader === false && (
                    <div className="space-y-2 pt-2 border-t border-white/10">
                      {(col.links || []).map((lnk, li) => (
                        <div key={li} className="flex flex-wrap items-center gap-2">
                          <input
                            type="text"
                            value={lnk.label}
                            onChange={e => updateFooterColLink('explore', li, { label: e.target.value })}
                            placeholder="Label"
                            className="w-36 bg-[#031D1C] border border-white/10 rounded-lg px-2.5 py-1.5 text-[#EDE9E0]"
                          />
                          <input
                            type="text"
                            value={lnk.url}
                            onChange={e =>
                              updateFooterColLink('explore', li, {
                                url: e.target.value,
                                isExternal: /^https?:\/\//i.test(e.target.value.trim())
                              })
                            }
                            placeholder="/path"
                            className="flex-1 min-w-[140px] bg-[#031D1C] border border-white/10 rounded-lg px-2.5 py-1.5 font-mono text-[#EDE9E0]"
                          />
                          <button
                            type="button"
                            disabled={li === 0}
                            onClick={() => moveFooterColLink('explore', li, li - 1)}
                            className="p-1 rounded bg-white/5 hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                          >
                            <MoveUp className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            disabled={li === (col.links?.length || 0) - 1}
                            onClick={() => moveFooterColLink('explore', li, li + 1)}
                            className="p-1 rounded bg-white/5 hover:bg-white/10 disabled:opacity-30 cursor-pointer"
                          >
                            <MoveDown className="w-3 h-3" />
                          </button>
                          <button
                            type="button"
                            onClick={() => removeFooterColLink('explore', li)}
                            className="p-1.5 rounded bg-red-500/10 text-red-300 cursor-pointer"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                      <button
                        type="button"
                        onClick={() => addFooterColLink('explore')}
                        className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#25CDB6] font-semibold inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Add Explore link</span>
                      </button>
                    </div>
                  )}
                </div>
              )}

              {col.id === 'departments' && (
                <p className="pl-7 text-[11px] text-[#EDE9E0]/55">
                  Auto-managed: displays published Departments dynamically.
                </p>
              )}
              {col.id === 'sectors' && (
                <p className="pl-7 text-[11px] text-[#EDE9E0]/55">
                  Auto-managed: displays published RDD Sectors dynamically.
                </p>
              )}
              {col.id === 'community' && (
                <p className="pl-7 text-[11px] text-[#EDE9E0]/55">
                  Auto-managed: renders visible channels configured under Brand &amp; site-wide.
                </p>
              )}

              {col.id === 'legal' && (
                <div className="pl-7 space-y-2 pt-1 border-t border-white/10">
                  {(col.links || []).length === 0 && (
                    <p className="text-[11px] text-[#EDE9E0]/55">No legal or policy links added yet.</p>
                  )}
                  {(col.links || []).map((lnk, li) => (
                    <div key={li} className="flex flex-wrap items-center gap-2">
                      <input
                        type="text"
                        value={lnk.label}
                        onChange={e => updateFooterColLink('legal', li, { label: e.target.value })}
                        placeholder="Privacy Policy"
                        className="w-40 bg-[#031D1C] border border-white/10 rounded-lg px-2.5 py-1.5 text-[#EDE9E0]"
                      />
                      <input
                        type="text"
                        value={lnk.url}
                        onChange={e =>
                          updateFooterColLink('legal', li, {
                            url: e.target.value,
                            isExternal: /^https?:\/\//i.test(e.target.value.trim())
                          })
                        }
                        placeholder="/pages/privacy-policy"
                        className="flex-1 min-w-[160px] bg-[#031D1C] border border-white/10 rounded-lg px-2.5 py-1.5 font-mono text-[#EDE9E0]"
                      />
                      <label className="inline-flex items-center gap-1 text-[11px] text-[#EDE9E0]/75 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={Boolean(lnk.newTab)}
                          onChange={e => updateFooterColLink('legal', li, { newTab: e.target.checked })}
                          className="w-3.5 h-3.5 accent-[#25CDB6]"
                        />
                        <span>New tab</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => removeFooterColLink('legal', li)}
                        className="p-1.5 rounded bg-red-500/10 text-red-300 cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => addFooterColLink('legal')}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[#25CDB6] font-semibold inline-flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add Legal link</span>
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Live Footer Preview */}
        <div className="p-4 rounded-xl bg-[#06302F] border border-white/10 space-y-3">
          <span className="text-[10px] uppercase tracking-wider font-bold text-[#EDE9E0]/45 block">
            Live Footer Preview
          </span>
          <div className="p-4 rounded-lg bg-[#031D1C] border border-white/10 grid grid-cols-1 md:grid-cols-6 gap-4 text-xs">
            <div className="md:col-span-2 space-y-1.5">
              <span className="font-bold text-[#EDE9E0] block">{overview.seo.siteName}</span>
              <p className="text-[11px] text-[#EDE9E0]/60 line-clamp-2">{menus.footer.blurb || '—'}</p>
              {menus.footer.showContactEmail && (
                <span className="text-[11px] text-[#25CDB6] block">Contact email displayed</span>
              )}
            </div>
            {menus.footer.columns
              .filter(c => c.visible)
              .map(c => (
                <div key={c.id} className="space-y-1">
                  <span className="font-bold text-[#EDE9E0] block">{c.title}</span>
                  {c.id === 'explore' && (
                    <div className="space-y-0.5 text-[11px] text-[#EDE9E0]/65">
                      {(c.sameAsHeader !== false ? livePreviewHeader.map(h => h.label) : (c.links || []).map(l => l.label))
                        .slice(0, 5)
                        .map((lbl, i) => (
                          <span key={i} className="block truncate">
                            {lbl}
                          </span>
                        ))}
                    </div>
                  )}
                  {c.id === 'departments' && <span className="text-[11px] text-[#EDE9E0]/45">Published Departments</span>}
                  {c.id === 'sectors' && <span className="text-[11px] text-[#EDE9E0]/45">Published Sectors</span>}
                  {c.id === 'community' && (
                    <span className="text-[11px] text-[#EDE9E0]/45">
                      {overview.social.links.filter(s => s.visible !== false).length} visible channels
                    </span>
                  )}
                  {c.id === 'legal' && (
                    <div className="space-y-0.5 text-[11px] text-[#EDE9E0]/65">
                      {(c.links || []).slice(0, 4).map((l, i) => (
                        <span key={i} className="block truncate">
                          {l.label}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
          </div>
          <div className="text-[11px] text-[#EDE9E0]/55">
            © {new Date().getFullYear()} {overview.seo.siteName}.{' '}
            {menus.footer.copyrightText.replace(/\{year\}/g, String(new Date().getFullYear()))}
          </div>
        </div>
      </section>

      <FloatingSaveBar
        visible={isDirty}
        title="Unsaved menu changes"
        subtitle={validationErrors.length > 0 ? validationErrors[0] : 'Review and save to update header & footer.'}
        error={errorMsg}
        saving={saving}
        saveDisabled={validationErrors.length > 0}
        saveLabel="Save menus"
        onDiscard={handleDiscard}
        onSave={handleSave}
      />
    </div>
  );
};
