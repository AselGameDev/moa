import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  Archive,
  ArrowDown,
  ArrowUp,
  BookOpen,
  Building,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Copy,
  Edit,
  ExternalLink,
  FolderKanban,
  GripVertical,
  Layers,
  Package,
  Plus,
  RotateCcw,
  Send,
  Trash2
} from 'lucide-react';
import {
  BulkContentAction,
  ContentListParams,
  Department,
  PaginatedResult,
  Product,
  Project,
  Publication,
  RoleDefinition,
  User
} from '../../../types';
import { api } from '../../../services/api';
import { can } from '../../../shared/permissions';
import {
  getSectorParentId,
  getUnitHref,
  isRddDepartment,
  isSector,
  splitOrgUnits
} from '../../../utils/orgHelpers';
import { getVisibleSubTabs } from '../portalRegistry';
import { DepartmentLogo } from '../../DepartmentLogo';
import { ContentReviewDrawer } from '../ContentReviewDrawer';
import { UnifiedContentEditor, UnifiedEditorKind } from '../UnifiedContentEditor';
import {
  PortalConfirmDialog,
  PortalEmptyState,
  PortalFilterBar,
  PortalFilterSelectConfig,
  PortalPageHeader,
  PortalSearchInput,
  PortalStatusBadge,
  PortalStatusLegend,
  PortalTable,
  PortalTableBulkAction,
  PortalTableColumn,
  PortalTableRowAction,
  PortalTabs
} from '../ui';

export type ContentSubTab = 'departments' | 'projects' | 'publications' | 'products';
export type ContentEntityTab = 'projects' | 'publications' | 'products';

export interface ContentRequestedEdit {
  kind: ContentSubTab;
  id: string | 'new';
  nonce: number;
}

interface ContentTabProps {
  initialSubTab?: ContentSubTab;
  onSubTabChange?: (sub: ContentSubTab) => void;
  initialSelectedOrgUnitId?: string | null;
  onSelectedOrgUnitChange?: (unitId: string | null) => void;
  requestedEdit?: ContentRequestedEdit | null;
  onConsumeRequestedEdit?: () => void;
  departments: Department[];
  projects: Project[];
  publications: Publication[];
  products: Product[];
  currentUser: User;
  roles?: RoleDefinition[];
  onSaveDepartment: (dept: Partial<Department>, targetId?: string) => Promise<Department | void>;
  onReorderDepartments?: (orderedIds: string[]) => Promise<void>;
  onDeleteDepartment: (
    id: string,
    options: { projectHandling: 'leave' | 'reassign'; targetDeptId?: string }
  ) => Promise<void>;
  onSaveProject: (proj: Partial<Project>, targetId?: string) => Promise<Project>;
  onProjectUpdated?: (updated: Project) => void;
  onDeleteProject: (id: string) => Promise<void>;
  onSavePublication: (pub: Partial<Publication>, targetId?: string) => Promise<Publication>;
  onReviewPublication: (
    id: string,
    action: 'approved' | 'rejected' | 'requested_changes',
    comment?: string
  ) => Promise<void>;
  onDeletePublication: (id: string) => Promise<void>;
  onSaveProduct: (prod: Partial<Product>, targetId?: string) => Promise<Product>;
  onReviewProduct: (
    id: string,
    action: 'approved' | 'rejected' | 'requested_changes',
    comment?: string
  ) => Promise<void>;
  onDeleteProduct: (id: string) => Promise<void>;
  onRefreshData?: () => Promise<void>;
  onNavigateSite: (path?: string) => void;
}

interface EditorState {
  kind: UnifiedEditorKind;
  item: Department | Project | Publication | Product | null;
  initialParentDepartmentId?: string;
}

type ContentRowItem =
  | { kind: 'project'; record: Project }
  | { kind: 'publication'; record: Publication }
  | { kind: 'product'; record: Product };

const SUBTAB_ICONS: Record<ContentSubTab, React.ComponentType<{ className?: string }>> = {
  departments: Building,
  projects: FolderKanban,
  publications: BookOpen,
  products: Package
};

const PAGE_SIZE = 20;

const SORT_OPTIONS = [
  { value: 'updated:desc', label: 'Updated (newest)' },
  { value: 'title:asc', label: 'Title (A–Z)' },
  { value: 'status:asc', label: 'Status' }
];

const STATUS_FILTER_OPTIONS = [
  { value: 'all', label: 'All statuses' },
  { value: 'Draft', label: 'Draft' },
  { value: 'Pending Review', label: 'In review' },
  { value: 'Published', label: 'Published' },
  { value: 'Archived', label: 'Archived' }
];

function formatShortDate(iso?: string): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

export const ContentTab: React.FC<ContentTabProps> = ({
  initialSubTab = 'departments',
  onSubTabChange,
  initialSelectedOrgUnitId = null,
  onSelectedOrgUnitChange,
  requestedEdit,
  onConsumeRequestedEdit,
  departments,
  projects,
  publications,
  products,
  currentUser,
  roles,
  onReorderDepartments,
  onDeleteDepartment,
  onDeleteProject,
  onDeletePublication,
  onDeleteProduct,
  onRefreshData,
  onNavigateSite
}) => {
  const visibleSubTabs = useMemo(
    () => getVisibleSubTabs('content', currentUser, roles),
    [currentUser, roles]
  );

  const [subTab, setSubTab] = useState<ContentSubTab>(() => {
    if (visibleSubTabs.some(st => st.id === initialSubTab)) return initialSubTab;
    return (visibleSubTabs[0]?.id as ContentSubTab) || 'projects';
  });

  useEffect(() => {
    if (visibleSubTabs.some(st => st.id === initialSubTab)) {
      setSubTab(initialSubTab);
    } else if (visibleSubTabs.length > 0 && !visibleSubTabs.some(st => st.id === subTab)) {
      setSubTab(visibleSubTabs[0].id as ContentSubTab);
    }
  }, [initialSubTab, visibleSubTabs, subTab]);

  // Permissions
  const canManageDepts = can(currentUser, 'departments.manage', roles);
  const canCreateProject = can(currentUser, 'projects.create', roles);
  const canEditAll = can(currentUser, 'projects.editAll', roles);
  const canEditOwn = can(currentUser, 'projects.editOwn', roles);
  const canPublish = can(currentUser, 'projects.publish', roles);
  const canManagePubs = can(currentUser, 'publications.manage', roles) || canPublish;
  const canManageProds = can(currentUser, 'products.manage', roles) || canPublish;

  const canEditEntry = useCallback(
    (authorId: string) =>
      canEditAll || canPublish || (canEditOwn && authorId === currentUser.id),
    [canEditAll, canEditOwn, canPublish, currentUser.id]
  );

  // Active un-deleted lists for counts, org tree, and author dropdowns
  const activeDepts = useMemo(() => departments.filter(d => !d.deletedAt), [departments]);
  const orgUnits = useMemo(() => splitOrgUnits(activeDepts), [activeDepts]);
  const activeProjects = useMemo(() => projects.filter(p => !p.deletedAt), [projects]);
  const activePubs = useMemo(() => publications.filter(p => !p.deletedAt), [publications]);
  const activeProds = useMemo(() => products.filter(p => !p.deletedAt), [products]);

  const deptNameMap = useMemo(() => {
    const map = new Map<string, string>();
    activeDepts.forEach(d => map.set(d.id, d.name));
    return map;
  }, [activeDepts]);

  // Top-level action state
  const [editorState, setEditorState] = useState<EditorState | null>(null);
  const [newMenuOpen, setNewMenuOpen] = useState(false);
  const newMenuRef = useRef<HTMLDivElement | null>(null);
  const [reviewDrawerOpen, setReviewDrawerOpen] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  useEffect(() => {
    if (!newMenuOpen) return;
    const onOutside = (e: MouseEvent) => {
      if (newMenuRef.current && !newMenuRef.current.contains(e.target as Node)) {
        setNewMenuOpen(false);
      }
    };
    const onEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setNewMenuOpen(false);
    };
    document.addEventListener('mousedown', onOutside);
    window.addEventListener('keydown', onEsc);
    return () => {
      document.removeEventListener('mousedown', onOutside);
      window.removeEventListener('keydown', onEsc);
    };
  }, [newMenuOpen]);

  const reviewQueueCount = useMemo(() => {
    return (
      activeProjects.filter(p => p.publicationStatus === 'Pending Review' || Boolean(p.pendingRevision)).length +
      activePubs.filter(p => p.publicationStatus === 'Pending Review' || Boolean(p.pendingRevision)).length +
      activeProds.filter(p => p.publicationStatus === 'Pending Review' || Boolean(p.pendingRevision)).length
    );
  }, [activeProjects, activePubs, activeProds]);

  // Handle deep-linked edit requests from Overview / Site
  const handledEditNonceRef = useRef<number | null>(null);
  useEffect(() => {
    if (!requestedEdit || handledEditNonceRef.current === requestedEdit.nonce) return;
    handledEditNonceRef.current = requestedEdit.nonce;
    if (requestedEdit.kind === 'departments' && canManageDepts) {
      setSubTab('departments');
      if (requestedEdit.id === 'new') {
        setEditorState({ kind: 'department', item: null });
      } else {
        const found = activeDepts.find(d => d.id === requestedEdit.id);
        if (found) {
          setSelectedOrgUnitId(found.id);
          setEditorState({
            kind: isSector(found) ? 'sector' : 'department',
            item: found
          });
        }
      }
    } else if (
      requestedEdit.kind === 'projects' &&
      (canCreateProject || canEditOwn || canEditAll || canPublish)
    ) {
      setSubTab('projects');
      if (requestedEdit.id === 'new' && canCreateProject) {
        setEditorState({ kind: 'project', item: null });
      } else {
        const found = projects.find(p => p.id === requestedEdit.id);
        if (found) setEditorState({ kind: 'project', item: found });
      }
    } else if (requestedEdit.kind === 'publications' && (canManagePubs || canCreateProject)) {
      setSubTab('publications');
      if (requestedEdit.id === 'new') {
        setEditorState({ kind: 'publication', item: null });
      } else {
        const found = publications.find(p => p.id === requestedEdit.id);
        if (found) setEditorState({ kind: 'publication', item: found });
      }
    } else if (requestedEdit.kind === 'products' && canManageProds) {
      setSubTab('products');
      if (requestedEdit.id === 'new') {
        setEditorState({ kind: 'product', item: null });
      } else {
        const found = products.find(p => p.id === requestedEdit.id);
        if (found) setEditorState({ kind: 'product', item: found });
      }
    }
    onConsumeRequestedEdit?.();
  }, [
    requestedEdit,
    onConsumeRequestedEdit,
    activeDepts,
    projects,
    publications,
    products,
    canManageDepts,
    canCreateProject,
    canEditOwn,
    canEditAll,
    canPublish,
    canManagePubs,
    canManageProds
  ]);

  const selectSubTab = (next: ContentSubTab) => {
    if (next === subTab) return;
    setSubTab(next);
    onSubTabChange?.(next);
  };

  // =========================================================================
  // 1. DEPARTMENTS & SECTORS STATE (C2)
  // =========================================================================
  const [selectedOrgUnitId, setSelectedOrgUnitId] = useState<string | null>(
    () => initialSelectedOrgUnitId || null
  );
  const [deptSearch, setDeptSearch] = useState('');
  const [draggingUnitId, setDraggingUnitId] = useState<string | null>(null);
  const [reorderingOrg, setReorderingOrg] = useState(false);
  const [togglingDeptId, setTogglingDeptId] = useState<string | null>(null);
  const [deletingDept, setDeletingDept] = useState<Department | null>(null);
  const [deptHandling, setDeptHandling] = useState<'leave' | 'reassign'>('leave');
  const [reassignTargetDeptId, setReassignTargetDeptId] = useState('');
  const [deletingDeptBusy, setDeletingDeptBusy] = useState(false);

  useEffect(() => {
    if (activeDepts.length === 0) {
      setSelectedOrgUnitId(null);
      return;
    }
    if (!selectedOrgUnitId || !activeDepts.some(d => d.id === selectedOrgUnitId)) {
      const nextId = orgUnits.departments[0]?.id || activeDepts[0].id;
      setSelectedOrgUnitId(nextId);
    }
  }, [activeDepts, orgUnits.departments, selectedOrgUnitId]);

  useEffect(() => {
    onSelectedOrgUnitChange?.(selectedOrgUnitId);
  }, [selectedOrgUnitId, onSelectedOrgUnitChange]);

  const selectedOrgUnit = useMemo(
    () => (selectedOrgUnitId ? activeDepts.find(d => d.id === selectedOrgUnitId) || null : null),
    [activeDepts, selectedOrgUnitId]
  );

  const sectorsByParentId = useMemo(() => {
    const map = new Map<string, Department[]>();
    orgUnits.sectors.forEach(s => {
      const pid = getSectorParentId(s);
      const list = map.get(pid) || [];
      list.push(s);
      map.set(pid, list);
    });
    return map;
  }, [orgUnits.sectors]);

  const deptIdSet = useMemo(() => new Set(orgUnits.departments.map(d => d.id)), [orgUnits.departments]);
  const orphanSectors = useMemo(
    () => orgUnits.sectors.filter(s => !deptIdSet.has(getSectorParentId(s))),
    [orgUnits.sectors, deptIdSet]
  );

  const filteredTreeQuery = deptSearch.trim().toLowerCase();
  const visibleDepartments = useMemo(() => {
    if (!filteredTreeQuery) return orgUnits.departments;
    return orgUnits.departments.filter(d => {
      if (d.name.toLowerCase().includes(filteredTreeQuery) || d.slug.toLowerCase().includes(filteredTreeQuery)) {
        return true;
      }
      const children = sectorsByParentId.get(d.id) || [];
      return children.some(
        s => s.name.toLowerCase().includes(filteredTreeQuery) || s.slug.toLowerCase().includes(filteredTreeQuery)
      );
    });
  }, [orgUnits.departments, sectorsByParentId, filteredTreeQuery]);

  const filterChildSectors = (parentDept: Department) => {
    const list = sectorsByParentId.get(parentDept.id) || [];
    if (!filteredTreeQuery) return list;
    const parentMatches =
      parentDept.name.toLowerCase().includes(filteredTreeQuery) ||
      parentDept.slug.toLowerCase().includes(filteredTreeQuery);
    if (parentMatches) return list;
    return list.filter(
      s => s.name.toLowerCase().includes(filteredTreeQuery) || s.slug.toLowerCase().includes(filteredTreeQuery)
    );
  };

  const commitOrgOrder = async (nextDepartments: Department[], nextSectors: Department[]) => {
    if (!onReorderDepartments) return;
    const combinedIds = [...nextDepartments.map(d => d.id), ...nextSectors.map(s => s.id)];
    setReorderingOrg(true);
    setActionError(null);
    try {
      await onReorderDepartments(combinedIds);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to reorder units.');
    } finally {
      setReorderingOrg(false);
    }
  };

  const handleReorderUnit = (dragId: string, targetId: string) => {
    if (!dragId || dragId === targetId) return;
    const dragUnit = activeDepts.find(d => d.id === dragId);
    const targetUnit = activeDepts.find(d => d.id === targetId);
    if (!dragUnit || !targetUnit) return;
    const dragIsSector = isSector(dragUnit);
    const targetIsSector = isSector(targetUnit);
    if (dragIsSector !== targetIsSector) return;

    if (!dragIsSector) {
      const list = [...orgUnits.departments];
      const fromIdx = list.findIndex(d => d.id === dragId);
      const toIdx = list.findIndex(d => d.id === targetId);
      if (fromIdx < 0 || toIdx < 0) return;
      const [moved] = list.splice(fromIdx, 1);
      list.splice(toIdx, 0, moved);
      void commitOrgOrder(list, orgUnits.sectors);
    } else {
      const dragParentId = getSectorParentId(dragUnit);
      const targetParentId = getSectorParentId(targetUnit);
      if (dragParentId !== targetParentId) return;
      const siblings = [...(sectorsByParentId.get(dragParentId) || [])];
      const fromIdx = siblings.findIndex(s => s.id === dragId);
      const toIdx = siblings.findIndex(s => s.id === targetId);
      if (fromIdx < 0 || toIdx < 0) return;
      const [moved] = siblings.splice(fromIdx, 1);
      siblings.splice(toIdx, 0, moved);
      const rebuiltSectors = orgUnits.sectors.map(s =>
        getSectorParentId(s) === dragParentId ? siblings.shift()! : s
      );
      void commitOrgOrder(orgUnits.departments, rebuiltSectors);
    }
  };

  const handleMoveUnitStep = (unit: Department, delta: -1 | 1) => {
    if (!isSector(unit)) {
      const list = [...orgUnits.departments];
      const idx = list.findIndex(d => d.id === unit.id);
      const nextIdx = idx + delta;
      if (idx < 0 || nextIdx < 0 || nextIdx >= list.length) return;
      const [moved] = list.splice(idx, 1);
      list.splice(nextIdx, 0, moved);
      void commitOrgOrder(list, orgUnits.sectors);
    } else {
      const parentId = getSectorParentId(unit);
      const siblings = [...(sectorsByParentId.get(parentId) || [])];
      const idx = siblings.findIndex(s => s.id === unit.id);
      const nextIdx = idx + delta;
      if (idx < 0 || nextIdx < 0 || nextIdx >= siblings.length) return;
      const [moved] = siblings.splice(idx, 1);
      siblings.splice(nextIdx, 0, moved);
      const rebuiltSectors = orgUnits.sectors.map(s =>
        getSectorParentId(s) === parentId ? siblings.shift()! : s
      );
      void commitOrgOrder(orgUnits.departments, rebuiltSectors);
    }
  };

  const handleToggleDeptFlag = async (dept: Department, field: 'published' | 'showInTree', value: boolean) => {
    setTogglingDeptId(`${dept.id}:${field}`);
    setActionError(null);
    try {
      await api.updateDepartment(dept.id, { [field]: value });
      await onRefreshData?.();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to update unit visibility.');
    } finally {
      setTogglingDeptId(null);
    }
  };

  const openDeleteDepartmentModal = (dept: Department) => {
    setDeletingDept(dept);
    setDeptHandling('leave');
    const firstAlt = activeDepts.find(d => d.id !== dept.id);
    setReassignTargetDeptId(firstAlt?.id || '');
    setActionError(null);
  };

  const handleConfirmDeleteDepartment = async () => {
    if (!deletingDept) return;
    if (deptHandling === 'reassign' && !reassignTargetDeptId) {
      setActionError('Choose a target department or select "Leave items unlinked".');
      return;
    }
    setDeletingDeptBusy(true);
    setActionError(null);
    try {
      await onDeleteDepartment(deletingDept.id, {
        projectHandling: deptHandling,
        targetDeptId: deptHandling === 'reassign' ? reassignTargetDeptId : undefined
      });
      setDeletingDept(null);
      await onRefreshData?.();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to move unit to trash.');
    } finally {
      setDeletingDeptBusy(false);
    }
  };

  // =========================================================================
  // 2. SERVER-PAGINATED PROJECTS / PUBLICATIONS / PRODUCTS (C3)
  // =========================================================================
  const [searchInput, setSearchInput] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [sectorFilter, setSectorFilter] = useState('all');
  const [authorFilter, setAuthorFilter] = useState('all');
  const [sortOption, setSortOption] = useState('updated:desc');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [page, setPage] = useState(1);

  const [pagedResult, setPagedResult] = useState<PaginatedResult<Project | Publication | Product>>({
    items: [],
    total: 0,
    page: 1,
    limit: PAGE_SIZE,
    totalPages: 1
  });
  const [listLoading, setListLoading] = useState(false);
  const [listError, setListError] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkTrashConfirmIds, setBulkTrashConfirmIds] = useState<string[] | null>(null);
  const [singleDeleteTarget, setSingleDeleteTarget] = useState<{
    kind: 'project' | 'publication' | 'product';
    id: string;
    label: string;
  } | null>(null);
  const [singleDeleteBusy, setSingleDeleteBusy] = useState(false);

  // Debounce search input
  useEffect(() => {
    const t = window.setTimeout(() => {
      setDebouncedSearch(searchInput.trim());
    }, 220);
    return () => window.clearTimeout(t);
  }, [searchInput]);

  // Reset pagination & selections when switching sub-tab or filters
  useEffect(() => {
    setPage(1);
    setSelectedIds([]);
  }, [subTab, debouncedSearch, statusFilter, departmentFilter, sectorFilter, authorFilter, sortOption]);

  // Reset sector filter if it no longer belongs to selected department
  useEffect(() => {
    if (sectorFilter === 'all') return;
    if (departmentFilter === 'all') return;
    const sec = orgUnits.sectors.find(s => s.id === sectorFilter);
    if (!sec || getSectorParentId(sec) !== departmentFilter) {
      setSectorFilter('all');
    }
  }, [departmentFilter, sectorFilter, orgUnits.sectors]);

  const activeEntityTab: ContentEntityTab | null =
    subTab === 'projects' || subTab === 'publications' || subTab === 'products' ? subTab : null;

  const loadPagedContent = useCallback(async () => {
    if (!activeEntityTab) return;
    setListLoading(true);
    setListError(null);
    const [sortByRaw, sortDirRaw] = sortOption.split(':');
    const params: ContentListParams & { page: number } = {
      page,
      limit: PAGE_SIZE,
      q: debouncedSearch || undefined,
      status: statusFilter !== 'all' ? statusFilter : undefined,
      departmentId: departmentFilter !== 'all' ? departmentFilter : undefined,
      sectorId: sectorFilter !== 'all' ? sectorFilter : undefined,
      authorId: authorFilter !== 'all' ? authorFilter : undefined,
      sortBy: (sortByRaw as 'updated' | 'title' | 'status') || 'updated',
      sortDir: (sortDirRaw as 'asc' | 'desc') || 'desc'
    };

    try {
      let res: PaginatedResult<Project | Publication | Product>;
      if (activeEntityTab === 'projects') {
        res = await api.getProjectsAdmin(params);
      } else if (activeEntityTab === 'publications') {
        res = await api.getPublicationsAdmin(params);
      } else {
        res = await api.getProductsAdmin(params);
      }
      setPagedResult(res);
    } catch (err) {
      setListError(err instanceof Error ? err.message : 'Failed to load items.');
    } finally {
      setListLoading(false);
    }
  }, [
    activeEntityTab,
    page,
    debouncedSearch,
    statusFilter,
    departmentFilter,
    sectorFilter,
    authorFilter,
    sortOption
  ]);

  useEffect(() => {
    if (activeEntityTab && !editorState) {
      void loadPagedContent();
    }
  }, [activeEntityTab, editorState, loadPagedContent]);

  const availableSectorOptions = useMemo(() => {
    const list =
      departmentFilter !== 'all'
        ? orgUnits.sectors.filter(s => getSectorParentId(s) === departmentFilter)
        : orgUnits.sectors;
    return [
      { value: 'all', label: 'All sectors' },
      ...list.map(s => ({ value: s.id, label: s.name }))
    ];
  }, [departmentFilter, orgUnits.sectors]);

  const authorOptions = useMemo(() => {
    const source =
      subTab === 'projects'
        ? activeProjects
        : subTab === 'publications'
        ? activePubs
        : subTab === 'products'
        ? activeProds
        : [];
    const map = new Map<string, string>();
    source.forEach(item => {
      if (item.authorId && item.authorName) {
        map.set(item.authorId, item.authorName);
      }
    });
    return [
      { value: 'all', label: 'All authors' },
      ...Array.from(map.entries())
        .sort((a, b) => a[1].localeCompare(b[1]))
        .map(([id, name]) => ({ value: id, label: name }))
    ];
  }, [subTab, activeProjects, activePubs, activeProds]);

  const filterSelects = useMemo<PortalFilterSelectConfig[]>(() => {
    const list: PortalFilterSelectConfig[] = [
      {
        id: 'status',
        label: 'Status filter',
        value: statusFilter,
        onChange: setStatusFilter,
        options: STATUS_FILTER_OPTIONS
      },
      {
        id: 'department',
        label: 'Department filter',
        value: departmentFilter,
        onChange: setDepartmentFilter,
        options: [
          { value: 'all', label: 'All departments' },
          ...orgUnits.departments.map(d => ({ value: d.id, label: d.name }))
        ]
      }
    ];
    if (availableSectorOptions.length > 1) {
      list.push({
        id: 'sector',
        label: 'Sector filter',
        value: sectorFilter,
        onChange: setSectorFilter,
        options: availableSectorOptions
      });
    }
    if (canEditAll && authorOptions.length > 2) {
      list.push({
        id: 'author',
        label: 'Author filter',
        value: authorFilter,
        onChange: setAuthorFilter,
        options: authorOptions
      });
    }
    return list;
  }, [
    statusFilter,
    departmentFilter,
    orgUnits.departments,
    availableSectorOptions,
    sectorFilter,
    canEditAll,
    authorOptions,
    authorFilter
  ]);

  const hasActiveFilters = Boolean(
    searchInput.trim() ||
      statusFilter !== 'all' ||
      departmentFilter !== 'all' ||
      sectorFilter !== 'all' ||
      authorFilter !== 'all'
  );

  const resetFilters = () => {
    setSearchInput('');
    setDebouncedSearch('');
    setStatusFilter('all');
    setDepartmentFilter('all');
    setSectorFilter('all');
    setAuthorFilter('all');
    setPage(1);
  };

  const rows: ContentRowItem[] = useMemo(() => {
    if (subTab === 'projects') {
      return (pagedResult.items as Project[]).map(record => ({ kind: 'project', record }));
    }
    if (subTab === 'publications') {
      return (pagedResult.items as Publication[]).map(record => ({ kind: 'publication', record }));
    }
    if (subTab === 'products') {
      return (pagedResult.items as Product[]).map(record => ({ kind: 'product', record }));
    }
    return [];
  }, [subTab, pagedResult.items]);

  const canCreateInActiveTab =
    subTab === 'projects'
      ? canCreateProject
      : subTab === 'publications'
      ? canManagePubs || canCreateProject
      : subTab === 'products'
      ? canManageProds
      : false;

  const canSelectRows =
    subTab === 'projects'
      ? canEditAll || canPublish || canEditOwn
      : subTab === 'publications'
      ? canManagePubs || canEditAll || canPublish
      : subTab === 'products'
      ? canManageProds || canEditAll || canPublish
      : false;

  const runBulkAction = async (ids: string[], action: BulkContentAction) => {
    if (!activeEntityTab || ids.length === 0) return;
    const singular =
      activeEntityTab === 'projects'
        ? 'project'
        : activeEntityTab === 'publications'
        ? 'publication'
        : 'product';
    setBulkBusy(true);
    setActionError(null);
    try {
      await api.bulkContentAction(singular, ids, action);
      setSelectedIds([]);
      await onRefreshData?.();
      await loadPagedContent();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Bulk action failed.');
    } finally {
      setBulkBusy(false);
    }
  };

  const bulkActions = useMemo<PortalTableBulkAction[]>(() => {
    const actions: PortalTableBulkAction[] = [];
    if (canPublish) {
      actions.push({
        id: 'publish',
        label: 'Publish',
        icon: CheckCircle2,
        disabled: bulkBusy,
        onClick: ids => void runBulkAction(ids, 'publish')
      });
    }
    actions.push({
      id: 'submit_review',
      label: 'Submit for review',
      icon: Send,
      disabled: bulkBusy,
      onClick: ids => void runBulkAction(ids, 'submit_review')
    });
    actions.push({
      id: 'unpublish',
      label: 'Move to draft',
      icon: RotateCcw,
      disabled: bulkBusy,
      onClick: ids => void runBulkAction(ids, 'unpublish')
    });
    if (canPublish) {
      actions.push({
        id: 'archive',
        label: 'Archive',
        icon: Archive,
        disabled: bulkBusy,
        onClick: ids => void runBulkAction(ids, 'archive')
      });
    }
    actions.push({
      id: 'trash',
      label: 'Move to trash',
      icon: Trash2,
      destructive: true,
      disabled: bulkBusy,
      onClick: ids => setBulkTrashConfirmIds(ids)
    });
    return actions;
  }, [canPublish, bulkBusy]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleDuplicateItem = async (row: ContentRowItem) => {
    setActionError(null);
    try {
      if (row.kind === 'project') {
        const cloned = await api.duplicateProject(row.record.id);
        await onRefreshData?.();
        setEditorState({ kind: 'project', item: cloned });
      } else if (row.kind === 'publication') {
        const cloned = await api.duplicatePublication(row.record.id);
        await onRefreshData?.();
        setEditorState({ kind: 'publication', item: cloned });
      } else {
        const cloned = await api.duplicateProduct(row.record.id);
        await onRefreshData?.();
        setEditorState({ kind: 'product', item: cloned });
      }
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to duplicate item.');
    }
  };

  const handleConfirmSingleDelete = async () => {
    if (!singleDeleteTarget) return;
    const target = singleDeleteTarget;
    setSingleDeleteBusy(true);
    setActionError(null);
    try {
      if (target.kind === 'project') await onDeleteProject(target.id);
      else if (target.kind === 'publication') await onDeletePublication(target.id);
      else await onDeleteProduct(target.id);
      setSingleDeleteTarget(null);
      setSelectedIds(prev => prev.filter(id => id !== target.id));
      await onRefreshData?.();
      await loadPagedContent();
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to move item to trash.');
    } finally {
      setSingleDeleteBusy(false);
    }
  };

  const getPublicUrlForRow = (row: ContentRowItem): string => {
    const preview = row.record.publicationStatus !== 'Published' ? '?preview=1' : '';
    if (row.kind === 'project') return `/projects/${row.record.slug}${preview}`;
    if (row.kind === 'publication') return `/research${preview}`;
    return `/products/${row.record.slug}${preview}`;
  };

  const tableColumns = useMemo<PortalTableColumn<ContentRowItem>[]>(() => {
    return [
      {
        key: 'title',
        header: 'Title',
        render: row => {
          const title = row.kind === 'product' ? row.record.name : row.record.title;
          const thumb =
            row.kind === 'publication'
              ? row.record.thumbnailUrl
              : row.record.coverImage;
          const slugText =
            row.kind === 'publication'
              ? row.record.publicationType || 'Publication'
              : `/${row.kind}s/${row.record.slug}`;
          return (
            <div className="flex items-center gap-3 min-w-0 max-w-md">
              <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 overflow-hidden shrink-0 flex items-center justify-center">
                {thumb ? (
                  <img src={thumb} alt={title} className="w-full h-full object-cover" />
                ) : row.kind === 'publication' ? (
                  <BookOpen className="w-4 h-4 text-[#25CDB6]/70" />
                ) : row.kind === 'product' ? (
                  <Package className="w-4 h-4 text-[#25CDB6]/70" />
                ) : (
                  <FolderKanban className="w-4 h-4 text-[#25CDB6]/70" />
                )}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-[#EDE9E0] truncate">{title}</span>
                  {row.record.pendingRevision && (
                    <span className="px-1.5 py-0.5 rounded bg-[#D0A873]/15 border border-[#D0A873]/30 text-[10px] font-semibold text-[#D0A873] shrink-0">
                      Revision pending
                    </span>
                  )}
                </div>
                <span className="text-[11px] font-mono text-[#EDE9E0]/45 block truncate">
                  {slugText}
                </span>
              </div>
            </div>
          );
        }
      },
      {
        key: 'status',
        header: 'Status',
        render: row => <PortalStatusBadge status={row.record.publicationStatus} />
      },
      {
        key: 'units',
        header: 'Departments',
        hideOnMobile: true,
        render: row => {
          const deptNames = (row.record.departmentIds || [])
            .map(id => deptNameMap.get(id))
            .filter((n): n is string => Boolean(n));
          const sectorNames = (row.record.sectorIds || [])
            .map(id => deptNameMap.get(id))
            .filter((n): n is string => Boolean(n));
          const combined = [...deptNames, ...sectorNames];
          if (combined.length === 0) {
            return <span className="text-[#EDE9E0]/35">Unassigned</span>;
          }
          return (
            <span className="text-[#EDE9E0]/75 line-clamp-1 max-w-[220px]">
              {combined.slice(0, 2).join(', ')}
              {combined.length > 2 ? ` +${combined.length - 2}` : ''}
            </span>
          );
        }
      },
      {
        key: 'updated',
        header: 'Updated',
        hideOnMobile: true,
        render: row => (
          <div className="text-[#EDE9E0]/70">
            <span className="block truncate max-w-[140px]">
              {row.kind === 'publication'
                ? row.record.authors || row.record.authorName
                : row.record.authorName}
            </span>
            <span className="text-[11px] text-[#EDE9E0]/45">
              {formatShortDate(row.record.updatedAt)}
            </span>
          </div>
        )
      }
    ];
  }, [deptNameMap]);

  const buildRowActions = (row: ContentRowItem): PortalTableRowAction[] => {
    const label = row.kind === 'product' ? row.record.name : row.record.title;
    const entityAllowed =
      row.kind === 'project'
        ? canEditEntry(row.record.authorId)
        : row.kind === 'publication'
        ? canManagePubs && canEditEntry(row.record.authorId)
        : canManageProds && canEditEntry(row.record.authorId);

    const canDuplicate =
      row.kind === 'project'
        ? canCreateProject || canEditAll || canPublish
        : row.kind === 'publication'
        ? canManagePubs || canCreateProject
        : canManageProds;

    return [
      {
        id: 'edit',
        label:
          row.record.publicationStatus === 'Pending Review' && canPublish
            ? 'Review & edit'
            : 'Edit',
        icon: Edit,
        hidden: !entityAllowed,
        onClick: () => setEditorState({ kind: row.kind, item: row.record })
      },
      {
        id: 'view',
        label: 'View on site',
        icon: ExternalLink,
        onClick: () => onNavigateSite(getPublicUrlForRow(row))
      },
      {
        id: 'duplicate',
        label: 'Duplicate',
        icon: Copy,
        hidden: !canDuplicate,
        onClick: () => void handleDuplicateItem(row)
      },
      {
        id: 'trash',
        label: 'Move to trash',
        icon: Trash2,
        destructive: true,
        hidden: !entityAllowed,
        onClick: () =>
          setSingleDeleteTarget({
            kind: row.kind,
            id: row.record.id,
            label
          })
      }
    ];
  };

  // Single permission-filtered "+ New" dropdown items
  const newDropdownItems = useMemo(() => {
    const items: Array<{
      id: string;
      label: string;
      icon: React.ComponentType<{ className?: string }>;
      onClick: () => void;
    }> = [];
    if (canManageDepts) {
      items.push({
        id: 'department',
        label: 'New department',
        icon: Building,
        onClick: () => setEditorState({ kind: 'department', item: null })
      });
      if (orgUnits.departments.length > 0) {
        items.push({
          id: 'sector',
          label: 'New sector',
          icon: Layers,
          onClick: () =>
            setEditorState({
              kind: 'sector',
              item: null,
              initialParentDepartmentId:
                selectedOrgUnit && !isSector(selectedOrgUnit)
                  ? selectedOrgUnit.id
                  : orgUnits.departments[0]?.id
            })
        });
      }
    }
    if (canCreateProject) {
      items.push({
        id: 'project',
        label: 'New project',
        icon: FolderKanban,
        onClick: () => setEditorState({ kind: 'project', item: null })
      });
    }
    if (canManagePubs || canCreateProject) {
      items.push({
        id: 'publication',
        label: 'New publication',
        icon: BookOpen,
        onClick: () => setEditorState({ kind: 'publication', item: null })
      });
    }
    if (canManageProds) {
      items.push({
        id: 'product',
        label: 'New product',
        icon: Package,
        onClick: () => setEditorState({ kind: 'product', item: null })
      });
    }
    return items;
  }, [
    canManageDepts,
    orgUnits.departments,
    selectedOrgUnit,
    canCreateProject,
    canManagePubs,
    canManageProds
  ]);

  // Tab bar configuration (accurate counts; depts & sectors displayed separately)
  const portalTabItems = useMemo(() => {
    return visibleSubTabs.map(tab => {
      const id = tab.id as ContentSubTab;
      const Icon = SUBTAB_ICONS[id] || FolderKanban;
      let badge: string | number = 0;
      if (id === 'departments') {
        badge = `${orgUnits.departments.length} depts · ${orgUnits.sectors.length} sectors`;
      } else if (id === 'projects') {
        badge = activeProjects.length;
      } else if (id === 'publications') {
        badge = activePubs.length;
      } else if (id === 'products') {
        badge = activeProds.length;
      }
      return {
        id,
        label: tab.label,
        icon: Icon,
        badge
      };
    });
  }, [
    visibleSubTabs,
    orgUnits.departments.length,
    orgUnits.sectors.length,
    activeProjects.length,
    activePubs.length,
    activeProds.length
  ]);

  // Linked item counts for selected department/sector summary card
  const selectedDeptStats = useMemo(() => {
    if (!selectedOrgUnit) return { projects: 0, publications: 0, products: 0, sectors: 0 };
    const unitId = selectedOrgUnit.id;
    const matchItem = (item: { departmentIds?: string[]; sectorIds?: string[] }) =>
      (item.departmentIds || []).includes(unitId) || (item.sectorIds || []).includes(unitId);
    return {
      projects: activeProjects.filter(matchItem).length,
      publications: activePubs.filter(matchItem).length,
      products: activeProds.filter(matchItem).length,
      sectors: isSector(selectedOrgUnit) ? 0 : (sectorsByParentId.get(unitId) || []).length
    };
  }, [selectedOrgUnit, activeProjects, activePubs, activeProds, sectorsByParentId]);

  // Unified Full-Screen Editor Route
  if (editorState) {
    return (
      <UnifiedContentEditor
        kind={editorState.kind}
        item={editorState.item}
        initialParentDepartmentId={editorState.initialParentDepartmentId}
        departments={activeDepts}
        projects={activeProjects}
        currentUser={currentUser}
        roles={roles}
        onBack={() => setEditorState(null)}
        onSaved={async (savedKind, saved) => {
          setEditorState({ kind: savedKind, item: saved });
          if (savedKind === 'department' || savedKind === 'sector') {
            const dept = saved as Department;
            setSelectedOrgUnitId(dept.id);
            setSubTab('departments');
            onSubTabChange?.('departments');
          } else {
            const targetSubTab: ContentSubTab =
              savedKind === 'project'
                ? 'projects'
                : savedKind === 'publication'
                ? 'publications'
                : 'products';
            setSubTab(targetSubTab);
            onSubTabChange?.(targetSubTab);
          }
          await onRefreshData?.();
          await loadPagedContent();
        }}
        onDuplicated={(clonedKind, cloned) => {
          setEditorState({ kind: clonedKind, item: cloned });
          void onRefreshData?.();
        }}
        onDeleted={async () => {
          setEditorState(null);
          await onRefreshData?.();
          await loadPagedContent();
        }}
        onNavigateSite={onNavigateSite}
      />
    );
  }

  return (
    <div className="space-y-6">
      <PortalPageHeader
        title="Content"
        subtitle="Manage departments, sectors, projects, publications, and product releases in one control room."
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setReviewDrawerOpen(true)}
              className={`h-9 px-3.5 rounded-xl border text-xs font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer ${
                reviewQueueCount > 0
                  ? 'bg-[#D0A873]/12 hover:bg-[#D0A873]/20 border-[#D0A873]/35 text-[#D0A873]'
                  : 'bg-[#031D1C] hover:bg-white/10 border-white/12 text-[#EDE9E0]/85'
              }`}
            >
              <span>Review queue ({reviewQueueCount})</span>
            </button>

            {newDropdownItems.length > 0 && (
              <div className="relative" ref={newMenuRef}>
                <button
                  type="button"
                  onClick={() => setNewMenuOpen(v => !v)}
                  aria-expanded={newMenuOpen}
                  aria-haspopup="menu"
                  className="h-9 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] text-xs font-bold inline-flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                >
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                  <span>New</span>
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>

                {newMenuOpen && (
                  <div
                    role="menu"
                    className="absolute right-0 top-11 z-30 min-w-[200px] rounded-xl bg-[#031D1C] border border-white/15 shadow-2xl py-1.5"
                  >
                    {newDropdownItems.map(entry => {
                      const Icon = entry.icon;
                      return (
                        <button
                          key={entry.id}
                          type="button"
                          role="menuitem"
                          onClick={() => {
                            setNewMenuOpen(false);
                            entry.onClick();
                          }}
                          className="w-full px-3.5 py-2 text-xs font-medium text-[#EDE9E0] hover:bg-white/10 flex items-center gap-2.5 text-left cursor-pointer"
                        >
                          <Icon className="w-3.5 h-3.5 text-[#25CDB6] shrink-0" />
                          <span>{entry.label}</span>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        }
      />

      <PortalTabs
        items={portalTabItems}
        activeId={subTab}
        onChange={id => selectSubTab(id as ContentSubTab)}
        ariaLabel="Content sections"
      />

      {actionError && (
        <div className="p-3.5 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span className="break-words">{actionError}</span>
          </div>
          <button
            type="button"
            onClick={() => setActionError(null)}
            className="text-xs text-red-300 hover:text-white shrink-0 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* TAB 1: DEPARTMENTS & SECTORS (Natural-scroll Master-Detail Tree) */}
      {subTab === 'departments' && canManageDepts && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
          {/* LEFT: Unified Org Outline Tree */}
          <aside className="lg:col-span-4 rounded-2xl bg-[#031D1C] border border-white/10 p-4 flex flex-col gap-3.5 lg:min-h-full">
            <PortalSearchInput
              value={deptSearch}
              onChange={setDeptSearch}
              placeholder="Filter departments & sectors..."
            />

            <div className="flex items-center justify-between px-1 pt-1 text-[11px] font-bold uppercase tracking-wider text-[#25CDB6] shrink-0">
              <span>Masters Of All</span>
              <span className="text-[10px] font-mono text-[#EDE9E0]/50">
                {reorderingOrg
                  ? 'Saving order...'
                  : `${orgUnits.departments.length} depts · ${orgUnits.sectors.length} sectors`}
              </span>
            </div>

            {visibleDepartments.length === 0 && orphanSectors.length === 0 ? (
              <div className="flex-1 flex flex-col justify-center">
                <PortalEmptyState
                  compact
                  icon={Building}
                  title="No matching units"
                  description="Try clearing the search filter or create a new department."
                  action={
                    deptSearch ? (
                      <button
                        type="button"
                        onClick={() => setDeptSearch('')}
                        className="h-8 px-3 rounded-lg bg-white/10 hover:bg-white/15 text-xs font-semibold text-[#EDE9E0] cursor-pointer"
                      >
                        Clear filter
                      </button>
                    ) : undefined
                  }
                />
              </div>
            ) : (
              <div className="flex-1 min-h-0 max-h-[680px] overflow-y-auto no-scrollbar space-y-1.5">
                {visibleDepartments.map((dept, index) => {
                  const isSelected = selectedOrgUnitId === dept.id;
                  const deptSectors = filterChildSectors(dept);
                  return (
                    <div key={dept.id} className="space-y-1">
                      <div
                        draggable={!filteredTreeQuery && Boolean(onReorderDepartments)}
                        onDragStart={() => setDraggingUnitId(dept.id)}
                        onDragOver={e => {
                          if (draggingUnitId && draggingUnitId !== dept.id) e.preventDefault();
                        }}
                        onDrop={() => {
                          if (draggingUnitId) handleReorderUnit(draggingUnitId, dept.id);
                          setDraggingUnitId(null);
                        }}
                        onDragEnd={() => setDraggingUnitId(null)}
                        className={`group flex items-start gap-2 px-2.5 py-2 rounded-xl border transition-colors ${
                          isSelected
                            ? 'bg-[#17A491]/15 border-[#25CDB6]/55 text-[#EDE9E0]'
                            : 'bg-transparent border-transparent hover:bg-white/[0.04] text-[#EDE9E0]/85'
                        }`}
                      >
                        {!filteredTreeQuery && onReorderDepartments && (
                          <span
                            className="text-[#EDE9E0]/35 hover:text-[#EDE9E0]/75 cursor-grab shrink-0 mt-1"
                            title="Drag to reorder"
                          >
                            <GripVertical className="w-3.5 h-3.5" />
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={() => setSelectedOrgUnitId(dept.id)}
                          className="flex-1 flex items-start gap-2.5 min-w-0 text-left cursor-pointer"
                        >
                          <div className="shrink-0 mt-0.5">
                            <DepartmentLogo department={dept} size={24} />
                          </div>
                          <span className="text-xs font-semibold leading-snug break-words flex-1">
                            {dept.name}
                          </span>
                          <span
                            className={`w-2 h-2 rounded-full shrink-0 mt-1.5 ${
                              dept.published ? 'bg-[#25CDB6]' : 'bg-white/25'
                            }`}
                            title={dept.published ? 'Published' : 'Hidden'}
                          />
                        </button>
                        {!filteredTreeQuery && onReorderDepartments && visibleDepartments.length > 1 && (
                          <div className="flex lg:hidden lg:group-hover:flex items-center gap-0.5 shrink-0 mt-0.5">
                            <button
                              type="button"
                              disabled={index === 0 || reorderingOrg}
                              onClick={() => handleMoveUnitStep(dept, -1)}
                              aria-label={`Move ${dept.name} up`}
                              className="p-1 rounded hover:bg-white/10 text-[#EDE9E0]/55 hover:text-white disabled:opacity-25 cursor-pointer"
                            >
                              <ArrowUp className="w-3 h-3" />
                            </button>
                            <button
                              type="button"
                              disabled={index === visibleDepartments.length - 1 || reorderingOrg}
                              onClick={() => handleMoveUnitStep(dept, 1)}
                              aria-label={`Move ${dept.name} down`}
                              className="p-1 rounded hover:bg-white/10 text-[#EDE9E0]/55 hover:text-white disabled:opacity-25 cursor-pointer"
                            >
                              <ArrowDown className="w-3 h-3" />
                            </button>
                          </div>
                        )}
                      </div>

                      {deptSectors.length > 0 && (
                        <div className="pl-3.5 ml-3 border-l border-[#D0A873]/30 space-y-1 pt-0.5 pb-1">
                          {deptSectors.map((sector, sIdx) => {
                            const isSectorSelected = selectedOrgUnitId === sector.id;
                            return (
                              <div key={sector.id} className="relative flex items-start">
                                <span
                                  aria-hidden="true"
                                  className="w-2.5 h-px bg-[#D0A873]/30 shrink-0 mr-1 mt-3.5"
                                />
                                <div
                                  draggable={!filteredTreeQuery && Boolean(onReorderDepartments)}
                                  onDragStart={() => setDraggingUnitId(sector.id)}
                                  onDragOver={e => {
                                    if (draggingUnitId && draggingUnitId !== sector.id) e.preventDefault();
                                  }}
                                  onDrop={() => {
                                    if (draggingUnitId) handleReorderUnit(draggingUnitId, sector.id);
                                    setDraggingUnitId(null);
                                  }}
                                  onDragEnd={() => setDraggingUnitId(null)}
                                  className={`flex-1 min-w-0 group flex items-start gap-1.5 px-2.5 py-1.5 rounded-xl border transition-colors ${
                                    isSectorSelected
                                      ? 'bg-[#17A491]/15 border-[#25CDB6]/55 text-[#EDE9E0]'
                                      : 'bg-transparent border-transparent hover:bg-white/[0.04] text-[#EDE9E0]/85'
                                  }`}
                                >
                                  {!filteredTreeQuery && onReorderDepartments && deptSectors.length > 1 && (
                                    <span
                                      className="text-[#EDE9E0]/35 hover:text-[#EDE9E0]/75 cursor-grab shrink-0 mt-1"
                                      title="Drag to reorder sector"
                                    >
                                      <GripVertical className="w-3 h-3" />
                                    </span>
                                  )}
                                  <button
                                    type="button"
                                    onClick={() => setSelectedOrgUnitId(sector.id)}
                                    className="flex-1 flex items-start gap-2 min-w-0 text-left cursor-pointer"
                                  >
                                    <div className="shrink-0 mt-0.5">
                                      <DepartmentLogo
                                        department={sector}
                                        size={20}
                                        rounded="xl"
                                        fallbackMode="icon"
                                        iconSize={12}
                                        showBorder={false}
                                      />
                                    </div>
                                    <span className="text-xs font-medium leading-snug break-words flex-1">
                                      {sector.name}
                                    </span>
                                    <span
                                      className={`w-2 h-2 rounded-full shrink-0 mt-1.5 ${
                                        sector.published ? 'bg-[#25CDB6]' : 'bg-white/25'
                                      }`}
                                      title={sector.published ? 'Published' : 'Hidden'}
                                    />
                                  </button>
                                  {!filteredTreeQuery && onReorderDepartments && deptSectors.length > 1 && (
                                    <div className="flex lg:hidden lg:group-hover:flex items-center gap-0.5 shrink-0 mt-0.5">
                                      <button
                                        type="button"
                                        disabled={sIdx === 0 || reorderingOrg}
                                        onClick={() => handleMoveUnitStep(sector, -1)}
                                        aria-label={`Move ${sector.name} up`}
                                        className="p-1 rounded hover:bg-white/10 text-[#EDE9E0]/55 hover:text-white disabled:opacity-25 cursor-pointer"
                                      >
                                        <ArrowUp className="w-3 h-3" />
                                      </button>
                                      <button
                                        type="button"
                                        disabled={sIdx === deptSectors.length - 1 || reorderingOrg}
                                        onClick={() => handleMoveUnitStep(sector, 1)}
                                        aria-label={`Move ${sector.name} down`}
                                        className="p-1 rounded hover:bg-white/10 text-[#EDE9E0]/55 hover:text-white disabled:opacity-25 cursor-pointer"
                                      >
                                        <ArrowDown className="w-3 h-3" />
                                      </button>
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}

                {orphanSectors.length > 0 && !filteredTreeQuery && (
                  <div className="pt-2 border-t border-white/10 space-y-1">
                    <div className="px-1 text-[10px] font-semibold uppercase tracking-wider text-amber-300/80">
                      Unparented sectors
                    </div>
                    {orphanSectors.map(sec => (
                      <button
                        key={sec.id}
                        type="button"
                        onClick={() => setSelectedOrgUnitId(sec.id)}
                        className={`w-full flex items-center gap-2 px-2.5 py-2 rounded-xl border text-left text-xs cursor-pointer ${
                          selectedOrgUnitId === sec.id
                            ? 'bg-[#17A491]/15 border-[#25CDB6]/55 text-[#EDE9E0]'
                            : 'border-transparent hover:bg-white/[0.04] text-[#EDE9E0]/80'
                        }`}
                      >
                        <span className="flex-1 break-words">{sec.name}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            <div className="mt-auto pt-2.5 border-t border-white/10 shrink-0">
              <PortalStatusLegend statuses={['Published', 'Hidden']} />
            </div>
          </aside>

          {/* RIGHT: Selected Unit Detail Summary Card */}
          <div className="lg:col-span-8 min-w-0 flex flex-col">
            {selectedOrgUnit ? (
              <div className="rounded-2xl bg-[#031D1C] border border-white/10 p-5 sm:p-6 space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-5 border-b border-white/10">
                  <div className="flex items-start gap-4 min-w-0">
                    <DepartmentLogo department={selectedOrgUnit} size={56} />
                    <div className="min-w-0 space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <PortalStatusBadge
                          status={selectedOrgUnit.published ? 'Published' : 'Hidden'}
                        />
                        <span className="px-2 py-0.5 rounded-full bg-white/8 border border-white/10 text-[10px] font-mono uppercase tracking-wider text-[#25CDB6]">
                          {isSector(selectedOrgUnit)
                            ? `Sector · ${deptNameMap.get(getSectorParentId(selectedOrgUnit)) || 'Department'}`
                            : isRddDepartment(selectedOrgUnit)
                            ? 'Core Department'
                            : 'Department'}
                        </span>
                      </div>
                      <h2 className="text-lg sm:text-xl font-bold text-[#EDE9E0] break-words">
                        {selectedOrgUnit.name}
                      </h2>
                      <p className="text-xs font-mono text-[#EDE9E0]/50 break-all">
                        {getUnitHref(selectedOrgUnit, activeDepts)}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() =>
                        setEditorState({
                          kind: isSector(selectedOrgUnit) ? 'sector' : 'department',
                          item: selectedOrgUnit
                        })
                      }
                      className="h-9 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>

                    {!isSector(selectedOrgUnit) && (
                      <button
                        type="button"
                        onClick={() =>
                          setEditorState({
                            kind: 'sector',
                            item: null,
                            initialParentDepartmentId: selectedOrgUnit.id
                          })
                        }
                        className="h-9 px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-[#25CDB6]/35 text-[#25CDB6] text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Add sector</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => onNavigateSite(getUnitHref(selectedOrgUnit, activeDepts))}
                      className="h-9 px-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/12 text-xs font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Open on site</span>
                    </button>
                  </div>
                </div>

                {/* Summary Copy */}
                <div className="space-y-2">
                  {selectedOrgUnit.tagline && (
                    <p className="text-sm font-medium text-[#25CDB6] leading-relaxed">
                      {selectedOrgUnit.tagline}
                    </p>
                  )}
                  <p className="text-xs text-[#EDE9E0]/75 leading-relaxed">
                    {selectedOrgUnit.introduction ||
                      selectedOrgUnit.purpose ||
                      'No overview copy written yet. Open the unified editor to write rich narrative sections and modular page blocks.'}
                  </p>
                </div>

                {/* Metrics Row */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {!isSector(selectedOrgUnit) && (
                    <div className="p-3.5 rounded-xl bg-[#06302F]/80 border border-white/10">
                      <div className="text-[11px] text-[#EDE9E0]/55">Child sectors</div>
                      <div className="text-lg font-bold text-[#EDE9E0] tabular-nums mt-0.5">
                        {selectedDeptStats.sectors}
                      </div>
                    </div>
                  )}
                  <div className="p-3.5 rounded-xl bg-[#06302F]/80 border border-white/10">
                    <div className="text-[11px] text-[#EDE9E0]/55">Linked projects</div>
                    <div className="text-lg font-bold text-[#EDE9E0] tabular-nums mt-0.5">
                      {selectedDeptStats.projects}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-[#06302F]/80 border border-white/10">
                    <div className="text-[11px] text-[#EDE9E0]/55">Publications</div>
                    <div className="text-lg font-bold text-[#EDE9E0] tabular-nums mt-0.5">
                      {selectedDeptStats.publications}
                    </div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-[#06302F]/80 border border-white/10">
                    <div className="text-[11px] text-[#EDE9E0]/55">Products</div>
                    <div className="text-lg font-bold text-[#EDE9E0] tabular-nums mt-0.5">
                      {selectedDeptStats.products}
                    </div>
                  </div>
                </div>

                {/* Inline Visibility Switches */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <label className="flex items-center justify-between gap-3 p-3.5 rounded-xl bg-[#06302F]/70 border border-white/10 cursor-pointer">
                    <div>
                      <span className="text-xs font-semibold text-[#EDE9E0] block">
                        Published on website
                      </span>
                      <span className="text-[11px] text-[#EDE9E0]/55">
                        Make this unit live for public visitors
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={Boolean(selectedOrgUnit.published)}
                      disabled={togglingDeptId === `${selectedOrgUnit.id}:published`}
                      onChange={e =>
                        void handleToggleDeptFlag(selectedOrgUnit, 'published', e.target.checked)
                      }
                      className="w-4 h-4 rounded accent-[#25CDB6] cursor-pointer"
                    />
                  </label>

                  <label className="flex items-center justify-between gap-3 p-3.5 rounded-xl bg-[#06302F]/70 border border-white/10 cursor-pointer">
                    <div>
                      <span className="text-xs font-semibold text-[#EDE9E0] block">
                        Show in hierarchy tree
                      </span>
                      <span className="text-[11px] text-[#EDE9E0]/55">
                        Include in public organization outline
                      </span>
                    </div>
                    <input
                      type="checkbox"
                      checked={selectedOrgUnit.showInTree !== false}
                      disabled={togglingDeptId === `${selectedOrgUnit.id}:showInTree`}
                      onChange={e =>
                        void handleToggleDeptFlag(selectedOrgUnit, 'showInTree', e.target.checked)
                      }
                      className="w-4 h-4 rounded accent-[#25CDB6] cursor-pointer"
                    />
                  </label>
                </div>

                {/* Child sectors list or Destructive Footer */}
                {!isSector(selectedOrgUnit) &&
                  (sectorsByParentId.get(selectedOrgUnit.id) || []).length > 0 && (
                    <div className="space-y-2 pt-2 border-t border-white/10">
                      <div className="text-xs font-semibold text-[#EDE9E0]/80">
                        Sectors under {selectedOrgUnit.shortName || selectedOrgUnit.name}
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {(sectorsByParentId.get(selectedOrgUnit.id) || []).map(sec => (
                          <button
                            key={sec.id}
                            type="button"
                            onClick={() => setSelectedOrgUnitId(sec.id)}
                            className="p-3 rounded-xl bg-[#06302F]/60 hover:bg-[#06302F] border border-white/10 flex items-center justify-between gap-2 text-left transition-colors cursor-pointer"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <DepartmentLogo department={sec} size={22} />
                              <span className="text-xs font-medium text-[#EDE9E0] truncate">
                                {sec.name}
                              </span>
                            </div>
                            <PortalStatusBadge status={sec.published ? 'Published' : 'Hidden'} />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                {!(!isSector(selectedOrgUnit) && isRddDepartment(selectedOrgUnit)) && (
                  <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-3">
                    <span className="text-[11px] text-[#EDE9E0]/50">
                      Updated {formatShortDate(selectedOrgUnit.updatedAt)}
                    </span>
                    <button
                      type="button"
                      onClick={() => openDeleteDepartmentModal(selectedOrgUnit)}
                      className="h-9 px-3.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-400/30 text-xs font-semibold text-red-200 inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Move to trash</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <PortalEmptyState
                icon={Building}
                title="No department selected"
                description="Select a department or sector from the outline tree, or create your first department."
                action={
                  <button
                    type="button"
                    onClick={() => setEditorState({ kind: 'department', item: null })}
                    className="h-9 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>New department</span>
                  </button>
                }
              />
            )}
          </div>
        </div>
      )}

      {/* TABS 2–4: PROJECTS / PUBLICATIONS / PRODUCTS (C3 Server-Paginated Unified List) */}
      {activeEntityTab && (
        <div className="space-y-4">
          <PortalFilterBar
            search={searchInput}
            onSearchChange={setSearchInput}
            searchPlaceholder={`Search ${activeEntityTab}...`}
            filters={filterSelects}
            sortValue={sortOption}
            onSortChange={setSortOption}
            sortOptions={SORT_OPTIONS}
            viewMode={viewMode}
            onViewModeChange={setViewMode}
            hasActiveFilters={hasActiveFilters}
            onResetFilters={resetFilters}
          />

          <div className="flex flex-wrap items-center justify-between gap-3 px-1">
            <PortalStatusLegend
              statuses={['Published', 'In review', 'Draft', 'Archived']}
            />
            <span className="text-[11px] text-[#EDE9E0]/55 tabular-nums">
              {pagedResult.total} {pagedResult.total === 1 ? 'item' : 'items'}
            </span>
          </div>

          {viewMode === 'table' ? (
            <PortalTable
              columns={tableColumns}
              items={rows}
              getRowKey={row => row.record.id}
              onRowClick={row => {
                const editable =
                  row.kind === 'project'
                    ? canEditEntry(row.record.authorId)
                    : row.kind === 'publication'
                    ? canManagePubs && canEditEntry(row.record.authorId)
                    : canManageProds && canEditEntry(row.record.authorId);
                if (editable) {
                  setEditorState({ kind: row.kind, item: row.record });
                }
              }}
              rowActions={buildRowActions}
              selectable={canSelectRows}
              selectedIds={selectedIds}
              onSelectionChange={setSelectedIds}
              bulkActions={bulkActions}
              loading={listLoading}
              error={listError}
              onRetry={() => void loadPagedContent()}
              page={pagedResult.page}
              totalPages={pagedResult.totalPages}
              totalItems={pagedResult.total}
              pageSize={pagedResult.limit || PAGE_SIZE}
              onPageChange={setPage}
              emptyState={
                <PortalEmptyState
                  icon={SUBTAB_ICONS[activeEntityTab]}
                  title={
                    hasActiveFilters
                      ? `No matching ${activeEntityTab}`
                      : `No ${activeEntityTab} yet`
                  }
                  description={
                    hasActiveFilters
                      ? 'Try clearing or adjusting your search and filter criteria.'
                      : `Create your first ${activeEntityTab.slice(0, -1)} to publish under Masters Of All.`
                  }
                  action={
                    hasActiveFilters ? (
                      <button
                        type="button"
                        onClick={resetFilters}
                        className="h-9 px-4 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-semibold text-[#EDE9E0] cursor-pointer"
                      >
                        Reset filters
                      </button>
                    ) : canCreateInActiveTab ? (
                      <button
                        type="button"
                        onClick={() =>
                          setEditorState({
                            kind:
                              activeEntityTab === 'projects'
                                ? 'project'
                                : activeEntityTab === 'publications'
                                ? 'publication'
                                : 'product',
                            item: null
                          })
                        }
                        className="h-9 px-4 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#06302F] text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>New {activeEntityTab.slice(0, -1)}</span>
                      </button>
                    ) : undefined
                  }
                />
              }
            />
          ) : (
            <div className="space-y-4">
              {listError ? (
                <PortalTable
                  columns={tableColumns}
                  items={[]}
                  getRowKey={row => row.record.id}
                  error={listError}
                  onRetry={() => void loadPagedContent()}
                />
              ) : listLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Array.from({ length: 6 }).map((_, idx) => (
                    <div
                      key={idx}
                      className="h-64 rounded-2xl bg-[#031D1C] border border-white/10 animate-pulse p-5 space-y-3"
                    >
                      <div className="h-32 rounded-xl bg-white/5" />
                      <div className="h-4 w-2/3 rounded bg-white/10" />
                      <div className="h-3 w-full rounded bg-white/5" />
                    </div>
                  ))}
                </div>
              ) : rows.length === 0 ? (
                <PortalEmptyState
                  icon={SUBTAB_ICONS[activeEntityTab]}
                  title={
                    hasActiveFilters
                      ? `No matching ${activeEntityTab}`
                      : `No ${activeEntityTab} yet`
                  }
                  description={
                    hasActiveFilters
                      ? 'Try clearing or adjusting your search and filter criteria.'
                      : `Create your first ${activeEntityTab.slice(0, -1)} to publish under Masters Of All.`
                  }
                  action={
                    hasActiveFilters ? (
                      <button
                        type="button"
                        onClick={resetFilters}
                        className="h-9 px-4 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs font-semibold text-[#EDE9E0] cursor-pointer"
                      >
                        Reset filters
                      </button>
                    ) : undefined
                  }
                />
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {rows.map(row => {
                      const title = row.kind === 'product' ? row.record.name : row.record.title;
                      const summary =
                        row.kind === 'publication'
                          ? row.record.abstract
                          : row.record.shortDescription || (row.kind === 'product' ? row.record.tagline : '');
                      const cover =
                        row.kind === 'publication'
                          ? row.record.thumbnailUrl
                          : row.record.coverImage;
                      const editable =
                        row.kind === 'project'
                          ? canEditEntry(row.record.authorId)
                          : row.kind === 'publication'
                          ? canManagePubs && canEditEntry(row.record.authorId)
                          : canManageProds && canEditEntry(row.record.authorId);

                      const deptNames = (row.record.departmentIds || [])
                        .map(id => deptNameMap.get(id))
                        .filter((n): n is string => Boolean(n));

                      return (
                        <div
                          key={row.record.id}
                          className="rounded-2xl bg-[#031D1C] border border-white/10 hover:border-[#25CDB6]/40 transition-colors p-4 flex flex-col justify-between gap-4"
                        >
                          <div className="space-y-3">
                            <div className="h-36 rounded-xl bg-[#06302F] border border-white/10 overflow-hidden relative flex items-center justify-center">
                              {cover ? (
                                <img src={cover} alt={title} className="w-full h-full object-cover" />
                              ) : row.kind === 'publication' ? (
                                <BookOpen className="w-8 h-8 text-[#25CDB6]/45" />
                              ) : row.kind === 'product' ? (
                                <Package className="w-8 h-8 text-[#25CDB6]/45" />
                              ) : (
                                <FolderKanban className="w-8 h-8 text-[#25CDB6]/45" />
                              )}
                              <div className="absolute top-2.5 right-2.5">
                                <PortalStatusBadge status={row.record.publicationStatus} />
                              </div>
                            </div>

                            <div className="space-y-1">
                              <h3 className="text-sm font-bold text-[#EDE9E0] line-clamp-1">{title}</h3>
                              <p className="text-xs text-[#EDE9E0]/60 line-clamp-2">
                                {summary || 'No summary provided.'}
                              </p>
                            </div>

                            <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-[#EDE9E0]/55">
                              {deptNames.slice(0, 2).map(name => (
                                <span
                                  key={name}
                                  className="px-2 py-0.5 rounded-md bg-white/5 border border-white/10 truncate max-w-[140px]"
                                >
                                  {name}
                                </span>
                              ))}
                              <span className="ml-auto tabular-nums">
                                {formatShortDate(row.record.updatedAt)}
                              </span>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 pt-3 border-t border-white/10">
                            {editable && (
                              <button
                                type="button"
                                onClick={() => setEditorState({ kind: row.kind, item: row.record })}
                                className="flex-1 h-8 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-[#EDE9E0] inline-flex items-center justify-center gap-1.5 cursor-pointer"
                              >
                                <Edit className="w-3.5 h-3.5 text-[#25CDB6]" />
                                <span>
                                  {row.record.publicationStatus === 'Pending Review' && canPublish
                                    ? 'Review & edit'
                                    : 'Edit'}
                                </span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => onNavigateSite(getPublicUrlForRow(row))}
                              title="View on public site"
                              className="h-8 w-8 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0]/65 hover:text-white inline-flex items-center justify-center cursor-pointer"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </button>
                            {editable && (
                              <button
                                type="button"
                                onClick={() =>
                                  setSingleDeleteTarget({
                                    kind: row.kind,
                                    id: row.record.id,
                                    label: title
                                  })
                                }
                                title="Move to trash"
                                className="h-8 w-8 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-400/25 text-red-300 inline-flex items-center justify-center cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {pagedResult.totalPages > 1 && (
                    <div className="px-4 py-3 rounded-2xl bg-[#031D1C] border border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs text-[#EDE9E0]/65">
                      <span className="tabular-nums">
                        Page {pagedResult.page} of {pagedResult.totalPages} ({pagedResult.total} total)
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          disabled={pagedResult.page <= 1}
                          onClick={() => setPage(p => Math.max(1, p - 1))}
                          className="h-8 px-3 rounded-lg bg-[#06302F] border border-white/10 hover:border-white/20 text-[#EDE9E0] inline-flex items-center gap-1 cursor-pointer disabled:opacity-40"
                        >
                          <ChevronLeft className="w-3.5 h-3.5" />
                          <span>Prev</span>
                        </button>
                        <button
                          type="button"
                          disabled={pagedResult.page >= pagedResult.totalPages}
                          onClick={() => setPage(p => p + 1)}
                          className="h-8 px-3 rounded-lg bg-[#06302F] border border-white/10 hover:border-white/20 text-[#EDE9E0] inline-flex items-center gap-1 cursor-pointer disabled:opacity-40"
                        >
                          <span>Next</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* Review Queue Drawer (C6) */}
      <ContentReviewDrawer
        isOpen={reviewDrawerOpen}
        onClose={() => setReviewDrawerOpen(false)}
        projects={activeProjects}
        publications={activePubs}
        products={activeProds}
        canPublish={canPublish}
        onOpenEditor={(kind, id) => {
          setReviewDrawerOpen(false);
          if (kind === 'project') {
            const found = activeProjects.find(p => p.id === id);
            if (found) setEditorState({ kind: 'project', item: found });
          } else if (kind === 'publication') {
            const found = activePubs.find(p => p.id === id);
            if (found) setEditorState({ kind: 'publication', item: found });
          } else {
            const found = activeProds.find(p => p.id === id);
            if (found) setEditorState({ kind: 'product', item: found });
          }
        }}
        onReviewed={async () => {
          await onRefreshData?.();
          await loadPagedContent();
        }}
      />

      {/* Department Delete / Reassign Dialog */}
      <PortalConfirmDialog
        isOpen={Boolean(deletingDept)}
        title={`Move "${deletingDept?.name || ''}" to trash?`}
        message="Choose how linked projects, publications, and products should be handled before removing this unit:"
        confirmLabel="Move to trash"
        isDestructive
        loading={deletingDeptBusy}
        confirmDisabled={deptHandling === 'reassign' && !reassignTargetDeptId}
        onCancel={() => setDeletingDept(null)}
        onConfirm={() => void handleConfirmDeleteDepartment()}
      >
        {deletingDept && (
          <div className="space-y-2.5 text-xs">
            <label className="flex items-start gap-2.5 p-3 rounded-xl bg-[#031D1C] border border-white/10 cursor-pointer">
              <input
                type="radio"
                name="deptHandling"
                checked={deptHandling === 'leave'}
                onChange={() => setDeptHandling('leave')}
                className="mt-0.5 accent-[#25CDB6]"
              />
              <span>
                <strong className="block text-[#EDE9E0]">Leave items unlinked</strong>
                <span className="text-[#EDE9E0]/60">
                  Remove only this unit link while keeping linked items intact.
                </span>
              </span>
            </label>

            <label className="flex items-start gap-2.5 p-3 rounded-xl bg-[#031D1C] border border-white/10 cursor-pointer">
              <input
                type="radio"
                name="deptHandling"
                checked={deptHandling === 'reassign'}
                onChange={() => setDeptHandling('reassign')}
                className="mt-0.5 accent-[#25CDB6]"
              />
              <span className="flex-1 space-y-2">
                <strong className="block text-[#EDE9E0]">Reassign to another unit</strong>
                {deptHandling === 'reassign' && (
                  <select
                    value={reassignTargetDeptId}
                    onChange={e => setReassignTargetDeptId(e.target.value)}
                    className="w-full h-9 bg-[#06302F] border border-white/15 rounded-xl px-3 text-xs text-[#EDE9E0]"
                  >
                    <option value="">Select destination...</option>
                    {activeDepts
                      .filter(d => d.id !== deletingDept.id)
                      .map(d => (
                        <option key={d.id} value={d.id}>
                          {d.name}
                        </option>
                      ))}
                  </select>
                )}
              </span>
            </label>
          </div>
        )}
      </PortalConfirmDialog>

      {/* Single Item Delete Dialog */}
      <PortalConfirmDialog
        isOpen={Boolean(singleDeleteTarget)}
        title="Move to trash?"
        message={
          singleDeleteTarget
            ? `Move "${singleDeleteTarget.label}" to Trash? You can restore it anytime from Trash.`
            : ''
        }
        confirmLabel="Move to trash"
        isDestructive
        loading={singleDeleteBusy}
        onCancel={() => setSingleDeleteTarget(null)}
        onConfirm={() => void handleConfirmSingleDelete()}
      />

      {/* Bulk Trash Confirmation Dialog */}
      <PortalConfirmDialog
        isOpen={Boolean(bulkTrashConfirmIds)}
        title="Move selected items to trash?"
        message={
          bulkTrashConfirmIds
            ? `Move ${bulkTrashConfirmIds.length} selected item(s) to Trash? You can restore them anytime from Trash.`
            : ''
        }
        confirmLabel="Move selected to trash"
        isDestructive
        loading={bulkBusy}
        onCancel={() => setBulkTrashConfirmIds(null)}
        onConfirm={() => {
          if (!bulkTrashConfirmIds) return;
          const ids = bulkTrashConfirmIds;
          setBulkTrashConfirmIds(null);
          void runBulkAction(ids, 'trash');
        }}
      />
    </div>
  );
};
