import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { DEFAULT_ROLES } from '../../src/shared/permissions';
import { INITIAL_DEPARTMENTS, INITIAL_SETTINGS, INITIAL_SITE_CONTENT } from '../../src/data/initialData';
import type { DatabaseState, ServerUserRecord } from './schema';
import { CURRENT_SCHEMA_VERSION } from './schema';
import { runMigrations } from './migrations';
import { hashPassword, verifyPassword } from '../utils/crypto';
import {
  deleteCredentialByUserIdFromSqlite,
  getCredentialByUserIdFromSqlite,
  upsertCredentialInSqlite
} from './sqliteAuth';
import {
  createPreMigrationSqliteBackup,
  getSqliteDbPath,
  hasSqliteDatabase,
  ingestLegacyDiskUploadsToSqlite,
  loadDatabaseFromSqlite,
  saveDatabaseToSqlite
} from './sqliteDb';
import { createDefaultWebsiteState } from './websiteDefaults';
import { collectUploadUrlsFromItems, deleteUploadFileIfUnused, purgeOrphanUploadUrls } from '../utils/mediaUsage';

export const DATA_DIR = path.resolve(process.env.MOA_DATA_DIR || 'data');
export const UPLOADS_DIR = path.resolve(process.env.MOA_UPLOADS_DIR || 'public/uploads');
export const TMP_UPLOADS_DIR = path.join(DATA_DIR, 'tmp-uploads');
export const SQLITE_DB_FILE = getSqliteDbPath(DATA_DIR);

const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

export function ensureDirectories(): void {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  if (!fs.existsSync(TMP_UPLOADS_DIR)) fs.mkdirSync(TMP_UPLOADS_DIR, { recursive: true });
}

export function cleanupStaleTempUploads(): void {
  try {
    if (!fs.existsSync(TMP_UPLOADS_DIR)) return;
    for (const entry of fs.readdirSync(TMP_UPLOADS_DIR)) {
      const target = path.join(TMP_UPLOADS_DIR, entry);
      try {
        if (fs.statSync(target).isFile()) {
          fs.unlinkSync(target);
        }
      } catch {
        // Ignore individual temp unlink errors
      }
    }
  } catch {
    // Ignore directory read errors
  }
}

function isStrongPasswordLiteral(pw: string | undefined): pw is string {
  return Boolean(
    pw &&
      pw.length >= 12 &&
      /[A-Z]/.test(pw) &&
      /\d/.test(pw) &&
      /[^A-Za-z0-9]/.test(pw)
  );
}

export function createInitialDatabase(): DatabaseState {
  const adminSalt = crypto.randomBytes(16).toString('hex');
  const envPassword = process.env.INITIAL_ADMIN_PASSWORD?.trim();
  const strongEnvPass = isStrongPasswordLiteral(envPassword);
  const initialPassword = strongEnvPass ? envPassword : 'admin123';

  if (!strongEnvPass) {
    console.warn(
      '⚠️  [MoA SETUP] Fresh database seeded: founder account admin@mastersofall.org created with default password "admin123" (mustChangePassword=true). Sign in and change this default password immediately.'
    );
  } else {
    console.log(
      '[MoA First Run] Founder admin@mastersofall.org seeded with INITIAL_ADMIN_PASSWORD (mustChangePassword=true on first sign-in).'
    );
  }

  const nowIso = new Date().toISOString();
  const founderUser: ServerUserRecord = {
    id: 'usr-admin-muslim',
    email: 'admin@mastersofall.org',
    name: 'Muslim Mehdi',
    role: 'Admin',
    roleId: 'role-admin',
    isFounder: true,
    salt: adminSalt,
    passwordHash: hashPassword(initialPassword, adminSalt),
    mustChangePassword: true,
    twoFactorEnabled: false,
    deactivated: false,
    createdAt: nowIso
  };

  return {
    schemaVersion: CURRENT_SCHEMA_VERSION,
    contentVersion: 1,
    users: [founderUser],
    roles: JSON.parse(JSON.stringify(DEFAULT_ROLES)),
    sessions: [],
    passwordResets: [],
    activityLog: [
      {
        id: 'act-init-1',
        userId: 'system',
        userEmail: 'system@mastersofall.org',
        action: 'System initialized with founder admin account and official departments',
        area: 'System',
        target: 'Control Room',
        timestamp: nowIso
      }
    ],
    securityLog: [],
    departments: INITIAL_DEPARTMENTS.map(d => ({ ...d, createdAt: nowIso })),
    projects: [],
    publications: [],
    products: [],
    media: [
      {
        id: 'med-moa-logo',
        name: 'MoA Official Emblem',
        url: '/drawing1.png',
        mimeType: 'image/png',
        type: 'image',
        size: 191718,
        altText: 'Masters Of All circular crest',
        tags: ['branding', 'official'],
        uploadedAt: nowIso,
        isLocked: true
      },
      {
        id: 'med-rdd-logo',
        name: 'RDD Logo Badge',
        url: '/5320.jpg',
        mimeType: 'image/jpeg',
        type: 'image',
        size: 38455,
        altText: 'Research Discover and Development official insignia',
        tags: ['branding', 'official'],
        uploadedAt: nowIso,
        isLocked: true
      }
    ],
    settings: JSON.parse(JSON.stringify(INITIAL_SETTINGS)),
    pageContent: JSON.parse(JSON.stringify(INITIAL_SITE_CONTENT)),
    contentHistory: [],
    pages: [],
    submissions: [],
    invitations: [],
    website: createDefaultWebsiteState(
      JSON.parse(JSON.stringify(INITIAL_SETTINGS)),
      JSON.parse(JSON.stringify(INITIAL_SITE_CONTENT)),
      nowIso
    )
  };
}

export function reconcileFounderAccount(db: DatabaseState): boolean {
  const isProd = process.env.NODE_ENV === 'production';
  let changed = false;

  // Purge legacy test/temporary accounts completely (including solo@mastersofall.org)
  const testIds = new Set<string>();
  for (const u of db.users) {
    const legacyTestFlag = (u as unknown as { isTestAccount?: boolean }).isTestAccount === true;
    const emailLower = u.email.toLowerCase();
    if (
      u.id === 'usr-test-admin' ||
      u.id === 'usr-test-solo' ||
      emailLower === 'solo@mastersofall.org' ||
      legacyTestFlag
    ) {
      testIds.add(u.id);
    }
  }

  if (testIds.size > 0) {
    db.users = db.users.filter(u => !testIds.has(u.id));
    db.sessions = db.sessions.filter(s => !testIds.has(s.userId));
    db.passwordResets = db.passwordResets.filter(r => !testIds.has(r.userId));
    for (const tid of testIds) {
      try {
        deleteCredentialByUserIdFromSqlite(tid);
      } catch {
        // Ignore if credential table row does not exist
      }
    }
    changed = true;
  }

  // Ensure the Founder Admin account remains present, active, and synced with SQLite credentials
  let founder = db.users.find(
    u => u.id === 'usr-admin-muslim' || u.isFounder || u.email.toLowerCase() === 'admin@mastersofall.org'
  );
  const sqliteFounderCred = getCredentialByUserIdFromSqlite(founder?.id || 'usr-admin-muslim');

  if (!founder) {
    const envPassword = process.env.INITIAL_ADMIN_PASSWORD?.trim();
    const strongEnvPass = isStrongPasswordLiteral(envPassword);
    const initialPassword = strongEnvPass ? envPassword : 'admin123';
    const adminSalt = crypto.randomBytes(16).toString('hex');
    const adminHash = hashPassword(initialPassword, adminSalt);
    if (!sqliteFounderCred && !strongEnvPass) {
      console.warn(
        '⚠️  [MoA SETUP] Founder account admin@mastersofall.org seeded with default password "admin123" (mustChangePassword=true). Sign in and change this default password immediately.'
      );
    }
    founder = {
      id: 'usr-admin-muslim',
      email: sqliteFounderCred?.email || 'admin@mastersofall.org',
      name: 'Muslim Mehdi',
      role: 'Admin',
      roleId: 'role-admin',
      salt: sqliteFounderCred?.salt || adminSalt,
      passwordHash: sqliteFounderCred?.passwordHash || adminHash,
      mustChangePassword: !sqliteFounderCred,
      isFounder: true,
      credentialsCustomized: Boolean(sqliteFounderCred),
      twoFactorEnabled: false,
      deactivated: false,
      createdAt: new Date().toISOString()
    };
    db.users.unshift(founder);
    upsertCredentialInSqlite({
      userId: founder.id,
      email: founder.email,
      passwordHash: founder.passwordHash,
      salt: founder.salt,
      updatedAt: founder.createdAt
    });
    changed = true;
  } else {
    if (!founder.isFounder) {
      founder.isFounder = true;
      changed = true;
    }
    if (founder.role !== 'Admin' || founder.roleId !== 'role-admin') {
      founder.role = 'Admin';
      founder.roleId = 'role-admin';
      changed = true;
    }
    if (founder.deactivated) {
      founder.deactivated = false;
      changed = true;
    }
    if ((founder as unknown as { isTestAccount?: boolean }).isTestAccount !== undefined) {
      delete (founder as unknown as { isTestAccount?: boolean }).isTestAccount;
      changed = true;
    }
    if (sqliteFounderCred) {
      if (
        founder.email !== sqliteFounderCred.email ||
        founder.salt !== sqliteFounderCred.salt ||
        founder.passwordHash !== sqliteFounderCred.passwordHash ||
        !founder.credentialsCustomized
      ) {
        founder.email = sqliteFounderCred.email;
        founder.salt = sqliteFounderCred.salt;
        founder.passwordHash = sqliteFounderCred.passwordHash;
        founder.credentialsCustomized = true;
        changed = true;
      }
    }
  }

  if (founder && !founder.deactivated) {
    const stillDefaultPw = verifyPassword('admin123', founder.salt, founder.passwordHash);
    if (isProd && stillDefaultPw && !founder.mustChangePassword) {
      founder.mustChangePassword = true;
      changed = true;
    }
    if (stillDefaultPw || founder.mustChangePassword || (isProd && !founder.twoFactorEnabled)) {
      const reasons = [
        stillDefaultPw ? 'using default password ("admin123") — sign in and change password immediately' : '',
        founder.mustChangePassword ? 'mustChangePassword pending' : '',
        isProd && !founder.twoFactorEnabled ? '2FA not yet enabled' : ''
      ]
        .filter(Boolean)
        .join('; ');
      console.warn(`⚠️  [MoA SECURITY WARNING] Founder account (${founder.email}): ${reasons}.`);
    }
  }

  return changed;
}

export function purgeExpiredTrashInDb(db: DatabaseState): boolean {
  const cutoff = Date.now() - THIRTY_DAYS_MS;
  const expiredDepts = db.departments.filter(d => d.deletedAt && new Date(d.deletedAt).getTime() <= cutoff);
  const expiredProjs = db.projects.filter(p => p.deletedAt && new Date(p.deletedAt).getTime() <= cutoff);
  const expiredPubs = db.publications.filter(p => p.deletedAt && new Date(p.deletedAt).getTime() <= cutoff);
  const expiredProds = db.products.filter(p => p.deletedAt && new Date(p.deletedAt).getTime() <= cutoff);
  const expiredPages = db.pages.filter(pg => pg.deletedAt && new Date(pg.deletedAt).getTime() <= cutoff);
  const expiredMedia = (db.media || []).filter(m => m.deletedAt && new Date(m.deletedAt).getTime() <= cutoff);
  const expiredSubmissions = (db.submissions || []).filter(s => s.deletedAt && new Date(s.deletedAt).getTime() <= cutoff);

  const totalExpired =
    expiredDepts.length +
    expiredProjs.length +
    expiredPubs.length +
    expiredProds.length +
    expiredPages.length +
    expiredMedia.length +
    expiredSubmissions.length;

  if (totalExpired === 0) return false;

  const candidateUrls = collectUploadUrlsFromItems([
    ...expiredDepts,
    ...expiredProjs,
    ...expiredPubs,
    ...expiredProds,
    ...expiredPages
  ]);

  db.departments = db.departments.filter(d => !(d.deletedAt && new Date(d.deletedAt).getTime() <= cutoff));
  db.projects = db.projects.filter(p => !(p.deletedAt && new Date(p.deletedAt).getTime() <= cutoff));
  db.publications = db.publications.filter(p => !(p.deletedAt && new Date(p.deletedAt).getTime() <= cutoff));
  db.products = db.products.filter(p => !(p.deletedAt && new Date(p.deletedAt).getTime() <= cutoff));
  db.pages = db.pages.filter(pg => !(pg.deletedAt && new Date(pg.deletedAt).getTime() <= cutoff));
  db.media = (db.media || []).filter(m => !(m.deletedAt && new Date(m.deletedAt).getTime() <= cutoff));
  db.submissions = (db.submissions || []).filter(s => !(s.deletedAt && new Date(s.deletedAt).getTime() <= cutoff));

  for (const mediaItem of expiredMedia) {
    deleteUploadFileIfUnused(db, UPLOADS_DIR, mediaItem.url, DATA_DIR);
  }
  purgeOrphanUploadUrls(db, UPLOADS_DIR, candidateUrls, DATA_DIR);
  return true;
}

export function purgeExpiredSessionsInDb(db: DatabaseState): boolean {
  const timeoutMinutes = db.settings?.securityPolicy?.sessionTimeoutMinutes || 120;
  const maxIdleMs = Math.max(5, timeoutMinutes) * 60 * 1000;
  const now = Date.now();
  const beforeSess = db.sessions.length;
  db.sessions = db.sessions.filter(
    s => now - (s.lastActivity || 0) <= maxIdleMs && (!s.expiresAt || s.expiresAt > now)
  );
  const beforeResets = db.passwordResets.length;
  db.passwordResets = db.passwordResets.filter(r => !r.usedAt && new Date(r.expiresAt).getTime() > now);
  return db.sessions.length !== beforeSess || db.passwordResets.length !== beforeResets;
}

class Store {
  private state: DatabaseState;
  private sessionActivityDirty = false;
  private writeQueue: Promise<unknown> = Promise.resolve();

  constructor() {
    this.state = this.initialize();
  }

  private writeToDisk(state: DatabaseState): void {
    ensureDirectories();
    saveDatabaseToSqlite(state, DATA_DIR);
  }

  private initialize(): DatabaseState {
    ensureDirectories();
    cleanupStaleTempUploads();

    if (!hasSqliteDatabase(DATA_DIR)) {
      const fresh = createInitialDatabase();
      reconcileFounderAccount(fresh);
      this.writeToDisk(fresh);
      ingestLegacyDiskUploadsToSqlite(UPLOADS_DIR, DATA_DIR);
      return fresh;
    }

    ingestLegacyDiskUploadsToSqlite(UPLOADS_DIR, DATA_DIR);
    const parsed = loadDatabaseFromSqlite(DATA_DIR) as unknown as Record<string, unknown>;
    const rawVersion = typeof parsed.schemaVersion === 'number' ? parsed.schemaVersion : 0;
    if (rawVersion > 0 && rawVersion < CURRENT_SCHEMA_VERSION) {
      const backupPath = createPreMigrationSqliteBackup(DATA_DIR, rawVersion, CURRENT_SCHEMA_VERSION);
      if (backupPath) {
        console.log(`[MoA DB] Created pre-migration SQLite backup before v${CURRENT_SCHEMA_VERSION} upgrade.`);
      }
    }

    const { db, appliedVersions } = runMigrations(parsed);
    const reconciled = reconcileFounderAccount(db);
    const purgedSess = purgeExpiredSessionsInDb(db);
    const purgedTrash = purgeExpiredTrashInDb(db);

    if (appliedVersions.length > 0) {
      console.log(`[MoA DB] Applied migrations: v${appliedVersions.join(', v')}`);
    }

    if (appliedVersions.length > 0 || reconciled || purgedSess || purgedTrash) {
      this.writeToDisk(db);
    }

    return db;
  }

  public read(): DatabaseState {
    return this.state;
  }

  public reloadFromDisk(): DatabaseState {
    this.sessionActivityDirty = false;
    this.state = this.initialize();
    return this.state;
  }

  public markSessionActivityDirty(): void {
    this.sessionActivityDirty = true;
  }

  public async write<T>(
    mutator: (db: DatabaseState) => T,
    opts?: { bumpContentVersion?: boolean }
  ): Promise<T> {
    const task = this.writeQueue.then(() => {
      const prevStateSnapshot = JSON.stringify(this.state);
      try {
        const out = mutator(this.state);
        if (opts?.bumpContentVersion) {
          this.state.contentVersion = (this.state.contentVersion || 1) + 1;
        }
        this.writeToDisk(this.state);
        this.sessionActivityDirty = false;
        return out;
      } catch (err) {
        this.state = JSON.parse(prevStateSnapshot) as DatabaseState;
        throw err;
      }
    });
    this.writeQueue = task.catch(() => undefined);
    return task;
  }

  public flushPendingNow(): void {
    if (this.sessionActivityDirty) {
      try {
        this.writeToDisk(this.state);
        this.sessionActivityDirty = false;
      } catch (err) {
        console.warn('[MoA DB] Error flushing pending state:', err);
      }
    }
  }
}

export const dbStore = new Store();
