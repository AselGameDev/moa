import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  ArrowRight,
  Edit3,
  ExternalLink,
  LogOut,
  Megaphone,
  Save,
  UploadCloud,
  X
} from 'lucide-react';
import type {
  Department,
  PageRecord,
  Product,
  Project,
  Publication,
  SiteContent,
  SiteSettings,
  User
} from './types';
import { INITIAL_DEPARTMENTS, INITIAL_SETTINGS, INITIAL_SITE_CONTENT } from './data/initialData';
import { useContent } from './hooks/useContent';
import { api } from './services/api';
import { formatSeoTitle } from './shared/pageRegistry';
import { can } from './shared/permissions';
import { sanitizeSafeUrl } from './shared/url';
import { getSectorParentId, isSector } from './utils/orgHelpers';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LoadingScreen } from './components/LoadingScreen';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomeView } from './views/HomeView';
import { AboutView } from './views/AboutView';
import { DepartmentsView } from './views/DepartmentsView';
import { DepartmentDetailView } from './views/DepartmentDetailView';
import { ProjectsView } from './views/ProjectsView';
import { ProjectDetailView } from './views/ProjectDetailView';
import { ProductsView } from './views/ProductsView';
import { ProductDetailView } from './views/ProductDetailView';
import { ContactView } from './views/ContactView';
import { CustomPageView } from './views/CustomPageView';
import { NotFoundView } from './views/NotFoundView';
import { SignInView } from './views/SignInView';
import { AdminPortal } from './views/AdminPortal';

function normalizePathname(raw: string): string {
  const pathOnly = raw.split('?')[0].split('#')[0] || '/';
  if (pathOnly.length > 1 && pathOnly.endsWith('/')) {
    return pathOnly.slice(0, -1);
  }
  return pathOnly;
}

function setNestedValue(source: SiteContent, fieldPath: string, value: unknown): SiteContent {
  const cloned: SiteContent = JSON.parse(JSON.stringify(source));
  const parts = fieldPath.split('.').filter(Boolean);
  if (parts.length === 0) return cloned;
  let curr: Record<string, unknown> = cloned as unknown as Record<string, unknown>;
  for (let i = 0; i < parts.length - 1; i++) {
    const key = parts[i];
    const next = curr[key];
    if (!next || typeof next !== 'object' || Array.isArray(next)) {
      curr[key] = {};
    }
    curr = curr[key] as Record<string, unknown>;
  }
  curr[parts[parts.length - 1]] = value;
  return cloned;
}

function resolveUnitBySegments(
  segments: string[],
  allDepartments: Department[],
  includeUnpublished: boolean
): Department | undefined {
  const visible = allDepartments.filter(d => !d.deletedAt && (includeUnpublished || d.published));
  if (segments.length === 0) return undefined;

  if (segments.length >= 2) {
    const firstSlug = decodeURIComponent(segments[0]).toLowerCase();
    const secondSlug = decodeURIComponent(segments[1]).toLowerCase();
    const parentDept = visible.find(d => !isSector(d) && d.slug.toLowerCase() === firstSlug);
    if (parentDept) {
      const child = visible.find(
        d => isSector(d) && d.slug.toLowerCase() === secondSlug && getSectorParentId(d) === parentDept.id
      );
      if (child) return child;
    }
    return visible.find(d => isSector(d) && d.slug.toLowerCase() === secondSlug);
  }

  const singleSlug = decodeURIComponent(segments[0]).toLowerCase();
  return (
    visible.find(d => !isSector(d) && d.slug.toLowerCase() === singleSlug) ||
    visible.find(d => d.slug.toLowerCase() === singleSlug)
  );
}

export default function App() {
  const [route, setRoute] = useState<string>(() =>
    typeof window !== 'undefined' ? `${window.location.pathname}${window.location.search}` : '/home'
  );
  const [currentUser, setCurrentUser] = useState<User | null>(() => api.getCurrentUser());
  const [authChecked, setAuthChecked] = useState(false);

  const [departments, setDepartments] = useState<Department[]>(INITIAL_DEPARTMENTS);
  const [projects, setProjects] = useState<Project[]>([]);
  const [publications, setPublications] = useState<Publication[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [pages, setPages] = useState<PageRecord[]>([]);
  const [settings, setSettings] = useState<SiteSettings>(INITIAL_SETTINGS);
  const [siteContent, setSiteContent] = useState<SiteContent>(INITIAL_SITE_CONTENT);
  const [loading, setLoading] = useState(true);

  const initialPathname = normalizePathname(route).toLowerCase();
  const [loaderDone, setLoaderDone] = useState(
    initialPathname === '/portal' ||
      initialPathname === '/admin' ||
      initialPathname === '/login'
  );

  const [isEditMode, setIsEditMode] = useState(false);
  const [draftContent, setDraftContent] = useState<Partial<SiteContent> | null>(null);
  const [pendingDeptPatches, setPendingDeptPatches] = useState<Record<string, Partial<Department>>>({});
  const [editorSaving, setEditorSaving] = useState(false);
  const [editorNotice, setEditorNotice] = useState<string | null>(null);
  const [editorError, setEditorError] = useState<string | null>(null);
  const [announcementDismissed, setAnnouncementDismissed] = useState(false);

  const { content: mergedContent } = useContent(
    siteContent,
    isEditMode ? draftContent : null
  );

  const navigate = useCallback((target: string) => {
    if (typeof window === 'undefined') return;
    if (/^https?:\/\//i.test(target)) {
      window.open(target, '_blank', 'noopener,noreferrer');
      return;
    }
    const normalized = target.startsWith('/') ? target : `/${target}`;
    if (`${window.location.pathname}${window.location.search}` !== normalized) {
      window.history.pushState({}, '', normalized);
    }
    setRoute(normalized);
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
  }, []);

  useEffect(() => {
    const onPopState = () => {
      setRoute(`${window.location.pathname}${window.location.search}`);
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const refreshData = useCallback(async (userOverride?: User | null) => {
    try {
      const activeUser = userOverride === undefined ? api.getCurrentUser() : userOverride;
      const [deptsData, projsData, pubsData, prodsData, pagesData, settingsData, pageContentData] =
        await Promise.all([
          activeUser ? api.getAllDepartments().catch(() => api.getDepartments()) : api.getDepartments(),
          activeUser ? api.getProjectsAdmin().catch(() => api.getProjects()) : api.getProjects(),
          activeUser ? api.getPublicationsAdmin().catch(() => api.getPublications()) : api.getPublications(),
          activeUser ? api.getProductsAdmin().catch(() => api.getProducts()) : api.getProducts(),
          api.getPages(),
          api.getSettings(),
          api.getPageContent()
        ]);
      if (Array.isArray(deptsData)) setDepartments(deptsData);
      if (Array.isArray(projsData)) setProjects(projsData);
      if (Array.isArray(pubsData)) setPublications(pubsData);
      if (Array.isArray(prodsData)) setProducts(prodsData);
      if (Array.isArray(pagesData)) setPages(pagesData);
      if (settingsData) setSettings(settingsData);
      if (pageContentData) setSiteContent(pageContentData);
    } catch {
      // Initial fallback stays active
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    api.registerUnauthorizedHandler(() => {
      setCurrentUser(null);
      setIsEditMode(false);
      setDraftContent(null);
      const pathLower = normalizePathname(window.location.pathname).toLowerCase();
      if (pathLower === '/portal' || pathLower === '/admin') {
        navigate('/login?expired=1');
      }
    });
    return () => api.registerUnauthorizedHandler(null);
  }, [navigate]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      let verifiedUser: User | null = null;
      if (api.getToken()) {
        try {
          verifiedUser = (await api.getMe()).user;
        } catch {
          api.clearSession();
          verifiedUser = null;
        }
      }
      if (!cancelled) {
        setCurrentUser(verifiedUser);
        setAuthChecked(true);
        await refreshData(verifiedUser);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [refreshData]);

  useEffect(() => {
    let lastVersion: number | null = null;
    const timer = window.setInterval(async () => {
      if (isEditMode) return;
      try {
        const res = await api.getContentVersion();
        if (lastVersion !== null && res.version !== lastVersion) {
          void refreshData(currentUser);
        }
        lastVersion = res.version;
      } catch {
        // Ignore transient network failures
      }
    }, 30000);
    return () => window.clearInterval(timer);
  }, [currentUser, isEditMode, refreshData]);

  useEffect(() => {
    const pathLower = normalizePathname(route).toLowerCase();
    const siteName = settings.siteName || 'Masters Of All';
    const template = settings.seoDefaults?.titleTemplate || '{page} · {site}';
    const pagesMeta = settings.websitePublic?.pagesMeta || {};
    const formatTitle = (key: string, fallbackPageName: string) =>
      pagesMeta[key]?.seoTitle?.trim() || formatSeoTitle(template, fallbackPageName, siteName);

    if (pathLower === '/portal' || pathLower === '/admin') {
      document.title = currentUser ? `Control Room — ${siteName}` : `Not Found — ${siteName}`;
    } else if (pathLower === '/login') {
      document.title = `Sign In — ${siteName}`;
    } else if (pathLower === '/' || pathLower === '/home') {
      document.title =
        pagesMeta.home?.seoTitle?.trim() ||
        settings.seoDefaults?.title ||
        `${siteName} — ${settings.tagline || 'Believe. Build. Become.'}`;
    } else if (pathLower === '/about') {
      document.title = formatTitle('about', 'About');
    } else if (pathLower === '/departments') {
      document.title = formatTitle('departments', 'Departments');
    } else if (pathLower === '/projects') {
      document.title = formatTitle('projects', 'Projects');
    } else if (pathLower === '/products') {
      document.title = formatTitle('products', 'Products');
    } else if (pathLower === '/contact') {
      document.title = formatTitle('contact', 'Contact');
    } else {
      const slugKey = (pathLower.startsWith('/pages/') ? pathLower.slice(7) : pathLower.slice(1)).replace(
        /^\/+|\/+$/g,
        ''
      );
      const custom = pages.find(
        p => !p.deletedAt && p.slug.replace(/^\/+|\/+$/g, '').toLowerCase() === slugKey
      );
      if (custom) {
        document.title = custom.seo?.title?.trim() || formatSeoTitle(template, custom.title, siteName);
      } else {
        document.title =
          settings.seoDefaults?.title || `${siteName} — ${settings.tagline || 'Believe. Build. Become.'}`;
      }
    }
  }, [route, settings, pages, currentUser]);

  const handleEnterEditMode = useCallback(
    async (targetPath?: string) => {
      if (!currentUser || !can(currentUser, 'website.edit')) return;
      try {
        const res = await api.getDraftContent();
        setDraftContent((res.draft || {}) as Partial<SiteContent>);
        setPendingDeptPatches({});
        setEditorError(null);
        setEditorNotice(null);
        setIsEditMode(true);
        if (targetPath) {
          navigate(targetPath);
        } else {
          const pathLower = normalizePathname(route).toLowerCase();
          if (
            pathLower === '/portal' ||
            pathLower === '/admin' ||
            pathLower === '/login'
          ) {
            navigate('/');
          }
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Unable to enter Live Editor mode.';
        setEditorError(msg);
        throw new Error(msg);
      }
    },
    [currentUser, route, navigate]
  );

  const handleUpdateContent = useCallback(
    (fieldPath: string, value: unknown) => {
      setDraftContent(prev => {
        const base = (prev || siteContent) as SiteContent;
        return setNestedValue(base, fieldPath, value);
      });
      setEditorNotice(null);
    },
    [siteContent]
  );

  const handleUpdateDepartment = useCallback((deptId: string, patch: Partial<Department>) => {
    setDepartments(prev => prev.map(d => (d.id === deptId ? { ...d, ...patch } : d)));
    setPendingDeptPatches(prev => ({
      ...prev,
      [deptId]: { ...(prev[deptId] || {}), ...patch }
    }));
    setEditorNotice(null);
  }, []);

  const handleSaveLiveDraft = useCallback(async () => {
    setEditorSaving(true);
    setEditorError(null);
    try {
      if (draftContent) {
        await api.saveDraftContent(draftContent);
      }
      for (const [id, patch] of Object.entries(pendingDeptPatches)) {
        await api.updateDepartment(id, patch);
      }
      setPendingDeptPatches({});
      setEditorNotice('Draft saved');
    } catch (err) {
      setEditorError(err instanceof Error ? err.message : 'Failed to save draft.');
    } finally {
      setEditorSaving(false);
    }
  }, [draftContent, pendingDeptPatches]);

  const handlePublishLive = useCallback(async () => {
    setEditorSaving(true);
    setEditorError(null);
    try {
      if (draftContent) {
        await api.saveDraftContent(draftContent);
        const published = await api.publishDraftContent();
        setSiteContent(published);
        setDraftContent(null);
      }
      for (const [id, patch] of Object.entries(pendingDeptPatches)) {
        await api.updateDepartment(id, patch);
      }
      setPendingDeptPatches({});
      await refreshData(currentUser);
      setEditorNotice('Published live');
    } catch (err) {
      setEditorError(err instanceof Error ? err.message : 'Failed to publish changes.');
    } finally {
      setEditorSaving(false);
    }
  }, [draftContent, pendingDeptPatches, refreshData, currentUser]);

  const handleExitLiveEditor = useCallback(async () => {
    setIsEditMode(false);
    setDraftContent(null);
    setPendingDeptPatches({});
    setEditorError(null);
    setEditorNotice(null);
    await refreshData(currentUser);
    navigate('/portal');
  }, [refreshData, currentUser, navigate]);

  const handleSignOut = useCallback(async () => {
    await api.signOut();
    setCurrentUser(null);
    setIsEditMode(false);
    setDraftContent(null);
    await refreshData(null);
    navigate('/home');
  }, [refreshData, navigate]);

  const slashTapRef = useRef({ count: 0, lastTime: 0 });
  useEffect(() => {
    const pathLower = normalizePathname(route).toLowerCase();
    const allowShortcut =
      Boolean(currentUser) &&
      pathLower !== '/portal' &&
      pathLower !== '/admin' &&
      pathLower !== '/login';

    if (!allowShortcut) {
      slashTapRef.current = { count: 0, lastTime: 0 };
      return;
    }

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) {
        slashTapRef.current = { count: 0, lastTime: 0 };
        return;
      }
      if (['Shift', 'Control', 'Alt', 'Meta', 'CapsLock'].includes(e.key)) return;
      const target = e.target as HTMLElement | null;
      if (
        (target && (['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) || target.isContentEditable)) ||
        e.key !== '/'
      ) {
        slashTapRef.current = { count: 0, lastTime: 0 };
        return;
      }
      if (e.repeat) return;
      e.preventDefault();
      const now = Date.now();
      const prev = slashTapRef.current;
      const nextCount = now - prev.lastTime <= 900 ? prev.count + 1 : 1;
      if (nextCount >= 3) {
        slashTapRef.current = { count: 0, lastTime: 0 };
        if (isEditMode) {
          void handleExitLiveEditor();
        } else {
          navigate('/portal');
        }
      } else {
        slashTapRef.current = { count: nextCount, lastTime: now };
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [currentUser, route, isEditMode, handleExitLiveEditor, navigate]);

  const cleanPath = normalizePathname(route);
  const pathLower = cleanPath.toLowerCase();
  const searchParams = useMemo(() => {
    const idx = route.indexOf('?');
    return new URLSearchParams(idx >= 0 ? route.slice(idx) : '');
  }, [route]);
  const isPreview = searchParams.get('preview') === '1' && Boolean(currentUser);

  const publishedProducts = useMemo(
    () => products.filter(p => !p.deletedAt && p.publicationStatus === 'Published'),
    [products]
  );
  const showProducts = Boolean(settings.alwaysShowProducts || publishedProducts.length > 0);

  const announcement = settings.announcementBar;
  const nowMs = Date.now();
  const startOk =
    !announcement?.startDate ||
    Number.isNaN(Date.parse(announcement.startDate)) ||
    Date.parse(announcement.startDate) <= nowMs;
  const endStr = announcement?.endDate || announcement?.expiresAt;
  const endOk = !endStr || Number.isNaN(Date.parse(endStr)) || Date.parse(endStr) > nowMs;
  const showAnnouncement = Boolean(
    !announcementDismissed && announcement?.enabled && announcement.text?.trim() && startOk && endOk
  );

  const sectionId = searchParams.get('section');
  useEffect(() => {
    if (!sectionId || loading) return;
    const timer = window.setTimeout(() => {
      document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
    return () => window.clearTimeout(timer);
  }, [sectionId, route, loading]);

  const headerNav = settings.websitePublic?.menus?.header || settings.navigation;
  const footerMenu = settings.websitePublic?.menus?.footer;
  const loaderLogoUrl = settings.websitePublic?.sameLoaderAsPrimary
    ? settings.moaLogoUrl || '/drawing1.png'
    : settings.loaderLogoUrl || settings.moaLogoUrl || '/drawing1.png';

  const isPortalSubpath = pathLower.startsWith('/portal/') || pathLower.startsWith('/admin/');
  if (pathLower === '/portal' || pathLower === '/admin' || isPortalSubpath) {
    if (!authChecked) {
      return <div className="min-h-screen bg-[#06302F]" />;
    }
    if (!currentUser || isPortalSubpath) {
      return (
        <div className="min-h-screen flex flex-col bg-[#06302F] text-[#EDE9E0]">
          <Navbar
            currentPath={cleanPath}
            onNavigate={navigate}
            socialLinks={settings.socialLinks}
            navigation={headerNav}
            showProducts={showProducts}
            logoUrl={settings.moaLogoUrl}
            siteName={settings.siteName}
          />
          <NotFoundView content={mergedContent} onNavigate={navigate} />
          <Footer
            departments={departments}
            onNavigate={navigate}
            socialLinks={settings.socialLinks}
            footerText={settings.footerText}
            footerColumns={settings.footerColumns}
            websiteFooter={footerMenu}
            headerMenu={headerNav}
            showProducts={showProducts}
            contactEmail={settings.contactEmail}
            organizationAddress={settings.organizationAddress}
            logoUrl={settings.moaLogoUrl}
            siteName={settings.siteName}
            tagline={settings.tagline}
            content={mergedContent.footer}
          />
        </div>
      );
    }
    return (
      <ErrorBoundary onResetHome={() => navigate('/')}>
        <AdminPortal
          currentUser={currentUser}
          onUpdateUser={setCurrentUser}
          onLogout={handleSignOut}
          onNavigateSite={path => {
            setIsEditMode(false);
            navigate(path || '/');
          }}
          onEnterEditMode={handleEnterEditMode}
          onRefreshData={() => refreshData(currentUser)}
        />
      </ErrorBoundary>
    );
  }

  if (pathLower === '/login') {
    return (
      <ErrorBoundary onResetHome={() => navigate('/home')}>
        <SignInView
          onSignInSuccess={user => {
            setCurrentUser(user);
            void refreshData(user);
          }}
          onNavigate={navigate}
          logoUrl={settings.moaLogoUrl}
          minPasswordLength={settings.securityPolicy?.minPasswordLength}
        />
      </ErrorBoundary>
    );
  }

  const renderSpinner = () => (
    <div className="flex-1 flex items-center justify-center py-24">
      <div
        className="w-8 h-8 rounded-full border-2 border-[#25CDB6]/25 border-t-[#25CDB6] animate-spin"
        role="status"
        aria-label="Loading page"
      />
    </div>
  );

  return (
    <div className="min-h-screen flex flex-col bg-[#06302F] text-[#EDE9E0]">
      {!loaderDone && <LoadingScreen onComplete={() => setLoaderDone(true)} logoUrl={loaderLogoUrl} />}

      {isEditMode && (
        <div className="sticky top-0 z-[60] bg-[#031D1C] border-b border-[#25CDB6]/40 px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs shadow-lg">
          <div className="flex items-center gap-2 min-w-0">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#17A491]/20 border border-[#25CDB6]/40 text-[#25CDB6] font-bold">
              <Edit3 className="w-3.5 h-3.5" />
              <span>Live Page Editor</span>
            </span>
            {editorNotice && <span className="text-[#25CDB6] font-semibold">{editorNotice}</span>}
            {editorError && <span className="text-red-300 font-semibold">{editorError}</span>}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={editorSaving}
              onClick={() => void handleSaveLiveDraft()}
              className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 font-semibold text-[#EDE9E0] inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{editorSaving ? 'Saving...' : 'Save Draft'}</span>
            </button>
            <button
              type="button"
              disabled={editorSaving}
              onClick={() => void handlePublishLive()}
              className="px-3.5 py-1.5 rounded-xl bg-[#17A491] hover:bg-[#25CDB6] text-[#031D1C] font-bold inline-flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <UploadCloud className="w-3.5 h-3.5" />
              <span>Publish Live</span>
            </button>
            <button
              type="button"
              onClick={() => void handleExitLiveEditor()}
              className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[#EDE9E0]/80 hover:text-white inline-flex items-center gap-1 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Back to Portal</span>
            </button>
          </div>
        </div>
      )}

      <Navbar
        currentPath={cleanPath}
        onNavigate={navigate}
        socialLinks={settings.socialLinks}
        navigation={headerNav}
        showProducts={showProducts}
        logoUrl={settings.moaLogoUrl}
        siteName={settings.siteName}
      />

      <main className="flex-1 flex flex-col">
        <ErrorBoundary onResetHome={() => navigate('/')}>
          {(() => {
            if (pathLower === '/' || pathLower === '/home') {
              return (
                <HomeView
                  content={mergedContent}
                  departments={departments}
                  onNavigate={navigate}
                  isEditMode={isEditMode}
                  onUpdateContent={handleUpdateContent}
                  logoUrl={settings.moaLogoUrl}
                />
              );
            }
            if (pathLower === '/about') {
              return (
                <AboutView
                  content={mergedContent}
                  departments={departments}
                  isEditMode={isEditMode}
                  onUpdateContent={handleUpdateContent}
                />
              );
            }
            if (pathLower === '/departments') {
              return (
                <DepartmentsView
                  departments={departments}
                  projects={projects}
                  publications={publications}
                  products={products}
                  content={mergedContent}
                  onNavigate={navigate}
                  loading={loading}
                  isEditMode={isEditMode}
                  onUpdateContent={handleUpdateContent}
                  onUpdateDepartment={handleUpdateDepartment}
                  moaLogoUrl={settings.moaLogoUrl}
                  rddLogoUrl={settings.rddLogoUrl}
                  siteName={settings.siteName}
                  animateTreeReady={loaderDone}
                />
              );
            }
            if (pathLower.startsWith('/departments/') || pathLower.startsWith('/sectors/')) {
              const segments = (
                pathLower.startsWith('/sectors/') ? cleanPath.slice(9) : cleanPath.slice(13)
              )
                .split('/')
                .filter(Boolean);
              const unit = resolveUnitBySegments(segments, departments, isPreview || isEditMode);
              if (!unit) {
                return loading ? (
                  renderSpinner()
                ) : (
                  <NotFoundView
                    content={mergedContent}
                    onNavigate={navigate}
                    isEditMode={isEditMode}
                    onUpdateContent={handleUpdateContent}
                  />
                );
              }
              const childIds = isSector(unit)
                ? []
                : departments
                    .filter(d => !d.deletedAt && isSector(d) && getSectorParentId(d) === unit.id)
                    .map(d => d.id);
              const scopeIds = new Set([unit.id, ...childIds]);
              const matchesUnit = (deptIds?: string[], sectorIds?: string[]) =>
                Boolean(deptIds?.some(id => scopeIds.has(id)) || sectorIds?.some(id => scopeIds.has(id)));
              const relProjects = projects.filter(
                p => !p.deletedAt && (isPreview || p.publicationStatus === 'Published') && matchesUnit(p.departmentIds, p.sectorIds)
              );
              const relPublications = publications.filter(
                p => !p.deletedAt && (isPreview || p.publicationStatus === 'Published') && matchesUnit(p.departmentIds, p.sectorIds)
              );
              const relProducts = products.filter(
                p => !p.deletedAt && (isPreview || p.publicationStatus === 'Published') && matchesUnit(p.departmentIds, p.sectorIds)
              );
              return (
                <DepartmentDetailView
                  department={unit}
                  allDepartments={departments}
                  relatedProjects={relProjects}
                  relatedPublications={relPublications}
                  relatedProducts={relProducts}
                  content={mergedContent}
                  isEditMode={isEditMode}
                  onUpdateContent={handleUpdateContent}
                  onUpdateDepartment={handleUpdateDepartment}
                  rddLogoUrl={settings.rddLogoUrl}
                  onNavigate={navigate}
                />
              );
            }
            if (pathLower === '/projects') {
              const pubProjects = projects.filter(p => !p.deletedAt && p.publicationStatus === 'Published');
              const pubPublications = publications.filter(p => !p.deletedAt && p.publicationStatus === 'Published');
              return (
                <ProjectsView
                  projects={pubProjects}
                  publications={pubPublications}
                  departments={departments}
                  content={mergedContent}
                  loading={loading}
                  onNavigate={navigate}
                  isEditMode={isEditMode}
                  onUpdateContent={handleUpdateContent}
                />
              );
            }
            if (pathLower.startsWith('/projects/')) {
              const slug = decodeURIComponent(cleanPath.slice(10)).toLowerCase();
              const proj = projects.find(
                p => !p.deletedAt && p.slug.toLowerCase() === slug && (isPreview || p.publicationStatus === 'Published')
              );
              if (!proj) {
                return loading ? (
                  renderSpinner()
                ) : (
                  <NotFoundView
                    content={mergedContent}
                    onNavigate={navigate}
                    isEditMode={isEditMode}
                    onUpdateContent={handleUpdateContent}
                  />
                );
              }
              const related = projects.filter(
                p =>
                  p.id !== proj.id &&
                  !p.deletedAt &&
                  p.publicationStatus === 'Published' &&
                  p.departmentIds?.some(id => proj.departmentIds?.includes(id))
              );
              return (
                <ProjectDetailView
                  project={proj}
                  departments={departments}
                  relatedProjects={related}
                  content={mergedContent}
                  isEditMode={isEditMode}
                  onUpdateContent={handleUpdateContent}
                  onNavigate={navigate}
                />
              );
            }
            if (pathLower === '/products') {
              if (!showProducts && !isPreview) {
                return loading ? (
                  renderSpinner()
                ) : (
                  <NotFoundView
                    content={mergedContent}
                    onNavigate={navigate}
                    isEditMode={isEditMode}
                    onUpdateContent={handleUpdateContent}
                  />
                );
              }
              return (
                <ProductsView
                  products={publishedProducts}
                  departments={departments}
                  content={mergedContent}
                  loading={loading}
                  onNavigate={navigate}
                  isEditMode={isEditMode}
                  onUpdateContent={handleUpdateContent}
                />
              );
            }
            if (pathLower.startsWith('/products/')) {
              const slug = decodeURIComponent(cleanPath.slice(10)).toLowerCase();
              const prod = products.find(
                p => !p.deletedAt && p.slug.toLowerCase() === slug && (isPreview || p.publicationStatus === 'Published')
              );
              if (!prod || (!showProducts && !isPreview)) {
                return loading ? (
                  renderSpinner()
                ) : (
                  <NotFoundView
                    content={mergedContent}
                    onNavigate={navigate}
                    isEditMode={isEditMode}
                    onUpdateContent={handleUpdateContent}
                  />
                );
              }
              return (
                <ProductDetailView
                  product={prod}
                  departments={departments}
                  projects={projects}
                  content={mergedContent}
                  isEditMode={isEditMode}
                  onUpdateContent={handleUpdateContent}
                  onNavigate={navigate}
                />
              );
            }
            if (pathLower === '/contact') {
              return (
                <ContactView
                  content={mergedContent}
                  isEditMode={isEditMode}
                  onUpdateContent={handleUpdateContent}
                  socialLinks={settings.socialLinks}
                  contactEmail={settings.contactEmail}
                  organizationAddress={settings.organizationAddress}
                  initialTopic={searchParams.get('topic') || undefined}
                />
              );
            }

            const customSlug = (
              pathLower.startsWith('/pages/') ? decodeURIComponent(cleanPath.slice(7)) : decodeURIComponent(cleanPath.slice(1))
            )
              .replace(/^\/+|\/+$/g, '')
              .toLowerCase();
            const customPage = pages.find(
              p => !p.deletedAt && p.slug.replace(/^\/+|\/+$/g, '').toLowerCase() === customSlug && (isPreview || p.status === 'Published')
            );
            if (customPage) {
              return (
                <CustomPageView
                  page={customPage}
                  departments={departments}
                  onNavigate={navigate}
                  moaLogoUrl={settings.moaLogoUrl}
                  rddLogoUrl={settings.rddLogoUrl}
                  siteName={settings.siteName}
                />
              );
            }

            const matchedRedirect = (settings.redirects || []).find(
              r => (r.from.replace(/\/+$/, '').toLowerCase() || '/') === pathLower
            );
            const safeRedirectTarget = matchedRedirect ? sanitizeSafeUrl(matchedRedirect.to) : '';
            if (safeRedirectTarget) {
              if (/^https?:\/\//i.test(safeRedirectTarget)) {
                window.location.replace(safeRedirectTarget);
                return renderSpinner();
              }
              const nextInternal = safeRedirectTarget.startsWith('/') ? safeRedirectTarget : `/${safeRedirectTarget}`;
              window.history.replaceState({}, '', nextInternal);
              setRoute(nextInternal);
              return renderSpinner();
            }

            return loading ? (
              renderSpinner()
            ) : (
              <NotFoundView
                content={mergedContent}
                onNavigate={navigate}
                isEditMode={isEditMode}
                onUpdateContent={handleUpdateContent}
              />
            );
          })()}
        </ErrorBoundary>
      </main>

      <Footer
        departments={departments}
        onNavigate={navigate}
        socialLinks={settings.socialLinks}
        footerText={settings.footerText}
        footerColumns={settings.footerColumns}
        websiteFooter={footerMenu}
        headerMenu={headerNav}
        showProducts={showProducts}
        contactEmail={settings.contactEmail}
        organizationAddress={settings.organizationAddress}
        logoUrl={settings.moaLogoUrl}
        siteName={settings.siteName}
        tagline={settings.tagline}
        content={mergedContent.footer}
      />

      <AnimatePresence>
        {showAnnouncement && announcement && (
          <motion.aside
            key="floating-announcement-widget"
            role="region"
            aria-label="Site announcement"
            initial={{ opacity: 0, y: 20, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.96 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className="fixed bottom-4 left-4 right-4 sm:left-auto sm:bottom-6 sm:right-6 sm:w-full sm:max-w-sm z-[55] rounded-2xl bg-[#031D1C]/95 backdrop-blur-md border border-[#25CDB6]/35 shadow-2xl shadow-black/55 p-4 text-[#EDE9E0]"
          >
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#17A491]/15 border border-[#25CDB6]/30 text-[#25CDB6] flex items-center justify-center shrink-0 mt-0.5">
                <Megaphone className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0 pr-1">
                <p className="text-xs sm:text-sm text-[#EDE9E0]/95 leading-snug font-medium">{announcement.text}</p>
                {announcement.linkUrl && sanitizeSafeUrl(announcement.linkUrl) && (
                  /^https?:\/\//i.test(announcement.linkUrl) ? (
                    <a
                      href={sanitizeSafeUrl(announcement.linkUrl)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 mt-2 text-xs font-bold text-[#25CDB6] hover:text-white transition-colors"
                    >
                      <span>{announcement.linkLabel || 'Learn more'}</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  ) : (
                    <button
                      type="button"
                      onClick={() => navigate(announcement.linkUrl!)}
                      className="inline-flex items-center gap-1.5 mt-2 text-xs font-bold text-[#25CDB6] hover:text-white transition-colors cursor-pointer"
                    >
                      <span>{announcement.linkLabel || 'Learn more'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )
                )}
              </div>
              <button
                type="button"
                onClick={() => setAnnouncementDismissed(true)}
                aria-label="Dismiss announcement"
                className="w-8 h-8 -mt-1 -mr-1 rounded-lg flex items-center justify-center text-[#EDE9E0]/60 hover:text-white hover:bg-white/10 transition-colors shrink-0 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>
    </div>
  );
}
