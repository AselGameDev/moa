import React, { useEffect, useRef, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';

interface WordByWordTextProps {
  text: string;
  prefix?: string;
  suffix?: string;
  staggerSeconds?: number;
  durationSeconds?: number;
  initialDelaySeconds?: number;
  yOffset?: number;
  className?: string;
}

export const WordByWordText: React.FC<WordByWordTextProps> = ({
  text,
  prefix = '',
  suffix = '',
  staggerSeconds = 0.045,
  durationSeconds = 0.48,
  initialDelaySeconds = 0,
  yOffset = 14,
  className = ''
}) => {
  const prefersReducedMotion = useReducedMotion();
  const containerRef = useRef<HTMLSpanElement>(null);
  const normalized = (text || '').trim();
  const words = normalized ? normalized.split(/\s+/) : [];
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(false);
  }, [normalized]);

  useEffect(() => {
    if (prefersReducedMotion || words.length === 0 || isVisible) return;
    const el = containerRef.current;
    if (!el || typeof window === 'undefined') return;

    const checkPosition = () => {
      const rect = el.getBoundingClientRect();
      const vh = window.innerHeight || document.documentElement.clientHeight || 800;
      if (rect.height === 0 && rect.width === 0) return false;
      // Reveal when the text enters the lower 92% of the viewport, or if already scrolled past above.
      if (rect.top <= vh * 0.92) {
        setIsVisible(true);
        return true;
      }
      return false;
    };

    if (checkPosition()) return;

    let observer: IntersectionObserver | null = null;
    if (typeof IntersectionObserver !== 'undefined') {
      observer = new IntersectionObserver(
        entries => {
          for (const entry of entries) {
            if (entry.isIntersecting || entry.boundingClientRect.top <= (window.innerHeight || 800) * 0.92) {
              setIsVisible(true);
              observer?.disconnect();
              break;
            }
          }
        },
        { threshold: [0, 0.05, 0.15] }
      );
      observer.observe(el);
    }

    const onScrollOrResize = () => {
      if (checkPosition()) {
        observer?.disconnect();
        window.removeEventListener('scroll', onScrollOrResize);
        window.removeEventListener('resize', onScrollOrResize);
      }
    };

    window.addEventListener('scroll', onScrollOrResize, { passive: true });
    window.addEventListener('resize', onScrollOrResize, { passive: true });

    return () => {
      observer?.disconnect();
      window.removeEventListener('scroll', onScrollOrResize);
      window.removeEventListener('resize', onScrollOrResize);
    };
  }, [prefersReducedMotion, words.length, isVisible, normalized]);

  if (prefersReducedMotion || words.length === 0) {
    return (
      <span className={className}>
        {prefix}
        {normalized}
        {suffix}
      </span>
    );
  }

  const ease = [0.16, 1, 0.3, 1] as const;
  let slotIndex = 0;

  return (
    <span
      key={normalized}
      ref={containerRef}
      aria-label={`${prefix}${normalized}${suffix}`}
      className={`inline-block ${className}`.trim()}
    >
      {prefix && (
        <motion.span
          aria-hidden="true"
          initial={{ opacity: 0, y: yOffset }}
          animate={isVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: yOffset }}
          transition={{
            duration: durationSeconds,
            delay: initialDelaySeconds + slotIndex++ * staggerSeconds,
            ease
          }}
          className="inline-block mr-0.5"
        >
          {prefix}
        </motion.span>
      )}
      {words.map((word, index) => {
        const delay = initialDelaySeconds + slotIndex++ * staggerSeconds;
        return (
          <React.Fragment key={`${word}-${index}`}>
            <motion.span
              aria-hidden="true"
              initial={{ opacity: 0, y: yOffset }}
              animate={isVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: yOffset }}
              transition={{
                duration: durationSeconds,
                delay,
                ease
              }}
              className="inline-block"
            >
              {word}
            </motion.span>
            {index < words.length - 1 ? ' ' : ''}
          </React.Fragment>
        );
      })}
      {suffix && (
        <motion.span
          aria-hidden="true"
          initial={{ opacity: 0, y: yOffset }}
          animate={isVisible ? { opacity: 1, y: 0 } : { opacity: 0, y: yOffset }}
          transition={{
            duration: durationSeconds,
            delay: initialDelaySeconds + slotIndex++ * staggerSeconds,
            ease
          }}
          className="inline-block ml-0.5"
        >
          {suffix}
        </motion.span>
      )}
    </span>
  );
};
