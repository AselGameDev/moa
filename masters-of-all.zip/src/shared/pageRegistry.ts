import type { SiteContent } from '../types';

export type RegistryPageKind = 'core' | 'system' | 'custom';

export interface PageSectionMeta {
  id: string;
  name: string;
  type: string;
  anchorId: string;
}

export interface PageTextFieldDef {
  /** Dot-path relative to SiteContent (e.g. 'departments.heading' or 'detailFallback.departmentEmpty') */
  path: string;
  label: string;
  multiline?: boolean;
  placeholder?: string;
}

export interface CorePageDefinition {
  id: 'home' | 'about' | 'departments' | 'projects' | 'products' | 'contact' | 'notFound';
  name: string;
  path: string;
  kind: 'core' | 'system';
  description: string;
  contentSectionKey: keyof SiteContent;
  sections: PageSectionMeta[];
  textFields: PageTextFieldDef[];
}

export const CORE_AND_SYSTEM_PAGES: CorePageDefinition[] = [
  {
    id: 'home',
    name: 'Home',
    path: '/',
    kind: 'core',
    description: 'Landing showcase featuring hero manifesto, 3-pillar methodology, philosophy cards, and departmental orbit.',
    contentSectionKey: 'home',
    sections: [
      { id: 'sec-hero', name: 'Hero Headline & Orbit Visual', type: 'Hero', anchorId: 'section-home-hero' },
      { id: 'sec-methodology', name: 'Explore / Create / Transform Methodology', type: 'Interactive', anchorId: 'section-home-methodology' },
      { id: 'sec-pillars', name: 'Believe · Build · Become Manifesto', type: 'Pillars', anchorId: 'section-home-pillars' },
      { id: 'sec-depts', name: 'Departmental Orbit & Closing Statement', type: 'Statement', anchorId: 'section-home-depts' }
    ],
    textFields: [
      { path: 'home.heroHeadlineLine1', label: 'Hero Headline Line 1' },
      { path: 'home.heroHeadlineLine2', label: 'Hero Headline Line 2' },
      { path: 'home.heroSubheadline', label: 'Hero Subheadline', multiline: true },
      { path: 'home.primaryCtaLabel', label: 'Primary CTA Button' },
      { path: 'home.secondaryCtaLabel', label: 'Secondary CTA Button' },
      { path: 'home.methodologyEyebrow', label: 'Methodology Eyebrow' },
      { path: 'home.methodologyHeading', label: 'Methodology Heading' },
      { path: 'home.methodologySubheading', label: 'Methodology Subheading' },
      { path: 'home.exploreTitle', label: 'Explore Pillar Title' },
      { path: 'home.exploreText', label: 'Explore Pillar Lead', multiline: true },
      { path: 'home.exploreSubtext', label: 'Explore Pillar Subtext', multiline: true },
      { path: 'home.createTitle', label: 'Create Pillar Title' },
      { path: 'home.createText', label: 'Create Pillar Lead', multiline: true },
      { path: 'home.createSubtext', label: 'Create Pillar Subtext', multiline: true },
      { path: 'home.transformTitle', label: 'Transform Pillar Title' },
      { path: 'home.transformText', label: 'Transform Pillar Lead', multiline: true },
      { path: 'home.transformSubtext', label: 'Transform Pillar Subtext', multiline: true },
      { path: 'home.believeWord', label: 'Manifesto I Word' },
      { path: 'home.believeText', label: 'Manifesto I Copy', multiline: true },
      { path: 'home.buildWord', label: 'Manifesto II Word' },
      { path: 'home.buildText', label: 'Manifesto II Copy', multiline: true },
      { path: 'home.becomeWord', label: 'Manifesto III Word' },
      { path: 'home.becomeText', label: 'Manifesto III Copy', multiline: true },
      { path: 'home.questionStatement', label: 'Closing Question Statement' },
      { path: 'home.readStoryLabel', label: 'Story Button Label' },
      { path: 'home.bottomTaglineSubtext', label: 'Bottom Tagline Subtext', multiline: true }
    ]
  },
  {
    id: 'about',
    name: 'About',
    path: '/about',
    kind: 'core',
    description: 'Organization story, four pillars of action, six-step inquiry continuum, philosophy, and founder statement.',
    contentSectionKey: 'about',
    sections: [
      { id: 'sec-origin', name: 'About Hero & Who We Are', type: 'Hero', anchorId: 'section-about-origin' },
      { id: 'sec-what', name: 'What We Do Action Cards', type: 'Cards', anchorId: 'section-about-what' },
      { id: 'sec-think', name: 'How We Think Continuum', type: 'Steps', anchorId: 'section-about-think' },
      { id: 'sec-founder', name: 'Philosophy Pillars & Founder Statement', type: 'Quote', anchorId: 'section-about-founder' }
    ],
    textFields: [
      { path: 'about.heroTitle', label: 'Hero Title' },
      { path: 'about.heroSub', label: 'Hero Subtitle', multiline: true },
      { path: 'about.whoWeAreBadge', label: 'Origin Section Eyebrow' },
      { path: 'about.whoWeAreHeading', label: 'Origin Section Heading' },
      { path: 'about.whoWeAre', label: 'Who We Are Lead', multiline: true },
      { path: 'about.whoWeAreSecondary', label: 'Who We Are Secondary Paragraph', multiline: true },
      { path: 'about.whatWeDoBadge', label: 'What We Do Eyebrow' },
      { path: 'about.whatWeDoHeading', label: 'What We Do Heading' },
      { path: 'about.whatWeDo', label: 'What We Do Overview', multiline: true },
      { path: 'about.deliverablesHeading', label: 'Deliverables Heading' },
      { path: 'about.howWeThinkBadge', label: 'How We Think Eyebrow' },
      { path: 'about.howWeThinkHeading', label: 'How We Think Heading' },
      { path: 'about.howWeThink', label: 'How We Think Copy', multiline: true },
      { path: 'about.ourPhilosophyBadge', label: 'Philosophy Eyebrow' },
      { path: 'about.ourPhilosophyHeading', label: 'Philosophy Heading' },
      { path: 'about.ourPhilosophy', label: 'Philosophy Body', multiline: true },
      { path: 'about.philosophyEthosTag', label: 'Philosophy Ethos Tag' },
      { path: 'about.founderStatement', label: 'Founder Statement Quote', multiline: true },
      { path: 'about.founderAttribution', label: 'Founder Attribution' },
      { path: 'about.endingLineTemplate', label: 'Signature / Ending Line' }
    ]
  },
  {
    id: 'departments',
    name: 'Departments',
    path: '/departments',
    kind: 'core',
    description: 'Interactive Masters Of All organization tree and published departments & RDD sector directory.',
    contentSectionKey: 'departments',
    sections: [
      { id: 'sec-rdd', name: 'Departments Overview Header', type: 'Header', anchorId: 'section-departments-header' },
      { id: 'sec-tree', name: 'Interactive Organization Tree', type: 'Diagram', anchorId: 'section-departments-tree' },
      { id: 'sec-dir', name: 'Published Departments Directory', type: 'Directory', anchorId: 'section-departments-dir' }
    ],
    textFields: [
      { path: 'departments.heading', label: 'Page Heading' },
      { path: 'departments.rddIntro', label: 'Intro Subheading', multiline: true },
      { path: 'departments.directoryEyebrow', label: 'Directory Eyebrow' },
      { path: 'departments.directoryTitleTemplate', label: 'Directory Heading' },
      { path: 'departments.directorySubtitle', label: 'Directory Subtitle', multiline: true },
      { path: 'departments.exploreButtonLabel', label: 'Open Department Button Label' },
      { path: 'departments.flagshipLabel', label: 'Flagship Department Badge' },
      { path: 'departments.viewSectorsLabel', label: 'View Sectors Button Label' },
      { path: 'departments.hideSectorsLabel', label: 'Hide Sectors Button Label' },
      { path: 'departments.emptyTitle', label: 'Empty State Title' },
      { path: 'departments.emptyDescription', label: 'Empty State Description', multiline: true },
      { path: 'detailFallback.departmentEmpty', label: 'Department Detail Empty Note', multiline: true },
      { path: 'detailFallback.sectorEmpty', label: 'Sector Detail Empty Note', multiline: true },
      { path: 'detailFallback.backToDepartmentsLabel', label: 'Back to Departments Label' },
      { path: 'detailFallback.moreDetailsComingSoon', label: 'Detail Fallback Copy' }
    ]
  },
  {
    id: 'projects',
    name: 'Projects',
    path: '/projects',
    kind: 'core',
    description: 'Searchable catalog of published projects and research publications filterable by department and sector.',
    contentSectionKey: 'work',
    sections: [
      { id: 'sec-work-header', name: 'Projects Header & Filters', type: 'Header', anchorId: 'section-projects-header' },
      { id: 'sec-work-catalog', name: 'Projects & Publications Catalog', type: 'Catalog', anchorId: 'section-projects-catalog' }
    ],
    textFields: [
      { path: 'work.heading', label: 'Page Heading' },
      { path: 'work.subtitle', label: 'Subtitle', multiline: true },
      { path: 'work.allTabLabel', label: 'All Filter Tab Label' },
      { path: 'work.projectsTabLabel', label: 'Projects Tab Label' },
      { path: 'work.publicationsTabLabel', label: 'Publications Tab Label' },
      { path: 'work.searchPlaceholder', label: 'Search Placeholder' },
      { path: 'work.allDepartmentsOption', label: 'All Departments Filter Label' },
      { path: 'work.allSectorsOption', label: 'All Sectors Filter Label' },
      { path: 'work.allStatusesOption', label: 'All Statuses Filter Label' },
      { path: 'work.clearFiltersLabel', label: 'Clear Filters Button Label' },
      { path: 'work.emptyTitle', label: 'Empty Catalog Title' },
      { path: 'work.emptySubtitle', label: 'Empty Catalog Description', multiline: true },
      { path: 'work.noMatchesTitle', label: 'No Matches Title' },
      { path: 'work.noMatchesDescription', label: 'No Matches Description', multiline: true },
      { path: 'detailFallback.backToProjectsLabel', label: 'Back to Projects Link Label' }
    ]
  },
  {
    id: 'products',
    name: 'Products',
    path: '/products',
    kind: 'core',
    description: 'Applied tools, software releases, and custom build inquiry panel (auto-visible when products are published).',
    contentSectionKey: 'products',
    sections: [
      { id: 'sec-products-header', name: 'Products Header & Filters', type: 'Header', anchorId: 'section-products-header' },
      { id: 'sec-products-grid', name: 'Products Showcase Grid', type: 'Catalog', anchorId: 'section-products-grid' },
      { id: 'sec-products-custom', name: 'Custom Product Request CTA', type: 'CTA', anchorId: 'section-products-custom' }
    ],
    textFields: [
      { path: 'products.heading', label: 'Page Heading' },
      { path: 'products.subtext', label: 'Subtitle', multiline: true },
      { path: 'products.searchPlaceholder', label: 'Search Placeholder' },
      { path: 'products.allDepartmentsOption', label: 'All Departments Filter Label' },
      { path: 'products.allSectorsOption', label: 'All Sectors Filter Label' },
      { path: 'products.allStatusesOption', label: 'All Statuses Filter Label' },
      { path: 'products.clearFiltersLabel', label: 'Clear Filters Button Label' },
      { path: 'products.emptyTitle', label: 'Empty Products Title' },
      { path: 'products.emptySubtitle', label: 'Empty Products Description', multiline: true },
      { path: 'products.noMatchesTitle', label: 'No Matches Title' },
      { path: 'products.noMatchesDescription', label: 'No Matches Description', multiline: true },
      { path: 'products.customEyebrow', label: 'Custom Inquiry Eyebrow' },
      { path: 'products.customHeading', label: 'Custom Inquiry Heading' },
      { path: 'products.customDescription', label: 'Custom Inquiry Description', multiline: true },
      { path: 'products.customCtaLabel', label: 'Custom Inquiry Button Label' },
      { path: 'detailFallback.backToProductsLabel', label: 'Back to Products Link Label' }
    ]
  },
  {
    id: 'contact',
    name: 'Contact',
    path: '/contact',
    kind: 'core',
    description: 'Direct email coordinates, interactive inquiry form, and official Masters Of All social channels.',
    contentSectionKey: 'contact',
    sections: [
      { id: 'sec-contact-intro', name: 'Direct Contact & Inquiry Form', type: 'Form', anchorId: 'section-contact-intro' },
      { id: 'sec-contact-channels', name: 'Official Social Channels', type: 'Channels', anchorId: 'section-contact-channels' }
    ],
    textFields: [
      { path: 'contact.heading', label: 'Page Heading' },
      { path: 'contact.subtext', label: 'Subtitle', multiline: true },
      { path: 'contact.directEyebrow', label: 'Direct Channel Eyebrow' },
      { path: 'contact.directHeading', label: 'Direct Channel Heading' },
      { path: 'contact.directDescription', label: 'Direct Channel Description', multiline: true },
      { path: 'contact.emailBoxLabel', label: 'Email Card Label' },
      { path: 'contact.sendEmailLabel', label: 'Send Email Link Label' },
      { path: 'contact.copyEmailLabel', label: 'Copy Email Button Label' },
      { path: 'contact.copiedEmailLabel', label: 'Copied State Label' },
      { path: 'contact.formHeading', label: 'Message Form Heading' },
      { path: 'contact.formNamePlaceholder', label: 'Name Input Placeholder' },
      { path: 'contact.formEmailPlaceholder', label: 'Email Input Placeholder' },
      { path: 'contact.formSubjectPlaceholder', label: 'Subject Input Placeholder' },
      { path: 'contact.formMessagePlaceholder', label: 'Message Input Placeholder' },
      { path: 'contact.formSubmitLabel', label: 'Form Submit Button Label' },
      { path: 'contact.formSuccessMessage', label: 'Form Success Confirmation', multiline: true },
      { path: 'contact.responseNote', label: 'Response Note' },
      { path: 'contact.channelsEyebrow', label: 'Channels Eyebrow' },
      { path: 'contact.channelsHeading', label: 'Channels Heading' },
      { path: 'contact.channelsDescription', label: 'Channels Description', multiline: true },
      { path: 'contact.channelsVisitLabel', label: 'Channel Visit Button Label' },
      { path: 'contact.channelsFooterNote', label: 'Channels Footer Note', multiline: true }
    ]
  },
  {
    id: 'notFound',
    name: '404 Not Found',
    path: '/not-found',
    kind: 'system',
    description: 'Fallback error page rendered for unknown URLs or unpublished restricted resources.',
    contentSectionKey: 'notFound',
    sections: [
      { id: 'sec-404', name: '404 Not Found Display', type: 'System', anchorId: 'section-404' }
    ],
    textFields: [
      { path: 'notFound.badge', label: 'Error Code Badge' },
      { path: 'notFound.heading', label: 'Heading' },
      { path: 'notFound.message', label: 'Message', multiline: true },
      { path: 'notFound.homeButtonLabel', label: 'Primary Return Home Label' },
      { path: 'notFound.exploreDepartmentsLabel', label: 'Secondary Explore Departments Label' }
    ]
  }
];

export const CORE_PAGE_IDS = new Set<string>(CORE_AND_SYSTEM_PAGES.map(p => p.id));

export function getCorePageDefinition(id: string): CorePageDefinition | undefined {
  return CORE_AND_SYSTEM_PAGES.find(p => p.id === id);
}

export function resolveRegistryIdForContentSection(sectionKey: string): string {
  if (sectionKey === 'work') return 'projects';
  if (sectionKey === 'detailFallback') return 'departments';
  return CORE_PAGE_IDS.has(sectionKey) ? sectionKey : 'home';
}

export function validateSeoTitleTemplate(template: unknown): string | null {
  if (typeof template !== 'string' || !template.trim()) {
    return 'Title template is required and must contain {page}.';
  }
  if (!template.includes('{page}')) {
    return 'Title template must include the {page} placeholder.';
  }
  return null;
}

export function formatSeoTitle(
  template: string | undefined,
  pageTitle: string,
  siteName: string
): string {
  const tpl = template && template.includes('{page}') ? template : '{page} · {site}';
  const safePage = (pageTitle || siteName || 'Masters Of All').trim();
  const safeSite = (siteName || 'Masters Of All').trim();
  return tpl
    .replace(/\{page\}/g, safePage)
    .replace(/\{site\}/g, safeSite)
    .replace(/\s+/g, ' ')
    .trim();
}

export function readContentPath(content: SiteContent, dotPath: string): string {
  const [section, key] = dotPath.split('.');
  if (!section || !key) return '';
  const secObj = (content as unknown as Record<string, Record<string, unknown>>)[section];
  if (!secObj || typeof secObj !== 'object') return '';
  const val = secObj[key];
  return typeof val === 'string' ? val : '';
}

export function extractPageTextValues(content: SiteContent, pageId: string): Record<string, string> {
  const def = getCorePageDefinition(pageId);
  if (!def) return {};
  const result: Record<string, string> = {};
  for (const field of def.textFields) {
    result[field.path] = readContentPath(content, field.path);
  }
  return result;
}

export function applyPageTextValues(
  content: SiteContent,
  pageId: string,
  values: Record<string, unknown>
): SiteContent {
  const def = getCorePageDefinition(pageId);
  if (!def || !values || typeof values !== 'object') return content;
  const allowedPaths = new Set(def.textFields.map(f => f.path));
  const clone = JSON.parse(JSON.stringify(content)) as unknown as Record<string, Record<string, unknown>>;

  for (const [dotPath, rawVal] of Object.entries(values)) {
    if (!allowedPaths.has(dotPath) || typeof rawVal !== 'string') continue;
    const [section, key] = dotPath.split('.');
    if (!section || !key) continue;
    if (!clone[section] || typeof clone[section] !== 'object') {
      clone[section] = {};
    }
    clone[section][key] = rawVal;
  }

  return clone as unknown as SiteContent;
}

export function extractPageDraftSlice(
  content: SiteContent,
  draftContent: Partial<SiteContent> | undefined,
  pageId: string
): Record<string, string> {
  if (!draftContent) return {};
  const def = getCorePageDefinition(pageId);
  if (!def) return {};
  const changed: Record<string, string> = {};
  for (const field of def.textFields) {
    const [section, key] = field.path.split('.');
    const draftSec = (draftContent as unknown as Record<string, Record<string, unknown> | undefined>)[section];
    if (draftSec && typeof draftSec[key] === 'string') {
      const liveVal = readContentPath(content, field.path);
      if (draftSec[key] !== liveVal) {
        changed[field.path] = draftSec[key] as string;
      }
    }
  }
  return changed;
}
